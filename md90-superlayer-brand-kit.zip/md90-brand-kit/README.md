# MD90 Superlayer — Brand Kit

Swiss editorial trading terminal identity.

## Palette
- Ink field:     #080b0a
- Bone serif:    #e9e7df
- Teal signal:   #2EB8B0 / #38c9c2
- Vermillion:    #D96A5E / #e06b5c

## Files
- og.jpg          1200×630  Open Graph / share card
- x-banner.jpg    1200×264  X (Twitter) banner
- favicon.svg     vector candlestick mark
- favicon-32.png  32×32 raster favicon

## Rules
- No purple, neon, cyberpunk, or emoji
- Title lockup: MD90 over SUPERLAYER
- Thin teal lines = candlestick wick language
- Generous margins, editorial restraint

Generated for MD90 Atelier / Paper Operator terminal.
