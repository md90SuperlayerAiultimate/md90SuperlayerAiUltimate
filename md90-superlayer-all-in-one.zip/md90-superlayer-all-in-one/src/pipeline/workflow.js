/** Cockpit-aligned workflow stages — paper only */
export const WORKFLOW_STAGES = ["SOURCE", "CONFLUENCE", "RISK_GATE", "PAPER_FILL", "JOURNAL"];

/**
 * SOURCE → CONFLUENCE → RISK_GATE → PAPER_FILL → JOURNAL
 * BLOCKED at any stage stops the pipeline.
 */
export function buildWorkflow(input) {
  const {
    instrument,
    baseTimeframe = "M15",
    higherTimeframe = "H1",
    generatedAt = new Date().toISOString(),
    dataFreshnessSeconds = 0,
    riskChecks = [],
    hasTrade = false,
    brainStep = "WAIT",
  } = input;

  const riskLocked = riskChecks.find((c) => c.status === "LOCKED");
  const fresh = dataFreshnessSeconds <= 90;
  const confluenceOk = brainStep === "BUY" || brainStep === "SELL";
  const paperAllowed = !riskLocked && fresh && confluenceOk;

  const events = [
    {
      stage: "SOURCE",
      state: fresh ? "QUALIFIED" : "BLOCKED",
      title: "Market context",
      detail: `${instrument} · freshness ${dataFreshnessSeconds}s · ${baseTimeframe}`,
    },
    {
      stage: "CONFLUENCE",
      state: confluenceOk ? "CONFIRMED" : "BLOCKED",
      title: "Brain confluence",
      detail: confluenceOk ? `Brain step ${brainStep}` : "Bias/area/confirm not aligned",
    },
    {
      stage: "RISK_GATE",
      state: paperAllowed ? "PASSED" : "BLOCKED",
      title: "Risk gate",
      detail: riskLocked ? `${riskLocked.label}: ${riskLocked.detail}` : "0.5–1.0% risk · paper only",
    },
    {
      stage: "PAPER_FILL",
      state: hasTrade && paperAllowed ? "FILLED" : "STAGED",
      title: "Paper fill",
      detail: hasTrade && paperAllowed ? "Fill in local book @ mark" : "No network order authority",
    },
    {
      stage: "JOURNAL",
      state: hasTrade && paperAllowed ? "RECORDED" : "STAGED",
      title: "Journal",
      detail: `Provenance retained · ${generatedAt}`,
    },
  ];

  const blocked = events.find((e) => e.state === "BLOCKED");
  return {
    mode: "PAPER_SHADOW",
    instrument,
    baseTimeframe,
    higherTimeframe,
    currentStage: blocked?.stage ?? (hasTrade ? "JOURNAL" : "PAPER_FILL"),
    decision: paperAllowed ? "PAPER_ALLOWED" : "PAPER_BLOCKED",
    liveRoute: "LIVE_PENDING_APPROVAL",
    custody: "DISABLED",
    events,
  };
}
