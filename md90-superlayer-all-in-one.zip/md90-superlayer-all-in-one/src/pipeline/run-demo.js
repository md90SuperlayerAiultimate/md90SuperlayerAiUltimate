import { mapBrain } from "./brain.js";
import { buildWorkflow } from "./workflow.js";
import { createAccount, openAtMark, markPositions, closeAll } from "./paper.js";

/** Synthetic walk for offline proof without network */
function synthCandles(n = 120, start = 4100) {
  const out = [];
  let p = start;
  for (let i = 0; i < n; i++) {
    const drift = Math.sin(i / 9) * 2.2 + (Math.random() - 0.5) * 1.4;
    const o = p;
    const c = p + drift;
    const h = Math.max(o, c) + Math.random();
    const l = Math.min(o, c) - Math.random();
    out.push({ t: i, o, h, l, c });
    p = c;
  }
  return out;
}

const candles = synthCandles();
const price = candles[candles.length - 1].c;
const brain = mapBrain(candles, price);
const wf = buildWorkflow({
  instrument: "XAUUSD",
  dataFreshnessSeconds: 5,
  brainStep: brain.step,
  hasTrade: false,
});

console.log("=== MD90 ALL-IN-ONE PIPELINE PROOF ===");
console.log("Price:", price.toFixed(2));
console.log("Bias:", brain.bias, "| Step:", brain.step);
for (const s of brain.steps) {
  console.log(`  ${s.n}. ${s.name}: ${s.pass ? "LULUS" : "TAHAN"} — ${s.evidence}`);
}
console.log("Workflow decision:", wf.decision, "| stage:", wf.currentStage);
for (const e of wf.events) {
  console.log(`  [${e.stage}] ${e.state} — ${e.detail}`);
}

const account = createAccount(10000);
if (brain.step === "BUY" || brain.step === "SELL") {
  const r = openAtMark(account, { side: brain.step, qty: 0.1, markPrice: price, note: "GATE_PASS" });
  console.log("Fill:", r.ok ? "FILLED" : r.reason);
} else {
  console.log("Fill: SKIPPED (gate TAHAN)");
  // force-demo fill only for book mechanics proof, labeled as manual override
  openAtMark(account, { side: "BUY", qty: 0.1, markPrice: price, note: "MANUAL_DEMO_ONLY" });
}
markPositions(account, price * 1.001);
console.log("Equity after mark:", account.equity.toFixed(2));
const n = closeAll(account, price * 1.001);
console.log("Closed positions:", n, "| dailyPnl:", account.dailyPnl.toFixed(2));
console.log("=== PROOF COMPLETE · PAPER ONLY · NO LIVE ROUTE ===");
