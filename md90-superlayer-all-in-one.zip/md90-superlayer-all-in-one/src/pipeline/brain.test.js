import { test } from "node:test";
import assert from "node:assert/strict";
import { mapBrain, voteOf } from "./brain.js";

test("voteOf detects up and down", () => {
  const up = [
    { c: 100 },
    { c: 101 },
  ];
  assert.equal(voteOf(up, 2).vote, "BUY");
  const down = [
    { c: 100 },
    { c: 99 },
  ];
  assert.equal(voteOf(down, 2).vote, "SELL");
});

test("mapBrain returns four steps", () => {
  const candles = Array.from({ length: 130 }, (_, i) => {
    const c = 100 + i * 0.01;
    return { o: c, h: c + 0.1, l: c - 0.1, c };
  });
  const brain = mapBrain(candles, candles.at(-1).c);
  assert.equal(brain.steps.length, 4);
  assert.ok(["BULLISH", "BEARISH", "FLAT"].includes(brain.bias));
  assert.ok(["BUY", "SELL", "WAIT"].includes(brain.step));
});
