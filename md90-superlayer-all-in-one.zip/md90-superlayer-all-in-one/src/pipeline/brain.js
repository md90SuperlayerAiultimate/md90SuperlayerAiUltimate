/** MD90 Brain — windowed slope votes + 4-step gate */
export function voteOf(candles, bars) {
  const slice = candles.slice(-bars);
  if (slice.length < 2) return { vote: "FLAT", delta: 0 };
  const a = slice[0].c;
  const b = slice[slice.length - 1].c;
  if (!(a > 0)) return { vote: "FLAT", delta: 0 };
  const delta = (b - a) / a;
  const vote = delta > 0.00035 ? "BUY" : delta < -0.00035 ? "SELL" : "FLAT";
  return { vote, delta };
}

const LADDER = [
  { id: "M", bars: 120 },
  { id: "W", bars: 90 },
  { id: "D", bars: 60 },
  { id: "H4", bars: 40 },
  { id: "H1", bars: 24 },
  { id: "M30", bars: 16 },
  { id: "M15", bars: 10 },
  { id: "M5", bars: 6 },
  { id: "M1", bars: 3 },
];

/**
 * One direction: BIAS → AREA → CONFIRM → EXECUTE
 * Any TAHAN step = no order.
 */
export function mapBrain(candles, price) {
  const rows = LADDER.map((row) => ({ id: row.id, ...voteOf(candles, row.bars) }));
  const pick = (id) => rows.find((r) => r.id === id)?.vote ?? "FLAT";
  const higher = rows.filter((r) => ["M", "W", "D", "H4", "H1"].includes(r.id));
  const bulls = higher.filter((r) => r.vote === "BUY").length;
  const bears = higher.filter((r) => r.vote === "SELL").length;
  const bias = bulls > bears ? "BULLISH" : bears > bulls ? "BEARISH" : "FLAT";

  const window = candles.slice(-40);
  const high = window.length ? Math.max(...window.map((c) => c.h)) : price;
  const low = window.length ? Math.min(...window.map((c) => c.l)) : price;
  const mid = (high + low) / 2;
  const span = Math.max(high - low, price * 0.0001);
  const nearHigh = price >= high - span * 0.25;
  const nearLow = price <= low + span * 0.25;
  const ultra = pick("M5");
  const micro = pick("M1");

  const biasPass = bias !== "FLAT";
  const areaPass = bias === "BULLISH" ? nearLow : bias === "BEARISH" ? nearHigh : false;
  const confirmPass =
    (bias === "BULLISH" && (micro === "BUY" || ultra === "BUY")) ||
    (bias === "BEARISH" && (micro === "SELL" || ultra === "SELL"));
  const execute = biasPass && areaPass && confirmPass;
  const step = !execute ? "WAIT" : bias === "BULLISH" ? "BUY" : "SELL";

  const steps = [
    {
      n: 1,
      name: "Bias",
      rule: "Mayoritas jendela M–H1 satu arah. Imbang = berhenti.",
      evidence: `${bulls} naik / ${bears} turun → ${bias}`,
      pass: biasPass,
    },
    {
      n: 2,
      name: "Area",
      rule:
        bias === "BEARISH"
          ? "Harga di 25% atas rentang 40 bar (resistance)."
          : "Harga di 25% bawah rentang 40 bar (support).",
      evidence: `harga ${price} · zona ${low}–${high} · ${areaPass ? "di dalam" : "di luar"}`,
      pass: areaPass,
    },
    {
      n: 3,
      name: "Konfirmasi",
      rule: "M5 atau M1 harus searah bias.",
      evidence: `M5 ${ultra} · M1 ${micro}`,
      pass: confirmPass,
    },
    {
      n: 4,
      name: "Eksekusi",
      rule: "1+2+3 lulus. Entry = mark. SL di luar zona. TP ke tengah lalu sisi lawan.",
      evidence: execute ? `${step} @ ${price}` : "Tunggu. Tidak ada order.",
      pass: execute,
    },
  ];

  const plan = execute
    ? step === "BUY"
      ? { entry: price, stop: low - span * 0.15, tp1: mid, tp2: high, tp3: high + span * 0.25 }
      : { entry: price, stop: high + span * 0.15, tp1: mid, tp2: low, tp3: low - span * 0.25 }
    : null;

  return {
    rows,
    bias,
    step,
    steps,
    plan,
    high,
    low,
    mid,
    macro: pick("H1"),
    prime: pick("M15"),
    ultra,
    micro,
  };
}
