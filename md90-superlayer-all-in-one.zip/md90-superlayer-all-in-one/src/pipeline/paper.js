/** Local paper book — average-cost, honest labels */
export function createAccount(equity = 10000) {
  return { equity, cash: equity, dailyPnl: 0, peak: equity, fills: [], positions: [] };
}

export function openAtMark(account, { side, qty, markPrice, note = "PAPER" }) {
  if (!(markPrice > 0) || !(qty > 0)) return { ok: false, reason: "INVALID" };
  const notional = markPrice * qty;
  if (notional > account.cash * 0.2) return { ok: false, reason: "EXPOSURE_CAP" };
  const pos = {
    id: `P-${Date.now()}`,
    side,
    qty,
    entry: markPrice,
    mark: markPrice,
    status: "OPEN",
    note,
    openedAt: new Date().toISOString(),
  };
  account.positions.push(pos);
  account.cash -= side === "BUY" ? notional : 0;
  account.fills.push({
    side,
    price: markPrice,
    qty,
    note: `OPEN ${note}`,
    at: pos.openedAt,
  });
  return { ok: true, position: pos };
}

export function markPositions(account, price) {
  let upnl = 0;
  for (const p of account.positions) {
    if (p.status !== "OPEN") continue;
    p.mark = price;
    upnl += p.side === "BUY" ? (price - p.entry) * p.qty : (p.entry - price) * p.qty;
  }
  account.equity = account.cash + account.positions
    .filter((p) => p.status === "OPEN")
    .reduce((a, p) => a + p.entry * p.qty, 0) + upnl;
  if (account.equity > account.peak) account.peak = account.equity;
  return account;
}

export function closeAll(account, price) {
  let closed = 0;
  for (const p of account.positions) {
    if (p.status !== "OPEN") continue;
    const pnl = p.side === "BUY" ? (price - p.entry) * p.qty : (p.entry - price) * p.qty;
    account.dailyPnl += pnl;
    account.cash += p.side === "BUY" ? price * p.qty : p.entry * p.qty + pnl;
    p.status = "CLOSED";
    p.mark = price;
    account.fills.push({
      side: p.side === "BUY" ? "SELL" : "BUY",
      price,
      qty: p.qty,
      note: "CLOSE ALL",
      at: new Date().toISOString(),
    });
    closed++;
  }
  markPositions(account, price);
  return closed;
}

export function winRate(account) {
  const closed = account.fills.filter(
    (f) => f.note.startsWith("TP") || f.note === "Stop hit" || f.note.startsWith("CLOSE"),
  );
  if (!closed.length) return null;
  const wins = closed.filter((f) => f.note.startsWith("TP")).length;
  return (wins / closed.length) * 100;
}
