# MD90 Superlayer · All-in-one Paper Desk

Satu arah pipeline. Bukan tempel 5.881 file dari repo asing.

```
INGEST → BIAS → AREA → KONFIRMASI → RISK_GATE → PAPER_FILL → JOURNAL
```

Satu langkah **TAHAN / BLOCKED** = tidak ada order.

## Bukti lokal

```bash
node src/pipeline/run-demo.js
node --test src/pipeline/*.test.js
```

Buka `public/index.html` lewat static server (ES modules):

```bash
npx --yes serve .
# atau: python3 -m http.server 8080
```

## Label jujur

| Label | Arti |
|---|---|
| PAPER_SHADOW | Isi hanya di buku lokal |
| LIVE_PENDING_APPROVAL | Tidak ada rute live di build ini |
| CUSTODY DISABLED | Tidak menahan dana exchange |

## Sumber arsitektur (merge semantik, bukan paste mentah)

- Cockpit `shared/workflow.ts` → `src/pipeline/workflow.js`
- MD90 brain map (flowchart bias→area→confirm→execute) → `src/pipeline/brain.js`
- OpenTerminal book model → `src/pipeline/paper.js`

## Win rate

Dihitung dari fill buku. Sampel kecil ≠ klaim 92%.
