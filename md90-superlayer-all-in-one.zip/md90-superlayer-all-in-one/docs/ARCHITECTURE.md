# All-in-one architecture

## Workflow
1. SOURCE — harga/candle fresh ≤ 90s
2. CONFLUENCE — brain step BUY atau SELL
3. RISK_GATE — tidak LOCKED, exposure cap
4. PAPER_FILL — openAtMark di buku lokal
5. JOURNAL — fill + PnL tercatat

## Kerangka berpikir
- Satu bias aktif (mayoritas M–H1)
- Area dulu, trigger belakangan (25% zona 40 bar)
- Konfirmasi M5/M1 searah
- Paper ≠ live

## Logika eksekusi
```
BUY  = BULLISH ∧ nearLow ∧ (M5|M1 BUY) ∧ risk PASS
SELL = BEARISH ∧ nearHigh ∧ (M5|M1 SELL) ∧ risk PASS
else = WAIT
```
