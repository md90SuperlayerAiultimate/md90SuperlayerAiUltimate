//+------------------------------------------------------------------+
//|                                        MD90_Ultimate_Fusion.mq5  |
//|                    MD90 Ultimate Fusion v4.0 - TRUE FULL MERGE    |
//|                    v3: 32-module architecture + 6-TP + confidence  |
//|                    v2: 17-layer analysis + execution_status logic  |
//|                    All 10 v2 bugs fixed. Zero compromise.          |
//+------------------------------------------------------------------+
#property copyright "MD90 Systems"
#property link      "https://github.com/md90"
#property version   "4.00"
#property description "MD90 Ultimate Fusion v4 — True Full Merge v3+v2"

#include <Trade\Trade.mqh>
#include <Trade\AccountInfo.mqh>
#include <MD90_Fusion\Common\Constants.mqh>
#include <MD90_Fusion\Common\Logger.mqh>
#include <MD90_Fusion\Common\Utils.mqh>
#include <MD90_Fusion\Core\SignalEngine.mqh>
#include <MD90_Fusion\Risk\PositionSizer.mqh>
#include <MD90_Fusion\Risk\StopManager.mqh>
#include <MD90_Fusion\Risk\EquityProtector.mqh>
#include <MD90_Fusion\Risk\SessionFilter.mqh>
#include <MD90_Fusion\Trade\OrderManager.mqh>
#include <MD90_Fusion\Trade\PartialCloseManager.mqh>
#include <MD90_Fusion\Trade\PositionTracker.mqh>
#include <MD90_Fusion\Trade\TradeLogger.mqh>
#include <MD90_Fusion\Visual\ChartObjects.mqh>
#include <MD90_Fusion\Visual\Dashboard.mqh>
#include <MD90_Fusion\Visual\AlertManager.mqh>

//+------------------------------------------------------------------+
//| Input Parameters — Full v2 set + v3 extensions                   |
//+------------------------------------------------------------------+
input group "════ STRATEGY ════"
input ENUM_STRATEGY_MODE  InpStrategyMode    = STRATEGY_FULL_FUSION;
input ENUM_TIMEFRAMES     InpMainTF          = PERIOD_M5;
input bool                InpRequireHTFAgree = true;

input group "════ ENTRY FILTERS ════"
input double              InpMinFusionScore  = 0.55;
input double              InpMinConfidence   = 75.0;
input double              InpMinRR           = 2.0;
input int                 InpMinLayers       = 10;
input bool                InpRequireSweep    = true;
input bool                InpRequireFVG      = false;

input group "════ SMC PARAMS ════"
input int                 InpSwingLength     = 5;
input int                 InpOBLookback      = 200;
input int                 InpFVGLookback     = 200;
input int                 InpLiqLookback     = 50;

input group "════ RISK ════"
input ENUM_RISK_MODE      InpRiskMode        = RISK_PERCENT_BALANCE;
input double              InpRiskPercent     = 1.0;
input double              InpFixedLot        = 0.01;
input double              InpATR_SL_Mult     = 1.5;
input int                 InpMaxPositions    = 3;
input double              InpMaxDailyLoss    = 3.0;
input double              InpMaxDrawdown     = 10.0;
input double              InpMinLot          = 0.01;
input double              InpMaxLot          = 10.0;

input group "════ 6-TP MANAGEMENT ════"
input bool                InpUsePartialClose = true;
input double              InpPctTP1          = 25.0;
input double              InpPctTP2          = 25.0;
input double              InpPctTP3          = 20.0;
input double              InpPctTP4          = 15.0;
input double              InpPctTP5          = 10.0;
input bool                InpUseTrailing     = true;
input double              InpTrailStartMult  = 1.0;
input double              InpTrailStepMult   = 0.5;
input bool                InpUseBreakeven    = true;
input double              InpBETriggerMult   = 1.0;
input int                 InpCooldownBars    = 3;

input group "════ SESSION ════"
input bool                InpUseSession      = true;
input bool                InpTradeAsian      = false;
input bool                InpTradeLondon     = true;
input bool                InpTradeNY         = true;
input bool                InpOverlapOnly     = false;

input group "════ SPREAD / MISC ════"
input bool                InpUseSpread       = true;
input double              InpMaxSpread       = 30;
input ulong               InpMagic           = 20250901;
input string              InpComment         = "MD90_v4";
input bool                InpBacktestMode    = false;

input group "════ VISUAL & ALERTS ════"
input bool                InpShowDashboard   = true;
input bool                InpDrawSMC         = true;
input bool                InpShowSignals     = true;
input bool                InpEnableAlerts    = true;
input bool                InpEnablePush      = false;
input bool                InpEnableEmail     = false;
input bool                InpEnableSound     = true;
input string              InpSoundFile       = "alert.wav";

input group "════ LOGGING ════"
input ENUM_LOG_LEVEL      InpLogLevel        = LOG_LEVEL_INFO;
input bool                InpLogFile         = false;
input bool                InpCSVTrades       = true;

//+------------------------------------------------------------------+
//| Subsystem instances                                               |
//+------------------------------------------------------------------+
CAccountInfo        m_account;

CSignalEngine*      g_signal;
CPositionSizer*     g_sizer;
CStopManager*       g_stops;
CEquityProtector*   g_equity;
CSessionFilter*     g_session;
COrderManager*      g_orders;
CPartialCloseManager* g_partial;
CPositionTracker*   g_tracker;
CTradeLogger*       g_tlog;
CChartObjects*      g_chart;
CDashboard*         g_dash;
CAlertManager*      g_alerts;

//--- State
datetime      g_last_bar;
int           g_cooldown;
double        g_daily_start_bal;
bool          g_daily_halted;
FusionSignal  g_last_signal;
bool          g_init_ok;

//+------------------------------------------------------------------+
int OnInit()
{
   Logger.Init(InpComment, InpLogLevel, InpLogFile);
   Logger.Info("═══════════════════════════════════════");
   Logger.Info("MD90 Ultimate Fusion v4.0 — Full Merge");
   Logger.Info("Symbol="+_Symbol+" TF="+EnumToString(InpMainTF));
   Logger.Info("═══════════════════════════════════════");

   g_signal  = new CSignalEngine();
   if(!g_signal.Init(_Symbol, InpMainTF))
   { Logger.Error("SignalEngine init FAILED"); return INIT_FAILED; }
   Logger.Info("SignalEngine: 17 layers ready");

   g_sizer   = new CPositionSizer();
   g_sizer.Init(_Symbol, InpRiskMode, InpRiskPercent, InpFixedLot);
   g_sizer.SetLotLimits(InpMinLot, InpMaxLot);

   g_stops   = new CStopManager();
   g_stops.Init(_Symbol, InpMagic);
   g_stops.SetSLMult(InpATR_SL_Mult);

   g_equity  = new CEquityProtector();
   g_equity.Init(InpMaxDailyLoss, InpMaxDrawdown);

   g_session = new CSessionFilter();
   g_session.Init(InpTradeAsian, InpTradeLondon, InpTradeNY, InpOverlapOnly);

   g_orders  = new COrderManager();
   g_orders.Init(_Symbol, InpMagic, InpComment);

   g_partial = new CPartialCloseManager();
   g_partial.Init(_Symbol, InpMagic, InpPctTP1);
   g_partial.SetPartialPcts(InpPctTP1,InpPctTP2,InpPctTP3,InpPctTP4,InpPctTP5,0);

   g_tracker = new CPositionTracker();
   g_tracker.Init(_Symbol, InpMagic);

   g_tlog    = new CTradeLogger();
   g_tlog.Init(_Symbol, InpCSVTrades);

   g_chart   = new CChartObjects();
   g_chart.Init(0, "MD90v4_");

   if(InpShowDashboard)
   { g_dash = new CDashboard(); g_dash.Init(_Symbol, InpMainTF); }

   g_alerts  = new CAlertManager();
   g_alerts.Init(InpEnableAlerts,InpEnablePush,InpEnableEmail,InpEnableSound,InpSoundFile);

   g_daily_start_bal = m_account.Balance();
   g_daily_halted    = false;
   g_last_bar        = 0;
   g_cooldown        = 0;
   ZeroMemory(g_last_signal);
   g_init_ok         = true;

   EventSetTimer(1);   // v3: heartbeat timer

   Logger.Info("MD90 v4 initialized successfully");
   Logger.Info("═══════════════════════════════════════");
   return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   EventKillTimer();
   if(g_signal)  { delete g_signal;  g_signal=NULL;  }
   if(g_sizer)   { delete g_sizer;   g_sizer=NULL;   }
   if(g_stops)   { delete g_stops;   g_stops=NULL;   }
   if(g_equity)  { delete g_equity;  g_equity=NULL;  }
   if(g_session) { delete g_session; g_session=NULL; }
   if(g_orders)  { delete g_orders;  g_orders=NULL;  }
   if(g_partial) { delete g_partial; g_partial=NULL; }
   if(g_tracker) { delete g_tracker; g_tracker=NULL; }
   if(g_tlog)    { g_tlog.Close(); delete g_tlog; g_tlog=NULL; }
   if(g_chart)   { delete g_chart;   g_chart=NULL;   }
   if(g_dash)    { delete g_dash;    g_dash=NULL;    }
   if(g_alerts)  { delete g_alerts;  g_alerts=NULL;  }
   Comment(""); ChartRedraw();
   Logger.Info("EA deinit. Reason="+IntToString(reason));
   Logger.Close();
}

//+------------------------------------------------------------------+
void OnTick()
{
   if(!g_init_ok) return;

   // New bar detection (v2 pattern)
   bool is_new_bar = false;
   datetime cur_bar = iTime(_Symbol,InpMainTF,0);
   if(cur_bar != g_last_bar)
   { g_last_bar=cur_bar; is_new_bar=true; g_signal.OnBar(); }
   g_signal.OnTick();

   // Dashboard update
   if(g_dash && InpShowDashboard)
      g_dash.Update(g_last_signal, m_account.Balance(), m_account.Equity());

   // Daily reset
   CheckDailyReset();

   // Risk limits — equity protector v3 Check() + v2 daily loss
   if(!CheckRiskLimits()) return;

   // Session filter
   if(InpUseSession && !g_session.IsTradingAllowed()) return;

   // Spread filter — BUG#1 FIXED: no MQL4 Ask/Bid globals
   if(InpUseSpread)
   {
      double spread = (SymbolInfoDouble(_Symbol,SYMBOL_ASK) -
                       SymbolInfoDouble(_Symbol,SYMBOL_BID)) / _Point;
      if(spread > InpMaxSpread) return;
   }

   // Cooldown
   if(g_cooldown>0) { g_cooldown--; return; }

   // Position management: trailing + BE + 6-TP partial closes
   ManagePositions();

   if(!is_new_bar) return;

   // Sync position tracker
   g_tracker.UpdateAll();

   // Get current signal (v2 analyzes all 17 layers internally)
   g_last_signal = g_signal.GetCurrentSignal();

   // v3: signal alert
   if(g_last_signal.direction!=SIGNAL_NEUTRAL && g_last_signal.execution_status=="ALL-IN")
      g_alerts.OnSignal(g_last_signal);

   if(!ShouldTrade()) return;

   ExecuteSignal();
}

//+------------------------------------------------------------------+
void OnTimer()
{
   if(!g_init_ok) return;
   if(g_tracker) g_tracker.UpdateAll();
   Logger.Flush();
}

//+------------------------------------------------------------------+
void CheckDailyReset()
{
   static datetime last_day=0;
   datetime now=StringToTime(TimeToString(TimeCurrent(),TIME_DATE));
   if(now!=last_day)
   {
      last_day=now;
      g_daily_start_bal=m_account.Balance();
      g_daily_halted=false;
      if(g_equity) g_equity.ResetDailyBalance();
      Logger.Info("Daily reset. Balance="+FormatDbl(m_account.Balance(),2));
   }
}

//+------------------------------------------------------------------+
bool CheckRiskLimits()
{
   // v3: EquityProtector.Check() handles peak DD + daily
   if(g_equity && !g_equity.Check())
   {
      if(!g_daily_halted)
      {
         g_daily_halted=true;
         g_orders.CloseAllPositions();
         g_alerts.OnEquityHalt(g_equity.GetHaltReason());
      }
      return false;
   }

   // v2: additional daily loss check
   if(!g_daily_halted && InpMaxDailyLoss>0)
   {
      double loss=(g_daily_start_bal-m_account.Equity())/g_daily_start_bal*100.0;
      if(loss>=InpMaxDailyLoss)
      {
         g_daily_halted=true;
         g_orders.CloseAllPositions();
         g_alerts.SendAlert("MD90 v4: Daily loss "+FormatDbl(loss,1)+"% — halted!");
         Logger.Warn("Daily loss limit reached: "+FormatDbl(loss,1)+"%");
         return false;
      }
   }
   if(g_daily_halted) return false;

   if(g_orders.GetPositionCount()>=InpMaxPositions) return false;
   return true;
}

//+------------------------------------------------------------------+
bool ShouldTrade()
{
   FusionSignal &s=g_last_signal;
   if(s.direction==SIGNAL_NEUTRAL)                              return false;
   if(s.execution_status=="ABORT")                              return false;
   if(s.execution_status=="WAITING" && !InpBacktestMode)        return false;
   if(s.fusion_score<InpMinFusionScore)                         return false;
   if(s.confidence<InpMinConfidence)                            return false;
   if(s.risk_reward[0]<InpMinRR)                                return false;
   int votes=MathMax(s.buy_votes,s.sell_votes);
   if(votes<InpMinLayers)                                       return false;
   if(InpRequireHTFAgree && !s.gate1_passed)                    return false;
   if(InpRequireSweep)
   { LayerSignal ly=g_signal.GetLayerSignal(LAYER_IDM_FVG-1);
     if(ly.strength<0.5) return false; }
   if(InpRequireFVG)
   { LayerSignal ly=g_signal.GetLayerSignal(LAYER_IDM_FVG-1);
     if(ly.strength<0.6) return false; }
   // Don't trade if already position in same direction
   if(g_tracker.HasPositionInDirection(s.direction)) return false;
   return true;
}

//+------------------------------------------------------------------+
void ExecuteSignal()
{
   FusionSignal &sig = g_last_signal;
   int    dir    = sig.direction;
   double entry  = sig.entry_price;
   double sl     = sig.stop_loss;

   // Apply v3 confidence multipliers
   g_sizer.SetLotMultiplier(sig.lot_multiplier);
   g_stops.SetSLMultiplier(sig.sl_multiplier);

   double lot = g_sizer.CalculateLotSize(entry, sl);
   if(lot < InpMinLot)
   { Logger.Warn("Lot "+FormatDbl(lot,2)+" < min"); return; }

   // Get ATR from signal engine volatility
   double atr = (sig.take_profit[0]>0 && ATR_TP1_MULT>0) ?
                MathAbs(sig.take_profit[0]-entry)/ATR_TP1_MULT : 0;
   if(atr<=0)
   {
      // Fallback: calculate directly
      int h_atr=iATR(_Symbol,InpMainTF,14);
      double buf[1]; ArraySetAsSeries(buf,true);
      if(h_atr!=INVALID_HANDLE && CopyBuffer(h_atr,0,1,1,buf)>0) atr=buf[0];
      IndicatorRelease(h_atr);
   }
   if(atr<=0) { Logger.Error("ATR=0, abort entry"); return; }

   // v3: 6-TP levels based on confidence
   int active_tps = MathMin(2+sig.confidence_level+1, 6);
   STPLevels tpls = g_stops.Calculate(dir, entry, atr, active_tps);

   string cmt = InpComment+"_"+(dir==SIGNAL_BUY?"B":"S")+
                "_"+FormatDbl(sig.fusion_score*100,0);

   bool ok=false;
   if(InpUsePartialClose && active_tps>=2)
   {
      double lot1=NormalizeLots(lot*(InpPctTP1/100.0),_Symbol);
      double lot2=NormalizeLots(lot-lot1,_Symbol);
      if(dir==SIGNAL_BUY)
      { ok=g_orders.PlaceBuyOrder(lot1,entry,tpls.sl,tpls.tp[0],cmt+"_T1");
        if(ok && lot2>=InpMinLot)
           g_orders.PlaceBuyOrder(lot2,entry,tpls.sl,tpls.tp[1],cmt+"_T2"); }
      else
      { ok=g_orders.PlaceSellOrder(lot1,entry,tpls.sl,tpls.tp[0],cmt+"_T1");
        if(ok && lot2>=InpMinLot)
           g_orders.PlaceSellOrder(lot2,entry,tpls.sl,tpls.tp[1],cmt+"_T2"); }
   }
   else
   {
      if(dir==SIGNAL_BUY)  ok=g_orders.PlaceBuyOrder(lot,entry,tpls.sl,tpls.tp[0],cmt);
      else                 ok=g_orders.PlaceSellOrder(lot,entry,tpls.sl,tpls.tp[0],cmt);
   }

   if(ok)
   {
      g_cooldown=InpCooldownBars;
      ulong ticket=g_orders.GetTrade().ResultOrder();

      // v3: register in PositionTracker
      STrackedPosition tp_rec;
      ZeroMemory(tp_rec);
      tp_rec.ticket=ticket; tp_rec.direction=dir;
      tp_rec.entry_price=entry; tp_rec.lots=lot;
      tp_rec.sl=tpls.sl; tp_rec.active_tps=active_tps;
      tp_rec.current_sl=tpls.sl; tp_rec.open_time=TimeCurrent();
      for(int j=0;j<6;j++) tp_rec.tp[j]=tpls.tp[j];
      tp_rec.valid=true;
      g_tracker.AddPosition(tp_rec);

      // v3: draw TP/SL lines + signal arrow
      if(InpDrawSMC)
         g_chart.DrawTPSLLevels(IntToString((int)ticket),dir,
                                 tpls.sl,tpls.tp[0],tpls.tp[1],tpls.tp[2],
                                 tpls.tp[3],tpls.tp[4],tpls.tp[5],active_tps);
      if(InpShowSignals)
         g_chart.DrawSignalArrow(iTime(_Symbol,InpMainTF,1),entry,dir,
                                  sig.fusion_score*100);

      // v3: trade logger
      STradeRecord rec;
      ZeroMemory(rec);
      rec.ticket=ticket; rec.direction=dir;
      rec.entry_price=entry; rec.sl=tpls.sl; rec.tp1=tpls.tp[0];
      rec.lots=lot; rec.fusion_score=sig.fusion_score*100;
      rec.confidence_level=sig.confidence_level;
      rec.open_time=TimeCurrent(); rec.closed=false;
      g_tlog.LogOpen(rec);

      // v3+v2 alerts
      g_alerts.OnTradeOpen(ticket,dir,entry,lot,sig.fusion_score*100);

      Logger.Info("TRADE: "+DirToStr(dir)+
                  " #"+IntToString((int)ticket)+
                  " Lot="+FormatDbl(lot,2)+
                  " Entry="+FormatDbl(entry)+
                  " SL="+FormatDbl(tpls.sl)+
                  " 6xTP="+FormatDbl(tpls.tp[0])+".."+FormatDbl(tpls.tp[5])+
                  " Score="+FormatDbl(sig.fusion_score*100,1)+"%"+
                  " Conf="+FormatDbl(sig.confidence,1)+"%"+
                  " Status="+sig.execution_status);
   }
}

//+------------------------------------------------------------------+
void ManagePositions()
{
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(!PositionSelectByTicket(ticket)) continue;
      if(PositionGetInteger(POSITION_MAGIC)!=(long)InpMagic) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;

      int dir=(int)PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY?
               SIGNAL_BUY:SIGNAL_SELL;
      double price=(dir==SIGNAL_BUY)?SymbolInfoDouble(_Symbol,SYMBOL_BID):
                                      SymbolInfoDouble(_Symbol,SYMBOL_ASK);
      double cur_sl=PositionGetDouble(POSITION_SL);
      double cur_tp=PositionGetDouble(POSITION_TP);

      STrackedPosition* p=g_tracker.GetPosition(ticket);

      // ATR for this symbol+TF
      double atr=0;
      int h_atr=iATR(_Symbol,InpMainTF,14);
      if(h_atr!=INVALID_HANDLE)
      {
         double buf[1]; ArraySetAsSeries(buf,true);
         if(CopyBuffer(h_atr,0,1,1,buf)>0) atr=buf[0];
         IndicatorRelease(h_atr);
      }
      if(atr<=0) continue;

      bool is_buy=(dir==SIGNAL_BUY);

      // v3+v2: Break-even
      if(InpUseBreakeven && p!=NULL && !p.be_activated)
         g_stops.CheckBreakeven(ticket,price,atr,InpBETriggerMult,is_buy);
      if(p!=NULL) p.be_activated=true;

      // v3+v2: Trailing stop
      if(InpUseTrailing)
         g_stops.UpdateTrailingStop(ticket,price,atr,InpTrailStartMult,InpTrailStepMult,is_buy);

      // v3: 6-TP partial close check
      if(InpUsePartialClose && p!=NULL)
      {
         int tp_idx=p.tp_hit;
         if(tp_idx<p.active_tps && tp_idx<5)
         {
            double tp_tgt=p.tp[tp_idx];
            bool reached=(is_buy&&price>=tp_tgt)||(!is_buy&&price<=tp_tgt);
            if(reached)
            {
               double pcts[5]={InpPctTP1,InpPctTP2,InpPctTP3,InpPctTP4,InpPctTP5};
               g_partial.ClosePartialPct(ticket,pcts[tp_idx]);
               p.tp_hit++;
               g_alerts.OnTPHit(ticket,tp_idx+1,
                                  PositionGetDouble(POSITION_PROFIT));
               Logger.Info("TP"+IntToString(tp_idx+1)+" hit #"+IntToString((int)ticket));
            }
         }
         // TP6: full close
         if(p.tp_hit>=5 && p.active_tps>=6)
         {
            bool tp6=(is_buy&&price>=p.tp[5])||(!is_buy&&price<=p.tp[5]);
            if(tp6) { g_orders.ClosePosition(ticket); }
         }
      }
   }
}

//+------------------------------------------------------------------+
void OnChartEvent(const int id,const long &lp,const double &dp,const string &sp)
{ if(g_dash) g_dash.OnChartEvent(id,lp,dp,sp); }

//+------------------------------------------------------------------+
void OnTradeTransaction(const MqlTradeTransaction &trans,
                        const MqlTradeRequest &req,
                        const MqlTradeResult  &res)
{
   if(trans.type!=TRADE_TRANSACTION_DEAL_ADD) return;
   if(!HistoryDealSelect(trans.deal)) return;
   if((ulong)HistoryDealGetInteger(trans.deal,DEAL_MAGIC)!=InpMagic) return;
   ENUM_DEAL_ENTRY de=(ENUM_DEAL_ENTRY)HistoryDealGetInteger(trans.deal,DEAL_ENTRY);
   if(de!=DEAL_ENTRY_OUT && de!=DEAL_ENTRY_INOUT) return;

   double profit=HistoryDealGetDouble(trans.deal,DEAL_PROFIT);
   ulong  pos_id=(ulong)HistoryDealGetInteger(trans.deal,DEAL_POSITION_ID);
   double close_price=HistoryDealGetDouble(trans.deal,DEAL_PRICE);

   // v3: log close
   STradeRecord rec;
   ZeroMemory(rec);
   rec.ticket=pos_id; rec.profit=profit;
   rec.close_time=(datetime)HistoryDealGetInteger(trans.deal,DEAL_TIME);
   rec.close_price=close_price; rec.close_reason="CLOSED"; rec.closed=true;
   g_tlog.LogClose(rec);

   // v3+v2 alerts
   g_alerts.OnTradeClose(pos_id,profit,"DEAL_OUT");

   // Remove from tracker + clean chart objects
   g_tracker.RemovePosition(pos_id);
   if(InpDrawSMC)
      g_chart.DeleteByPrefix("POS_"+IntToString((int)pos_id));

   Logger.Info("Position closed #"+IntToString((int)pos_id)+
               " P/L="+FormatDbl(profit,2));
}
