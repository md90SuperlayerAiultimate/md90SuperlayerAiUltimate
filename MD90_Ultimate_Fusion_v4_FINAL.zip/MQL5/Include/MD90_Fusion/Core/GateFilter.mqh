//+------------------------------------------------------------------+
//|                                                   GateFilter.mqh |
//|                    MD90 Ultimate Fusion v4.0 - FINAL             |
//+------------------------------------------------------------------+
#ifndef MD90_GATE_FILTER_MQH
#define MD90_GATE_FILTER_MQH

#include "../Common/Constants.mqh"

class CGateFilter
{
public:
   // Gate 1: Trend & Structure (EMA + MTF + PrimeSwing must agree)
   static bool EvaluateGate1(LayerSignal &l_ema, LayerSignal &l_mtf, LayerSignal &l_swing)
   {
      if(l_ema.direction==SIGNAL_NEUTRAL) return false;
      return (l_ema.direction==l_mtf.direction && l_mtf.direction==l_swing.direction);
   }

   // Gate 2: Location & Trap (OTE + IDM/FVG agree)
   static bool EvaluateGate2(LayerSignal &l_ote, LayerSignal &l_idmfvg)
   {
      if(l_ote.direction!=SIGNAL_NEUTRAL && l_ote.direction==l_idmfvg.direction) return true;
      if(l_idmfvg.strength>0.8) return true;
      return false;
   }

   // Gate 3: Momentum (at least 3 of: RSI, Stoch, Volume, VWAP agree with signal)
   static bool EvaluateGate3(LayerSignal &l_rsi, LayerSignal &l_stoch,
                              LayerSignal &l_vol,  LayerSignal &l_vwap,
                              int target_dir)
   {
      int agree=0;
      if(l_rsi.direction==target_dir)   agree++;
      if(l_stoch.direction==target_dir) agree++;
      if(l_vol.direction==target_dir)   agree++;
      if(l_vwap.direction==target_dir)  agree++;
      return agree>=3;
   }

   // Gate 4: Trigger (MasterCall candle pattern + UltraScalper sweep confirm)
   static bool EvaluateGate4(LayerSignal &l_mastercall, LayerSignal &l_scalper, int target_dir)
   {
      if(l_mastercall.direction!=target_dir) return false;
      if(l_scalper.direction==target_dir)    return true;
      if(l_mastercall.strength>0.8)          return true;
      return false;
   }

   // Gate 5: Risk (TimeStop killzone active + RR meets minimum)
   static bool EvaluateGate5(LayerSignal &l_timestop, double risk_reward)
   {
      if(l_timestop.strength<0.5) return false;
      if(risk_reward<RR_MINIMUM)  return false;
      return true;
   }
};

#endif // MD90_GATE_FILTER_MQH
