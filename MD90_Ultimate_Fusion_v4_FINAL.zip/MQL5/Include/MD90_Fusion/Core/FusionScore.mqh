//+------------------------------------------------------------------+
//|                                                  FusionScore.mqh |
//|                    MD90 Ultimate Fusion v4.0 - FINAL             |
//+------------------------------------------------------------------+
#ifndef MD90_FUSION_SCORE_MQH
#define MD90_FUSION_SCORE_MQH

#include "../Common/Constants.mqh"

class CFusionScore
{
public:
   static void Calculate(LayerSignal &layers[], double weights[], FusionSignal &result)
   {
      double w_buy=0, w_sell=0, w_total=0;
      result.buy_votes=0; result.sell_votes=0; result.neutral_votes=0;

      for(int i=0;i<TOTAL_LAYERS;i++)
      {
         double w=weights[i];
         double s=layers[i].strength;
         w_total+=w;
         if(layers[i].direction==SIGNAL_BUY)
         { w_buy+=w*s;  result.buy_votes++; }
         else if(layers[i].direction==SIGNAL_SELL)
         { w_sell+=w*s; result.sell_votes++; }
         else
         { result.neutral_votes++; }
      }

      if(w_total>0)
      {
         double bs=w_buy/w_total, ss=w_sell/w_total;
         if(bs>ss)       { result.direction=SIGNAL_BUY;  result.fusion_score=bs; }
         else if(ss>bs)  { result.direction=SIGNAL_SELL; result.fusion_score=ss; }
         else            { result.direction=SIGNAL_NEUTRAL; result.fusion_score=0; }
      }
      else
      { result.direction=SIGNAL_NEUTRAL; result.fusion_score=0; }
   }
};

#endif // MD90_FUSION_SCORE_MQH
