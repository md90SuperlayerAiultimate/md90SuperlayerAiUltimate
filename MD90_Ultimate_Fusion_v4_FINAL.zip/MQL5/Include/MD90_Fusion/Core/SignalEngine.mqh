//|                                              SignalEngine.mqh    |
//|                                      MD90 Ultimate Fusion v2.0   |
//+------------------------------------------------------------------+
#ifndef MD90_SIGNAL_ENGINE_MQH
#define MD90_SIGNAL_ENGINE_MQH

#property copyright "MD90 Systems"
#property link      "https://www.mql5.com"
#property version   "2.00"

#include "../Common/Constants.mqh"
#include "../Common/Utils.mqh"
#include "../SMC/SwingDetector.mqh"
#include "../SMC/OrderBlockDetector.mqh"
#include "../SMC/FVGDetector.mqh"
#include "../SMC/LiquiditySweepDetector.mqh"
#include "../SMC/PDZoneCalculator.mqh"
#include "../Indicators/TrendIndicators.mqh"
#include "../Indicators/MomentumIndicators.mqh"
#include "../Indicators/VolatilityIndicators.mqh"
#include "../Indicators/VolumeIndicators.mqh"
#include "GateFilter.mqh"
#include "FusionScore.mqh"
#include "ConfidenceEngine.mqh"

//+------------------------------------------------------------------+
//| Signal Engine Class - 17 Layer Analysis                           |
//+------------------------------------------------------------------+
class CSignalEngine
{
private:
   string            m_symbol;
   ENUM_TIMEFRAMES   m_timeframe;
   
   CSwingDetector*   m_swing;
   COrderBlockDetector* m_ob;
   CFVGDetector*     m_fvg;
   CLiquiditySweepDetector* m_liq;
   CPDZoneCalculator* m_pd;
   CTrendIndicators* m_trend;
   CMomentumIndicators* m_momentum;
   CVolatilityIndicators* m_vol;
   CVolumeIndicators* m_volume;
   
   double            m_layer_weights[17];
   FusionSignal      m_current_signal;
   LayerSignal       m_layer_signals[17];
   
   void              ClearSignals();
   LayerSignal       AnalyzeLayer1_SNR();
   LayerSignal       AnalyzeLayer2_EMA();
   LayerSignal       AnalyzeLayer3_RSI();
   LayerSignal       AnalyzeLayer4_Stochastic();
   LayerSignal       AnalyzeLayer5_OrderBlock();
   LayerSignal       AnalyzeLayer6_Volume();
   LayerSignal       AnalyzeLayer7_MTF();
   LayerSignal       AnalyzeLayer8_Sentiment();
   LayerSignal       AnalyzeLayer9_UltraScalper();
   LayerSignal       AnalyzeLayer10_PrimeSwing();
   LayerSignal       AnalyzeLayer11_MacroFlow();
   LayerSignal       AnalyzeLayer12_VWAP();
   LayerSignal       AnalyzeLayer13_ATR();
   LayerSignal       AnalyzeLayer14_OTE();
   LayerSignal       AnalyzeLayer15_IDM_FVG();
   LayerSignal       AnalyzeLayer16_MasterCall();
   LayerSignal       AnalyzeLayer17_TimeStop();
   
   void              CalculateEntryExitLevels();
   void              DetermineExecutionStatus();
   
public:
   CSignalEngine();
   ~CSignalEngine();
   
   bool              Init(string symbol, ENUM_TIMEFRAMES tf);
   void              Deinit();
   void              OnTick();
   void              OnBar();
   
   FusionSignal      Analyze();
   FusionSignal      GetCurrentSignal() { return m_current_signal; }
   LayerSignal       GetLayerSignal(int id) { return m_layer_signals[id]; }
};

//+------------------------------------------------------------------+
//| Constructor                                                       |
//+------------------------------------------------------------------+
CSignalEngine::CSignalEngine()
{
   m_symbol = "";
   m_timeframe = PERIOD_CURRENT;
   m_swing = NULL; m_ob = NULL; m_fvg = NULL; m_liq = NULL; m_pd = NULL;
   m_trend = NULL; m_momentum = NULL; m_vol = NULL; m_volume = NULL;
   
   double w[] = {0.08,0.07,0.06,0.05,0.08,0.06,0.07,0.04,0.07,0.08,0.07,0.04,0.04,0.06,0.06,0.05,0.02};
   for(int i=0;i<17;i++) m_layer_weights[i]=w[i];
   ClearSignals();
}

//+------------------------------------------------------------------+
//| Destructor                                                        |
//+------------------------------------------------------------------+
CSignalEngine::~CSignalEngine()
{
   Deinit();
}

//+------------------------------------------------------------------+
//| Initialize                                                        |
//+------------------------------------------------------------------+
bool CSignalEngine::Init(string symbol, ENUM_TIMEFRAMES tf)
{
   m_symbol = symbol;
   m_timeframe = tf;
   
   m_swing = new CSwingDetector();
   if(!m_swing.Init(symbol, tf, InpSwingLength)) return false;
   
   m_ob = new COrderBlockDetector();
   if(!m_ob.Init(symbol, tf)) return false;
   
   m_fvg = new CFVGDetector();
   if(!m_fvg.Init(symbol, tf)) return false;
   
   m_liq = new CLiquiditySweepDetector();
   if(!m_liq.Init(symbol, tf)) return false;
   
   m_pd = new CPDZoneCalculator();
   if(!m_pd.Init(symbol, tf)) return false;
   
   m_trend = new CTrendIndicators();
   if(!m_trend.Init(symbol, tf)) return false;
   
   m_momentum = new CMomentumIndicators();
   if(!m_momentum.Init(symbol, tf)) return false;
   
   m_vol = new CVolatilityIndicators();
   if(!m_vol.Init(symbol, tf)) return false;
   
   m_volume = new CVolumeIndicators();
   if(!m_volume.Init(symbol, tf)) return false;
   
   return true;
}

//+------------------------------------------------------------------+
//| Deinitialize                                                      |
//+------------------------------------------------------------------+
void CSignalEngine::Deinit()
{
   if(m_swing) { delete m_swing; m_swing = NULL; }
   if(m_ob) { delete m_ob; m_ob = NULL; }
   if(m_fvg) { delete m_fvg; m_fvg = NULL; }
   if(m_liq) { delete m_liq; m_liq = NULL; }
   if(m_pd) { delete m_pd; m_pd = NULL; }
   if(m_trend) { delete m_trend; m_trend = NULL; }
   if(m_momentum) { delete m_momentum; m_momentum = NULL; }
   if(m_vol) { delete m_vol; m_vol = NULL; }
   if(m_volume) { delete m_volume; m_volume = NULL; }
}

//+------------------------------------------------------------------+
//| Clear signals                                                     |
//+------------------------------------------------------------------+
void CSignalEngine::ClearSignals()
{
   m_current_signal.direction = SIGNAL_NEUTRAL;
   m_current_signal.fusion_score = 0;
   m_current_signal.confidence = 0;
   m_current_signal.buy_votes = m_current_signal.sell_votes = m_current_signal.neutral_votes = 0;
   m_current_signal.gate1_passed = m_current_signal.gate2_passed = m_current_signal.gate3_passed = false;
   m_current_signal.gate4_passed = m_current_signal.gate5_passed = false;
   m_current_signal.execution_status = "ABORT";
   for(int i=0;i<17;i++)
   {
      m_layer_signals[i].direction = SIGNAL_NEUTRAL;
      m_layer_signals[i].strength = 0;
   }
}

//+------------------------------------------------------------------+
//| OnTick - update tick-based indicators                             |
//+------------------------------------------------------------------+
void CSignalEngine::OnTick()
{
   if(m_vol) m_vol.OnTick();
   if(m_volume) m_volume.OnTick();
}

//+------------------------------------------------------------------+
//| OnBar - run full analysis                                         |
//+------------------------------------------------------------------+
void CSignalEngine::OnBar()
{
   if(m_swing) m_swing.OnBar();
   if(m_ob) m_ob.OnBar();
   if(m_fvg) m_fvg.OnBar();
   if(m_liq) m_liq.OnBar();
   if(m_pd) m_pd.OnBar();
   Analyze();
}

//+------------------------------------------------------------------+
//| Analyze all 17 layers                                             |
//+------------------------------------------------------------------+
FusionSignal CSignalEngine::Analyze()
{
   ClearSignals();
   
   m_layer_signals[0] = AnalyzeLayer1_SNR();
   m_layer_signals[1] = AnalyzeLayer2_EMA();
   m_layer_signals[2] = AnalyzeLayer3_RSI();
   m_layer_signals[3] = AnalyzeLayer4_Stochastic();
   m_layer_signals[4] = AnalyzeLayer5_OrderBlock();
   m_layer_signals[5] = AnalyzeLayer6_Volume();
   m_layer_signals[6] = AnalyzeLayer7_MTF();
   m_layer_signals[7] = AnalyzeLayer8_Sentiment();
   m_layer_signals[8] = AnalyzeLayer9_UltraScalper();
   m_layer_signals[9] = AnalyzeLayer10_PrimeSwing();
   m_layer_signals[10] = AnalyzeLayer11_MacroFlow();
   m_layer_signals[11] = AnalyzeLayer12_VWAP();
   m_layer_signals[12] = AnalyzeLayer13_ATR();
   m_layer_signals[13] = AnalyzeLayer14_OTE();
   m_layer_signals[14] = AnalyzeLayer15_IDM_FVG();
   m_layer_signals[15] = AnalyzeLayer16_MasterCall();
   m_layer_signals[16] = AnalyzeLayer17_TimeStop();
   
   CFusionScore::Calculate(m_layer_signals, m_layer_weights, m_current_signal);
   
   if(m_current_signal.direction == SIGNAL_NEUTRAL)
   {
      m_current_signal.execution_status = "ABORT";
      return m_current_signal;
   }
   
   CalculateEntryExitLevels();
   
   bool vol_spike = (m_layer_signals[5].strength > 0.7);
   double vol_ratio = m_vol.GetATRRatio();
   m_current_signal.confidence = CConfidenceEngine::Calculate(
      m_current_signal, m_layer_signals, vol_ratio, vol_spike);
   
   DetermineExecutionStatus();
   m_current_signal.signal_time = TimeCurrent();
   
   return m_current_signal;
}

//+------------------------------------------------------------------+
//| Layer 1: Support/Resistance                                       |
//+------------------------------------------------------------------+
LayerSignal CSignalEngine::AnalyzeLayer1_SNR()
{
   LayerSignal s; s.layer_id=1; s.layer_name="SNR";
   double curr = iClose(m_symbol,m_timeframe,0);
   double sh = m_swing.GetLastSwingHigh();
   double sl = m_swing.GetLastSwingLow();
   double atr = m_vol.GetATR();
   
   double dist_res = (sh>0) ? (sh-curr)/atr : 100;
   double dist_sup = (sl<DBL_MAX) ? (curr-sl)/atr : 100;
   
   if(dist_sup < 0.5)
   {
      s.direction = SIGNAL_BUY;
      s.strength = 0.7;
      s.reason = "Near support";
   }
   else if(dist_res < 0.5)
   {
      s.direction = SIGNAL_SELL;
      s.strength = 0.7;
      s.reason = "Near resistance";
   }
   else
   {
      s.direction = SIGNAL_NEUTRAL;
      s.reason = "No clear S/R";
   }
   return s;
}

//+------------------------------------------------------------------+
//| Layer 2: EMA                                                      |
//+------------------------------------------------------------------+
LayerSignal CSignalEngine::AnalyzeLayer2_EMA()
{
   LayerSignal s; s.layer_id=2; s.layer_name="EMA";
   double e9 = m_trend.GetEMA(9);
   double e21 = m_trend.GetEMA(21);
   
   if(e9 > e21)
   {
      s.direction = SIGNAL_BUY;
      s.strength = 0.6;
      s.reason = "EMA9 above EMA21";
   }
   else if(e9 < e21)
   {
      s.direction = SIGNAL_SELL;
      s.strength = 0.6;
      s.reason = "EMA9 below EMA21";
   }
   else
   {
      s.direction = SIGNAL_NEUTRAL;
      s.reason = "EMA flat";
   }
   return s;
}

//+------------------------------------------------------------------+
//| Layer 3: RSI                                                      |
//+------------------------------------------------------------------+
LayerSignal CSignalEngine::AnalyzeLayer3_RSI()
{
   LayerSignal s; s.layer_id=3; s.layer_name="RSI";
   double rsi = m_momentum.GetRSI(0);
   
   if(rsi < 30)
   {
      s.direction = SIGNAL_BUY;
      s.strength = 0.7;
      s.reason = "RSI oversold";
   }
   else if(rsi > 70)
   {
      s.direction = SIGNAL_SELL;
      s.strength = 0.7;
      s.reason = "RSI overbought";
   }
   else if(rsi > 50)
   {
      s.direction = SIGNAL_BUY;
      s.strength = 0.4;
      s.reason = "RSI bullish momentum";
   }
   else if(rsi < 50)
   {
      s.direction = SIGNAL_SELL;
      s.strength = 0.4;
      s.reason = "RSI bearish momentum";
   }
   else
   {
      s.direction = SIGNAL_NEUTRAL;
      s.reason = "RSI neutral";
   }
   return s;
}

//+------------------------------------------------------------------+
//| Layer 4: Stochastic                                               |
//+------------------------------------------------------------------+
LayerSignal CSignalEngine::AnalyzeLayer4_Stochastic()
{
   LayerSignal s; s.layer_id=4; s.layer_name="Stochastic";
   double k = m_momentum.GetStochasticK(0);
   double d = m_momentum.GetStochasticD(0);
   
   if(k < 20 && k > d)
   {
      s.direction = SIGNAL_BUY;
      s.strength = 0.6;
      s.reason = "Stochastic oversold cross up";
   }
   else if(k > 80 && k < d)
   {
      s.direction = SIGNAL_SELL;
      s.strength = 0.6;
      s.reason = "Stochastic overbought cross down";
   }
   else if(k > d)
   {
      s.direction = SIGNAL_BUY;
      s.strength = 0.3;
      s.reason = "Stochastic bullish";
   }
   else if(k < d)
   {
      s.direction = SIGNAL_SELL;
      s.strength = 0.3;
      s.reason = "Stochastic bearish";
   }
   else
   {
      s.direction = SIGNAL_NEUTRAL;
      s.reason = "Stochastic neutral";
   }
   return s;
}

//+------------------------------------------------------------------+
//| Layer 5: Order Block                                              |
//+------------------------------------------------------------------+
LayerSignal CSignalEngine::AnalyzeLayer5_OrderBlock()
{
   LayerSignal s; s.layer_id=5; s.layer_name="OrderBlock";
   double curr = iClose(m_symbol,m_timeframe,0);
   COB* bull = m_ob.GetNearestBullishOB();
   COB* bear = m_ob.GetNearestBearishOB();
   
   if(bull && curr >= bull.low && curr <= bull.high)
   {
      s.direction = SIGNAL_BUY;
      s.strength = 0.8;
      s.reason = "Inside bullish OB";
   }
   else if(bear && curr >= bear.low && curr <= bear.high)
   {
      s.direction = SIGNAL_SELL;
      s.strength = 0.8;
      s.reason = "Inside bearish OB";
   }
   else
   {
      s.direction = SIGNAL_NEUTRAL;
      s.reason = "No active OB";
   }
   return s;
}

//+------------------------------------------------------------------+
//| Layer 6: Volume                                                   |
//+------------------------------------------------------------------+
LayerSignal CSignalEngine::AnalyzeLayer6_Volume()
{
   LayerSignal s; s.layer_id=6; s.layer_name="Volume";
   double ratio = m_volume.GetVolumeRatio(0);
   
   if(ratio > 1.5)
   {
      if(iClose(m_symbol,m_timeframe,0) > iOpen(m_symbol,m_timeframe,0))
      {
         s.direction = SIGNAL_BUY;
         s.strength = 0.7;
         s.reason = "Volume spike bullish";
      }
      else
      {
         s.direction = SIGNAL_SELL;
         s.strength = 0.7;
         s.reason = "Volume spike bearish";
      }
   }
   else
   {
      s.direction = SIGNAL_NEUTRAL;
      s.reason = "Normal volume";
   }
   return s;
}

//+------------------------------------------------------------------+
//| Layer 7: Multi-Timeframe                                          |
//+------------------------------------------------------------------+
LayerSignal CSignalEngine::AnalyzeLayer7_MTF()
{
   LayerSignal s; s.layer_id=7; s.layer_name="MTF";
   int bull=0, bear=0;
   ENUM_TIMEFRAMES tfs[] = {PERIOD_M5, PERIOD_M15, PERIOD_H1, PERIOD_H4, PERIOD_D1};
   
   for(int i=0; i<5; i++)
   {
      int h_ma = iMA(m_symbol, tfs[i], 21, 0, MODE_EMA, PRICE_CLOSE);
      double e21 = 0.0;
      if(h_ma != INVALID_HANDLE)
      {
         double buf[1]; ArraySetAsSeries(buf,true);
         if(CopyBuffer(h_ma, 0, 1, 1, buf) > 0) e21 = buf[0];
         IndicatorRelease(h_ma);
      }
      double close = iClose(m_symbol, tfs[i], 1);
      if(close > e21 && e21 > 0) bull++; else if(e21 > 0) bear++;
   }
   
   if(bull >= 4)
   {
      s.direction = SIGNAL_BUY;
      s.strength = 0.8;
      s.reason = "4+ timeframes bullish";
   }
   else if(bear >= 4)
   {
      s.direction = SIGNAL_SELL;
      s.strength = 0.8;
      s.reason = "4+ timeframes bearish";
   }
   else
   {
      s.direction = SIGNAL_NEUTRAL;
      s.reason = "Mixed MTF";
   }
   return s;
}

//+------------------------------------------------------------------+
//| Layer 8: Sentiment                                                |
//+------------------------------------------------------------------+
LayerSignal CSignalEngine::AnalyzeLayer8_Sentiment()
{
   LayerSignal s; s.layer_id=8; s.layer_name="Sentiment";
   double pressure = m_volume.GetBuyPressure();
   
   if(pressure > 60)
   {
      s.direction = SIGNAL_BUY;
      s.strength = 0.5;
      s.reason = "Buy pressure > 60%";
   }
   else if(pressure < 40)
   {
      s.direction = SIGNAL_SELL;
      s.strength = 0.5;
      s.reason = "Sell pressure > 60%";
   }
   else
   {
      s.direction = SIGNAL_NEUTRAL;
      s.reason = "Neutral sentiment";
   }
   return s;
}

//+------------------------------------------------------------------+
//| Layer 9: UltraScalper                                             |
//+------------------------------------------------------------------+
LayerSignal CSignalEngine::AnalyzeLayer9_UltraScalper()
{
   LayerSignal s; s.layer_id=9; s.layer_name="UltraScalper";
   
   if(m_liq.HasRecentSweep(5))
   {
      CLiqSweep* sweep = m_liq.GetLastBuySweep();
      if(sweep && sweep.is_confirmed)
      {
         s.direction = SIGNAL_BUY;
         s.strength = 0.8;
         s.reason = "Recent buy liquidity sweep";
      }
      else
      {
         sweep = m_liq.GetLastSellSweep();
         if(sweep && sweep.is_confirmed)
         {
            s.direction = SIGNAL_SELL;
            s.strength = 0.8;
            s.reason = "Recent sell liquidity sweep";
         }
         else
         {
            s.direction = SIGNAL_NEUTRAL;
            s.reason = "No confirmed sweep";
         }
      }
   }
   else
   {
      s.direction = SIGNAL_NEUTRAL;
      s.reason = "No recent sweep";
   }
   return s;
}

//+------------------------------------------------------------------+
//| Layer 10: PrimeSwing                                              |
//+------------------------------------------------------------------+
LayerSignal CSignalEngine::AnalyzeLayer10_PrimeSwing()
{
   LayerSignal s; s.layer_id=10; s.layer_name="PrimeSwing";
   
   if(m_swing.IsCHoCHBullish() && m_pd.IsInDiscount())
   {
      s.direction = SIGNAL_BUY;
      s.strength = 0.9;
      s.reason = "CHoCH bullish at discount";
   }
   else if(m_swing.IsCHoCHBearish() && m_pd.IsInPremium())
   {
      s.direction = SIGNAL_SELL;
      s.strength = 0.9;
      s.reason = "CHoCH bearish at premium";
   }
   else if(m_swing.IsBullishStructure())
   {
      s.direction = SIGNAL_BUY;
      s.strength = 0.5;
      s.reason = "Bullish structure";
   }
   else if(m_swing.IsBearishStructure())
   {
      s.direction = SIGNAL_SELL;
      s.strength = 0.5;
      s.reason = "Bearish structure";
   }
   else
   {
      s.direction = SIGNAL_NEUTRAL;
      s.reason = "No clear structure";
   }
   return s;
}

//+------------------------------------------------------------------+
//| Layer 11: MacroFlow                                               |
//+------------------------------------------------------------------+
LayerSignal CSignalEngine::AnalyzeLayer11_MacroFlow()
{
   LayerSignal s; s.layer_id=11; s.layer_name="MacroFlow";
   int h_e200 = iMA(m_symbol, PERIOD_D1, 200, 0, MODE_EMA, PRICE_CLOSE);
   double e200 = 0.0;
   if(h_e200 != INVALID_HANDLE)
   {
      double buf[1]; ArraySetAsSeries(buf,true);
      if(CopyBuffer(h_e200, 0, 1, 1, buf) > 0) e200 = buf[0];
      IndicatorRelease(h_e200);
   }
   double close = iClose(m_symbol, PERIOD_D1, 1);
   
   if(close > e200)
   {
      s.direction = SIGNAL_BUY;
      s.strength = 0.6;
      s.reason = "Daily close above EMA200";
   }
   else
   {
      s.direction = SIGNAL_SELL;
      s.strength = 0.6;
      s.reason = "Daily close below EMA200";
   }
   return s;
}

//+------------------------------------------------------------------+
//| Layer 12: VWAP                                                    |
//+------------------------------------------------------------------+
LayerSignal CSignalEngine::AnalyzeLayer12_VWAP()
{
   LayerSignal s; s.layer_id=12; s.layer_name="VWAP";
   double vwap = m_volume.GetVWAP(0);
   double curr = iClose(m_symbol,m_timeframe,0);
   
   if(curr > vwap)
   {
      s.direction = SIGNAL_BUY;
      s.strength = 0.4;
      s.reason = "Price above VWAP";
   }
   else if(curr < vwap)
   {
      s.direction = SIGNAL_SELL;
      s.strength = 0.4;
      s.reason = "Price below VWAP";
   }
   else
   {
      s.direction = SIGNAL_NEUTRAL;
      s.reason = "At VWAP";
   }
   return s;
}

//+------------------------------------------------------------------+
//| Layer 13: ATR                                                     |
//+------------------------------------------------------------------+
LayerSignal CSignalEngine::AnalyzeLayer13_ATR()
{
   LayerSignal s; s.layer_id=13; s.layer_name="ATR";
   // ATR provides context only, direction follows trend
   s.direction = m_trend.IsBullish() ? SIGNAL_BUY : SIGNAL_SELL;
   s.strength = 0.3;
   s.reason = "ATR context";
   return s;
}

//+------------------------------------------------------------------+
//| Layer 14: OTE (Optimal Trade Entry)                               |
//+------------------------------------------------------------------+
LayerSignal CSignalEngine::AnalyzeLayer14_OTE()
{
   LayerSignal s; s.layer_id=14; s.layer_name="OTE";
   double sh = m_swing.GetLastSwingHigh();
   double sl = m_swing.GetLastSwingLow();
   if(sh==0 || sl==DBL_MAX) { s.direction=SIGNAL_NEUTRAL; return s; }
   
   double curr = iClose(m_symbol,m_timeframe,0);
   double ote = sl + (sh - sl) * 0.705;
   
   if(ApproxEqual(curr, ote, 0.001))
   {
      s.direction = m_swing.IsBullishStructure() ? SIGNAL_BUY : SIGNAL_SELL;
      s.strength = 0.7;
      s.reason = "Price at OTE zone";
   }
   else
   {
      s.direction = SIGNAL_NEUTRAL;
      s.reason = "Not at OTE";
   }
   return s;
}

//+------------------------------------------------------------------+
//| Layer 15: IDM/FVG                                                 |
//+------------------------------------------------------------------+
LayerSignal CSignalEngine::AnalyzeLayer15_IDM_FVG()
{
   LayerSignal s; s.layer_id=15; s.layer_name="IDM/FVG";
   bool sweep = m_liq.HasRecentSweep(10);
   CFVG* fvg = m_fvg.GetUnfilledFVG(true);
   if(!fvg) fvg = m_fvg.GetUnfilledFVG(false);
   
   if(sweep && fvg)
   {
      CLiqSweep* ls = m_liq.GetLastBuySweep();
      if(!ls) ls = m_liq.GetLastSellSweep();
      if(ls && ((ls.is_buy_sweep && fvg.is_bullish) || (ls.is_sell_sweep && !fvg.is_bullish)))
      {
         s.direction = ls.is_buy_sweep ? SIGNAL_BUY : SIGNAL_SELL;
         s.strength = 0.9;
         s.reason = "Liquidity sweep + FVG confluence";
      }
      else
      {
         s.direction = SIGNAL_NEUTRAL;
      }
   }
   else
   {
      s.direction = SIGNAL_NEUTRAL;
   }
   return s;
}

//+------------------------------------------------------------------+
//| Layer 16: MasterCall (Candle Pattern)                             |
//+------------------------------------------------------------------+
LayerSignal CSignalEngine::AnalyzeLayer16_MasterCall()
{
   LayerSignal s; s.layer_id=16; s.layer_name="MasterCall";
   double open = iOpen(m_symbol,m_timeframe,1);
   double close = iClose(m_symbol,m_timeframe,1);
   double high = iHigh(m_symbol,m_timeframe,1);
   double low = iLow(m_symbol,m_timeframe,1);
   double body = MathAbs(close-open);
   double range = high-low;
   
   if(close > open && body > range*0.7)
   {
      s.direction = SIGNAL_BUY;
      s.strength = 0.7;
      s.reason = "Bullish Marubozu";
   }
   else if(close < open && body > range*0.7)
   {
      s.direction = SIGNAL_SELL;
      s.strength = 0.7;
      s.reason = "Bearish Marubozu";
   }
   else
   {
      s.direction = SIGNAL_NEUTRAL;
      s.reason = "No clear pattern";
   }
   return s;
}

//+------------------------------------------------------------------+
//| Layer 17: TimeStop (Session Filter)                               |
//+------------------------------------------------------------------+
LayerSignal CSignalEngine::AnalyzeLayer17_TimeStop()
{
   LayerSignal s; s.layer_id=17; s.layer_name="TimeStop";
   int hour = GetGMTHour();
   if((hour >= 8 && hour < 12) || (hour >= 13 && hour < 16))
   {
      s.strength = 1.0;
      s.reason = "Killzone active";
   }
   else
   {
      s.strength = 0.0;
      s.reason = "Outside killzone";
   }
   s.direction = SIGNAL_NEUTRAL;
   return s;
}

//+------------------------------------------------------------------+
//| Calculate Entry/Exit Levels                                       |
//+------------------------------------------------------------------+
void CSignalEngine::CalculateEntryExitLevels()
{
   double curr = iClose(m_symbol,m_timeframe,0);
   double atr = m_vol.GetATR();
   
   if(m_current_signal.direction == SIGNAL_BUY)
   {
      m_current_signal.entry_price = curr;
      m_current_signal.stop_loss = curr - atr * ATR_SL_MULT;
      m_current_signal.take_profit[0] = curr + atr * ATR_TP1_MULT;
      m_current_signal.take_profit[1] = curr + atr * ATR_TP2_MULT;
      m_current_signal.take_profit[2] = curr + atr * ATR_TP3_MULT;
   }
   else
   {
      m_current_signal.entry_price = curr;
      m_current_signal.stop_loss = curr + atr * ATR_SL_MULT;
      m_current_signal.take_profit[0] = curr - atr * ATR_TP1_MULT;
      m_current_signal.take_profit[1] = curr - atr * ATR_TP2_MULT;
      m_current_signal.take_profit[2] = curr - atr * ATR_TP3_MULT;
   }
   
   double risk = MathAbs(m_current_signal.entry_price - m_current_signal.stop_loss);
   for(int i=0;i<3;i++)
   {
      double reward = MathAbs(m_current_signal.take_profit[i] - m_current_signal.entry_price);
      m_current_signal.risk_reward[i] = (risk>0) ? reward/risk : 0;
   }
}

//+------------------------------------------------------------------+
//| Determine Execution Status                                        |
//+------------------------------------------------------------------+
void CSignalEngine::DetermineExecutionStatus()
{
   m_current_signal.gate1_passed = CGateFilter::EvaluateGate1(
      m_layer_signals[1], m_layer_signals[6], m_layer_signals[9]);
   m_current_signal.gate2_passed = CGateFilter::EvaluateGate2(
      m_layer_signals[13], m_layer_signals[14]);
   m_current_signal.gate3_passed = CGateFilter::EvaluateGate3(
      m_layer_signals[2], m_layer_signals[3], m_layer_signals[5], 
      m_layer_signals[11], m_current_signal.direction);
   m_current_signal.gate4_passed = CGateFilter::EvaluateGate4(
      m_layer_signals[15], m_layer_signals[8], m_current_signal.direction);
   m_current_signal.gate5_passed = CGateFilter::EvaluateGate5(
      m_layer_signals[16], m_current_signal.risk_reward[0]);
   
   if(!m_current_signal.gate1_passed || !m_current_signal.gate5_passed)
      m_current_signal.execution_status = "ABORT";
   else if(!m_current_signal.gate2_passed || !m_current_signal.gate4_passed)
      m_current_signal.execution_status = "WAITING";
   else if(m_current_signal.fusion_score >= FUSION_SCORE_MIN && 
           m_current_signal.confidence >= CONFIDENCE_MIN)
      m_current_signal.execution_status = "ALL-IN";
   else
      m_current_signal.execution_status = "WAITING";
}
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+


#endif // MD90_SIGNAL_ENGINE_MQH
