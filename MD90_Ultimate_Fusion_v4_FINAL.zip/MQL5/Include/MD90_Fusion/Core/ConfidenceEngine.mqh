//+------------------------------------------------------------------+
//|                                             ConfidenceEngine.mqh |
//|                    MD90 Ultimate Fusion v4.0 - FINAL             |
//+------------------------------------------------------------------+
#ifndef MD90_CONFIDENCE_ENGINE_MQH
#define MD90_CONFIDENCE_ENGINE_MQH

#include "../Common/Constants.mqh"
#include "../Common/Utils.mqh"

class CConfidenceEngine
{
public:
   // Calculate confidence 0-100 and populate FusionSignal multipliers
   static double Calculate(FusionSignal &signal, LayerSignal &layers[],
                           double volatility_ratio, bool has_volume_spike)
   {
      double base=signal.fusion_score*100.0;
      double bonus=0, penalty=0;

      // MTF alignment bonus
      if(layers[LAYER_MTF-1].strength>0.7)           bonus+=5.0;
      if(has_volume_spike)                            bonus+=5.0;
      if(layers[LAYER_IDM_FVG-1].strength>0.8)        bonus+=5.0;
      if(layers[LAYER_MASTER_CALL-1].strength>0.8)    bonus+=3.0;

      // Confluence bonus
      int conf=0;
      for(int i=0;i<TOTAL_LAYERS;i++)
         if(layers[i].direction==signal.direction) conf++;
      if(conf>=12)      bonus+=10.0;
      else if(conf>=10) bonus+=5.0;

      // Penalties
      if(layers[LAYER_MTF-1].direction!=signal.direction)        penalty+=5.0;
      if(layers[LAYER_VOLUME-1].strength<0.3)                    penalty+=3.0;
      if(layers[LAYER_TIMESTOP-1].strength<0.5)                  penalty+=10.0;
      if(volatility_ratio>2.0)                                   penalty+=5.0;

      double conf_val=Clamp(base+bonus-penalty,0.0,100.0);

      // v3: populate multipliers from confidence level
      if(conf_val>=90)
      { signal.confidence_level=CONFIDENCE_ULTRA;  signal.lot_multiplier=2.0; signal.sl_multiplier=0.8; }
      else if(conf_val>=80)
      { signal.confidence_level=CONFIDENCE_HIGH;   signal.lot_multiplier=1.5; signal.sl_multiplier=0.9; }
      else if(conf_val>=65)
      { signal.confidence_level=CONFIDENCE_MEDIUM; signal.lot_multiplier=1.0; signal.sl_multiplier=1.0; }
      else
      { signal.confidence_level=CONFIDENCE_LOW;    signal.lot_multiplier=0.5; signal.sl_multiplier=1.2; }

      return conf_val;
   }
};

#endif // MD90_CONFIDENCE_ENGINE_MQH
