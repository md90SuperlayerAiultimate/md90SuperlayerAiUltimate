//|                                        OrderBlockDetector.mqh    |
//|                                      MD90 Ultimate Fusion v2.0   |
//+------------------------------------------------------------------+
#ifndef MD90_ORDER_BLOCK_DETECTOR_MQH
#define MD90_ORDER_BLOCK_DETECTOR_MQH

#property copyright "MD90 Systems"
#property link      "https://www.mql5.com"
#property version   "2.00"

#include <Arrays\ArrayObj.mqh>
#include "../Common/Constants.mqh"
#include "../Common/Utils.mqh"

//+------------------------------------------------------------------+
//| Order Block Class (inherits CObject for CArrayObj)                |
//+------------------------------------------------------------------+
class COB : public CObject
{
public:
   datetime   time_start;
   datetime   time_end;
   double     high;
   double     low;
   double     mid;
   int        bar_index;
   bool       is_bullish;
   bool       is_breaker;
   int        touches;
   bool       is_mitigated;
   double     volume;
   double     strength;
   
   COB()
   {
      time_start = 0;
      time_end = 0;
      high = 0;
      low = 0;
      mid = 0;
      bar_index = 0;
      is_bullish = true;
      is_breaker = false;
      touches = 0;
      is_mitigated = false;
      volume = 0;
      strength = 0;
   }
};

//+------------------------------------------------------------------+
//| Order Block Detector Class                                        |
//+------------------------------------------------------------------+
class COrderBlockDetector
{
private:
   string            m_symbol;
   ENUM_TIMEFRAMES   m_timeframe;
   CArrayObj         m_order_blocks;
   CArrayObj         m_mitigated_obs;
   int               m_max_obs;
   int               m_lookback_bars;
   double            m_min_ob_size;
   double            m_atr_value;
   int               m_atr_period;
   double            m_displacement_factor;
   double            m_volume_factor;
   
   double            GetCandleBody(int bar);
   double            GetCandleRange(int bar);
   bool              IsDisplacementCandle(int bar, bool bullish);
   bool              HasVolumeSpike(int bar);
   void              CheckMitigation();
   
public:
   COrderBlockDetector();
   ~COrderBlockDetector();
   bool              Init(string symbol, ENUM_TIMEFRAMES tf);
   void              Deinit();
   void              OnBar();
   COB*              DetectBullishOB();
   COB*              DetectBearishOB();
   COB*              GetNearestBullishOB();
   COB*              GetNearestBearishOB();
   double            GetOptimalEntry(COB* ob);
   double            GetStopLossLevel(COB* ob, bool is_buy);
};

//+------------------------------------------------------------------+
//| Constructor                                                       |
//+------------------------------------------------------------------+
COrderBlockDetector::COrderBlockDetector()
{
   m_symbol = "";
   m_timeframe = PERIOD_CURRENT;
   m_max_obs = 20;
   m_lookback_bars = 200;
   m_min_ob_size = 0.3;
   m_atr_value = 0;
   m_atr_period = 14;
   m_displacement_factor = 0.6;
   m_volume_factor = 1.5;
}

//+------------------------------------------------------------------+
//| Destructor                                                        |
//+------------------------------------------------------------------+
COrderBlockDetector::~COrderBlockDetector()
{
   Deinit();
}

//+------------------------------------------------------------------+
//| Deinitialize                                                      |
//+------------------------------------------------------------------+
void COrderBlockDetector::Deinit()
{
   for(int i = m_order_blocks.Total() - 1; i >= 0; i--)
      delete m_order_blocks.At(i);
   for(int i = m_mitigated_obs.Total() - 1; i >= 0; i--)
      delete m_mitigated_obs.At(i);
   m_order_blocks.Clear();
   m_mitigated_obs.Clear();
}

//+------------------------------------------------------------------+
//| Initialize                                                        |
//+------------------------------------------------------------------+
bool COrderBlockDetector::Init(string symbol, ENUM_TIMEFRAMES tf)
{
   m_symbol = symbol;
   m_timeframe = tf;
   int atr_handle = iATR(m_symbol, m_timeframe, m_atr_period);
   if(atr_handle == INVALID_HANDLE) return false;
   double buf[1];
   if(CopyBuffer(atr_handle, 0, 0, 1, buf) > 0)
      m_atr_value = buf[0];
   IndicatorRelease(atr_handle);
   return true;
}

//+------------------------------------------------------------------+
//| Get candle body                                                   |
//+------------------------------------------------------------------+
double COrderBlockDetector::GetCandleBody(int bar)
{
   return MathAbs(iOpen(m_symbol, m_timeframe, bar) - iClose(m_symbol, m_timeframe, bar));
}

//+------------------------------------------------------------------+
//| Get candle range                                                  |
//+------------------------------------------------------------------+
double COrderBlockDetector::GetCandleRange(int bar)
{
   return iHigh(m_symbol, m_timeframe, bar) - iLow(m_symbol, m_timeframe, bar);
}

//+------------------------------------------------------------------+
//| Check displacement candle                                         |
//+------------------------------------------------------------------+
bool COrderBlockDetector::IsDisplacementCandle(int bar, bool bullish)
{
   double body = GetCandleBody(bar);
   double range = GetCandleRange(bar);
   if(range == 0) return false;
   if(body / range < m_displacement_factor) return false;
   if(body < m_min_ob_size * m_atr_value) return false;
   if(bullish)
      return iClose(m_symbol, m_timeframe, bar) > iOpen(m_symbol, m_timeframe, bar);
   else
      return iClose(m_symbol, m_timeframe, bar) < iOpen(m_symbol, m_timeframe, bar);
}

//+------------------------------------------------------------------+
//| Check volume spike                                                |
//+------------------------------------------------------------------+
bool COrderBlockDetector::HasVolumeSpike(int bar)
{
   long vol = iTickVolume(m_symbol, m_timeframe, bar);
   long sum = 0;
   for(int i = 1; i <= 10; i++)
      sum += iTickVolume(m_symbol, m_timeframe, bar + i);
   double avg = sum / 10.0;
   return vol > avg * m_volume_factor;
}

//+------------------------------------------------------------------+
//| Detect Bullish OB                                                 |
//+------------------------------------------------------------------+
COB* COrderBlockDetector::DetectBullishOB()
{
   for(int bar = 2; bar < m_lookback_bars; bar++)
   {
      bool bearish_prev = (iClose(m_symbol, m_timeframe, bar + 1) < iOpen(m_symbol, m_timeframe, bar + 1));
      if(!bearish_prev || !IsDisplacementCandle(bar, true) || !HasVolumeSpike(bar))
         continue;
      double prev_high = iHigh(m_symbol, m_timeframe, bar + 1);
      if(iClose(m_symbol, m_timeframe, bar) <= prev_high) continue;
      
      COB* ob = new COB();
      ob.time_start = iTime(m_symbol, m_timeframe, bar + 1);
      ob.high = iHigh(m_symbol, m_timeframe, bar + 1);
      ob.low = iLow(m_symbol, m_timeframe, bar + 1);
      ob.mid = (ob.high + ob.low) / 2.0;
      ob.bar_index = bar + 1;
      ob.is_bullish = true;
      ob.volume = (double)iTickVolume(m_symbol, m_timeframe, bar + 1);
      ob.strength = MathMin(1.0, (ob.high - ob.low) / (m_atr_value * 2));
      m_order_blocks.Add(ob);
      return ob;
   }
   return NULL;
}

//+------------------------------------------------------------------+
//| Detect Bearish OB                                                 |
//+------------------------------------------------------------------+
COB* COrderBlockDetector::DetectBearishOB()
{
   for(int bar = 2; bar < m_lookback_bars; bar++)
   {
      bool bullish_prev = (iClose(m_symbol, m_timeframe, bar + 1) > iOpen(m_symbol, m_timeframe, bar + 1));
      if(!bullish_prev || !IsDisplacementCandle(bar, false) || !HasVolumeSpike(bar))
         continue;
      double prev_low = iLow(m_symbol, m_timeframe, bar + 1);
      if(iClose(m_symbol, m_timeframe, bar) >= prev_low) continue;
      
      COB* ob = new COB();
      ob.time_start = iTime(m_symbol, m_timeframe, bar + 1);
      ob.high = iHigh(m_symbol, m_timeframe, bar + 1);
      ob.low = iLow(m_symbol, m_timeframe, bar + 1);
      ob.mid = (ob.high + ob.low) / 2.0;
      ob.bar_index = bar + 1;
      ob.is_bullish = false;
      ob.volume = (double)iTickVolume(m_symbol, m_timeframe, bar + 1);
      ob.strength = MathMin(1.0, (ob.high - ob.low) / (m_atr_value * 2));
      m_order_blocks.Add(ob);
      return ob;
   }
   return NULL;
}

//+------------------------------------------------------------------+
//| Check mitigation                                                  |
//+------------------------------------------------------------------+
void COrderBlockDetector::CheckMitigation()
{
   double curr = iClose(m_symbol, m_timeframe, 0);
   double prev = iClose(m_symbol, m_timeframe, 1);
   for(int i = m_order_blocks.Total() - 1; i >= 0; i--)
   {
      COB* ob = m_order_blocks.At(i);
      if(ob.is_mitigated) continue;
      bool mitigated = false;
      if(ob.is_bullish)
         mitigated = (curr < ob.low && prev >= ob.low);
      else
         mitigated = (curr > ob.high && prev <= ob.high);
      if(mitigated)
      {
         ob.is_mitigated = true;
         ob.time_end = iTime(m_symbol, m_timeframe, 0);
         m_mitigated_obs.Add(ob);
         m_order_blocks.Delete(i);
      }
   }
}

//+------------------------------------------------------------------+
//| Get nearest bullish OB                                            |
//+------------------------------------------------------------------+
COB* COrderBlockDetector::GetNearestBullishOB()
{
   COB* nearest = NULL;
   int nearest_dist = 999999;
   int curr_bar = Bars(m_symbol, m_timeframe);
   for(int i = 0; i < m_order_blocks.Total(); i++)
   {
      COB* ob = m_order_blocks.At(i);
      if(!ob.is_bullish || ob.is_mitigated) continue;
      int dist = curr_bar - ob.bar_index;
      if(dist < nearest_dist)
      {
         nearest_dist = dist;
         nearest = ob;
      }
   }
   return nearest;
}

//+------------------------------------------------------------------+
//| Get nearest bearish OB                                            |
//+------------------------------------------------------------------+
COB* COrderBlockDetector::GetNearestBearishOB()
{
   COB* nearest = NULL;
   int nearest_dist = 999999;
   int curr_bar = Bars(m_symbol, m_timeframe);
   for(int i = 0; i < m_order_blocks.Total(); i++)
   {
      COB* ob = m_order_blocks.At(i);
      if(ob.is_bullish || ob.is_mitigated) continue;
      int dist = curr_bar - ob.bar_index;
      if(dist < nearest_dist)
      {
         nearest_dist = dist;
         nearest = ob;
      }
   }
   return nearest;
}

//+------------------------------------------------------------------+
//| Get optimal entry (OTE)                                           |
//+------------------------------------------------------------------+
double COrderBlockDetector::GetOptimalEntry(COB* ob)
{
   if(ob == NULL) return 0;
   double range = ob.high - ob.low;
   if(ob.is_bullish)
      return ob.low + range * 0.705;
   else
      return ob.high - range * 0.705;
}

//+------------------------------------------------------------------+
//| Get stop loss level                                               |
//+------------------------------------------------------------------+
double COrderBlockDetector::GetStopLossLevel(COB* ob, bool is_buy)
{
   if(ob == NULL) return 0;
   double buffer = m_atr_value * 0.3;
   if(is_buy)
      return ob.low - buffer;
   else
      return ob.high + buffer;
}

//+------------------------------------------------------------------+
//| OnBar handler                                                     |
//+------------------------------------------------------------------+
void COrderBlockDetector::OnBar()
{
   int atr_handle = iATR(m_symbol, m_timeframe, m_atr_period);
   double buf[1];
   if(CopyBuffer(atr_handle, 0, 1, 1, buf) > 0)
      m_atr_value = buf[0];
   IndicatorRelease(atr_handle);
   
   DetectBullishOB();
   DetectBearishOB();
   CheckMitigation();
   while(m_order_blocks.Total() > m_max_obs)
      delete m_order_blocks.Detach(m_order_blocks.Total() - 1);
}
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+


#endif // MD90_ORDER_BLOCK_DETECTOR_MQH
