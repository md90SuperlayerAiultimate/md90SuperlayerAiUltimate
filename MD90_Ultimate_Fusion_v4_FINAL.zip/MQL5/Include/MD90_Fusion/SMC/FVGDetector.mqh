//|                                            FVGDetector.mqh       |
//|                                      MD90 Ultimate Fusion v2.0   |
//+------------------------------------------------------------------+
#ifndef MD90_FVG_DETECTOR_MQH
#define MD90_FVG_DETECTOR_MQH

#property copyright "MD90 Systems"
#property link      "https://www.mql5.com"
#property version   "2.00"

#include <Arrays\ArrayObj.mqh>
#include "../Common/Constants.mqh"
#include "../Common/Utils.mqh"

//+------------------------------------------------------------------+
//| Fair Value Gap Class                                              |
//+------------------------------------------------------------------+
class CFVG : public CObject
{
public:
   datetime   time_start;
   datetime   time_end;
   double     upper;
   double     lower;
   double     mid;
   int        bar_index;
   bool       is_bullish;
   bool       is_filled;
   bool       is_inverse;
   double     fill_percent;
   double     volume_imbalance;
   double     atr_multiple;
   
   CFVG()
   {
      time_start = 0;
      time_end = 0;
      upper = 0;
      lower = 0;
      mid = 0;
      bar_index = 0;
      is_bullish = true;
      is_filled = false;
      is_inverse = false;
      fill_percent = 0;
      volume_imbalance = 1.0;
      atr_multiple = 0;
   }
};

//+------------------------------------------------------------------+
//| FVG Detector Class                                                |
//+------------------------------------------------------------------+
class CFVGDetector
{
private:
   string            m_symbol;
   ENUM_TIMEFRAMES   m_timeframe;
   CArrayObj         m_fvgs;
   CArrayObj         m_filled_fvgs;
   int               m_max_fvgs;
   int               m_lookback_bars;
   double            m_min_gap_size;
   double            m_atr_value;
   int               m_atr_period;
   
   bool              IsBullishFVG(int bar);
   bool              IsBearishFVG(int bar);
   void              CheckFills();
   
public:
   CFVGDetector();
   ~CFVGDetector();
   bool              Init(string symbol, ENUM_TIMEFRAMES tf);
   void              Deinit();
   void              OnBar();
   CFVG*             DetectBullishFVG();
   CFVG*             DetectBearishFVG();
   CFVG*             GetUnfilledFVG(bool bullish);
};

//+------------------------------------------------------------------+
//| Constructor                                                       |
//+------------------------------------------------------------------+
CFVGDetector::CFVGDetector()
{
   m_symbol = "";
   m_timeframe = PERIOD_CURRENT;
   m_max_fvgs = 30;
   m_lookback_bars = 200;
   m_min_gap_size = 0.2;
   m_atr_value = 0;
   m_atr_period = 14;
}

//+------------------------------------------------------------------+
//| Destructor                                                        |
//+------------------------------------------------------------------+
CFVGDetector::~CFVGDetector()
{
   Deinit();
}

//+------------------------------------------------------------------+
//| Deinitialize                                                      |
//+------------------------------------------------------------------+
void CFVGDetector::Deinit()
{
   for(int i = m_fvgs.Total() - 1; i >= 0; i--)
      delete m_fvgs.At(i);
   for(int i = m_filled_fvgs.Total() - 1; i >= 0; i--)
      delete m_filled_fvgs.At(i);
   m_fvgs.Clear();
   m_filled_fvgs.Clear();
}

//+------------------------------------------------------------------+
//| Initialize                                                        |
//+------------------------------------------------------------------+
bool CFVGDetector::Init(string symbol, ENUM_TIMEFRAMES tf)
{
   m_symbol = symbol;
   m_timeframe = tf;
   int atr_handle = iATR(m_symbol, m_timeframe, m_atr_period);
   if(atr_handle == INVALID_HANDLE) return false;
   double buf[1];
   if(CopyBuffer(atr_handle, 0, 0, 1, buf) > 0)
      m_atr_value = buf[0];
   IndicatorRelease(atr_handle);
   return true;
}

//+------------------------------------------------------------------+
//| Check Bullish FVG                                                 |
//+------------------------------------------------------------------+
bool CFVGDetector::IsBullishFVG(int bar)
{
   double low_2 = iLow(m_symbol, m_timeframe, bar + 2);
   double high_0 = iHigh(m_symbol, m_timeframe, bar);
   if(low_2 <= high_0) return false;
   double gap = low_2 - high_0;
   if(gap < m_min_gap_size * m_atr_value) return false;
   double body_1 = MathAbs(iClose(m_symbol, m_timeframe, bar + 1) - iOpen(m_symbol, m_timeframe, bar + 1));
   double range_1 = iHigh(m_symbol, m_timeframe, bar + 1) - iLow(m_symbol, m_timeframe, bar + 1);
   if(range_1 == 0 || body_1 / range_1 < 0.5) return false;
   return iClose(m_symbol, m_timeframe, bar + 1) > iOpen(m_symbol, m_timeframe, bar + 1);
}

//+------------------------------------------------------------------+
//| Check Bearish FVG                                                 |
//+------------------------------------------------------------------+
bool CFVGDetector::IsBearishFVG(int bar)
{
   // Bearish FVG: bar[bar+2].low > bar[bar].high  (gap descending)
   // bar[bar+2] = oldest candle, bar[bar+1] = impulse, bar[bar] = newest
   double low_2  = iLow(m_symbol, m_timeframe, bar + 2);
   double high_0 = iHigh(m_symbol, m_timeframe, bar);
   if(low_2 <= high_0) return false;      // no gap downward
   double gap = low_2 - high_0;
   if(gap < m_min_gap_size * m_atr_value) return false;
   double body_1 = MathAbs(iClose(m_symbol, m_timeframe, bar + 1) - iOpen(m_symbol, m_timeframe, bar + 1));
   double range_1 = iHigh(m_symbol, m_timeframe, bar + 1) - iLow(m_symbol, m_timeframe, bar + 1);
   if(range_1 == 0 || body_1 / range_1 < 0.5) return false;
   return iClose(m_symbol, m_timeframe, bar + 1) < iOpen(m_symbol, m_timeframe, bar + 1);
}

//+------------------------------------------------------------------+
//| Detect Bullish FVG                                                |
//+------------------------------------------------------------------+
CFVG* CFVGDetector::DetectBullishFVG()
{
   for(int bar = 0; bar < m_lookback_bars - 3; bar++)
   {
      if(!IsBullishFVG(bar)) continue;
      bool exists = false;
      for(int i = 0; i < m_fvgs.Total(); i++)
      {
         CFVG* f = m_fvgs.At(i);
         if(ApproxEqual(f.upper, iLow(m_symbol, m_timeframe, bar + 2)) &&
            ApproxEqual(f.lower, iHigh(m_symbol, m_timeframe, bar)))
            { exists = true; break; }
      }
      if(exists) continue;
      
      CFVG* fvg = new CFVG();
      fvg.time_start = iTime(m_symbol, m_timeframe, bar);
      fvg.upper = iLow(m_symbol, m_timeframe, bar + 2);
      fvg.lower = iHigh(m_symbol, m_timeframe, bar);
      fvg.mid = (fvg.upper + fvg.lower) / 2.0;
      fvg.bar_index = bar;
      fvg.is_bullish = true;
      m_fvgs.Add(fvg);
      return fvg;
   }
   return NULL;
}

//+------------------------------------------------------------------+
//| Detect Bearish FVG                                                |
//+------------------------------------------------------------------+
CFVG* CFVGDetector::DetectBearishFVG()
{
   for(int bar = 0; bar < m_lookback_bars - 3; bar++)
   {
      if(!IsBearishFVG(bar)) continue;
      bool exists = false;
      for(int i = 0; i < m_fvgs.Total(); i++)
      {
         CFVG* f = m_fvgs.At(i);
         if(ApproxEqual(f.upper, iLow(m_symbol, m_timeframe, bar + 2)) &&
            ApproxEqual(f.lower, iHigh(m_symbol, m_timeframe, bar)))
            { exists = true; break; }
      }
      if(exists) continue;
      
      CFVG* fvg = new CFVG();
      fvg.time_start = iTime(m_symbol, m_timeframe, bar);
      // Bearish FVG zone: upper = bar[bar+2].low (top of gap), lower = bar[bar].high (bottom)
      fvg.upper = iLow(m_symbol, m_timeframe, bar + 2);
      fvg.lower = iHigh(m_symbol, m_timeframe, bar);
      fvg.mid = (fvg.upper + fvg.lower) / 2.0;
      fvg.bar_index = bar;
      fvg.is_bullish = false;
      m_fvgs.Add(fvg);
      return fvg;
   }
   return NULL;
}

//+------------------------------------------------------------------+
//| Check fills                                                       |
//+------------------------------------------------------------------+
void CFVGDetector::CheckFills()
{
   double curr_high = iHigh(m_symbol, m_timeframe, 0);
   double curr_low = iLow(m_symbol, m_timeframe, 0);
   for(int i = m_fvgs.Total() - 1; i >= 0; i--)
   {
      CFVG* fvg = m_fvgs.At(i);
      bool filled = false;
      if(fvg.is_bullish)
      {
         if(curr_low <= fvg.lower)
            filled = true;
      }
      else
      {
         if(curr_high >= fvg.upper)
            filled = true;
      }
      if(filled)
      {
         fvg.is_filled = true;
         fvg.time_end = iTime(m_symbol, m_timeframe, 0);
         m_filled_fvgs.Add(fvg);
         m_fvgs.Delete(i);
      }
   }
}

//+------------------------------------------------------------------+
//| Get unfilled FVG                                                  |
//+------------------------------------------------------------------+
CFVG* CFVGDetector::GetUnfilledFVG(bool bullish)
{
   for(int i = 0; i < m_fvgs.Total(); i++)
   {
      CFVG* fvg = m_fvgs.At(i);
      if(fvg.is_bullish == bullish && !fvg.is_filled)
         return fvg;
   }
   return NULL;
}

//+------------------------------------------------------------------+
//| OnBar handler                                                     |
//+------------------------------------------------------------------+
void CFVGDetector::OnBar()
{
   int atr_handle = iATR(m_symbol, m_timeframe, m_atr_period);
   double buf[1];
   if(CopyBuffer(atr_handle, 0, 1, 1, buf) > 0)
      m_atr_value = buf[0];
   IndicatorRelease(atr_handle);
   
   DetectBullishFVG();
   DetectBearishFVG();
   CheckFills();
   while(m_fvgs.Total() > m_max_fvgs)
      delete m_fvgs.Detach(m_fvgs.Total() - 1);
}
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+


#endif // MD90_FVG_DETECTOR_MQH
