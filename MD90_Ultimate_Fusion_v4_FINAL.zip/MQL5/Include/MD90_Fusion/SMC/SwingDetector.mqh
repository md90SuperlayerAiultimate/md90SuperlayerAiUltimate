//|                                            SwingDetector.mqh     |
//|                                      MD90 Ultimate Fusion v2.0   |
//+------------------------------------------------------------------+
#ifndef MD90_SWING_DETECTOR_MQH
#define MD90_SWING_DETECTOR_MQH

#property copyright "MD90 Systems"
#property link      "https://www.mql5.com"
#property version   "2.00"

#include <Arrays\ArrayDouble.mqh>
#include <Arrays\ArrayInt.mqh>
#include "../Common/Constants.mqh"

//+------------------------------------------------------------------+
//| Swing Detector Class                                              |
//+------------------------------------------------------------------+
class CSwingDetector
{
private:
   string            m_symbol;
   ENUM_TIMEFRAMES   m_timeframe;
   int               m_swing_length;
   
   CArrayDouble      m_swing_highs;
   CArrayDouble      m_swing_lows;
   CArrayInt         m_swing_high_bars;
   CArrayInt         m_swing_low_bars;
   
   double            m_last_swing_high;
   double            m_last_swing_low;
   int               m_last_swing_high_bar;
   int               m_last_swing_low_bar;
   
   bool              m_bullish_structure;
   bool              m_bearish_structure;
   int               m_trend_state;
   
   bool              IsPivotHigh(int bar);
   bool              IsPivotLow(int bar);
   void              UpdateStructureState();
   void              CleanOldSwings(int max_bars);
   
public:
   CSwingDetector();
   ~CSwingDetector();
   bool              Init(string symbol, ENUM_TIMEFRAMES tf, int swing_len = 5);
   void              OnBar();
   
   double            GetLastSwingHigh() const { return m_last_swing_high; }
   double            GetLastSwingLow() const  { return m_last_swing_low; }
   bool              IsBOSBullish();
   bool              IsBOSBearish();
   bool              IsCHoCHBullish();
   bool              IsCHoCHBearish();
   int               GetTrendState() const { return m_trend_state; }
   bool              IsBullishStructure() const { return m_bullish_structure; }
   bool              IsBearishStructure() const { return m_bearish_structure; }
};

//+------------------------------------------------------------------+
//| Constructor                                                       |
//+------------------------------------------------------------------+
CSwingDetector::CSwingDetector()
{
   m_symbol = "";
   m_timeframe = PERIOD_CURRENT;
   m_swing_length = SWING_DETECTION_BARS;
   m_last_swing_high = 0;
   m_last_swing_low = DBL_MAX;
   m_last_swing_high_bar = 0;
   m_last_swing_low_bar = 0;
   m_bullish_structure = false;
   m_bearish_structure = false;
   m_trend_state = 0;
}

//+------------------------------------------------------------------+
//| Destructor                                                        |
//+------------------------------------------------------------------+
CSwingDetector::~CSwingDetector()
{
   m_swing_highs.Clear();
   m_swing_lows.Clear();
   m_swing_high_bars.Clear();
   m_swing_low_bars.Clear();
}

//+------------------------------------------------------------------+
//| Initialize                                                        |
//+------------------------------------------------------------------+
bool CSwingDetector::Init(string symbol, ENUM_TIMEFRAMES tf, int swing_len = 5)
{
   m_symbol = symbol;
   m_timeframe = tf;
   m_swing_length = swing_len;
   return true;
}

//+------------------------------------------------------------------+
//| Check if bar is pivot high                                        |
//+------------------------------------------------------------------+
bool CSwingDetector::IsPivotHigh(int bar)
{
   if(bar < m_swing_length || bar > Bars(m_symbol, m_timeframe) - m_swing_length - 1)
      return false;
   
   double high_val = iHigh(m_symbol, m_timeframe, bar);
   for(int i = 1; i <= m_swing_length; i++)
   {
      if(iHigh(m_symbol, m_timeframe, bar - i) >= high_val) return false;
      if(iHigh(m_symbol, m_timeframe, bar + i) >= high_val) return false;
   }
   return true;
}

//+------------------------------------------------------------------+
//| Check if bar is pivot low                                         |
//+------------------------------------------------------------------+
bool CSwingDetector::IsPivotLow(int bar)
{
   if(bar < m_swing_length || bar > Bars(m_symbol, m_timeframe) - m_swing_length - 1)
      return false;
   
   double low_val = iLow(m_symbol, m_timeframe, bar);
   for(int i = 1; i <= m_swing_length; i++)
   {
      if(iLow(m_symbol, m_timeframe, bar - i) <= low_val) return false;
      if(iLow(m_symbol, m_timeframe, bar + i) <= low_val) return false;
   }
   return true;
}

//+------------------------------------------------------------------+
//| Update structure state                                            |
//+------------------------------------------------------------------+
void CSwingDetector::UpdateStructureState()
{
   int size_highs = m_swing_highs.Total();
   int size_lows = m_swing_lows.Total();
   if(size_highs < 2 || size_lows < 2) return;
   
   double curr_high = m_swing_highs.At(size_highs - 1);
   double prev_high = m_swing_highs.At(size_highs - 2);
   double curr_low = m_swing_lows.At(size_lows - 1);
   double prev_low = m_swing_lows.At(size_lows - 2);
   
   m_bullish_structure = (curr_high > prev_high) && (curr_low > prev_low);
   m_bearish_structure = (curr_high < prev_high) && (curr_low < prev_low);
   
   if(m_bullish_structure) m_trend_state = 1;
   else if(m_bearish_structure) m_trend_state = -1;
   else m_trend_state = 0;
}

//+------------------------------------------------------------------+
//| Clean old swings                                                  |
//+------------------------------------------------------------------+
void CSwingDetector::CleanOldSwings(int max_bars)
{
   int current_bar = Bars(m_symbol, m_timeframe);
   for(int i = m_swing_highs.Total() - 1; i >= 0; i--)
   {
      if(current_bar - m_swing_high_bars.At(i) > max_bars)
      {
         m_swing_highs.Delete(i);
         m_swing_high_bars.Delete(i);
      }
   }
   for(int i = m_swing_lows.Total() - 1; i >= 0; i--)
   {
      if(current_bar - m_swing_low_bars.At(i) > max_bars)
      {
         m_swing_lows.Delete(i);
         m_swing_low_bars.Delete(i);
      }
   }
}

//+------------------------------------------------------------------+
//| OnBar handler                                                     |
//+------------------------------------------------------------------+
void CSwingDetector::OnBar()
{
   int total_bars = Bars(m_symbol, m_timeframe);
   int check_bar = 1;
   
   if(IsPivotHigh(check_bar))
   {
      double high_val = iHigh(m_symbol, m_timeframe, check_bar);
      m_swing_highs.Add(high_val);
      m_swing_high_bars.Add(total_bars - check_bar);
      m_last_swing_high = high_val;
      m_last_swing_high_bar = total_bars - check_bar;
   }
   if(IsPivotLow(check_bar))
   {
      double low_val = iLow(m_symbol, m_timeframe, check_bar);
      m_swing_lows.Add(low_val);
      m_swing_low_bars.Add(total_bars - check_bar);
      m_last_swing_low = low_val;
      m_last_swing_low_bar = total_bars - check_bar;
   }
   UpdateStructureState();
   CleanOldSwings(100);
}

//+------------------------------------------------------------------+
//| BOS Bullish                                                       |
//+------------------------------------------------------------------+
bool CSwingDetector::IsBOSBullish()
{
   if(m_last_swing_high == 0) return false;
   double curr = iClose(m_symbol, m_timeframe, 0);
   double prev = iClose(m_symbol, m_timeframe, 1);
   return (curr > m_last_swing_high && prev <= m_last_swing_high);
}

//+------------------------------------------------------------------+
//| BOS Bearish                                                       |
//+------------------------------------------------------------------+
bool CSwingDetector::IsBOSBearish()
{
   if(m_last_swing_low == DBL_MAX) return false;
   double curr = iClose(m_symbol, m_timeframe, 0);
   double prev = iClose(m_symbol, m_timeframe, 1);
   return (curr < m_last_swing_low && prev >= m_last_swing_low);
}

//+------------------------------------------------------------------+
//| CHoCH Bullish                                                     |
//+------------------------------------------------------------------+
bool CSwingDetector::IsCHoCHBullish()
{
   if(!m_bearish_structure) return false;
   return IsBOSBullish();
}

//+------------------------------------------------------------------+
//| CHoCH Bearish                                                     |
//+------------------------------------------------------------------+
bool CSwingDetector::IsCHoCHBearish()
{
   if(!m_bullish_structure) return false;
   return IsBOSBearish();
}
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+


#endif // MD90_SWING_DETECTOR_MQH
