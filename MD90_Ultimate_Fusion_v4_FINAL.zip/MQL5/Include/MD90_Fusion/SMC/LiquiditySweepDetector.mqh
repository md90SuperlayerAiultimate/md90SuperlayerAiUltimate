//|                                   LiquiditySweepDetector.mqh     |
//|                                      MD90 Ultimate Fusion v2.0   |
//+------------------------------------------------------------------+
#ifndef MD90_LIQUIDITY_SWEEP_DETECTOR_MQH
#define MD90_LIQUIDITY_SWEEP_DETECTOR_MQH

#property copyright "MD90 Systems"
#property link      "https://www.mql5.com"
#property version   "2.00"

#include <Arrays\ArrayObj.mqh>
#include "../Common/Constants.mqh"

//+------------------------------------------------------------------+
//| Liquidity Sweep Class                                             |
//+------------------------------------------------------------------+
class CLiqSweep : public CObject
{
public:
   datetime   time;
   double     level;
   double     wick_price;
   int        bar_index;
   bool       is_buy_sweep;
   bool       is_sell_sweep;
   double     volume;
   double     wick_size;
   bool       is_confirmed;
   double     reversal_close;
   
   CLiqSweep()
   {
      time = 0;
      level = 0;
      wick_price = 0;
      bar_index = 0;
      is_buy_sweep = false;
      is_sell_sweep = false;
      volume = 0;
      wick_size = 0;
      is_confirmed = false;
      reversal_close = 0;
   }
};

//+------------------------------------------------------------------+
//| Liquidity Sweep Detector Class                                    |
//+------------------------------------------------------------------+
class CLiquiditySweepDetector
{
private:
   string            m_symbol;
   ENUM_TIMEFRAMES   m_timeframe;
   CArrayObj         m_sweeps;
   int               m_lookback_bars;
   double            m_atr_value;
   int               m_atr_period;
   double            m_sweep_threshold;
   double            m_volume_threshold;
   
   double            GetSwingHigh(int lookback);
   double            GetSwingLow(int lookback);
   bool              IsLiquiditySweep(int bar, bool check_highs);
   double            GetWickSize(int bar, bool check_highs);
   bool              HasReversalConfirmation(int bar, bool bullish);
   void              CleanOldSweeps();
   
public:
   CLiquiditySweepDetector();
   ~CLiquiditySweepDetector();
   bool              Init(string symbol, ENUM_TIMEFRAMES tf);
   void              Deinit();
   void              OnBar();
   CLiqSweep*        DetectBuySweep();
   CLiqSweep*        DetectSellSweep();
   CLiqSweep*        GetLastBuySweep();
   CLiqSweep*        GetLastSellSweep();
   bool              HasRecentSweep(int bars_back);
};

//+------------------------------------------------------------------+
//| Constructor                                                       |
//+------------------------------------------------------------------+
CLiquiditySweepDetector::CLiquiditySweepDetector()
{
   m_symbol = "";
   m_timeframe = PERIOD_CURRENT;
   m_lookback_bars = 50;
   m_atr_value = 0;
   m_atr_period = 14;
   m_sweep_threshold = 0.5;
   m_volume_threshold = 1.5;
}

//+------------------------------------------------------------------+
//| Destructor                                                        |
//+------------------------------------------------------------------+
CLiquiditySweepDetector::~CLiquiditySweepDetector()
{
   Deinit();
}

//+------------------------------------------------------------------+
//| Deinitialize                                                      |
//+------------------------------------------------------------------+
void CLiquiditySweepDetector::Deinit()
{
   for(int i = m_sweeps.Total() - 1; i >= 0; i--)
      delete m_sweeps.At(i);
   m_sweeps.Clear();
}

//+------------------------------------------------------------------+
//| Initialize                                                        |
//+------------------------------------------------------------------+
bool CLiquiditySweepDetector::Init(string symbol, ENUM_TIMEFRAMES tf)
{
   m_symbol = symbol;
   m_timeframe = tf;
   int atr_handle = iATR(m_symbol, m_timeframe, m_atr_period);
   if(atr_handle == INVALID_HANDLE) return false;
   double buf[1];
   if(CopyBuffer(atr_handle, 0, 0, 1, buf) > 0)
      m_atr_value = buf[0];
   IndicatorRelease(atr_handle);
   return true;
}

//+------------------------------------------------------------------+
//| Get swing high                                                    |
//+------------------------------------------------------------------+
double CLiquiditySweepDetector::GetSwingHigh(int lookback)
{
   double highest = 0;
   for(int i = 1; i <= lookback; i++)
   {
      double h = iHigh(m_symbol, m_timeframe, i);
      if(h > highest) highest = h;
   }
   return highest;
}

//+------------------------------------------------------------------+
//| Get swing low                                                     |
//+------------------------------------------------------------------+
double CLiquiditySweepDetector::GetSwingLow(int lookback)
{
   double lowest = DBL_MAX;
   for(int i = 1; i <= lookback; i++)
   {
      double l = iLow(m_symbol, m_timeframe, i);
      if(l < lowest) lowest = l;
   }
   return lowest;
}

//+------------------------------------------------------------------+
//| Get wick size                                                     |
//+------------------------------------------------------------------+
double CLiquiditySweepDetector::GetWickSize(int bar, bool check_highs)
{
   double high = iHigh(m_symbol, m_timeframe, bar);
   double low = iLow(m_symbol, m_timeframe, bar);
   double open = iOpen(m_symbol, m_timeframe, bar);
   double close = iClose(m_symbol, m_timeframe, bar);
   if(check_highs)
      return high - MathMax(open, close);
   else
      return MathMin(open, close) - low;
}

//+------------------------------------------------------------------+
//| Check liquidity sweep                                             |
//+------------------------------------------------------------------+
bool CLiquiditySweepDetector::IsLiquiditySweep(int bar, bool check_highs)
{
   double high = iHigh(m_symbol, m_timeframe, bar);
   double low = iLow(m_symbol, m_timeframe, bar);
   double close = iClose(m_symbol, m_timeframe, bar);
   double swing_level = check_highs ? GetSwingHigh(m_lookback_bars) : GetSwingLow(m_lookback_bars);
   if(swing_level == 0 || swing_level == DBL_MAX) return false;
   
   bool swept = check_highs ? (high > swing_level && close < swing_level) : (low < swing_level && close > swing_level);
   if(!swept) return false;
   
   double wick = GetWickSize(bar, check_highs);
   if(wick < m_sweep_threshold * m_atr_value) return false;
   
   long vol = iTickVolume(m_symbol, m_timeframe, bar);
   long avg_vol = 0;
   for(int i = 1; i <= 10; i++)
      avg_vol += iTickVolume(m_symbol, m_timeframe, bar + i);
   avg_vol /= 10;
   if(vol < avg_vol * m_volume_threshold) return false;
   
   return true;
}

//+------------------------------------------------------------------+
//| Check reversal confirmation                                       |
//+------------------------------------------------------------------+
bool CLiquiditySweepDetector::HasReversalConfirmation(int bar, bool bullish)
{
   double sweep_close = iClose(m_symbol, m_timeframe, bar);
   double next_close = iClose(m_symbol, m_timeframe, bar - 1);
   if(bullish)
      return next_close > sweep_close;
   else
      return next_close < sweep_close;
}

//+------------------------------------------------------------------+
//| Detect Buy Sweep                                                  |
//+------------------------------------------------------------------+
CLiqSweep* CLiquiditySweepDetector::DetectBuySweep()
{
   for(int bar = 1; bar < m_lookback_bars; bar++)
   {
      if(!IsLiquiditySweep(bar, false)) continue;
      bool exists = false;
      for(int i = 0; i < m_sweeps.Total(); i++)
      {
         CLiqSweep* s = m_sweeps.At(i);
         if(s.bar_index == bar && s.is_buy_sweep) { exists = true; break; }
      }
      if(exists) continue;
      
      CLiqSweep* sweep = new CLiqSweep();
      sweep.time = iTime(m_symbol, m_timeframe, bar);
      sweep.level = GetSwingLow(m_lookback_bars);
      sweep.wick_price = iLow(m_symbol, m_timeframe, bar);
      sweep.bar_index = bar;
      sweep.is_buy_sweep = true;
      sweep.volume = (double)iTickVolume(m_symbol, m_timeframe, bar);
      sweep.wick_size = GetWickSize(bar, false) / m_atr_value;
      sweep.is_confirmed = HasReversalConfirmation(bar, true);
      sweep.reversal_close = iClose(m_symbol, m_timeframe, bar - 1);
      m_sweeps.Add(sweep);
      return sweep;
   }
   return NULL;
}

//+------------------------------------------------------------------+
//| Detect Sell Sweep                                                 |
//+------------------------------------------------------------------+
CLiqSweep* CLiquiditySweepDetector::DetectSellSweep()
{
   for(int bar = 1; bar < m_lookback_bars; bar++)
   {
      if(!IsLiquiditySweep(bar, true)) continue;
      bool exists = false;
      for(int i = 0; i < m_sweeps.Total(); i++)
      {
         CLiqSweep* s = m_sweeps.At(i);
         if(s.bar_index == bar && s.is_sell_sweep) { exists = true; break; }
      }
      if(exists) continue;
      
      CLiqSweep* sweep = new CLiqSweep();
      sweep.time = iTime(m_symbol, m_timeframe, bar);
      sweep.level = GetSwingHigh(m_lookback_bars);
      sweep.wick_price = iHigh(m_symbol, m_timeframe, bar);
      sweep.bar_index = bar;
      sweep.is_sell_sweep = true;
      sweep.volume = (double)iTickVolume(m_symbol, m_timeframe, bar);
      sweep.wick_size = GetWickSize(bar, true) / m_atr_value;
      sweep.is_confirmed = HasReversalConfirmation(bar, false);
      sweep.reversal_close = iClose(m_symbol, m_timeframe, bar - 1);
      m_sweeps.Add(sweep);
      return sweep;
   }
   return NULL;
}

//+------------------------------------------------------------------+
//| Get last buy sweep                                                |
//+------------------------------------------------------------------+
CLiqSweep* CLiquiditySweepDetector::GetLastBuySweep()
{
   for(int i = 0; i < m_sweeps.Total(); i++)
   {
      CLiqSweep* s = m_sweeps.At(i);
      if(s.is_buy_sweep && s.is_confirmed)
         return s;
   }
   return NULL;
}

//+------------------------------------------------------------------+
//| Get last sell sweep                                               |
//+------------------------------------------------------------------+
CLiqSweep* CLiquiditySweepDetector::GetLastSellSweep()
{
   for(int i = 0; i < m_sweeps.Total(); i++)
   {
      CLiqSweep* s = m_sweeps.At(i);
      if(s.is_sell_sweep && s.is_confirmed)
         return s;
   }
   return NULL;
}

//+------------------------------------------------------------------+
//| Check recent sweep                                                |
//+------------------------------------------------------------------+
bool CLiquiditySweepDetector::HasRecentSweep(int bars_back)
{
   int curr_bar = Bars(m_symbol, m_timeframe);
   for(int i = 0; i < m_sweeps.Total(); i++)
   {
      CLiqSweep* s = m_sweeps.At(i);
      if(curr_bar - s.bar_index <= bars_back)
         return true;
   }
   return false;
}

//+------------------------------------------------------------------+
//| Clean old sweeps                                                  |
//+------------------------------------------------------------------+
void CLiquiditySweepDetector::CleanOldSweeps()
{
   int curr_bar = Bars(m_symbol, m_timeframe);
   for(int i = m_sweeps.Total() - 1; i >= 0; i--)
   {
      CLiqSweep* s = m_sweeps.At(i);
      if(curr_bar - s.bar_index > 100)
      {
         delete s;
         m_sweeps.Delete(i);
      }
   }
}

//+------------------------------------------------------------------+
//| OnBar handler                                                     |
//+------------------------------------------------------------------+
void CLiquiditySweepDetector::OnBar()
{
   int atr_handle = iATR(m_symbol, m_timeframe, m_atr_period);
   double buf[1];
   if(CopyBuffer(atr_handle, 0, 1, 1, buf) > 0)
      m_atr_value = buf[0];
   IndicatorRelease(atr_handle);
   
   DetectBuySweep();
   DetectSellSweep();
   CleanOldSweeps();
}
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+


#endif // MD90_LIQUIDITY_SWEEP_DETECTOR_MQH
