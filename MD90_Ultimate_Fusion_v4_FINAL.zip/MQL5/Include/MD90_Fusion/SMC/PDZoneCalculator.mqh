//+------------------------------------------------------------------+
//|                                             PDZoneCalculator.mqh |
//|                    MD90 Ultimate Fusion v4.0 - FINAL MERGE       |
//|                    v3: full SPDZone struct + 62.5/37.5 levels     |
//|                    v2: IsInPremium/IsInDiscount/GetEquilibrium    |
//+------------------------------------------------------------------+
#ifndef MD90_PD_ZONE_CALC_MQH
#define MD90_PD_ZONE_CALC_MQH

#include "../Common/Constants.mqh"
#include "../Common/Utils.mqh"

struct SPDZone
{
   double range_high, range_low, equilibrium;
   double premium_start, discount_start;
   double current_price, pd_position_pct;
   bool   in_premium, in_discount, at_equilibrium;
};

class CPDZoneCalculator
{
private:
   string            m_symbol;
   ENUM_TIMEFRAMES   m_timeframe;
   int               m_lookback;
   SPDZone           m_zone;

public:
   CPDZoneCalculator() : m_lookback(50) { m_symbol=_Symbol; m_timeframe=PERIOD_CURRENT; ZeroMemory(m_zone); }

   bool Init(string symbol, ENUM_TIMEFRAMES tf)
   { m_symbol=symbol; m_timeframe=tf; return true; }

   void OnBar() { Calculate(); }

   void Calculate()
   {
      double hi=-DBL_MAX, lo=DBL_MAX;
      int depth=MathMin(m_lookback, Bars(m_symbol,m_timeframe)-1);
      for(int i=1;i<=depth;i++)
      {
         hi=MathMax(hi,iHigh(m_symbol,m_timeframe,i));
         lo=MathMin(lo,iLow(m_symbol,m_timeframe,i));
      }
      m_zone.range_high    =hi;
      m_zone.range_low     =lo;
      m_zone.equilibrium   =lo+(hi-lo)*0.50;
      m_zone.premium_start =lo+(hi-lo)*0.625;
      m_zone.discount_start=lo+(hi-lo)*0.375;
      m_zone.current_price =iClose(m_symbol,m_timeframe,0);
      double rng=hi-lo;
      m_zone.pd_position_pct=(rng>0)?(m_zone.current_price-lo)/rng*100.0:50.0;
      m_zone.in_premium    =m_zone.current_price>=m_zone.premium_start;
      m_zone.in_discount   =m_zone.current_price<=m_zone.discount_start;
      m_zone.at_equilibrium=InRange(m_zone.current_price,m_zone.discount_start,m_zone.premium_start);
   }

   //--- v2 compat
   double GetEquilibrium() { Calculate(); return m_zone.equilibrium; }
   bool IsInPremium()      { Calculate(); return m_zone.in_premium;  }
   bool IsInDiscount()     { Calculate(); return m_zone.in_discount; }

   //--- v3 methods
   SPDZone GetZone()       const { return m_zone; }
   bool SuitableToBuy()    const { return m_zone.in_discount; }
   bool SuitableToSell()   const { return m_zone.in_premium;  }
   double GetPDPosition()  const { return m_zone.pd_position_pct; }
};

#endif // MD90_PD_ZONE_CALC_MQH
