//+------------------------------------------------------------------+
//|                                                      Logger.mqh  |
//|                    MD90 Ultimate Fusion v4.0 - FINAL             |
//+------------------------------------------------------------------+
#ifndef MD90_LOGGER_MQH
#define MD90_LOGGER_MQH

#include "Constants.mqh"

class CLogger
{
private:
   string            m_name;
   ENUM_LOG_LEVEL    m_level;
   bool              m_file_enabled;
   int               m_file_handle;

   string LevelTag(ENUM_LOG_LEVEL lv)
   {
      switch(lv)
      {
         case LOG_LEVEL_ERROR:   return "[ERROR]";
         case LOG_LEVEL_WARN:    return "[WARN] ";
         case LOG_LEVEL_INFO:    return "[INFO] ";
         case LOG_LEVEL_DEBUG:   return "[DEBUG]";
         case LOG_LEVEL_VERBOSE: return "[VERB] ";
         default:                return "[?????]";
      }
   }

public:
   CLogger() : m_name("MD90"), m_level(LOG_LEVEL_INFO),
               m_file_enabled(false), m_file_handle(INVALID_HANDLE) {}
   ~CLogger() { Close(); }

   void Init(string name, ENUM_LOG_LEVEL level=LOG_LEVEL_INFO, bool write_file=false)
   {
      m_name=name; m_level=level; m_file_enabled=write_file;
      if(write_file)
      {
         string fn=name+"_"+TimeToString(TimeCurrent(),TIME_DATE)+".log";
         m_file_handle=FileOpen(fn,FILE_WRITE|FILE_TXT|FILE_COMMON);
         if(m_file_handle==INVALID_HANDLE) m_file_enabled=false;
      }
   }

   void SetLevel(ENUM_LOG_LEVEL lv) { m_level=lv; }

   void Log(ENUM_LOG_LEVEL lv, const string &msg)
   {
      if(lv<m_level) return;
      string ts=TimeToString(TimeCurrent(),TIME_DATE|TIME_SECONDS);
      string out=ts+" "+LevelTag(lv)+" ["+m_name+"] "+msg;
      Print(out);
      if(m_file_enabled && m_file_handle!=INVALID_HANDLE)
         FileWriteString(m_file_handle, out+"\n");
   }

   void Debug(string msg)   { Log(LOG_LEVEL_DEBUG, msg); }
   void Info(string msg)    { Log(LOG_LEVEL_INFO,  msg); }
   void Warning(string msg) { Log(LOG_LEVEL_WARN,  msg); }
   void Warn(string msg)    { Log(LOG_LEVEL_WARN,  msg); }
   void Error(string msg)   { Log(LOG_LEVEL_ERROR, msg); }
   void Verbose(string msg) { Log(LOG_LEVEL_VERBOSE,msg); }

   void Flush()
   { if(m_file_enabled && m_file_handle!=INVALID_HANDLE) FileFlush(m_file_handle); }
   void Close()
   {
      if(m_file_enabled && m_file_handle!=INVALID_HANDLE)
      { FileFlush(m_file_handle); FileClose(m_file_handle); m_file_handle=INVALID_HANDLE; }
   }
};

// Global singleton (v3 pattern)
CLogger Logger;

#endif // MD90_LOGGER_MQH
