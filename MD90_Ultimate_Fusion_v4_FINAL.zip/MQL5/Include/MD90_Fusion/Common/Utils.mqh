//+------------------------------------------------------------------+
//|                                                        Utils.mqh |
//|                    MD90 Ultimate Fusion v4.0 - FINAL             |
//+------------------------------------------------------------------+
#ifndef MD90_UTILS_MQH
#define MD90_UTILS_MQH

#include "Constants.mqh"

//--- Safe division (v2)
double SafeDiv(double n, double d, double def=0.0) { return d!=0.0 ? n/d : def; }

//--- Hyperbolic tangent for score normalization (v2 - renamed to avoid clash)
double MD90_Tanh(double x)
{
   double ep=MathExp(x), en=MathExp(-x);
   return (ep-en)/(ep+en);
}

//--- Clamp (both v2 and v3)
double Clamp(double v,double lo,double hi) { return MathMax(lo,MathMin(hi,v)); }

//--- Lerp
double Lerp(double a,double b,double t) { return a+(b-a)*Clamp(t,0,1); }

//--- Approximate equality (v2)
bool ApproxEqual(double a,double b,double tol=0.000001) { return MathAbs(a-b)<=tol; }

//--- Range check
bool InRange(double v,double lo,double hi) { return v>=lo && v<=hi; }

//--- GMT hour (v2)
int GetGMTHour() { MqlDateTime dt; TimeGMT(dt); return dt.hour; }

//--- Day of week
int GetDayOfWeek() { MqlDateTime dt; TimeGMT(dt); return dt.day_of_week; }

//--- Pip helpers (v3)
double PipSize(const string sym=NULL)
{
   string s=(sym==NULL)?_Symbol:sym;
   double pt=SymbolInfoDouble(s,SYMBOL_POINT);
   int d=(int)SymbolInfoInteger(s,SYMBOL_DIGITS);
   return (d==3||d==5) ? pt*10.0 : pt;
}
double PriceToPips(double diff,const string sym=NULL) { return MathAbs(diff)/PipSize(sym); }
double PipsToPriceDiff(double pips,const string sym=NULL) { return pips*PipSize(sym); }

//--- Price normalization (v3)
double NormalizePrice(double price,const string sym=NULL)
{
   string s=(sym==NULL)?_Symbol:sym;
   return NormalizeDouble(price,(int)SymbolInfoInteger(s,SYMBOL_DIGITS));
}

//--- Lot normalization (v3)
double NormalizeLots(double lots,const string sym=NULL)
{
   string s=(sym==NULL)?_Symbol:sym;
   double lo=SymbolInfoDouble(s,SYMBOL_VOLUME_MIN);
   double hi=SymbolInfoDouble(s,SYMBOL_VOLUME_MAX);
   double st=SymbolInfoDouble(s,SYMBOL_VOLUME_STEP);
   lots=MathFloor(lots/st)*st;
   return NormalizeDouble(Clamp(lots,lo,hi),2);
}

//--- Broker fill mode (v3)
ENUM_ORDER_TYPE_FILLING GetBrokerFillMode(const string sym=NULL)
{
   string s=(sym==NULL)?_Symbol:sym;
   uint fill=(uint)SymbolInfoInteger(s,SYMBOL_FILLING_MODE);
   if((fill&SYMBOL_FILLING_IOC)!=0) return ORDER_FILLING_IOC;
   if((fill&SYMBOL_FILLING_FOK)!=0) return ORDER_FILLING_FOK;
   return ORDER_FILLING_RETURN;
}

//--- Account equity safe (v3)
double AccountEquitySafe()
{
   double eq=AccountInfoDouble(ACCOUNT_EQUITY);
   return (eq>0)?eq:AccountInfoDouble(ACCOUNT_BALANCE);
}

//--- Candle helpers (v3)
double CandleBody(const string sym,ENUM_TIMEFRAMES tf,int shift)
{ return MathAbs(iClose(sym,tf,shift)-iOpen(sym,tf,shift)); }
double CandleRange(const string sym,ENUM_TIMEFRAMES tf,int shift)
{ return iHigh(sym,tf,shift)-iLow(sym,tf,shift); }
bool IsBullishCandle(const string sym,ENUM_TIMEFRAMES tf,int shift)
{ return iClose(sym,tf,shift)>iOpen(sym,tf,shift); }

//--- String helpers (v3)
string BoolToStr(bool v) { return v?"true":"false"; }
string DirToStr(int d)   { return d>0?"BUY":(d<0?"SELL":"NEUTRAL"); }
string FormatDbl(double v,int dig=5) { return DoubleToString(v,dig); }

#endif // MD90_UTILS_MQH
