//+------------------------------------------------------------------+
//|                                                    Constants.mqh |
//|                    MD90 Ultimate Fusion v4.0 - FINAL             |
//|                    Combined v3 + v2 Architecture                  |
//+------------------------------------------------------------------+
#ifndef MD90_CONSTANTS_MQH
#define MD90_CONSTANTS_MQH

//--- EA Identity
#define EA_NAME                  "MD90_Ultimate_Fusion_v4"
#define EA_VERSION               "4.0.0"
#define EA_MAGIC_NUMBER          20250901

//--- Signal Direction Enum (v2 style - compatible with int comparison)
enum ENUM_SIGNAL_DIRECTION
{
   SIGNAL_NEUTRAL = 0,
   SIGNAL_BUY     = 1,
   SIGNAL_SELL    = -1
};

//--- Compatibility aliases (v3 used these names)
#define SIGNAL_NONE  SIGNAL_NEUTRAL

//--- Risk Mode Enum (v2)
enum ENUM_RISK_MODE
{
   RISK_FIXED_LOT       = 0,
   RISK_PERCENT_BALANCE = 1,
   RISK_PERCENT_EQUITY  = 2,
   RISK_ATR_BASED       = 3,
   RISK_KELLY           = 4
};

//--- Strategy Mode Enum (v2)
enum ENUM_STRATEGY_MODE
{
   STRATEGY_ULTRA_SCALPER = 0,
   STRATEGY_PRIME_SWING   = 1,
   STRATEGY_MACRO_FLOW    = 2,
   STRATEGY_FULL_FUSION   = 3
};

//--- Log Levels (v2 enum + v3 defines)
enum ENUM_LOG_LEVEL
{
   LOG_LEVEL_DEBUG   = 0,
   LOG_LEVEL_INFO    = 1,
   LOG_LEVEL_WARN    = 2,
   LOG_LEVEL_ERROR   = 3,
   LOG_LEVEL_VERBOSE = 4
};
#define LOG_NONE    4
#define LOG_ERROR   LOG_LEVEL_ERROR
#define LOG_WARN    LOG_LEVEL_WARN
#define LOG_INFO    LOG_LEVEL_INFO
#define LOG_DEBUG   LOG_LEVEL_DEBUG
#define LOG_VERBOSE LOG_LEVEL_VERBOSE

//--- Layer IDs (v3) — maps to v2's AnalyzeLayer1..17
#define LAYER_SNR            1   // Support/Resistance
#define LAYER_EMA            2   // EMA Stack
#define LAYER_RSI            3   // RSI
#define LAYER_STOCHASTIC     4   // Stochastic
#define LAYER_ORDER_BLOCK    5   // Order Block
#define LAYER_VOLUME         6   // Volume/Delta
#define LAYER_MTF            7   // Multi-Timeframe
#define LAYER_SENTIMENT      8   // Buy/Sell Pressure
#define LAYER_ULTRA_SCALPER  9   // Liquidity Sweep
#define LAYER_PRIME_SWING    10  // CHoCH / BOS
#define LAYER_MACRO_FLOW     11  // EMA200 Daily
#define LAYER_VWAP           12  // VWAP
#define LAYER_ATR_CONTEXT    13  // ATR Context
#define LAYER_OTE            14  // Optimal Trade Entry
#define LAYER_IDM_FVG        15  // IDM / FVG Confluence
#define LAYER_MASTER_CALL    16  // Candle Pattern
#define LAYER_TIMESTOP       17  // Session / Killzone
#define TOTAL_LAYERS         17

//--- Gate IDs (v3)
#define GATE_TREND           1
#define GATE_LOCATION        2
#define GATE_MOMENTUM        3
#define GATE_TRIGGER         4
#define GATE_RISK            5
#define TOTAL_GATES          5

//--- SMC Constants
#define SWING_DETECTION_BARS    5
#define ORDER_BLOCK_MAX_AGE     100
#define FVG_MAX_AGE             50
#define LIQUIDITY_LOOKBACK      20
#define OB_LOOKBACK             200
#define FVG_MIN_SIZE_ATR        0.2

//--- ATR Multipliers (v3: 6 TP levels)
#define ATR_SL_MULT             1.5
#define ATR_TP1_MULT            2.0
#define ATR_TP2_MULT            3.0
#define ATR_TP3_MULT            4.0
#define ATR_TP4_MULT            5.5
#define ATR_TP5_MULT            7.0
#define ATR_TP6_MULT            10.0

//--- Partial Close (v3)
#define PARTIAL_PCT_TP1         25.0
#define PARTIAL_PCT_TP2         25.0
#define PARTIAL_PCT_TP3         20.0
#define PARTIAL_PCT_TP4         15.0
#define PARTIAL_PCT_TP5         10.0

//--- Session Times (GMT)
#define SESSION_TOKYO_START     1
#define SESSION_TOKYO_END       9
#define SESSION_LONDON_START    8
#define SESSION_LONDON_CLOSE    17
#define SESSION_NY_START        13
#define SESSION_NY_CLOSE        22

//--- Risk Defaults
#define DEFAULT_RISK_PCT        1.0
#define MAX_RISK_PCT            3.0
#define MAX_DRAWDOWN_PERCENT    10.0
#define MAX_DAILY_LOSS_PERCENT  5.0
#define MAX_POSITIONS           3

//--- Signal Thresholds (v2)
#define FUSION_SCORE_MIN        0.55
#define CONFIDENCE_MIN          75.0
#define RR_MINIMUM              2.0

//--- Confidence levels (v3)
#define CONFIDENCE_LOW          0
#define CONFIDENCE_MEDIUM       1
#define CONFIDENCE_HIGH         2
#define CONFIDENCE_ULTRA        3

//+------------------------------------------------------------------+
//| Layer Signal Structure (v2) — result of each of 17 layers        |
//+------------------------------------------------------------------+
struct LayerSignal
{
   int         layer_id;
   string      layer_name;
   int         direction;     // SIGNAL_BUY / SIGNAL_SELL / SIGNAL_NEUTRAL
   double      strength;      // 0.0 - 1.0
   double      confidence;    // 0.0 - 100.0
   string      reason;
   datetime    timestamp;
};

//+------------------------------------------------------------------+
//| Fusion Signal Structure (v2 extended with v3 fields)             |
//+------------------------------------------------------------------+
struct FusionSignal
{
   int         direction;
   double      fusion_score;      // 0.0 - 1.0 weighted consensus
   double      confidence;        // 0.0 - 100.0
   int         buy_votes;
   int         sell_votes;
   int         neutral_votes;
   bool        gate1_passed;
   bool        gate2_passed;
   bool        gate3_passed;
   bool        gate4_passed;
   bool        gate5_passed;
   string      execution_status;  // "ALL-IN" / "WAITING" / "ABORT"
   double      entry_price;
   double      stop_loss;
   double      take_profit[6];    // v3: 6 TP levels
   double      risk_reward[6];
   datetime    signal_time;
   int         confidence_level;  // v3: CONFIDENCE_LOW..ULTRA
   double      lot_multiplier;    // v3: from confidence engine
   double      sl_multiplier;     // v3: from confidence engine
};

#endif // MD90_CONSTANTS_MQH
