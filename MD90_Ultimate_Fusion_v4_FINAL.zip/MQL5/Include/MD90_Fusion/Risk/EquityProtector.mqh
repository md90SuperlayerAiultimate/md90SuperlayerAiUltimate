//+------------------------------------------------------------------+
//|                                             EquityProtector.mqh  |
//|                    MD90 Ultimate Fusion v4.0 - FINAL MERGE       |
//|                    v3: peak equity tracking + IsHalted()          |
//|                    v2: daily reset + IsDailyLossLimitReached()    |
//+------------------------------------------------------------------+
#ifndef MD90_EQUITY_PROTECTOR_MQH
#define MD90_EQUITY_PROTECTOR_MQH

#include "../Common/Constants.mqh"
#include "../Common/Logger.mqh"
#include "../Common/Utils.mqh"

class CEquityProtector
{
private:
   double   m_max_dd_pct;
   double   m_max_daily_pct;
   double   m_initial_balance;
   double   m_daily_start;
   double   m_peak_equity;
   bool     m_daily_limit_reached;
   bool     m_halted;
   string   m_halt_reason;
   datetime m_last_day;

public:
   CEquityProtector()
    : m_max_dd_pct(MAX_DRAWDOWN_PERCENT), m_max_daily_pct(MAX_DAILY_LOSS_PERCENT),
      m_initial_balance(0), m_daily_start(0), m_peak_equity(0),
      m_daily_limit_reached(false), m_halted(false), m_halt_reason(""),
      m_last_day(0) {}

   void Init(double max_daily_loss=MAX_DAILY_LOSS_PERCENT,
             double max_drawdown=MAX_DRAWDOWN_PERCENT)
   {
      m_max_dd_pct       = max_drawdown;
      m_max_daily_pct    = max_daily_loss;
      m_initial_balance  = AccountInfoDouble(ACCOUNT_BALANCE);
      m_daily_start      = m_initial_balance;
      m_peak_equity      = AccountEquitySafe();
      m_halted           = false;
      m_halt_reason      = "";
      Logger.Info("EquityProtector: MaxDD="+FormatDbl(max_drawdown,1)+
                  "% MaxDaily="+FormatDbl(max_daily_loss,1)+"%");
   }

   //--- v3: Check() returns false if halted, updates peak, handles daily reset
   bool Check()
   {
      if(m_halted) return false;

      double equity=AccountEquitySafe();
      if(equity>m_peak_equity) m_peak_equity=equity;

      // New day reset
      MqlDateTime now_dt, last_dt;
      TimeToStruct(TimeCurrent(), now_dt);
      TimeToStruct(m_last_day,    last_dt);
      if(now_dt.day!=last_dt.day)
      { m_daily_start=AccountInfoDouble(ACCOUNT_BALANCE);
        m_daily_limit_reached=false;
        m_last_day=TimeCurrent();
        Logger.Info("EquityProtector daily reset. Balance="+FormatDbl(m_daily_start,2)); }

      if(GetCurrentDD()>=m_max_dd_pct)
      { m_halted=true; m_halt_reason="Max drawdown "+FormatDbl(GetCurrentDD(),1)+"% reached";
        Logger.Error("EquityProtector HALT: "+m_halt_reason); return false; }

      if(GetDailyLossPct()>=m_max_daily_pct)
      { m_halted=true; m_halt_reason="Daily loss "+FormatDbl(GetDailyLossPct(),1)+"% reached";
        Logger.Error("EquityProtector HALT: "+m_halt_reason); return false; }

      return true;
   }

   //--- v2 compat methods
   void ResetDailyBalance()
   { m_daily_start=AccountInfoDouble(ACCOUNT_BALANCE); m_daily_limit_reached=false; }

   bool IsDailyLossLimitReached()
   {
      if(m_daily_limit_reached) return true;
      if(GetDailyLossPct()>=m_max_daily_pct)
      { m_daily_limit_reached=true; return true; }
      return false;
   }

   bool IsMaxDrawdownReached() { return GetCurrentDD()>=m_max_dd_pct; }

   //--- v3 accessors
   bool   IsHalted()           const { return m_halted; }
   string GetHaltReason()      const { return m_halt_reason; }
   void   Reset()              { m_halted=false; m_halt_reason=""; }

   double GetCurrentDD() const
   {
      double eq=AccountEquitySafe();
      return (m_peak_equity>0) ? (m_peak_equity-eq)/m_peak_equity*100.0 : 0.0;
   }

   double GetDailyLossPct() const
   {
      double eq=AccountEquitySafe();
      return (m_daily_start>0) ? (m_daily_start-eq)/m_daily_start*100.0 : 0.0;
   }

   double GetCurrentDrawdownPercent() { return GetCurrentDD(); }
};

#endif // MD90_EQUITY_PROTECTOR_MQH
