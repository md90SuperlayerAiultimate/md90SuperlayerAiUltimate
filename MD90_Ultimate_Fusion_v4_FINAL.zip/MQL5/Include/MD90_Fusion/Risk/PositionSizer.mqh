//+------------------------------------------------------------------+
//|                                               PositionSizer.mqh  |
//|                    MD90 Ultimate Fusion v4.0 - FINAL             |
//|                    v2: ENUM_RISK_MODE + v3: lot_multiplier        |
//+------------------------------------------------------------------+
#ifndef MD90_POSITION_SIZER_MQH
#define MD90_POSITION_SIZER_MQH

#include "../Common/Constants.mqh"
#include "../Common/Utils.mqh"

class CPositionSizer
{
private:
   string         m_symbol;
   ENUM_RISK_MODE m_mode;
   double         m_risk_pct;
   double         m_fixed_lot;
   double         m_min_lot;
   double         m_max_lot;
   double         m_lot_multiplier;  // v3: from confidence engine

public:
   CPositionSizer()
   {
      m_symbol=""; m_mode=RISK_PERCENT_BALANCE;
      m_risk_pct=DEFAULT_RISK_PCT; m_fixed_lot=0.01;
      m_min_lot=0.01; m_max_lot=100.0; m_lot_multiplier=1.0;
   }

   void Init(string symbol, ENUM_RISK_MODE mode=RISK_PERCENT_BALANCE,
             double risk_pct=1.0, double fixed_lot=0.01)
   {
      m_symbol=symbol; m_mode=mode; m_risk_pct=risk_pct; m_fixed_lot=fixed_lot;
   }
   void SetLotLimits(double lo, double hi) { m_min_lot=lo; m_max_lot=hi; }
   void SetRiskPct(double pct)             { m_risk_pct=pct; }
   void SetLotMultiplier(double m)         { m_lot_multiplier=m; }

   double CalculateLotSize(double entry_price, double stop_loss)
   {
      if(m_mode==RISK_FIXED_LOT) return NormalizeLots(m_fixed_lot*m_lot_multiplier, m_symbol);

      double balance = (m_mode==RISK_PERCENT_EQUITY) ?
                       AccountInfoDouble(ACCOUNT_EQUITY) :
                       AccountInfoDouble(ACCOUNT_BALANCE);
      double risk_money=balance*m_risk_pct/100.0;

      double tick_val=SymbolInfoDouble(m_symbol,SYMBOL_TRADE_TICK_VALUE);
      double tick_sz =SymbolInfoDouble(m_symbol,SYMBOL_TRADE_TICK_SIZE);
      double vol_step=SymbolInfoDouble(m_symbol,SYMBOL_VOLUME_STEP);

      if(tick_val<=0||tick_sz<=0||vol_step<=0) return m_min_lot;
      double sl_ticks=MathAbs(entry_price-stop_loss)/tick_sz;
      if(sl_ticks<=0) return m_min_lot;

      double lot=risk_money/(sl_ticks*tick_val)*m_lot_multiplier;
      lot=MathFloor(lot/vol_step)*vol_step;
      return Clamp(NormalizeLots(lot,m_symbol), m_min_lot, m_max_lot);
   }
};

#endif // MD90_POSITION_SIZER_MQH
