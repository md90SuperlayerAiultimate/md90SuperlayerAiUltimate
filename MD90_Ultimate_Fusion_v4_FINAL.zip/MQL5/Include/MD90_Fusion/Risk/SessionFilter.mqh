//+------------------------------------------------------------------+
//|                                                SessionFilter.mqh |
//|                    MD90 Ultimate Fusion v4.0 - FINAL MERGE       |
//|                    v3: server offset support                       |
//|                    v2: GMT-based session detection                 |
//+------------------------------------------------------------------+
#ifndef MD90_SESSION_FILTER_MQH
#define MD90_SESSION_FILTER_MQH

#include "../Common/Constants.mqh"
#include "../Common/Logger.mqh"
#include "../Common/Utils.mqh"

class CSessionFilter
{
private:
   bool m_asia, m_london, m_ny, m_overlap_only;
   int  m_server_offset;

   bool IsAsian(int h)   { return h>=SESSION_TOKYO_START  && h<SESSION_TOKYO_END; }
   bool IsLondon(int h)  { return h>=SESSION_LONDON_START && h<SESSION_LONDON_CLOSE; }
   bool IsNY(int h)      { return h>=SESSION_NY_START     && h<SESSION_NY_CLOSE; }
   bool IsOverlap(int h) { return h>=SESSION_NY_START     && h<SESSION_LONDON_CLOSE; }

   int CurrentHour()
   {
      MqlDateTime dt; TimeGMT(dt);
      return (dt.hour - m_server_offset + 24) % 24;
   }

public:
   CSessionFilter() : m_asia(false), m_london(true), m_ny(true),
                      m_overlap_only(false), m_server_offset(0) {}

   //--- v2 Init signature
   void Init(bool asia, bool london, bool ny, bool overlap_only, int server_offset=0)
   {
      m_asia=asia; m_london=london; m_ny=ny;
      m_overlap_only=overlap_only; m_server_offset=server_offset;
      Logger.Info("SessionFilter: Asia="+BoolToStr(asia)+
                  " London="+BoolToStr(london)+" NY="+BoolToStr(ny));
   }

   bool IsTradingAllowed()
   {
      int h=CurrentHour();
      if(m_overlap_only) return IsOverlap(h);
      if(m_london && IsLondon(h)) return true;
      if(m_ny     && IsNY(h))     return true;
      if(m_asia   && IsAsian(h))  return true;
      return false;
   }

   string GetCurrentSession()
   {
      int h=CurrentHour();
      if(IsOverlap(h))  return "LONDON-NY OVERLAP";
      if(IsLondon(h))   return "LONDON";
      if(IsNY(h))       return "NEW YORK";
      if(IsAsian(h))    return "ASIAN";
      return "OFF HOURS";
   }

   bool IsLondonSession()  { return IsLondon(CurrentHour()); }
   bool IsNYSession()      { return IsNY(CurrentHour()); }
   bool IsTokyoSession()   { return IsAsian(CurrentHour()); }
};

#endif // MD90_SESSION_FILTER_MQH
