//+------------------------------------------------------------------+
//|                                                 StopManager.mqh  |
//|                    MD90 Ultimate Fusion v4.0 - FINAL             |
//|                    v3: 6 TP levels + v2: trailing interface       |
//+------------------------------------------------------------------+
#ifndef MD90_STOP_MANAGER_MQH
#define MD90_STOP_MANAGER_MQH

#include <Trade\Trade.mqh>
#include "../Common/Constants.mqh"
#include "../Common/Utils.mqh"

struct STPLevels
{
   double sl;
   double tp[6];    // tp[0]=TP1 .. tp[5]=TP6
   int    active;
};

class CStopManager
{
private:
   CTrade  m_trade;
   string  m_symbol;
   ulong   m_magic;
   double  m_sl_atr_mult;
   double  m_sl_multiplier;

public:
   CStopManager() : m_sl_atr_mult(ATR_SL_MULT), m_sl_multiplier(1.0)
   { m_symbol=_Symbol; m_magic=EA_MAGIC_NUMBER; }

   void Init(string symbol, ulong magic)
   {
      m_symbol=symbol; m_magic=magic;
      m_trade.SetExpertMagicNumber(magic);
   }
   void SetSLMult(double m)          { m_sl_atr_mult=m; }
   void SetSLMultiplier(double m)    { m_sl_multiplier=m; }

   STPLevels Calculate(int direction, double entry, double atr, int active_tps=6)
   {
      STPLevels tp; ZeroMemory(tp); tp.active=MathMin(active_tps,6);
      double sl_dist=atr*m_sl_atr_mult*m_sl_multiplier;
      int d=(direction==SIGNAL_BUY)?1:-1;
      tp.sl      = NormalizePrice(entry - d*sl_dist, m_symbol);
      double mults[6]={ATR_TP1_MULT,ATR_TP2_MULT,ATR_TP3_MULT,
                       ATR_TP4_MULT,ATR_TP5_MULT,ATR_TP6_MULT};
      for(int i=0;i<6;i++)
         tp.tp[i]=NormalizePrice(entry + d*atr*mults[i], m_symbol);
      return tp;
   }

   // Trailing stop calculation
   double CalcTrailingStop(int direction, double current_price,
                           double current_sl, double atr, double mult=1.0)
   {
      double trail=atr*mult;
      if(direction==SIGNAL_BUY)
      { double ns=current_price-trail; return (ns>current_sl)?ns:current_sl; }
      else
      { double ns=current_price+trail; return (ns<current_sl&&ns>0)?ns:current_sl; }
   }

   // Direct trailing stop update on position
   void UpdateTrailingStop(ulong ticket, double current_price, double atr,
                           double start_mult, double step_mult, bool is_buy)
   {
      if(!PositionSelectByTicket(ticket)) return;
      double open  =PositionGetDouble(POSITION_PRICE_OPEN);
      double cur_sl=PositionGetDouble(POSITION_SL);
      double trail_start=atr*start_mult, trail_step=atr*step_mult;
      double new_sl=0;
      if(is_buy)
      {
         if(current_price-open>=trail_start)
         { new_sl=current_price-trail_step;
           if(new_sl>cur_sl && new_sl>open)
              m_trade.PositionModify(ticket,new_sl,PositionGetDouble(POSITION_TP)); }
      }
      else
      {
         if(open-current_price>=trail_start)
         { new_sl=current_price+trail_step;
           if((new_sl<cur_sl||cur_sl==0) && new_sl<open)
              m_trade.PositionModify(ticket,new_sl,PositionGetDouble(POSITION_TP)); }
      }
   }

   // Break-even
   void CheckBreakeven(ulong ticket, double current_price, double atr,
                       double trigger_mult, bool is_buy)
   {
      if(!PositionSelectByTicket(ticket)) return;
      double open  =PositionGetDouble(POSITION_PRICE_OPEN);
      double cur_sl=PositionGetDouble(POSITION_SL);
      if(is_buy && cur_sl<open)
      {
         if(current_price-open>=atr*trigger_mult)
            m_trade.PositionModify(ticket, open+0.1*_Point, PositionGetDouble(POSITION_TP));
      }
      else if(!is_buy && (cur_sl>open||cur_sl==0))
      {
         if(open-current_price>=atr*trigger_mult)
            m_trade.PositionModify(ticket, open-0.1*_Point, PositionGetDouble(POSITION_TP));
      }
   }
};

#endif // MD90_STOP_MANAGER_MQH
