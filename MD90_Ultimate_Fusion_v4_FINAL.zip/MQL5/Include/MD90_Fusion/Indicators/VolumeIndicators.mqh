//+------------------------------------------------------------------+
//|                                            VolumeIndicators.mqh  |
//|              MD90 Ultimate Fusion EA - Volume Indicators         |
//|              MD90_Fusion/Indicators/VolumeIndicators.mqh         |
//+------------------------------------------------------------------+
#ifndef MD90_VOLUME_INDICATORS_MQH
#define MD90_VOLUME_INDICATORS_MQH

#include "../Common/Constants.mqh"
#include "../Common/Logger.mqh"
#include "../Common/Utils.mqh"
#include "../Data/DataManager.mqh"

//+------------------------------------------------------------------+
//| CVolumeIndicators — OBV, MFI (L9, L10)                          |
//+------------------------------------------------------------------+
class CVolumeIndicators
{
private:
   string            m_symbol;
   ENUM_TIMEFRAMES   m_tf;
   CDataManager*     m_data;

   int               m_h_mfi;

   double            m_obv;
   double            m_obv_prev;
   double            m_mfi;

   bool              m_initialized;

   void              CalculateOBV();

public:
                     CVolumeIndicators();
                    ~CVolumeIndicators();

   bool              Init(const string symbol, ENUM_TIMEFRAMES tf, CDataManager* data);
   bool              Calculate();
   void              Deinit();

   //--- L9: OBV
   int               GetOBVSignal()     const;
   double            GetOBV()           const { return m_obv; }
   bool              OBVRising()        const { return m_obv > m_obv_prev; }

   //--- L10: MFI
   int               GetMFISignal()     const;
   double            GetMFI()           const { return m_mfi; }
   bool              MFIOverbought()    const { return m_mfi >= 80.0; }
   bool              MFIOversold()      const { return m_mfi <= 20.0; }

   bool              IsReady() const { return m_initialized; }
};

//--- Implementation ---------------------------------------------------

CVolumeIndicators::CVolumeIndicators()
 : m_data(NULL), m_h_mfi(INVALID_HANDLE),
   m_obv(0), m_obv_prev(0), m_mfi(50), m_initialized(false)
{ m_symbol = _Symbol; m_tf = PERIOD_CURRENT; }

CVolumeIndicators::~CVolumeIndicators() { Deinit(); }

bool CVolumeIndicators::Init(const string symbol, ENUM_TIMEFRAMES tf, CDataManager* data)
{
   m_symbol = symbol; m_tf = tf; m_data = data;
   m_h_mfi  = iMFI(symbol, tf, 14, VOLUME_TICK);
   if(m_h_mfi == INVALID_HANDLE)
   { Logger.Error("VolumeIndicators: MFI handle failed"); return false; }
   m_initialized = true;
   Logger.Info("VolumeIndicators initialized: " + symbol);
   return true;
}

void CVolumeIndicators::Deinit()
{
   if(m_h_mfi != INVALID_HANDLE) { IndicatorRelease(m_h_mfi); m_h_mfi = INVALID_HANDLE; }
   m_initialized = false;
}

void CVolumeIndicators::CalculateOBV()
{
   if(!m_data || !m_data->IsReady()) return;
   m_obv_prev = m_obv;
   int depth  = MathMin(50, m_data->GetDepth());
   double obv = 0.0;
   for(int i = depth - 1; i >= 1; i--)
   {
      double close_curr = m_data->GetClose(i);
      double close_prev = m_data->GetClose(i + 1);
      double vol        = (double)m_data->GetVolume(i);
      if(close_curr > close_prev)      obv += vol;
      else if(close_curr < close_prev) obv -= vol;
   }
   m_obv = obv;
}

bool CVolumeIndicators::Calculate()
{
   if(!m_initialized) return false;
   CalculateOBV();
   double buf[1];
   if(CopyBuffer(m_h_mfi, 0, 1, 1, buf) == 1) m_mfi = buf[0];
   return true;
}

int CVolumeIndicators::GetOBVSignal() const
{
   if(OBVRising())  return SIGNAL_BUY;
   return SIGNAL_SELL;
}

int CVolumeIndicators::GetMFISignal() const
{
   if(MFIOversold())   return SIGNAL_BUY;
   if(MFIOverbought()) return SIGNAL_SELL;
   return SIGNAL_NONE;
}

#endif // MD90_VOLUME_INDICATORS_MQH
