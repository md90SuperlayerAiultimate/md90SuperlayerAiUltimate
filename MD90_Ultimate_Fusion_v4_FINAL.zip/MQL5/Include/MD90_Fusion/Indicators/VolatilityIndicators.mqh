//+------------------------------------------------------------------+
//|                                         VolatilityIndicators.mqh |
//|          MD90 Ultimate Fusion EA - Volatility Indicators         |
//|          MD90_Fusion/Indicators/VolatilityIndicators.mqh         |
//+------------------------------------------------------------------+
#ifndef MD90_VOLATILITY_INDICATORS_MQH
#define MD90_VOLATILITY_INDICATORS_MQH

#include "../Common/Constants.mqh"
#include "../Common/Logger.mqh"
#include "../Common/Utils.mqh"

//+------------------------------------------------------------------+
//| CVolatilityIndicators — ATR, Bollinger Bands (L7, L8)            |
//+------------------------------------------------------------------+
class CVolatilityIndicators
{
private:
   string            m_symbol;
   ENUM_TIMEFRAMES   m_tf;

   int               m_h_atr;
   int               m_h_bb;

   double            m_atr;
   double            m_bb_upper, m_bb_mid, m_bb_lower;
   double            m_bb_width_pips;

   bool              m_initialized;

public:
                     CVolatilityIndicators();
                    ~CVolatilityIndicators();

   bool              Init(const string symbol, ENUM_TIMEFRAMES tf);
   bool              Calculate();
   void              Deinit();

   //--- L7: ATR
   double            GetATR()            const { return m_atr; }
   double            GetATRPips()        const { return PriceToPips(m_atr, m_symbol); }
   bool              HighVolatility()    const { return GetATRPips() > 15.0; }
   bool              LowVolatility()     const { return GetATRPips() < 5.0; }

   //--- L8: Bollinger Bands
   int               GetBBSignal(double price) const;
   double            GetBBUpper()        const { return m_bb_upper; }
   double            GetBBMid()          const { return m_bb_mid; }
   double            GetBBLower()        const { return m_bb_lower; }
   double            GetBBWidth()        const { return m_bb_width_pips; }
   bool              PriceAtBBLower(double price) const { return price <= m_bb_lower * 1.001; }
   bool              PriceAtBBUpper(double price) const { return price >= m_bb_upper * 0.999; }

   bool              IsReady() const { return m_initialized; }
};

//--- Implementation ---------------------------------------------------

CVolatilityIndicators::CVolatilityIndicators()
 : m_h_atr(INVALID_HANDLE), m_h_bb(INVALID_HANDLE),
   m_atr(0), m_bb_upper(0), m_bb_mid(0), m_bb_lower(0), m_bb_width_pips(0),
   m_initialized(false)
{ m_symbol = _Symbol; m_tf = PERIOD_CURRENT; }

CVolatilityIndicators::~CVolatilityIndicators() { Deinit(); }

bool CVolatilityIndicators::Init(const string symbol, ENUM_TIMEFRAMES tf)
{
   m_symbol = symbol; m_tf = tf;
   m_h_atr = iATR(symbol, tf, PERIOD_ATR);
   m_h_bb  = iBands(symbol, tf, PERIOD_BB, 0, 2.0, PRICE_CLOSE);
   if(m_h_atr == INVALID_HANDLE || m_h_bb == INVALID_HANDLE)
   { Logger.Error("VolatilityIndicators: handle creation failed"); return false; }
   m_initialized = true;
   Logger.Info("VolatilityIndicators initialized: " + symbol);
   return true;
}

void CVolatilityIndicators::Deinit()
{
   if(m_h_atr != INVALID_HANDLE) { IndicatorRelease(m_h_atr); m_h_atr = INVALID_HANDLE; }
   if(m_h_bb  != INVALID_HANDLE) { IndicatorRelease(m_h_bb);  m_h_bb  = INVALID_HANDLE; }
   m_initialized = false;
}

bool CVolatilityIndicators::Calculate()
{
   if(!m_initialized) return false;
   double buf[1];
   if(CopyBuffer(m_h_atr, 0, 1, 1, buf) == 1) m_atr = buf[0];
   if(CopyBuffer(m_h_bb,  1, 1, 1, buf) == 1) m_bb_upper = buf[0];
   if(CopyBuffer(m_h_bb,  0, 1, 1, buf) == 1) m_bb_mid   = buf[0];
   if(CopyBuffer(m_h_bb,  2, 1, 1, buf) == 1) m_bb_lower = buf[0];
   m_bb_width_pips = PriceToPips(m_bb_upper - m_bb_lower, m_symbol);
   return true;
}

int CVolatilityIndicators::GetBBSignal(double price) const
{
   if(PriceAtBBLower(price)) return SIGNAL_BUY;
   if(PriceAtBBUpper(price)) return SIGNAL_SELL;
   return SIGNAL_NONE;
}

#endif // MD90_VOLATILITY_INDICATORS_MQH
