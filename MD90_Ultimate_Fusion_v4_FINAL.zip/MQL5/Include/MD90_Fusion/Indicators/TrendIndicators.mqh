//+------------------------------------------------------------------+
//|                                             TrendIndicators.mqh  |
//|              MD90 Ultimate Fusion EA - Trend Indicators          |
//|              MD90_Fusion/Indicators/TrendIndicators.mqh          |
//+------------------------------------------------------------------+
#ifndef MD90_TREND_INDICATORS_MQH
#define MD90_TREND_INDICATORS_MQH

#include "../Common/Constants.mqh"
#include "../Common/Logger.mqh"
#include "../Common/Utils.mqh"

//+------------------------------------------------------------------+
//| CTrendIndicators — EMA stack, ADX, SuperTrend (L1, L2, L3)      |
//+------------------------------------------------------------------+
class CTrendIndicators
{
private:
   string            m_symbol;
   ENUM_TIMEFRAMES   m_tf;

   //--- Handles
   int               m_h_ema8;
   int               m_h_ema21;
   int               m_h_ema50;
   int               m_h_ema200;
   int               m_h_adx;

   //--- Values
   double            m_ema8, m_ema21, m_ema50, m_ema200;
   double            m_adx, m_di_plus, m_di_minus;

   bool              m_initialized;

   bool              CopyBuffer1(int handle, double &out, int shift = 1);

public:
                     CTrendIndicators();
                    ~CTrendIndicators();

   bool              Init(const string symbol, ENUM_TIMEFRAMES tf);
   bool              Calculate();
   void              Deinit();

   //--- L1: EMA Trend
   int               GetEMATrend()        const;
   bool              EMABullStack()        const { return m_ema8 > m_ema21 && m_ema21 > m_ema50 && m_ema50 > m_ema200; }
   bool              EMABearStack()        const { return m_ema8 < m_ema21 && m_ema21 < m_ema50 && m_ema50 < m_ema200; }
   bool              PriceAbove200()       const { return m_ema8 > m_ema200; }

   //--- L3: ADX
   int               GetADXTrend()        const;
   double            GetADX()             const { return m_adx; }
   bool              ADXTrending()         const { return m_adx >= 25.0; }
   bool              ADXBull()             const { return m_di_plus > m_di_minus; }

   //--- Raw values
   double            GetEMA8()    const { return m_ema8;   }
   double            GetEMA21()   const { return m_ema21;  }
   double            GetEMA50()   const { return m_ema50;  }
   double            GetEMA200()  const { return m_ema200; }

   bool              IsReady() const { return m_initialized; }
};

//--- Implementation ---------------------------------------------------

CTrendIndicators::CTrendIndicators()
 : m_h_ema8(INVALID_HANDLE), m_h_ema21(INVALID_HANDLE),
   m_h_ema50(INVALID_HANDLE), m_h_ema200(INVALID_HANDLE),
   m_h_adx(INVALID_HANDLE),
   m_ema8(0), m_ema21(0), m_ema50(0), m_ema200(0),
   m_adx(0), m_di_plus(0), m_di_minus(0),
   m_initialized(false)
{
   m_symbol = _Symbol;
   m_tf     = PERIOD_CURRENT;
}

CTrendIndicators::~CTrendIndicators() { Deinit(); }

bool CTrendIndicators::Init(const string symbol, ENUM_TIMEFRAMES tf)
{
   m_symbol = symbol;
   m_tf     = tf;

   m_h_ema8   = iMA(symbol, tf, PERIOD_EMA_FAST, 0, MODE_EMA, PRICE_CLOSE);
   m_h_ema21  = iMA(symbol, tf, PERIOD_EMA_MID,  0, MODE_EMA, PRICE_CLOSE);
   m_h_ema50  = iMA(symbol, tf, PERIOD_EMA_SLOW, 0, MODE_EMA, PRICE_CLOSE);
   m_h_ema200 = iMA(symbol, tf, PERIOD_EMA_200,  0, MODE_EMA, PRICE_CLOSE);
   m_h_adx    = iADX(symbol, tf, PERIOD_ADX);

   if(m_h_ema8 == INVALID_HANDLE || m_h_ema21 == INVALID_HANDLE ||
      m_h_ema50 == INVALID_HANDLE || m_h_ema200 == INVALID_HANDLE ||
      m_h_adx   == INVALID_HANDLE)
   {
      Logger.Error("TrendIndicators: handle creation failed");
      return false;
   }
   m_initialized = true;
   Logger.Info("TrendIndicators initialized: " + symbol);
   return true;
}

void CTrendIndicators::Deinit()
{
   if(m_h_ema8   != INVALID_HANDLE) { IndicatorRelease(m_h_ema8);   m_h_ema8   = INVALID_HANDLE; }
   if(m_h_ema21  != INVALID_HANDLE) { IndicatorRelease(m_h_ema21);  m_h_ema21  = INVALID_HANDLE; }
   if(m_h_ema50  != INVALID_HANDLE) { IndicatorRelease(m_h_ema50);  m_h_ema50  = INVALID_HANDLE; }
   if(m_h_ema200 != INVALID_HANDLE) { IndicatorRelease(m_h_ema200); m_h_ema200 = INVALID_HANDLE; }
   if(m_h_adx    != INVALID_HANDLE) { IndicatorRelease(m_h_adx);    m_h_adx    = INVALID_HANDLE; }
   m_initialized = false;
}

bool CTrendIndicators::CopyBuffer1(int handle, double &out, int shift = 1)
{
   double buf[1];
   if(CopyBuffer(handle, 0, shift, 1, buf) != 1) return false;
   out = buf[0];
   return true;
}

bool CTrendIndicators::Calculate()
{
   if(!m_initialized) return false;
   bool ok = true;
   ok &= CopyBuffer1(m_h_ema8,   m_ema8);
   ok &= CopyBuffer1(m_h_ema21,  m_ema21);
   ok &= CopyBuffer1(m_h_ema50,  m_ema50);
   ok &= CopyBuffer1(m_h_ema200, m_ema200);

   double adx_buf[1], dip_buf[1], dim_buf[1];
   if(CopyBuffer(m_h_adx, 0, 1, 1, adx_buf) == 1) m_adx      = adx_buf[0];
   if(CopyBuffer(m_h_adx, 1, 1, 1, dip_buf) == 1) m_di_plus  = dip_buf[0];
   if(CopyBuffer(m_h_adx, 2, 1, 1, dim_buf) == 1) m_di_minus = dim_buf[0];

   return ok;
}

int CTrendIndicators::GetEMATrend() const
{
   if(EMABullStack()) return SIGNAL_BUY;
   if(EMABearStack()) return SIGNAL_SELL;
   return SIGNAL_NONE;
}

int CTrendIndicators::GetADXTrend() const
{
   if(!ADXTrending()) return SIGNAL_NONE;
   return ADXBull() ? SIGNAL_BUY : SIGNAL_SELL;
}

#endif // MD90_TREND_INDICATORS_MQH
