//+------------------------------------------------------------------+
//|                                          MomentumIndicators.mqh  |
//|            MD90 Ultimate Fusion EA - Momentum Indicators         |
//|            MD90_Fusion/Indicators/MomentumIndicators.mqh         |
//+------------------------------------------------------------------+
#ifndef MD90_MOMENTUM_INDICATORS_MQH
#define MD90_MOMENTUM_INDICATORS_MQH

#include "../Common/Constants.mqh"
#include "../Common/Logger.mqh"
#include "../Common/Utils.mqh"

//+------------------------------------------------------------------+
//| CMomentumIndicators — RSI, MACD, Stochastic (L4, L5, L6)        |
//+------------------------------------------------------------------+
class CMomentumIndicators
{
private:
   string            m_symbol;
   ENUM_TIMEFRAMES   m_tf;

   int               m_h_rsi;
   int               m_h_macd;
   int               m_h_stoch;

   double            m_rsi;
   double            m_macd_main, m_macd_signal, m_macd_hist;
   double            m_stoch_main, m_stoch_signal;

   bool              m_initialized;

public:
                     CMomentumIndicators();
                    ~CMomentumIndicators();

   bool              Init(const string symbol, ENUM_TIMEFRAMES tf);
   bool              Calculate();
   void              Deinit();

   //--- L4: RSI
   int               GetRSISignal()     const;
   double            GetRSI()           const { return m_rsi; }
   bool              RSIOverbought()    const { return m_rsi >= 70.0; }
   bool              RSIOversold()      const { return m_rsi <= 30.0; }
   bool              RSIBullish()       const { return m_rsi > 50.0 && !RSIOverbought(); }
   bool              RSIBearish()       const { return m_rsi < 50.0 && !RSIOversold(); }

   //--- L5: MACD
   int               GetMACDSignal()    const;
   double            GetMACDHist()      const { return m_macd_hist; }
   bool              MACDBullCross()    const { return m_macd_main > m_macd_signal && m_macd_hist > 0; }
   bool              MACDBearCross()    const { return m_macd_main < m_macd_signal && m_macd_hist < 0; }

   //--- L6: Stochastic
   int               GetStochSignal()   const;
   double            GetStochMain()     const { return m_stoch_main; }
   bool              StochOverbought()  const { return m_stoch_main >= 80.0; }
   bool              StochOversold()    const { return m_stoch_main <= 20.0; }

   bool              IsReady() const { return m_initialized; }
};

//--- Implementation ---------------------------------------------------

CMomentumIndicators::CMomentumIndicators()
 : m_h_rsi(INVALID_HANDLE), m_h_macd(INVALID_HANDLE), m_h_stoch(INVALID_HANDLE),
   m_rsi(50), m_macd_main(0), m_macd_signal(0), m_macd_hist(0),
   m_stoch_main(50), m_stoch_signal(50), m_initialized(false)
{
   m_symbol = _Symbol; m_tf = PERIOD_CURRENT;
}

CMomentumIndicators::~CMomentumIndicators() { Deinit(); }

bool CMomentumIndicators::Init(const string symbol, ENUM_TIMEFRAMES tf)
{
   m_symbol = symbol; m_tf = tf;
   m_h_rsi   = iRSI(symbol, tf, PERIOD_RSI, PRICE_CLOSE);
   m_h_macd  = iMACD(symbol, tf, PERIOD_MACD_FAST, PERIOD_MACD_SLOW, PERIOD_MACD_SIG, PRICE_CLOSE);
   m_h_stoch = iStochastic(symbol, tf, PERIOD_STOCH_K, PERIOD_STOCH_D, 3, MODE_SMA, STO_LOWHIGH);

   if(m_h_rsi == INVALID_HANDLE || m_h_macd == INVALID_HANDLE || m_h_stoch == INVALID_HANDLE)
   {
      Logger.Error("MomentumIndicators: handle creation failed");
      return false;
   }
   m_initialized = true;
   Logger.Info("MomentumIndicators initialized: " + symbol);
   return true;
}

void CMomentumIndicators::Deinit()
{
   if(m_h_rsi   != INVALID_HANDLE) { IndicatorRelease(m_h_rsi);   m_h_rsi   = INVALID_HANDLE; }
   if(m_h_macd  != INVALID_HANDLE) { IndicatorRelease(m_h_macd);  m_h_macd  = INVALID_HANDLE; }
   if(m_h_stoch != INVALID_HANDLE) { IndicatorRelease(m_h_stoch); m_h_stoch = INVALID_HANDLE; }
   m_initialized = false;
}

bool CMomentumIndicators::Calculate()
{
   if(!m_initialized) return false;
   double buf[1];
   if(CopyBuffer(m_h_rsi,   0, 1, 1, buf) == 1) m_rsi         = buf[0];
   if(CopyBuffer(m_h_macd,  0, 1, 1, buf) == 1) m_macd_main   = buf[0];
   if(CopyBuffer(m_h_macd,  1, 1, 1, buf) == 1) m_macd_signal = buf[0];
   m_macd_hist = m_macd_main - m_macd_signal;
   if(CopyBuffer(m_h_stoch, 0, 1, 1, buf) == 1) m_stoch_main  = buf[0];
   if(CopyBuffer(m_h_stoch, 1, 1, 1, buf) == 1) m_stoch_signal= buf[0];
   return true;
}

int CMomentumIndicators::GetRSISignal() const
{
   if(RSIBullish())  return SIGNAL_BUY;
   if(RSIBearish())  return SIGNAL_SELL;
   return SIGNAL_NONE;
}

int CMomentumIndicators::GetMACDSignal() const
{
   if(MACDBullCross()) return SIGNAL_BUY;
   if(MACDBearCross()) return SIGNAL_SELL;
   return SIGNAL_NONE;
}

int CMomentumIndicators::GetStochSignal() const
{
   if(StochOversold()  && m_stoch_main > m_stoch_signal) return SIGNAL_BUY;
   if(StochOverbought()&& m_stoch_main < m_stoch_signal) return SIGNAL_SELL;
   return SIGNAL_NONE;
}

#endif // MD90_MOMENTUM_INDICATORS_MQH
