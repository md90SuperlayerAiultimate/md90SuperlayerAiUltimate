//+------------------------------------------------------------------+
//|                                              PositionTracker.mqh |
//|                    MD90 Ultimate Fusion v4.0 - FINAL MERGE       |
//|                    v3: STrackedPosition struct + 6-TP tracking    |
//|                    v2: GetTotalPositions/Profit/Volume helpers    |
//+------------------------------------------------------------------+
#ifndef MD90_POSITION_TRACKER_MQH
#define MD90_POSITION_TRACKER_MQH

#include <Trade\PositionInfo.mqh>
#include "../Common/Constants.mqh"
#include "../Common/Logger.mqh"
#include "../Common/Utils.mqh"

//+------------------------------------------------------------------+
//| v3: per-position tracking struct                                  |
//+------------------------------------------------------------------+
struct STrackedPosition
{
   ulong    ticket;
   int      direction;
   double   entry_price, lots;
   double   sl;
   double   tp[6];           // 6 TP levels
   int      active_tps;
   int      tp_hit;
   double   current_sl;
   bool     be_activated;
   datetime open_time;
   bool     valid;
};

class CPositionTracker
{
private:
   string            m_symbol;
   ulong             m_magic;
   CPositionInfo     m_pos;
   STrackedPosition  m_tracked[3];   // up to MAX_POSITIONS
   int               m_count;

public:
   CPositionTracker() : m_count(0), m_magic(EA_MAGIC_NUMBER) { m_symbol=_Symbol; }

   void Init(string symbol, ulong magic)
   { m_symbol=symbol; m_magic=magic; m_count=0;
     for(int i=0;i<3;i++) m_tracked[i].valid=false; }

   //--- v3 methods
   void AddPosition(const STrackedPosition &p)
   {
      if(m_count>=3) { Logger.Warn("PositionTracker: max 3 reached"); return; }
      m_tracked[m_count]=p; m_tracked[m_count].valid=true; m_count++;
   }

   void RemovePosition(ulong ticket)
   {
      for(int i=0;i<m_count;i++)
         if(m_tracked[i].ticket==ticket)
         {
            for(int j=i;j<m_count-1;j++) m_tracked[j]=m_tracked[j+1];
            m_count--; return;
         }
   }

   void UpdateAll()
   {
      for(int i=m_count-1;i>=0;i--)
         if(!PositionSelectByTicket(m_tracked[i].ticket))
            RemovePosition(m_tracked[i].ticket);
   }

   STrackedPosition* GetPosition(ulong ticket)
   {
      for(int i=0;i<m_count;i++)
         if(m_tracked[i].ticket==ticket) return &m_tracked[i];
      return NULL;
   }

   void MarkTPHit(ulong ticket)
   { STrackedPosition* p=GetPosition(ticket); if(p) p.tp_hit++; }
   void SetCurrentSL(ulong ticket, double sl)
   { STrackedPosition* p=GetPosition(ticket); if(p) p.current_sl=sl; }
   void SetBEActivated(ulong ticket)
   { STrackedPosition* p=GetPosition(ticket); if(p) p.be_activated=true; }

   int  GetCount()             const { return m_count; }
   bool HasOpenPosition()      const { return m_count>0; }

   //--- v2 compat methods (scan live positions)
   int GetTotalPositions()
   {
      int cnt=0;
      for(int i=PositionsTotal()-1;i>=0;i--)
      {
         ulong t=PositionGetTicket(i);
         if(PositionSelectByTicket(t) &&
            PositionGetString(POSITION_SYMBOL)==m_symbol &&
            PositionGetInteger(POSITION_MAGIC)==(long)m_magic) cnt++;
      }
      return cnt;
   }

   double GetTotalProfit()
   {
      double p=0;
      for(int i=PositionsTotal()-1;i>=0;i--)
      {
         ulong t=PositionGetTicket(i);
         if(PositionSelectByTicket(t) &&
            PositionGetString(POSITION_SYMBOL)==m_symbol &&
            PositionGetInteger(POSITION_MAGIC)==(long)m_magic)
            p+=PositionGetDouble(POSITION_PROFIT);
      }
      return p;
   }

   double GetTotalVolume()
   {
      double v=0;
      for(int i=PositionsTotal()-1;i>=0;i--)
      {
         ulong t=PositionGetTicket(i);
         if(PositionSelectByTicket(t) &&
            PositionGetString(POSITION_SYMBOL)==m_symbol &&
            PositionGetInteger(POSITION_MAGIC)==(long)m_magic)
            v+=PositionGetDouble(POSITION_VOLUME);
      }
      return v;
   }

   bool HasPositionInDirection(int dir)
   {
      for(int i=PositionsTotal()-1;i>=0;i--)
      {
         ulong t=PositionGetTicket(i);
         if(!PositionSelectByTicket(t)) continue;
         if(PositionGetString(POSITION_SYMBOL)!=m_symbol) continue;
         if(PositionGetInteger(POSITION_MAGIC)!=(long)m_magic) continue;
         int pt=(int)PositionGetInteger(POSITION_TYPE);
         if((dir==SIGNAL_BUY&&pt==POSITION_TYPE_BUY)||
            (dir==SIGNAL_SELL&&pt==POSITION_TYPE_SELL)) return true;
      }
      return false;
   }
};

#endif // MD90_POSITION_TRACKER_MQH
