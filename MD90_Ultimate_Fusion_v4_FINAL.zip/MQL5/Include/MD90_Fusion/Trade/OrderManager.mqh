//+------------------------------------------------------------------+
//|                                                 OrderManager.mqh |
//|                    MD90 Ultimate Fusion v4.0 - FINAL             |
//|                    v2 interface + v3 broker-adaptive fill         |
//+------------------------------------------------------------------+
#ifndef MD90_ORDER_MANAGER_MQH
#define MD90_ORDER_MANAGER_MQH

#include <Trade\Trade.mqh>
#include <Trade\PositionInfo.mqh>
#include "../Common/Constants.mqh"
#include "../Common/Utils.mqh"
#include "../Common/Logger.mqh"

class COrderManager
{
private:
   string        m_symbol;
   ulong         m_magic;
   string        m_comment;
   CTrade        m_trade;
   CPositionInfo m_position;
   int           m_max_retries;

public:
   COrderManager() : m_magic(EA_MAGIC_NUMBER), m_max_retries(3)
   { m_symbol=_Symbol; m_comment="MD90_v4"; }

   void Init(string symbol, ulong magic, string comment="MD90_v4")
   {
      m_symbol=symbol; m_magic=magic; m_comment=comment;
      m_trade.SetExpertMagicNumber(magic);
      m_trade.SetDeviationInPoints(10);
      m_trade.SetTypeFilling(GetBrokerFillMode(symbol));  // v3: broker-adaptive
      m_trade.SetAsyncMode(false);
      Logger.Info("OrderManager: "+symbol+" Fill="+EnumToString(GetBrokerFillMode(symbol)));
   }

   CTrade* GetTrade() { return &m_trade; }

   int GetPositionCount()
   {
      int cnt=0;
      for(int i=PositionsTotal()-1;i>=0;i--)
      {
         ulong t=PositionGetTicket(i);
         if(PositionSelectByTicket(t) &&
            PositionGetString(POSITION_SYMBOL)==m_symbol &&
            PositionGetInteger(POSITION_MAGIC)==(long)m_magic) cnt++;
      }
      return cnt;
   }

   bool PlaceBuyOrder(double lot, double entry, double sl, double tp, string extra="")
   {
      string cmt=m_comment+(extra!=""?"_"+extra:"");
      sl=NormalizePrice(sl,m_symbol); tp=NormalizePrice(tp,m_symbol);
      for(int i=0;i<m_max_retries;i++)
      {
         if(m_trade.Buy(lot,m_symbol,0,sl,tp,cmt))
         { Logger.Info("BUY opened lot="+FormatDbl(lot,2)+" sl="+FormatDbl(sl)+" tp="+FormatDbl(tp)); return true; }
         Logger.Warn("BUY retry "+IntToString(i+1)+" err="+IntToString((int)m_trade.ResultRetcode()));
         Sleep(200);
      }
      Logger.Error("BUY FAILED: "+cmt); return false;
   }

   bool PlaceSellOrder(double lot, double entry, double sl, double tp, string extra="")
   {
      string cmt=m_comment+(extra!=""?"_"+extra:"");
      sl=NormalizePrice(sl,m_symbol); tp=NormalizePrice(tp,m_symbol);
      for(int i=0;i<m_max_retries;i++)
      {
         if(m_trade.Sell(lot,m_symbol,0,sl,tp,cmt))
         { Logger.Info("SELL opened lot="+FormatDbl(lot,2)+" sl="+FormatDbl(sl)+" tp="+FormatDbl(tp)); return true; }
         Logger.Warn("SELL retry "+IntToString(i+1)+" err="+IntToString((int)m_trade.ResultRetcode()));
         Sleep(200);
      }
      Logger.Error("SELL FAILED: "+cmt); return false;
   }

   bool ModifyPosition(ulong ticket, double sl, double tp)
   {
      sl=NormalizePrice(sl,m_symbol); tp=NormalizePrice(tp,m_symbol);
      return m_trade.PositionModify(ticket,sl,tp);
   }

   bool ClosePosition(ulong ticket) { return m_trade.PositionClose(ticket); }

   void CloseAllPositions()
   {
      for(int i=PositionsTotal()-1;i>=0;i--)
      {
         ulong t=PositionGetTicket(i);
         if(PositionSelectByTicket(t) &&
            PositionGetString(POSITION_SYMBOL)==m_symbol &&
            PositionGetInteger(POSITION_MAGIC)==(long)m_magic)
            m_trade.PositionClose(t);
      }
   }

   // v2 compatibility stubs (actual logic in StopManager)
   void UpdateTrailingStops(double,double) {}
   void CheckBreakeven(double) {}
};

#endif // MD90_ORDER_MANAGER_MQH
