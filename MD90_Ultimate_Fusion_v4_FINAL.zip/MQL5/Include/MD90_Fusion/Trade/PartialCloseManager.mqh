//+------------------------------------------------------------------+
//|                                          PartialCloseManager.mqh |
//|                    MD90 Ultimate Fusion v4.0 - FINAL             |
//|                    v3: 6-TP staged closes (BUG #7 fixed)          |
//+------------------------------------------------------------------+
#ifndef MD90_PARTIAL_CLOSE_MQH
#define MD90_PARTIAL_CLOSE_MQH

#include <Trade\Trade.mqh>
#include "../Common/Constants.mqh"
#include "../Common/Utils.mqh"
#include "../Common/Logger.mqh"

class CPartialCloseManager
{
private:
   string   m_symbol;
   ulong    m_magic;
   CTrade   m_trade;
   double   m_pct[6];   // % to close at each TP

public:
   CPartialCloseManager()
   {
      m_symbol=_Symbol; m_magic=EA_MAGIC_NUMBER;
      m_pct[0]=PARTIAL_PCT_TP1; m_pct[1]=PARTIAL_PCT_TP2;
      m_pct[2]=PARTIAL_PCT_TP3; m_pct[3]=PARTIAL_PCT_TP4;
      m_pct[4]=PARTIAL_PCT_TP5; m_pct[5]=0.0;  // TP6 = full close by OrderManager
   }

   void Init(string symbol, ulong magic, double close_pct=50.0)
   {
      m_symbol=symbol; m_magic=magic;
      m_trade.SetExpertMagicNumber(magic);
      // v2 compat: set TP1 pct from close_pct
      m_pct[0]=close_pct;
   }

   void SetPartialPcts(double p1,double p2,double p3,double p4,double p5,double p6=0)
   { m_pct[0]=p1;m_pct[1]=p2;m_pct[2]=p3;m_pct[3]=p4;m_pct[4]=p5;m_pct[5]=p6; }

   // Fixed: use PositionClosePartial (BUG #7 from v2)
   bool ClosePartial(ulong ticket, double close_volume)
   {
      if(!PositionSelectByTicket(ticket)) return false;
      double cur_vol=PositionGetDouble(POSITION_VOLUME);
      if(close_volume>=cur_vol) return m_trade.PositionClose(ticket);
      return m_trade.PositionClosePartial(ticket, close_volume);
   }

   bool ClosePartialPct(ulong ticket, double pct)
   {
      if(!PositionSelectByTicket(ticket)) return false;
      double vol=PositionGetDouble(POSITION_VOLUME);
      double close_vol=NormalizeLots(vol*(pct/100.0), m_symbol);
      if(close_vol<=0) return false;
      return ClosePartial(ticket, close_vol);
   }

   // v2 compat stub
   void CheckAndClose() {}
};

#endif // MD90_PARTIAL_CLOSE_MQH
