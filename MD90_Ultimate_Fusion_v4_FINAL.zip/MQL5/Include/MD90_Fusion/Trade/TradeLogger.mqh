//+------------------------------------------------------------------+
//|                                                  TradeLogger.mqh |
//|                    MD90 Ultimate Fusion v4.0 - FINAL MERGE       |
//|                    v3: STradeRecord struct + typed LogOpen/Close  |
//|                    v2: CSV file + LogTrade/LogClose methods       |
//+------------------------------------------------------------------+
#ifndef MD90_TRADE_LOGGER_MQH
#define MD90_TRADE_LOGGER_MQH

#include "../Common/Constants.mqh"
#include "../Common/Logger.mqh"
#include "../Common/Utils.mqh"

//+------------------------------------------------------------------+
//| v3: Trade record struct                                           |
//+------------------------------------------------------------------+
struct STradeRecord
{
   ulong    ticket;
   int      direction;
   double   entry_price, sl, tp1;
   double   lots;
   double   fusion_score;
   int      confidence_level;
   datetime open_time;
   datetime close_time;
   double   close_price;
   double   profit;
   string   close_reason;
   bool     closed;
};

//+------------------------------------------------------------------+
//| CTradeLogger — CSV + Print (v3 struct + v2 methods)              |
//+------------------------------------------------------------------+
class CTradeLogger
{
private:
   int      m_handle;
   bool     m_enabled;
   string   m_filename;

   void WriteHeader()
   {
      if(m_handle==INVALID_HANDLE) return;
      FileWrite(m_handle,"Time","Ticket","Direction","Entry","SL","TP1",
                "Lots","FusionScore","Confidence","OpenTime",
                "CloseTime","ClosePrice","Profit","Reason");
   }

   void WriteRecord(const STradeRecord &r)
   {
      if(m_handle==INVALID_HANDLE) return;
      string ci[]={"LOW","MEDIUM","HIGH","ULTRA"};
      int cl=MathMin(r.confidence_level,3);
      FileWrite(m_handle,
         TimeToString(TimeCurrent(),TIME_DATE|TIME_SECONDS),
         IntToString((int)r.ticket),
         DirToStr(r.direction),
         FormatDbl(r.entry_price), FormatDbl(r.sl), FormatDbl(r.tp1),
         FormatDbl(r.lots,2),
         FormatDbl(r.fusion_score,1)+"%",
         ci[cl],
         TimeToString(r.open_time,  TIME_DATE|TIME_SECONDS),
         TimeToString(r.close_time, TIME_DATE|TIME_SECONDS),
         FormatDbl(r.close_price),
         FormatDbl(r.profit,2),
         r.close_reason);
      FileFlush(m_handle);
   }

public:
   CTradeLogger() : m_handle(INVALID_HANDLE), m_enabled(false) {}
   ~CTradeLogger() { Close(); }

   //--- v2 compat Init
   void Init(string symbol, bool enabled=true)
   {
      m_enabled=enabled;
      if(!m_enabled) return;
      m_filename=symbol+"_MD90v4_"+TimeToString(TimeCurrent(),TIME_DATE)+".csv";
      m_handle=FileOpen(m_filename,FILE_WRITE|FILE_CSV|FILE_READ|FILE_COMMON,',');
      if(m_handle==INVALID_HANDLE) { m_enabled=false; return; }
      FileSeek(m_handle,0,SEEK_END);
      if(FileTell(m_handle)==0) WriteHeader();
      Logger.Info("TradeLogger: "+m_filename);
   }

   //--- v3: typed open/close
   void LogOpen(const STradeRecord &r)
   {
      Logger.Info("TRADE OPEN | "+DirToStr(r.direction)+
                  " #"+IntToString((int)r.ticket)+
                  " Entry="+FormatDbl(r.entry_price)+
                  " Lots="+FormatDbl(r.lots,2)+
                  " Score="+FormatDbl(r.fusion_score,1)+"%");
      if(m_enabled) WriteRecord(r);
   }

   void LogClose(const STradeRecord &r)
   {
      Logger.Info("TRADE CLOSE | #"+IntToString((int)r.ticket)+
                  " P/L="+FormatDbl(r.profit,2)+
                  " Reason="+r.close_reason);
      if(m_enabled) WriteRecord(r);
   }

   //--- v2 compat methods
   void LogTrade(ulong ticket, string action, double volume, double price,
                 double sl, double tp, string comment)
   {
      if(!m_enabled || m_handle==INVALID_HANDLE) return;
      FileWrite(m_handle, TimeToString(TimeCurrent()), IntToString((int)ticket),
                action, FormatDbl(volume,2), FormatDbl(price),
                "0", FormatDbl(sl), FormatDbl(tp), "0", comment);
      FileFlush(m_handle);
   }

   void LogClose(ulong ticket, double exit_price, double profit)
   {
      if(!m_enabled || m_handle==INVALID_HANDLE) return;
      FileWrite(m_handle, TimeToString(TimeCurrent()),
                IntToString((int)ticket), "CLOSE",
                "0", FormatDbl(exit_price),
                FormatDbl(exit_price), "0","0",
                FormatDbl(profit,2), "");
      FileFlush(m_handle);
   }

   void Close()
   {
      if(m_handle!=INVALID_HANDLE)
      { FileFlush(m_handle); FileClose(m_handle); m_handle=INVALID_HANDLE; }
   }
};

#endif // MD90_TRADE_LOGGER_MQH
