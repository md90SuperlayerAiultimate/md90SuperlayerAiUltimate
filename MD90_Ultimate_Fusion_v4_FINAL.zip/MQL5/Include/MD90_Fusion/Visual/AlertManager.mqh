//+------------------------------------------------------------------+
//|                                                 AlertManager.mqh |
//|                    MD90 Ultimate Fusion v4.0 - FINAL MERGE       |
//|                    v3: OnSignal/OnTrade/OnEquityHalt events       |
//|                    v2: SendAlert/SendBuyAlert/SendSellAlert compat |
//+------------------------------------------------------------------+
#ifndef MD90_ALERT_MANAGER_MQH
#define MD90_ALERT_MANAGER_MQH

#include "../Common/Constants.mqh"
#include "../Common/Logger.mqh"
#include "../Common/Utils.mqh"

class CAlertManager
{
private:
   bool     m_popup, m_push, m_email, m_sound, m_enabled;
   string   m_sound_file;
   datetime m_last_alert;
   int      m_cooldown_secs;

   void Send(const string &msg, bool popup, bool sound,
             bool push, bool email, const string snd="alert.wav")
   {
      Logger.Info("ALERT: "+msg);
      if(popup)  Alert(msg);
      if(sound)  PlaySound(snd);
      if(push)   SendNotification(msg);
      if(email)  SendMail(EA_NAME+" Alert", msg);
   }

public:
   CAlertManager() : m_popup(true),  m_push(false), m_email(false),
                     m_sound(true),  m_enabled(true),
                     m_sound_file("alert.wav"),
                     m_last_alert(0), m_cooldown_secs(30) {}

   //--- v2 Init signature
   void Init(bool enable, bool push, bool email, bool sound, string snd_file)
   {
      m_enabled=enable; m_popup=enable; m_push=push;
      m_email=email; m_sound=sound; m_sound_file=snd_file;
   }

   void SetCooldown(int secs) { m_cooldown_secs=secs; }

   bool CanSend()
   { return m_enabled && (TimeCurrent()-m_last_alert>=m_cooldown_secs); }

   //--- v2: generic SendAlert
   void SendAlert(string msg, bool bypass=false)
   {
      if(!m_enabled) return;
      if(!bypass && !CanSend()) return;
      Send(msg, m_popup, m_sound, m_push, m_email, m_sound_file);
      m_last_alert=TimeCurrent();
   }

   //--- v2: trade-specific alerts
   void SendBuyAlert(string sym, double price, double sl, double tp, double score)
   {
      SendAlert(StringFormat("MD90 v4: BUY %s @ %.5f | SL:%.5f | TP:%.5f | Score:%.1f%%",
                sym,price,sl,tp,score));
   }
   void SendSellAlert(string sym, double price, double sl, double tp, double score)
   {
      SendAlert(StringFormat("MD90 v4: SELL %s @ %.5f | SL:%.5f | TP:%.5f | Score:%.1f%%",
                sym,price,sl,tp,score));
   }
   void SendStatusAlert(string status, string detail)
   { SendAlert("MD90 v4: "+status+" — "+detail); }

   //--- v3: event-based alerts
   void OnSignal(const FusionSignal &sig)
   {
      if(!CanSend()) return;
      string ci[]={"LOW","MED","HIGH","ULTRA"};
      int cl=MathMin(sig.confidence_level,3);
      SendAlert("SIGNAL: "+DirToStr(sig.direction)+
                " Score="+FormatDbl(sig.fusion_score*100,1)+"%"+
                " Conf="+FormatDbl(sig.confidence,1)+"%"+
                " ["+ci[cl]+"] "+_Symbol, true);
   }

   void OnTradeOpen(ulong ticket, int dir, double entry, double lots, double score)
   {
      SendAlert("TRADE OPEN: "+DirToStr(dir)+" #"+IntToString((int)ticket)+
                " Entry="+FormatDbl(entry)+" Lots="+FormatDbl(lots,2)+
                " Score="+FormatDbl(score,1)+"%", true);
   }

   void OnTradeClose(ulong ticket, double profit, string reason)
   {
      string snd=(profit>=0)?m_sound_file:"news.wav";
      Send("TRADE CLOSE: #"+IntToString((int)ticket)+
           " P/L="+FormatDbl(profit,2)+" "+reason,
           m_popup, m_sound, m_push, m_email, snd);
   }

   void OnTPHit(ulong ticket, int tp_num, double profit)
   {
      Send("TP"+IntToString(tp_num)+" HIT #"+IntToString((int)ticket)+
           " P/L="+FormatDbl(profit,2),
           false, m_sound, m_push, false, "ok.wav");
   }

   void OnEquityHalt(string reason)
   {
      Send("!! TRADING HALTED !! "+reason,
           true, m_sound, m_push, m_email, "news.wav");
   }

   void OnEquityWarning(double dd_pct)
   {
      Send("EQUITY WARNING: DD="+FormatDbl(dd_pct,1)+"%",
           false, false, m_push, false);
   }

   void SendCustom(string msg) { SendAlert(msg); }
};

#endif // MD90_ALERT_MANAGER_MQH
