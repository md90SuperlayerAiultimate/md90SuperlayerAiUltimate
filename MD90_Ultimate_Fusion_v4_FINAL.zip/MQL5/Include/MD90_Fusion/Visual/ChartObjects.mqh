//+------------------------------------------------------------------+
//|                                               ChartObjects.mqh   |
//|                    MD90 Ultimate Fusion v4.0 - FINAL MERGE       |
//|                    v3: DrawTPSLLevels/OB/FVG/Signal arrows        |
//|                    v2: Static DrawLabel/Line/Rectangle helpers    |
//+------------------------------------------------------------------+
#ifndef MD90_CHART_OBJECTS_MQH
#define MD90_CHART_OBJECTS_MQH

#include "../Common/Constants.mqh"
#include "../Common/Logger.mqh"
#include "../Common/Utils.mqh"

class CChartObjects
{
private:
   long     m_chart_id;
   string   m_prefix;
   int      m_obj_count;

   string   MakeName(const string tag)
   { return m_prefix + tag + IntToString(m_obj_count++); }

public:
   CChartObjects() : m_chart_id(0), m_prefix("MD90_"), m_obj_count(0) {}
   ~CChartObjects() { DeleteAll(); }

   void Init(long chart_id=0, const string prefix="MD90_")
   { m_chart_id=(chart_id==0)?ChartID():chart_id; m_prefix=prefix; m_obj_count=0; }

   //--- v2 static helpers (compatible with Dashboard calling CChartObjects::DrawLabel)
   static void DrawLabel(string name, int x, int y, string text, color clr, int fs=10)
   {
      long cid=ChartID();
      if(ObjectFind(cid,name)<0) ObjectCreate(cid,name,OBJ_LABEL,0,0,0);
      ObjectSetInteger(cid,name,OBJPROP_XDISTANCE,x);
      ObjectSetInteger(cid,name,OBJPROP_YDISTANCE,y);
      ObjectSetInteger(cid,name,OBJPROP_CORNER,CORNER_LEFT_UPPER);
      ObjectSetString (cid,name,OBJPROP_TEXT,text);
      ObjectSetInteger(cid,name,OBJPROP_COLOR,clr);
      ObjectSetInteger(cid,name,OBJPROP_FONTSIZE,fs);
      ObjectSetInteger(cid,name,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(cid,name,OBJPROP_HIDDEN,true);
   }

   static void DrawLine(string name, datetime t1, double p1,
                        datetime t2, double p2,
                        color clr, int width=1, int style=STYLE_SOLID)
   {
      long cid=ChartID();
      if(ObjectFind(cid,name)<0) ObjectCreate(cid,name,OBJ_TREND,0,t1,p1,t2,p2);
      ObjectSetInteger(cid,name,OBJPROP_TIME,0,t1);
      ObjectSetDouble (cid,name,OBJPROP_PRICE,0,p1);
      ObjectSetInteger(cid,name,OBJPROP_TIME,1,t2);
      ObjectSetDouble (cid,name,OBJPROP_PRICE,1,p2);
      ObjectSetInteger(cid,name,OBJPROP_COLOR,clr);
      ObjectSetInteger(cid,name,OBJPROP_WIDTH,width);
      ObjectSetInteger(cid,name,OBJPROP_STYLE,style);
      ObjectSetInteger(cid,name,OBJPROP_RAY_RIGHT,false);
      ObjectSetInteger(cid,name,OBJPROP_SELECTABLE,false);
   }

   static void DrawRectangle(string name, datetime t1, double p1,
                              datetime t2, double p2, color clr)
   {
      long cid=ChartID();
      if(ObjectFind(cid,name)<0) ObjectCreate(cid,name,OBJ_RECTANGLE,0,t1,p1,t2,p2);
      ObjectSetInteger(cid,name,OBJPROP_TIME,0,t1);
      ObjectSetDouble (cid,name,OBJPROP_PRICE,0,p1);
      ObjectSetInteger(cid,name,OBJPROP_TIME,1,t2);
      ObjectSetDouble (cid,name,OBJPROP_PRICE,1,p2);
      ObjectSetInteger(cid,name,OBJPROP_COLOR,clr);
      ObjectSetInteger(cid,name,OBJPROP_FILL,true);
      ObjectSetInteger(cid,name,OBJPROP_BACK,true);
      ObjectSetInteger(cid,name,OBJPROP_SELECTABLE,false);
   }

   static void DrawArrow(string name, datetime time, double price,
                         bool is_buy, color clr)
   {
      long cid=ChartID();
      if(ObjectFind(cid,name)<0) ObjectCreate(cid,name,OBJ_ARROW,0,time,price);
      ObjectSetInteger(cid,name,OBJPROP_TIME,time);
      ObjectSetDouble (cid,name,OBJPROP_PRICE,price);
      ObjectSetInteger(cid,name,OBJPROP_ARROWCODE,is_buy?225:226);
      ObjectSetInteger(cid,name,OBJPROP_COLOR,clr);
      ObjectSetInteger(cid,name,OBJPROP_WIDTH,2);
      ObjectSetInteger(cid,name,OBJPROP_ANCHOR,is_buy?ANCHOR_TOP:ANCHOR_BOTTOM);
      ObjectSetInteger(cid,name,OBJPROP_SELECTABLE,false);
   }

   static void DeleteObject(string name) { ObjectDelete(ChartID(),name); }
   static void ClearAll(string prefix)   { ObjectsDeleteAll(ChartID(),prefix); }

   //--- v3 instance methods (need Init() first)
   void DrawHLine(const string name, double price, color clr,
                  int width=1, ENUM_LINE_STYLE style=STYLE_SOLID)
   {
      long cid=m_chart_id;
      if(ObjectFind(cid,name)>=0) ObjectDelete(cid,name);
      ObjectCreate(cid,name,OBJ_HLINE,0,0,price);
      ObjectSetInteger(cid,name,OBJPROP_COLOR,clr);
      ObjectSetInteger(cid,name,OBJPROP_WIDTH,width);
      ObjectSetInteger(cid,name,OBJPROP_STYLE,style);
      ObjectSetInteger(cid,name,OBJPROP_SELECTABLE,false);
   }

   void DrawRect(const string name, datetime t1, double p1,
                 datetime t2, double p2,
                 color clr, int width=1, bool filled=false)
   {
      long cid=m_chart_id;
      if(ObjectFind(cid,name)>=0) ObjectDelete(cid,name);
      ObjectCreate(cid,name,OBJ_RECTANGLE,0,t1,p1,t2,p2);
      ObjectSetInteger(cid,name,OBJPROP_COLOR,clr);
      ObjectSetInteger(cid,name,OBJPROP_WIDTH,width);
      ObjectSetInteger(cid,name,OBJPROP_FILL,filled);
      ObjectSetInteger(cid,name,OBJPROP_BACK,true);
      ObjectSetInteger(cid,name,OBJPROP_SELECTABLE,false);
   }

   void DrawTextLabel(const string name, datetime time, double price,
                      const string text, color clr, int fs=8)
   {
      long cid=m_chart_id;
      if(ObjectFind(cid,name)>=0) ObjectDelete(cid,name);
      ObjectCreate(cid,name,OBJ_TEXT,0,time,price);
      ObjectSetString (cid,name,OBJPROP_TEXT,text);
      ObjectSetInteger(cid,name,OBJPROP_COLOR,clr);
      ObjectSetInteger(cid,name,OBJPROP_FONTSIZE,fs);
      ObjectSetInteger(cid,name,OBJPROP_SELECTABLE,false);
   }

   void DrawArrowInst(const string name, datetime time, double price,
                      int code, color clr, int width=2)
   {
      long cid=m_chart_id;
      if(ObjectFind(cid,name)>=0) ObjectDelete(cid,name);
      ObjectCreate(cid,name,OBJ_ARROW,0,time,price);
      ObjectSetInteger(cid,name,OBJPROP_ARROWCODE,code);
      ObjectSetInteger(cid,name,OBJPROP_COLOR,clr);
      ObjectSetInteger(cid,name,OBJPROP_WIDTH,width);
      ObjectSetInteger(cid,name,OBJPROP_SELECTABLE,false);
   }

   // v3: signal entry arrow
   void DrawSignalArrow(datetime time, double price, int direction, double score)
   {
      string name=MakeName("SIG_");
      int code=(direction==SIGNAL_BUY)?233:234;
      color clr=(direction==SIGNAL_BUY)?clrDodgerBlue:clrOrangeRed;
      DrawArrowInst(name,time,price,code,clr,3);
      DrawTextLabel(name+"_L",time,price,
                    DirToStr(direction)+" "+FormatDbl(score,0)+"%",clr,7);
   }

   // v3: draw all 6 TP + SL lines for a position
   void DrawTPSLLevels(const string ticket_str, int direction,
                       double sl, double tp1, double tp2, double tp3,
                       double tp4, double tp5, double tp6, int active_tps)
   {
      string base=m_prefix+"POS_"+ticket_str+"_";
      DrawHLine(base+"SL",  sl,  clrRed,       1, STYLE_SOLID);
      if(active_tps>=1) DrawHLine(base+"TP1",tp1,clrLimeGreen,1,STYLE_DOT);
      if(active_tps>=2) DrawHLine(base+"TP2",tp2,clrLimeGreen,1,STYLE_DOT);
      if(active_tps>=3) DrawHLine(base+"TP3",tp3,clrGreen,    1,STYLE_DOT);
      if(active_tps>=4) DrawHLine(base+"TP4",tp4,clrGreen,    1,STYLE_DOT);
      if(active_tps>=5) DrawHLine(base+"TP5",tp5,clrDarkGreen,1,STYLE_DOT);
      if(active_tps>=6) DrawHLine(base+"TP6",tp6,clrDarkGreen,2,STYLE_SOLID);
   }

   // v3: draw Order Block zone
   void DrawOrderBlock(datetime t1, double ob_high, double ob_low,
                       int direction, bool mitigated)
   {
      string name=MakeName("OB_");
      color clr=mitigated?clrDimGray:(direction==SIGNAL_BUY?clrRoyalBlue:clrCrimson);
      DrawRect(name,t1,ob_high,TimeCurrent(),ob_low,clr,1,false);
   }

   // v3: draw FVG zone
   void DrawFVG(datetime t1, double fvg_high, double fvg_low,
                int direction, bool filled)
   {
      string name=MakeName("FVG_");
      color clr=filled?clrDimGray:(direction==SIGNAL_BUY?clrCornflowerBlue:clrLightCoral);
      DrawRect(name,t1,fvg_high,TimeCurrent(),fvg_low,clr,1,true);
   }

   void DeleteAll() { ObjectsDeleteAll(m_chart_id,m_prefix); }
   void DeleteByPrefix(const string sub) { ObjectsDeleteAll(m_chart_id,m_prefix+sub); }
};

#endif // MD90_CHART_OBJECTS_MQH
