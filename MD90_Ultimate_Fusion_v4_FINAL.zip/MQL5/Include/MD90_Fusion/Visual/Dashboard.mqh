//+------------------------------------------------------------------+
//|                                                    Dashboard.mqh |
//|                    MD90 Ultimate Fusion v4.0 - FINAL MERGE       |
//|                    v3: equity/DD/session rows                     |
//|                    v2: FusionSignal gates/votes/execution_status  |
//+------------------------------------------------------------------+
#ifndef MD90_DASHBOARD_MQH
#define MD90_DASHBOARD_MQH

#include "../Common/Constants.mqh"
#include "../Common/Utils.mqh"
#include "ChartObjects.mqh"

class CDashboard
{
private:
   string            m_prefix;
   bool              m_visible;
   string            m_symbol;
   ENUM_TIMEFRAMES   m_tf;

   void Row(int r, string key, string val, color kc, color vc)
   {
      CChartObjects::DrawLabel(m_prefix+"K"+IntToString(r), 10,  28+r*15, key, kc, 8);
      CChartObjects::DrawLabel(m_prefix+"V"+IntToString(r), 138, 28+r*15, val, vc, 8);
   }

public:
   CDashboard() : m_prefix("MD90v4_"), m_visible(false)
   { m_symbol=_Symbol; m_tf=PERIOD_CURRENT; }

   void Init(string symbol, ENUM_TIMEFRAMES tf)
   { m_symbol=symbol; m_tf=tf; m_visible=true; }

   void Update(FusionSignal &sig, double balance, double equity)
   {
      if(!m_visible) return;
      string ci[]={"LOW","MEDIUM","HIGH","ULTRA"};
      int cl=MathMin(sig.confidence_level,3);
      color d_clr=(sig.direction==SIGNAL_BUY)?clrDodgerBlue:
                  (sig.direction==SIGNAL_SELL)?clrOrangeRed:clrGray;
      color s_clr=(sig.execution_status=="ALL-IN")?clrLime:
                  (sig.execution_status=="WAITING")?clrYellow:clrRed;

      Row(0,"╔══ MD90 ULTIMATE FUSION v4 ══╗","",       clrGold,     clrGold);
      Row(1,"Symbol  :",m_symbol+" "+EnumToString(m_tf), clrSilver,   clrWhite);
      Row(2,"Time    :",TimeToString(TimeCurrent(),TIME_SECONDS),clrSilver,clrWhite);
      Row(3,"─────────────────────────────","",          clrDimGray,  clrDimGray);
      Row(4,"Status  :",sig.execution_status,            clrSilver,   s_clr);
      Row(5,"Signal  :",DirToStr(sig.direction),         clrSilver,   d_clr);
      Row(6,"Score   :",FormatDbl(sig.fusion_score*100,1)+"%",clrSilver,
          sig.fusion_score>=0.80?clrLime:sig.fusion_score>=0.55?clrYellow:clrOrangeRed);
      Row(7,"Conf    :",FormatDbl(sig.confidence,1)+"%", clrSilver,
          sig.confidence>=80?clrLime:sig.confidence>=60?clrYellow:clrOrange);
      Row(8,"Level   :",ci[cl],                          clrSilver,   clrCyan);
      Row(9,"Votes   :","B:"+IntToString(sig.buy_votes)+
                         " S:"+IntToString(sig.sell_votes)+
                         " N:"+IntToString(sig.neutral_votes),clrSilver,clrWhite);
      Row(10,"─────────────────────────────","",         clrDimGray,  clrDimGray);
      string gstr="G1:"+(sig.gate1_passed?"✓":"✗")+
                  " G2:"+(sig.gate2_passed?"✓":"✗")+
                  " G3:"+(sig.gate3_passed?"✓":"✗")+
                  " G4:"+(sig.gate4_passed?"✓":"✗")+
                  " G5:"+(sig.gate5_passed?"✓":"✗");
      Row(11,"Gates   :",gstr,                           clrSilver,   clrWhite);
      Row(12,"Entry   :",FormatDbl(sig.entry_price),     clrSilver,   clrWhite);
      Row(13,"SL      :",FormatDbl(sig.stop_loss),       clrSilver,   clrRed);
      Row(14,"TP1-TP3 :",FormatDbl(sig.take_profit[0])+" / "+
                          FormatDbl(sig.take_profit[1])+" / "+
                          FormatDbl(sig.take_profit[2]),clrSilver,   clrLimeGreen);
      Row(15,"TP4-TP6 :",FormatDbl(sig.take_profit[3])+" / "+
                          FormatDbl(sig.take_profit[4])+" / "+
                          FormatDbl(sig.take_profit[5]),clrSilver,   clrGreen);
      Row(16,"RR 1/2  :",FormatDbl(sig.risk_reward[0],2)+"x / "+
                          FormatDbl(sig.risk_reward[1],2)+"x",clrSilver,
          sig.risk_reward[0]>=2.0?clrLime:clrOrange);
      Row(17,"─────────────────────────────","",         clrDimGray,  clrDimGray);
      Row(18,"Balance :",StringFormat("$%.2f",balance),  clrSilver,   clrWhite);
      Row(19,"Equity  :",StringFormat("$%.2f",equity),   clrSilver,
          equity>=balance?clrLime:clrOrangeRed);
      Row(20,"LotMult :",FormatDbl(sig.lot_multiplier,2)+"x",clrSilver,clrCyan);
      Row(21,"SLMult  :",FormatDbl(sig.sl_multiplier,2)+"x",clrSilver,clrCyan);
      Row(22,"─────────────────────────────","",         clrDimGray,  clrDimGray);
      Row(23,"EA      :",EA_NAME+" v"+EA_VERSION,        clrDimGray,  clrDimGray);
      ChartRedraw();
   }

   void Refresh() {}
   void OnChartEvent(const int id,const long&,const double&,const string&) {}
   void Hide() { m_visible=false; CChartObjects::ClearAll(m_prefix); }
   void Show() { m_visible=true; }
};

#endif // MD90_DASHBOARD_MQH
