//+------------------------------------------------------------------+
//|                                             HTFDataProvider.mqh  |
//|                    MD90 Ultimate Fusion v4.0 - FINAL             |
//+------------------------------------------------------------------+
#ifndef MD90_HTF_DATA_PROVIDER_MQH
#define MD90_HTF_DATA_PROVIDER_MQH

#include "../Common/Constants.mqh"
#include "../Common/Logger.mqh"

class CHTFDataProvider
{
private:
   string m_symbol;

   // MQL5-correct: create handle, CopyBuffer, release
   double _GetIndicator(int handle, int buf, int shift)
   {
      if(handle==INVALID_HANDLE) return 0.0;
      double arr[1]; ArraySetAsSeries(arr,true);
      double result=0.0;
      if(CopyBuffer(handle,buf,shift,1,arr)>0) result=arr[0];
      return result;
   }

public:
   bool Init(string symbol) { m_symbol=symbol; return true; }

   double GetClose(ENUM_TIMEFRAMES tf, int shift=0) { return iClose(m_symbol,tf,shift); }
   double GetHigh(ENUM_TIMEFRAMES tf, int shift=0)  { return iHigh(m_symbol,tf,shift);  }
   double GetLow(ENUM_TIMEFRAMES tf, int shift=0)   { return iLow(m_symbol,tf,shift);   }
   double GetOpen(ENUM_TIMEFRAMES tf, int shift=0)  { return iOpen(m_symbol,tf,shift);  }
   long   GetVolume(ENUM_TIMEFRAMES tf, int shift=0){ return iTickVolume(m_symbol,tf,shift); }

   // MQL5 handle-based MA (FIXED from v2 bug)
   double GetMA(ENUM_TIMEFRAMES tf, int period, int shift=0)
   {
      int h=iMA(m_symbol,tf,period,0,MODE_EMA,PRICE_CLOSE);
      double r=_GetIndicator(h,0,shift);
      IndicatorRelease(h);
      return r;
   }

   // MQL5 handle-based ATR (FIXED from v2 bug)
   double GetATR(ENUM_TIMEFRAMES tf, int period, int shift=0)
   {
      int h=iATR(m_symbol,tf,period);
      double r=_GetIndicator(h,0,shift);
      IndicatorRelease(h);
      return r;
   }

   // HTF bias: compare close vs EMA20 on H4 and D1
   int GetH4Bias()
   {
      double c=GetClose(PERIOD_H4,1), ma=GetMA(PERIOD_H4,20,1);
      return (ma>0) ? (c>ma?SIGNAL_BUY:SIGNAL_SELL) : SIGNAL_NEUTRAL;
   }
   int GetD1Bias()
   {
      double c=GetClose(PERIOD_D1,1), ma=GetMA(PERIOD_D1,50,1);
      return (ma>0) ? (c>ma?SIGNAL_BUY:SIGNAL_SELL) : SIGNAL_NEUTRAL;
   }
};

#endif // MD90_HTF_DATA_PROVIDER_MQH
