//+------------------------------------------------------------------+
//|                                                  DataManager.mqh |
//|                    MD90 Ultimate Fusion v4.0 - FINAL MERGE       |
//|                    v3: OHLCV cache arrays + IsNewBar()            |
//|                    v2: orchestrates HTF/Tick/External providers   |
//+------------------------------------------------------------------+
#ifndef MD90_DATA_MANAGER_MQH
#define MD90_DATA_MANAGER_MQH

#include "../Common/Constants.mqh"
#include "../Common/Logger.mqh"
#include "../Common/Utils.mqh"
#include "HTFDataProvider.mqh"
#include "TickDataProvider.mqh"
#include "ExternalDataProvider.mqh"

struct SBarData
{
   datetime time;
   double   open,high,low,close,volume;
   bool     valid;
};

class CDataManager
{
private:
   string            m_symbol;
   ENUM_TIMEFRAMES   m_tf;
   int               m_depth;
   datetime          m_last_bar;

   // v3: cached OHLCV arrays
   double            m_open[],m_high[],m_low[],m_close[];
   long              m_volume[];
   datetime          m_time[];
   bool              m_ready;

   // v2: sub-providers
   CHTFDataProvider*      m_htf;
   CTickDataProvider*     m_tick;
   CExternalDataProvider* m_ext;

public:
   CDataManager() : m_depth(300), m_last_bar(0), m_ready(false),
                    m_htf(NULL), m_tick(NULL), m_ext(NULL)
   { m_symbol=_Symbol; m_tf=PERIOD_CURRENT; }

   ~CDataManager()
   { if(m_htf) delete m_htf; if(m_tick) delete m_tick; if(m_ext) delete m_ext; }

   bool Init(string symbol, ENUM_TIMEFRAMES tf, int depth=300)
   {
      m_symbol=symbol; m_tf=tf; m_depth=depth;
      ArraySetAsSeries(m_open,true); ArraySetAsSeries(m_high,true);
      ArraySetAsSeries(m_low,true);  ArraySetAsSeries(m_close,true);
      ArraySetAsSeries(m_volume,true);ArraySetAsSeries(m_time,true);

      m_htf  = new CHTFDataProvider();  m_htf.Init(symbol);
      m_tick = new CTickDataProvider(); m_tick.Init(symbol);
      m_ext  = new CExternalDataProvider(); m_ext.Init(symbol);

      return Refresh();
   }

   bool Refresh()
   {
      if(CopyOpen(m_symbol,m_tf,0,m_depth,m_open)  <=0) return false;
      if(CopyHigh(m_symbol,m_tf,0,m_depth,m_high)  <=0) return false;
      if(CopyLow(m_symbol,m_tf,0,m_depth,m_low)    <=0) return false;
      if(CopyClose(m_symbol,m_tf,0,m_depth,m_close) <=0) return false;
      if(CopyTickVolume(m_symbol,m_tf,0,m_depth,m_volume)<=0)
      { ArrayResize(m_volume,m_depth); ArrayInitialize(m_volume,0); }
      if(CopyTime(m_symbol,m_tf,0,m_depth,m_time)  <=0) return false;
      m_ready=true; return true;
   }

   bool IsNewBar()
   {
      datetime cur=iTime(m_symbol,m_tf,0);
      if(cur!=m_last_bar) { m_last_bar=cur; return true; }
      return false;
   }

   SBarData GetBar(int shift) const
   {
      SBarData b; b.valid=m_ready&&shift>=0&&shift<m_depth;
      if(!b.valid) return b;
      b.time=m_time[shift]; b.open=m_open[shift]; b.high=m_high[shift];
      b.low=m_low[shift]; b.close=m_close[shift]; b.volume=(double)m_volume[shift];
      return b;
   }

   double   GetClose(int s)  const { return (m_ready&&s<m_depth)?m_close[s]:0; }
   double   GetHigh(int s)   const { return (m_ready&&s<m_depth)?m_high[s]:0; }
   double   GetLow(int s)    const { return (m_ready&&s<m_depth)?m_low[s]:0; }
   double   GetOpen(int s)   const { return (m_ready&&s<m_depth)?m_open[s]:0; }
   long     GetVolume(int s) const { return (m_ready&&s<m_depth)?m_volume[s]:0; }
   datetime GetTime(int s)   const { return (m_ready&&s<m_depth)?m_time[s]:0; }
   int      GetDepth()       const { return m_depth; }
   bool     IsReady()        const { return m_ready; }
   string   GetSymbol()      const { return m_symbol; }
   ENUM_TIMEFRAMES GetTF()   const { return m_tf; }

   CHTFDataProvider*      GetHTFProvider()      { return m_htf; }
   CTickDataProvider*     GetTickProvider()     { return m_tick; }
   CExternalDataProvider* GetExternalProvider() { return m_ext; }
};

#endif // MD90_DATA_MANAGER_MQH
