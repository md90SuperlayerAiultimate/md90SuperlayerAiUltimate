//+------------------------------------------------------------------+
//|                                            TickDataProvider.mqh  |
//|                    MD90 Ultimate Fusion v4.0 - FINAL MERGE       |
//|                    v3: STickSnapshot struct + GetSpreadPts()      |
//|                    v2: OnTick() + IsBidUp/Down                    |
//+------------------------------------------------------------------+
#ifndef MD90_TICK_DATA_PROVIDER_MQH
#define MD90_TICK_DATA_PROVIDER_MQH

#include "../Common/Constants.mqh"
#include "../Common/Logger.mqh"

struct STickSnapshot
{
   datetime time;
   double   bid, ask, spread_pts, last;
   ulong    volume;
   bool     valid;
};

class CTickDataProvider
{
private:
   string        m_symbol;
   STickSnapshot m_last, m_prev;
   int           m_tick_count;

public:
   CTickDataProvider() : m_tick_count(0) { m_symbol=_Symbol; ZeroMemory(m_last); ZeroMemory(m_prev); }

   bool Init(string symbol)
   {
      m_symbol=symbol;
      MqlTick t;
      if(SymbolInfoTick(symbol,t))
      {
         m_last.time=t.time; m_last.bid=t.bid; m_last.ask=t.ask;
         m_last.last=t.last; m_last.volume=t.volume;
         m_last.spread_pts=t.ask-t.bid; m_last.valid=true;
         m_prev=m_last;
      }
      return true;
   }

   bool OnTick()
   {
      MqlTick t;
      if(!SymbolInfoTick(m_symbol,t)) return false;
      m_prev=m_last;
      m_last.time=t.time; m_last.bid=t.bid; m_last.ask=t.ask;
      m_last.last=t.last; m_last.volume=t.volume;
      m_last.spread_pts=t.ask-t.bid; m_last.valid=true;
      m_tick_count++;
      return true;
   }

   STickSnapshot GetLastTick() const { return m_last; }
   STickSnapshot GetPrevTick() const { return m_prev; }

   double GetBid()       const { return m_last.bid; }
   double GetAsk()       const { return m_last.ask; }
   double GetSpreadPts() const { return m_last.spread_pts; }
   double GetMid()       const { return (m_last.bid+m_last.ask)*0.5; }
   double GetLast()      const { return m_last.last; }
   long   GetVolume()    const { return (long)m_last.volume; }
   int    GetTickCount() const { return m_tick_count; }

   //--- v2 compat
   double GetSpread() const { return m_last.spread_pts/_Point; }
   bool IsBidUp()     const { return m_last.bid>m_prev.bid; }
   bool IsBidDown()   const { return m_last.bid<m_prev.bid; }

   int GetTickDirection() const
   {
      if(!m_last.valid||!m_prev.valid) return SIGNAL_NEUTRAL;
      if(m_last.bid>m_prev.bid) return SIGNAL_BUY;
      if(m_last.bid<m_prev.bid) return SIGNAL_SELL;
      return SIGNAL_NEUTRAL;
   }
};

#endif // MD90_TICK_DATA_PROVIDER_MQH
