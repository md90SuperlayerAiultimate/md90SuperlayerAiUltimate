"""
latency/ws_engine.py — WebSocket Latency Engine
Dual feed: Polymarket + Binance simultaneously.
Detects divergence in <500ms. Fires callback for execution.
This is the core of the $40M latency arbitrage strategy.
"""
import asyncio, json, logging, time
from datetime import datetime, timezone, timedelta
from typing import Callable, Dict, Optional
import websockets

log = logging.getLogger("MD90.Latency")
WITA     = timezone(timedelta(hours=8))
BIN_WS   = "wss://stream.binance.com:9443/ws/btcusdt@ticker"
POLY_WS  = "wss://ws-subscriptions-clob.polymarket.com/ws/market"
DIVERGE  = 0.025


class LatencyEngine:
    def __init__(self, on_signal: Callable = None):
        self._poly: Dict[str,float] = {}
        self._bin   = 0.0
        self._on_signal = on_signal or self._log_signal
        self._running   = False
        self._fired     = 0
        self._start_ts  = 0.0

    async def start(self):
        self._running  = True
        self._start_ts = time.time()
        log.info("[WS] Latency engine starting...")
        await asyncio.gather(
            self._binance_loop(),
            self._polymarket_loop(),
            return_exceptions=True
        )

    def stop(self):
        self._running = False

    async def _binance_loop(self):
        while self._running:
            try:
                async with websockets.connect(BIN_WS, ping_interval=20,
                                               open_timeout=10) as ws:
                    log.info("[WS] ✅ Binance feed connected")
                    async for raw in ws:
                        if not self._running: break
                        d = json.loads(raw)
                        self._bin = float(d.get("c",0))
                        await self._check()
            except Exception as e:
                log.warning(f"[WS-BIN] {e} — retry 3s")
                await asyncio.sleep(3)

    async def _polymarket_loop(self):
        while self._running:
            try:
                async with websockets.connect(POLY_WS, ping_interval=20,
                                               open_timeout=10) as ws:
                    log.info("[WS] ✅ Polymarket feed connected")
                    await ws.send(json.dumps({"type":"subscribe","channel":"price_change"}))
                    async for raw in ws:
                        if not self._running: break
                        try:
                            d = json.loads(raw)
                            mkt = d.get("market","")
                            p   = float(d.get("price",0))
                            if mkt and p > 0:
                                self._poly[mkt] = p
                                await self._check()
                        except: pass
            except Exception as e:
                log.warning(f"[WS-POLY] {e} — retry 3s")
                await asyncio.sleep(3)

    async def _check(self):
        if not self._bin: return
        for mkt, p in self._poly.items():
            if abs(p - 0.5) > DIVERGE:
                self._fired += 1
                await self._on_signal({
                    "type":       "LATENCY_SIGNAL",
                    "market_id":  mkt,
                    "poly_price": p,
                    "bin_price":  self._bin,
                    "divergence": round(abs(p-0.5),4),
                    "direction":  "YES" if p > 0.5 else "NO",
                    "latency_ms": round((time.time()-self._start_ts)*1000,1),
                    "ts":         datetime.now(WITA).isoformat(),
                })

    async def _log_signal(self, s: dict):
        log.info(f"[SIGNAL] div={s['divergence']:.4f} dir={s['direction']} mkt={s['market_id'][:16]}")

    def stats(self) -> dict:
        return {"running":self._running,"bin_price":self._bin,
                "poly_markets":len(self._poly),"signals_fired":self._fired}
