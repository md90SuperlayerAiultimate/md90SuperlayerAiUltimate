#!/usr/bin/env python3
"""
MD90 ULTIMATE FUSION v4 — Live Dashboard
Real-time monitoring: Signal + HMM + MiroFish + Bayesian + Performance
Reads from state files — no trading logic here.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import json
from datetime import datetime, timezone, timedelta
import time

WITA = timezone(timedelta(hours=8))

st.set_page_config(page_title="MD90 v4", page_icon="⚡", layout="wide")

st.markdown("""
<style>
[data-testid="stAppViewContainer"]{background:#0d1117}
[data-testid="stSidebar"]{background:#161b22;border-right:1px solid #21262d}
.card{background:#161b22;border:1px solid #30363d;border-radius:10px;padding:16px;margin:6px 0}
.bull{color:#3fb950;font-weight:700} .bear{color:#f85149;font-weight:700} .neut{color:#8b949e}
.badge-allin{background:#3fb950;color:#0d1117;padding:3px 10px;border-radius:12px;font-weight:700;font-size:12px}
.badge-wait{background:#d29922;color:#0d1117;padding:3px 10px;border-radius:12px;font-weight:700;font-size:12px}
.badge-abort{background:#f85149;color:white;padding:3px 10px;border-radius:12px;font-weight:700;font-size:12px}
.halt{background:#da3633;color:white;padding:14px;border-radius:8px;text-align:center;font-weight:700;font-size:16px;margin:8px 0}
.engine-badge{font-size:13px;padding:4px 12px;border-radius:8px;font-weight:600}
</style>""", unsafe_allow_html=True)

LAYER_LABELS = [
    "L1 SNR","L2 EMA","L3 RSI","L4 Stoch","L5 OB",
    "L6 Vol","L7 MTF","L8 Sentiment","L9 UltraScalp","L10 PrimeSwing",
    "L11 Macro","L12 VWAP","L13 ATR","L14 OTE","L15 FVG",
    "L16 MasterCall","L17 Time"
]

def load_md90_state():
    try:
        p = "/tmp/md90_v4_state.json"
        if os.path.exists(p):
            return json.loads(open(p).read())
    except: pass
    return {}

def load_poly_state():
    fn = os.getenv("POLYMARKET_STATE_FILE","polymarket_state.json")
    try:
        if os.path.exists(fn):
            return json.loads(open(fn).read())
    except: pass
    return {}

def load_bayesian():
    fn = os.getenv("BAYESIAN_PRIORS_FILE","polymarket_priors.json")
    try:
        if os.path.exists(fn):
            return json.loads(open(fn).read())
    except: pass
    return {}

def load_backtest():
    fn = "logs/backtest_results.json"
    try:
        if os.path.exists(fn):
            return json.loads(open(fn).read())
    except: pass
    return {}

def regime_color(r):
    return {"BULL_TREND":"#3fb950","BEAR_TREND":"#f85149",
            "HIGH_VOL":"#d29922","LOW_VOL":"#8b949e","RANGING":"#58a6ff",
            "TRENDING_UP":"#3fb950","TRENDING_DOWN":"#f85149",
            "VOLATILE":"#d29922","BREAKOUT":"#a371f7",
            "SIDEWAYS":"#8b949e"}.get(r,"#8b949e")

def regime_emoji(r):
    return {"BULL_TREND":"📈","BEAR_TREND":"📉","HIGH_VOL":"⚡",
            "LOW_VOL":"😴","RANGING":"〰️","TRENDING_UP":"📈",
            "TRENDING_DOWN":"📉","VOLATILE":"⚡","BREAKOUT":"🚀",
            "SIDEWAYS":"〰️","TRANSITION":"🔄"}.get(r,"❓")

def main():
    st.title("⚡ MD90 ULTIMATE FUSION v4")
    now = datetime.now(WITA).strftime("%Y-%m-%d %H:%M:%S WITA")

    s4  = load_md90_state()
    ps  = load_poly_state()
    bay = load_bayesian()
    bt  = load_backtest()

    # ── SIDEBAR ────────────────────────────────────────────────────
    with st.sidebar:
        st.markdown("## ⚙️ Controls")
        refresh = st.slider("Refresh (sec)", 5, 60, 10)
        st.markdown("---")
        st.markdown("### System Status")
        eng = s4.get("engine_status","—")
        sc  = {"RUNNING":"🟢","STOPPED":"🔴","HALTED":"🔴","STARTING":"🟡"}.get(eng,"⚪")
        st.markdown(f"**Engine:** {sc} {eng}")
        st.markdown(f"**WITA:** `{now}`")
        st.markdown("---")
        st.markdown("### Architecture Layers")
        st.markdown("""
| Layer | Component |
|-------|-----------|
| L1 | Memory (CLAUDE.md) |
| L2 | Knowledge (Playbooks) |
| L3 | Guardrail (PreMarket) |
| L4 | Delegation (Agents) |
| L5 | Distribution (Telegram) |
| L6 | Live State |
| L7 | Recovery (CircuitBreaker) |
| L8 | Learning (Bayesian) |
        """)
        st.markdown("---")
        st.markdown("### Signal Gates")
        st.markdown("""
- **G1** EMA+MTF+PrimeSwing
- **G2** OTE+FVG
- **G3** RSI+Stoch+Vol+VWAP (3/4)
- **G4** MasterCall+UltraScalp
- **G5** TimeStop+RR≥2.0
        """)

    # ── ALERTS ─────────────────────────────────────────────────────
    if eng in ("HALTED","STOPPED"):
        st.markdown('<div class="halt">⛔ ENGINE HALTED — Check circuit breaker</div>', unsafe_allow_html=True)

    # ── ACCOUNT ROW ────────────────────────────────────────────────
    acc  = s4.get("account",{})
    risk = s4.get("risk",{})
    c1,c2,c3,c4,c5,c6 = st.columns(6)
    c1.metric("Equity",   f"${acc.get('equity',0):,.2f}")
    c2.metric("Balance",  f"${acc.get('balance',0):,.2f}")
    dd = risk.get("session_dd", ps.get("snapshots", [{}])[-1].get("equity",0))
    c3.metric("Session DD", f"{risk.get('session_dd',0):.2f}%")
    c4.metric("Open Pos",   acc.get("open_positions", len(ps.get("positions",[]))))
    c5.metric("Regime",     s4.get("regime","—"))
    c6.metric("Session",    s4.get("session","—"))

    st.divider()

    # ── SIGNAL BOARD ───────────────────────────────────────────────
    st.subheader("📡 Signal Board")
    pairs = s4.get("pairs",{})
    if pairs:
        cols = st.columns(min(len(pairs),4))
        for i,(sym,sig) in enumerate(pairs.items()):
            with cols[i%4]:
                d  = sig.get("direction",0)
                fs = sig.get("fusion_score",0)
                co = sig.get("confidence",0)
                st_ = sig.get("execution_status","ABORT")
                clz = {1:"bull",-1:"bear",0:"neut"}.get(d,"neut")
                bc  = {1:"#3fb950",-1:"#f85149",0:"#8b949e"}.get(d,"#8b949e")
                em  = {1:"🟢",-1:"🔴",0:"⚪"}.get(d,"⚪")
                ds  = {1:"BUY",-1:"SELL",0:"NEUTRAL"}.get(d,"?")
                badge = {"ALL-IN":"badge-allin","WAITING":"badge-wait","ABORT":"badge-abort"}.get(st_,"badge-abort")
                g   = [sig.get(f"gate{j}",False) for j in range(1,6)]
                gates = "".join("✅" if x else "❌" for x in g)
                r   = sig.get("regime","?")
                rc  = regime_color(r)
                st.markdown(f"""
<div class="card" style="border-color:{bc}">
  <div style="display:flex;justify-content:space-between;align-items:center">
    <b style="font-size:15px">{sym}</b>
    <span class="{badge}">{st_}</span>
  </div>
  <div class="{clz}" style="font-size:22px;font-weight:700;margin:6px 0">{em} {ds}</div>
  <div style="background:#21262d;height:5px;border-radius:3px;margin:4px 0">
    <div style="width:{int(fs*100)}%;height:5px;background:{bc};border-radius:3px"></div>
  </div>
  <div style="font-size:12px;color:#c9d1d9">
    Score: <b>{fs:.3f}</b> | Conf: <b>{co:.0f}%</b><br>
    <span style="color:{rc}">{regime_emoji(r)} {r}</span><br>
    <span style="color:#8b949e">Gates: {gates}</span>
  </div>
</div>""", unsafe_allow_html=True)
    else:
        st.info("Waiting for engine signals...")

    st.divider()

    # ── 17-LAYER HEATMAP ───────────────────────────────────────────
    st.subheader("🔥 17-Layer Signal Heatmap")
    if pairs:
        syms   = list(pairs.keys())
        matrix = []
        for sym in syms:
            ld = pairs[sym].get("layer_directions",[0]*17)
            ls = pairs[sym].get("layer_strengths",[0.0]*17)
            row = [s*d for s,d in zip(ls[:17],ld[:17])]
            while len(row) < 17: row.append(0)
            matrix.append(row)

        fig = go.Figure(go.Heatmap(
            z=matrix, x=LAYER_LABELS, y=syms,
            colorscale=[[0,"#f85149"],[0.5,"#161b22"],[1,"#3fb950"]],
            zmid=0, zmin=-1, zmax=1,
            text=[[f"{v:+.2f}" for v in row] for row in matrix],
            texttemplate="%{text}", showscale=True,
            colorbar=dict(title="Dir×Str", tickvals=[-1,0,1],
                         ticktext=["SELL","NEUT","BUY"],
                         bgcolor="#161b22",bordercolor="#30363d",
                         tickcolor="#c9d1d9",titlefont=dict(color="#c9d1d9"),
                         tickfont=dict(color="#c9d1d9"))))
        fig.update_layout(paper_bgcolor="#0d1117",plot_bgcolor="#0d1117",
                          font_color="#c9d1d9",height=max(180,len(syms)*70+60),
                          margin=dict(l=0,r=0,t=10,b=0),
                          xaxis=dict(tickangle=45,tickfont=dict(size=10)))
        st.plotly_chart(fig, use_container_width=True)

    st.divider()

    # ── HMM + MIROFISH ROW ────────────────────────────────────────
    col_hmm, col_miro, col_bay = st.columns(3)

    with col_hmm:
        st.subheader("🧬 HMM Regime")
        regime = s4.get("regime","—")
        rc     = regime_color(regime)
        st.markdown(f"""
<div class="card">
  <div style="font-size:28px;color:{rc};font-weight:700">{regime_emoji(regime)} {regime}</div>
  <div style="color:#8b949e;font-size:12px;margin-top:8px">
    Session: {s4.get('session','—')}<br>
    Engine: {s4.get('engine_status','—')}
  </div>
</div>""", unsafe_allow_html=True)

    with col_miro:
        st.subheader("🕸️ MiroFish Network")
        # Read from first pair's network score if available
        net_score = 0.5; clusters = 0; direction = "NEUTRAL"
        if pairs:
            fp = list(pairs.values())[0]
            net_score = fp.get("network_score", 0.5)
            clusters  = fp.get("clusters", 0)
        st.markdown(f"""
<div class="card">
  <div style="font-size:24px;font-weight:700;color:#58a6ff">
    Score: {net_score:.3f}
  </div>
  <div style="color:#8b949e;font-size:12px;margin-top:8px">
    Clusters: {clusters}<br>
    Source: Wallet-Market Graph
  </div>
</div>""", unsafe_allow_html=True)

    with col_bay:
        st.subheader("📊 Bayesian Priors")
        if bay:
            records = []
            for mid, v in list(bay.items())[:5]:
                a = v.get("alpha",1); b = v.get("beta",1)
                prob = a/(a+b)
                records.append({"Market":mid[:20]+"...", "P(win)":round(prob,3), "N":v.get("total",0)})
            if records:
                df = pd.DataFrame(records)
                st.dataframe(df, use_container_width=True, hide_index=True)
            else:
                st.info("No prior data yet")
        else:
            st.info("No prior data yet")

    st.divider()

    # ── POLYMARKET POSITIONS ───────────────────────────────────────
    st.subheader("📋 Polymarket Positions")
    poly_pos = ps.get("positions",[])
    if poly_pos:
        st.dataframe(pd.DataFrame(poly_pos), use_container_width=True, hide_index=True)
    else:
        st.info("No open Polymarket positions")

    # ── PERFORMANCE ────────────────────────────────────────────────
    st.divider()
    st.subheader("📈 Performance")

    # MD90 trade history
    hist = s4.get("trade_history",[])
    # Polymarket snapshots
    snaps = ps.get("snapshots",[])

    tab1, tab2, tab3 = st.tabs(["Equity Curve","Trade History","Backtest"])

    with tab1:
        if snaps:
            eq_vals = [s.get("equity",0) for s in snaps]
            fig = go.Figure(go.Scatter(y=eq_vals, fill="tozeroy",
                line=dict(color="#3fb950",width=2), name="Equity"))
            fig.update_layout(paper_bgcolor="#0d1117",plot_bgcolor="#161b22",
                font_color="#c9d1d9",height=300,margin=dict(l=0,r=0,t=10,b=0),
                xaxis=dict(showgrid=False),yaxis=dict(gridcolor="#21262d",title="USDC"))
            st.plotly_chart(fig, use_container_width=True)
        elif hist and "pnl" in (hist[0] if hist else {}):
            pnls = [t["pnl"] for t in hist]
            cum  = [sum(pnls[:i+1]) for i in range(len(pnls))]
            fig  = go.Figure(go.Scatter(y=cum, fill="tozeroy",
                line=dict(color="#3fb950",width=2)))
            fig.update_layout(paper_bgcolor="#0d1117",plot_bgcolor="#161b22",
                font_color="#c9d1d9",height=300,margin=dict(l=0,r=0,t=10,b=0))
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No equity data yet")

    with tab2:
        if hist:
            df = pd.DataFrame(hist)
            cols_show = [c for c in ["symbol","side","entry","exit","pnl","reason","session","regime","close_time"] if c in df.columns]
            if cols_show:
                st.dataframe(df[cols_show].tail(50), use_container_width=True, hide_index=True)
                total = len(df)
                if "pnl" in df.columns:
                    wins   = (df["pnl"]>0).sum()
                    wr     = wins/total*100 if total>0 else 0
                    gp     = df[df["pnl"]>0]["pnl"].sum()
                    gl     = abs(df[df["pnl"]<0]["pnl"].sum())
                    pf     = gp/gl if gl>0 else 0
                    c1,c2,c3,c4 = st.columns(4)
                    c1.metric("Total",total); c2.metric("WR",f"{wr:.1f}%")
                    c3.metric("PF",f"{pf:.2f}"); c4.metric("PnL",f"${df['pnl'].sum():+.2f}")
        else:
            st.info("No trade history yet")

    with tab3:
        if bt:
            c1,c2,c3,c4,c5,c6 = st.columns(6)
            c1.metric("Win Rate",   f"{bt.get('win_rate',0):.1f}%")
            c2.metric("Profit Factor", f"{bt.get('profit_factor',0):.2f}")
            c3.metric("Sharpe",     f"{bt.get('sharpe',0):.3f}")
            c4.metric("Sortino",    f"{bt.get('sortino',0):.3f}")
            c5.metric("Max DD",     f"{bt.get('max_dd_pct',0):.2f}%")
            c6.metric("Total PnL",  f"${bt.get('final_cap',0)-bt.get('initial_cap',0):+,.0f}")
            # Equity curve from backtest
            ec = bt.get("equity_curve",[])
            if ec:
                fig = go.Figure(go.Scatter(y=ec, fill="tozeroy",
                    line=dict(color="#58a6ff",width=2), name="Backtest"))
                fig.update_layout(paper_bgcolor="#0d1117",plot_bgcolor="#161b22",
                    font_color="#c9d1d9",height=280,margin=dict(l=0,r=0,t=10,b=0),
                    title=f"Backtest {bt.get('symbol','')} {bt.get('timeframe','')} {bt.get('start','')}→{bt.get('end','')}",
                    yaxis=dict(title="$",gridcolor="#21262d"))
                st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("Run backtest first: python main.py --mode backtest")

    # ── ERRORS ─────────────────────────────────────────────────────
    errors = s4.get("errors",[])
    if errors:
        with st.expander(f"⚠️ Error Log ({len(errors)})"):
            for e in reversed(errors[-10:]):
                st.text(f"{e.get('time','')} — {e.get('msg','')}")

    time.sleep(refresh)
    st.rerun()


if __name__ == "__main__":
    main()
