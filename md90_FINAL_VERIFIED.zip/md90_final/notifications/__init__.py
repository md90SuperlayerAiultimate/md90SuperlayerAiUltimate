"""
MD90 — Notifications (Telegram)
Trade open/close, signal alert, whale veto, circuit breaker, daily briefing.
Jika token tidak di-set → fallback ke console print (tidak crash).
"""
import os, asyncio
from datetime import datetime, timezone, timedelta

WITA = timezone(timedelta(hours=8))


class TelegramNotifier:

    def __init__(self, token: str = "", chat_id: str = ""):
        self.token   = token   or os.getenv("TELEGRAM_TOKEN",   "")
        self.chat_id = chat_id or os.getenv("TELEGRAM_CHAT_ID", "")
        self._enabled = bool(self.token and self.chat_id)
        if not self._enabled:
            print("[Notif] Telegram tidak dikonfigurasi — fallback console")

    async def send(self, text: str, parse_mode: str = "Markdown") -> bool:
        if not self._enabled:
            now = datetime.now(WITA).strftime("%H:%M")
            print(f"[NOTIF {now}] {text.replace('`','').replace('*','')[:160]}")
            return True
        try:
            import aiohttp
            url = f"https://api.telegram.org/bot{self.token}/sendMessage"
            for chunk in [text[i:i+4000] for i in range(0, len(text), 4000)]:
                async with aiohttp.ClientSession() as s:
                    await s.post(url, json={
                        "chat_id": self.chat_id,
                        "text": chunk,
                        "parse_mode": parse_mode
                    }, timeout=aiohttp.ClientTimeout(total=10))
            return True
        except Exception as e:
            print(f"[Notif] Telegram error: {e}")
            return False

    async def trade_open(self, side: str, symbol: str, price: float,
                         size: float, sl: float, tp1: float, session: str,
                         regime: str, risk_pct: float, confidence: float,
                         status: str, lot_mult: float):
        icon = "📈" if side == "LONG" else "📉"
        await self.send(
            f"{icon} *OPEN {status}* — {symbol}\n"
            f"```\n"
            f"Side    : {side}\n"
            f"Entry   : {price:.5f}\n"
            f"Size    : {size:.5f}\n"
            f"SL      : {sl:.5f}\n"
            f"TP1     : {tp1:.5f}\n"
            f"Session : {session} | Regime: {regime}\n"
            f"Risk    : {risk_pct:.2f}%  Mult: {lot_mult:.1f}x\n"
            f"Conf    : {confidence:.1f}%\n"
            f"Time    : {datetime.now(WITA).strftime('%H:%M WITA')}\n"
            f"```"
        )

    async def trade_close(self, side: str, symbol: str, entry: float,
                          exit_price: float, pnl: float, reason: str, equity: float):
        icon = "✅" if pnl > 0 else "❌"
        await self.send(
            f"{icon} *CLOSE [{reason}]* — {symbol}\n"
            f"```\n"
            f"Side    : {side}\n"
            f"Entry   : {entry:.5f}\n"
            f"Exit    : {exit_price:.5f}\n"
            f"PnL     : ${pnl:+.2f}\n"
            f"Equity  : ${equity:.2f}\n"
            f"Time    : {datetime.now(WITA).strftime('%H:%M WITA')}\n"
            f"```"
        )

    async def partial_tp(self, symbol: str, side: str, tp_num: int,
                         price: float, pnl: float, equity: float, pct: float):
        await self.send(
            f"🎯 *PARTIAL TP{tp_num}* — {symbol}\n"
            f"```\n"
            f"Side    : {side}\n"
            f"Price   : {price:.5f}\n"
            f"Closed  : {pct:.0f}%\n"
            f"PnL     : ${pnl:+.2f}\n"
            f"Equity  : ${equity:.2f}\n"
            f"Time    : {datetime.now(WITA).strftime('%H:%M WITA')}\n"
            f"```"
        )

    async def signal_alert(self, symbol: str, direction: str, status: str,
                           score: float, confidence: float, session: str, regime: str):
        if status not in ("ALL-IN", "WAITING"):
            return
        icon = "🔥" if status == "ALL-IN" else "⏳"
        await self.send(
            f"{icon} *SIGNAL {status}* — {symbol}\n"
            f"```\n"
            f"Dir     : {direction}\n"
            f"Score   : {score:.4f}\n"
            f"Conf    : {confidence:.1f}%\n"
            f"Session : {session} | Regime: {regime}\n"
            f"Time    : {datetime.now(WITA).strftime('%H:%M WITA')}\n"
            f"```"
        )

    async def whale_veto(self, symbol: str, reason: str,
                         net_flow: float, exit_count: int):
        await self.send(
            f"🚨 *WHALE VETO* — {symbol}\n"
            f"```\n"
            f"Reason  : {reason}\n"
            f"NetFlow : ${net_flow:,.0f}\n"
            f"Exits   : {exit_count}\n"
            f"Action  : FORCE CLOSE\n"
            f"Time    : {datetime.now(WITA).strftime('%H:%M WITA')}\n"
            f"```"
        )

    async def circuit_breaker(self, reason: str, equity: float,
                              daily_pnl: float, drawdown_pct: float):
        await self.send(
            f"🛑 *CIRCUIT BREAKER*\n"
            f"```\n"
            f"Reason  : {reason}\n"
            f"Equity  : ${equity:.2f}\n"
            f"DayPnL  : ${daily_pnl:+.2f}\n"
            f"DD      : {drawdown_pct:.2f}%\n"
            f"Time    : {datetime.now(WITA).strftime('%H:%M WITA')}\n"
            f"```"
        )

    async def daily_briefing(self, report_text: str):
        await self.send(
            f"📊 *DAILY BRIEFING — {datetime.now(WITA).strftime('%d %b %Y')}*\n"
            f"```\n{report_text}\n```"
        )

    async def error_alert(self, context: str, error: str):
        await self.send(
            f"⚠️ *ERROR [{context}]*\n"
            f"`{str(error)[:300]}`\n"
            f"_{datetime.now(WITA).strftime('%H:%M WITA')}_"
        )
