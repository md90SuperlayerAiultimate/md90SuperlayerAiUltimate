"""
hmm/regime_engine.py
HMM (Hidden Markov Model) Regime Engine.
5-state HMM trained on returns, volatility, and volume.
States: BULL_TREND | BEAR_TREND | HIGH_VOL | LOW_VOL | RANGING
Provides: regime label, transition probability, persistence score.
"""
import numpy as np
import logging
from dataclasses import dataclass
from typing import List, Optional

log = logging.getLogger(__name__)


@dataclass
class HMMRegimeState:
    regime:      str    # BULL_TREND | BEAR_TREND | HIGH_VOL | LOW_VOL | RANGING
    state_id:    int
    probability: float  # P(current state)
    persistence: float  # How long in this state (0-1)
    transition_risk: float  # P(transition next bar)
    confidence:  float


REGIME_NAMES = {
    0: "BULL_TREND",
    1: "BEAR_TREND",
    2: "HIGH_VOL",
    3: "LOW_VOL",
    4: "RANGING",
}


class HMMRegimeEngine:
    """
    Gaussian HMM for market regime detection.
    Features: [returns, log_volume, volatility, adx]
    Fitted online using EM (hmmlearn if available, else rule-based fallback).
    """
    N_COMPONENTS = 5
    WINDOW       = 20   # bars for feature computation

    def __init__(self):
        self._model          = None
        self._fitted         = False
        self._current_state  = 4   # start in RANGING
        self._state_history  = []
        self._init_model()

    def _init_model(self):
        try:
            from hmmlearn import hmm
            self._model = hmm.GaussianHMM(
                n_components = self.N_COMPONENTS,
                covariance_type = "diag",
                n_iter = 100,
                random_state = 42,
            )
            log.info("HMM: hmmlearn model initialized")
        except ImportError:
            log.warning("hmmlearn not installed — using rule-based regime fallback")
            self._model = None

    def prepare_features(self, closes:List[float], highs:List[float],
                          lows:List[float], volumes:List[float],
                          adx_values:List[float]) -> np.ndarray:
        """Build feature matrix: [return, log_vol, realized_vol, adx_norm]"""
        c = np.array(closes)
        v = np.array(volumes)

        returns   = np.diff(c) / c[:-1]
        log_vol   = np.log(v[1:] + 1)
        window    = self.WINDOW
        real_vol  = np.array([
            np.std(returns[max(0,i-window):i+1])
            for i in range(len(returns))
        ])
        adx_arr   = np.array(adx_values[1:]) / 100.0 if adx_values else np.zeros(len(returns))
        # Align lengths
        n = min(len(returns), len(log_vol), len(real_vol), len(adx_arr))
        feats = np.column_stack([
            returns[-n:],
            log_vol[-n:],
            real_vol[-n:],
            adx_arr[-n:],
        ])
        return feats

    def fit(self, closes:List[float], highs:List[float],
             lows:List[float], volumes:List[float],
             adx_values:List[float]) -> bool:
        """Fit HMM on historical data."""
        if self._model is None:
            self._fitted = False; return False
        if len(closes) < 100:
            log.warning("HMM: need ≥100 bars to fit"); return False
        try:
            X = self.prepare_features(closes, highs, lows, volumes, adx_values)
            self._model.fit(X)
            self._fitted = True
            log.info(f"HMM fitted on {len(X)} observations")
            return True
        except Exception as e:
            log.error(f"HMM fit error: {e}"); return False

    def predict(self, closes:List[float], highs:List[float],
                 lows:List[float], volumes:List[float],
                 adx_values:List[float]) -> HMMRegimeState:
        """Predict current regime."""
        if self._fitted and self._model is not None:
            return self._hmm_predict(closes, highs, lows, volumes, adx_values)
        return self._rule_based(closes, highs, lows, adx_values)

    def _hmm_predict(self, closes, highs, lows, volumes, adx_values) -> HMMRegimeState:
        try:
            X = self.prepare_features(closes, highs, lows, volumes, adx_values)
            if len(X) < 2: return self._rule_based(closes, highs, lows, adx_values)

            states  = self._model.predict(X)
            probs   = self._model.predict_proba(X)

            current = int(states[-1])
            prob    = float(probs[-1, current])

            # Persistence: fraction of last 20 bars in same state
            recent  = states[-20:] if len(states) >= 20 else states
            persist = float(np.mean(recent == current))

            # Transition risk: max off-diagonal probability
            trans_mat = self._model.transmat_
            trans_risk= float(1.0 - trans_mat[current, current])

            self._current_state = current
            self._state_history.append(current)

            return HMMRegimeState(
                regime       = REGIME_NAMES[current],
                state_id     = current,
                probability  = round(prob, 4),
                persistence  = round(persist, 3),
                transition_risk = round(trans_risk, 4),
                confidence   = round(prob * persist * 100, 1),
            )
        except Exception as e:
            log.error(f"HMM predict error: {e}")
            return self._rule_based(closes, highs, lows, adx_values)

    def _rule_based(self, closes, highs, lows, adx_values) -> HMMRegimeState:
        """Fallback rule-based regime detection (no hmmlearn needed)."""
        if len(closes) < 20:
            return HMMRegimeState("RANGING",4,0.5,0.5,0.5,50.0)

        c   = np.array(closes[-50:])
        adx = float(adx_values[-1]) if adx_values else 25.0

        # Trend: EMA20 vs EMA50
        ema20 = float(np.mean(c[-20:]))
        ema50 = float(np.mean(c[-50:])) if len(c) >= 50 else float(np.mean(c))
        price = float(c[-1])

        # Volatility: ATR ratio
        h = np.array(highs[-20:]); l = np.array(lows[-20:])
        atr = float(np.mean(h - l))
        atr_pct = atr / price * 100

        if adx > 30 and price > ema20 > ema50:
            regime,sid = "BULL_TREND", 0
        elif adx > 30 and price < ema20 < ema50:
            regime,sid = "BEAR_TREND", 1
        elif atr_pct > 2.0:
            regime,sid = "HIGH_VOL", 2
        elif adx < 20 and atr_pct < 0.5:
            regime,sid = "LOW_VOL", 3
        else:
            regime,sid = "RANGING", 4

        return HMMRegimeState(
            regime      = regime,
            state_id    = sid,
            probability = 0.75,
            persistence = 0.60,
            transition_risk = 0.25,
            confidence  = 72.0,
        )
