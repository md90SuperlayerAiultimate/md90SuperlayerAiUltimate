"""
memory/qdrant_memory.py — Qdrant Vector Memory
Replaces flat JSON. Semantic search over trade history.
"Find trades similar to current market conditions"
"""
import json, logging, os
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Optional

log = logging.getLogger("MD90.Memory")
WITA = timezone(timedelta(hours=8))
QDRANT_URL = os.getenv("QDRANT_URL", "http://localhost:6333")
COLLECTION = "md90_trades"
VECTOR_DIM = 32  # compact feature vector


class QdrantMemory:
    """Vector memory for semantic trade recall."""

    def __init__(self):
        self._client = None
        self._fallback: List[Dict] = []
        self._init()

    def _init(self):
        try:
            from qdrant_client import QdrantClient
            from qdrant_client.models import Distance, VectorParams
            self._client = QdrantClient(url=QDRANT_URL, timeout=5)
            collections = [c.name for c in self._client.get_collections().collections]
            if COLLECTION not in collections:
                self._client.create_collection(
                    COLLECTION,
                    vectors_config=VectorParams(size=VECTOR_DIM, distance=Distance.COSINE)
                )
            log.info(f"✅ Qdrant connected: {QDRANT_URL}")
        except Exception as e:
            log.warning(f"Qdrant unavailable ({e}) — using in-memory fallback")
            self._client = None

    def _vectorize(self, context: dict) -> List[float]:
        """Convert market context to 32-dim feature vector."""
        import math
        def safe(v, default=0.0):
            try: return float(v)
            except: return default
        v = [
            safe(context.get("fusion_score", 0.5)),
            safe(context.get("confidence", 50)) / 100,
            safe(context.get("edge", 0)),
            safe(context.get("bayesian_prior", 0.5)),
            safe(context.get("hmm_prob", 0.5)),
            safe(context.get("network_score", 0.5)),
            1.0 if context.get("regime") == "Bull Trending" else 0.0,
            1.0 if context.get("regime") == "Bear Trending" else 0.0,
            1.0 if context.get("regime") == "Ranging" else 0.0,
            1.0 if context.get("regime") == "Chaotic" else 0.0,
            1.0 if context.get("session") in ("LONDON","NY","OVERLAP_LN") else 0.0,
            safe(context.get("volume_ratio", 1.0)) / 3.0,
            safe(context.get("atr_ratio", 1.0)) / 3.0,
            safe(context.get("rsi", 50)) / 100,
            1.0 if context.get("gate1") else 0.0,
            1.0 if context.get("gate2") else 0.0,
            1.0 if context.get("gate3") else 0.0,
            1.0 if context.get("gate4") else 0.0,
            1.0 if context.get("gate5") else 0.0,
        ]
        # Pad to VECTOR_DIM
        while len(v) < VECTOR_DIM:
            v.append(0.0)
        # Normalize
        mag = math.sqrt(sum(x*x for x in v)) or 1.0
        return [x/mag for x in v[:VECTOR_DIM]]

    def store(self, context: dict, outcome: dict):
        """Store a trade context + outcome in vector memory."""
        vec    = self._vectorize(context)
        record = {"context": context, "outcome": outcome,
                  "ts": datetime.now(WITA).isoformat()}
        if self._client:
            try:
                from qdrant_client.models import PointStruct
                import uuid
                self._client.upsert(COLLECTION, points=[
                    PointStruct(id=str(uuid.uuid4()), vector=vec, payload=record)
                ])
                log.debug("Stored in Qdrant")
                return
            except Exception as e:
                log.warning(f"Qdrant store: {e}")
        self._fallback.append({"vec": vec, **record})
        if len(self._fallback) > 1000:
            self._fallback = self._fallback[-1000:]

    def recall(self, context: dict, top_k: int = 5) -> List[Dict]:
        """Find most similar past trades semantically."""
        vec = self._vectorize(context)
        if self._client:
            try:
                hits = self._client.search(COLLECTION, query_vector=vec, limit=top_k)
                return [h.payload for h in hits]
            except Exception as e:
                log.warning(f"Qdrant recall: {e}")
        # Fallback: cosine similarity
        if not self._fallback:
            return []
        import math
        def cosine(a, b):
            dot = sum(x*y for x,y in zip(a,b))
            ma  = math.sqrt(sum(x*x for x in a)) or 1e-9
            mb  = math.sqrt(sum(x*x for x in b)) or 1e-9
            return dot/(ma*mb)
        scored = sorted(self._fallback,
                        key=lambda r: cosine(vec, r["vec"]), reverse=True)
        return scored[:top_k]

    def get_win_rate_similar(self, context: dict) -> float:
        """Return win rate of similar past trades."""
        similar = self.recall(context, top_k=10)
        if not similar: return 0.5
        wins = sum(1 for r in similar
                   if r.get("outcome",{}).get("pnl",0) > 0)
        return wins / len(similar)

    def summary(self) -> dict:
        if self._client:
            try:
                info = self._client.get_collection(COLLECTION)
                return {"backend":"qdrant","count":info.points_count,
                        "url":QDRANT_URL}
            except: pass
        return {"backend":"in-memory","count":len(self._fallback)}
