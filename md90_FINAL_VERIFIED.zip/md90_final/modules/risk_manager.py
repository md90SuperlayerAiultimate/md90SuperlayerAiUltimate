"""modules/risk_manager.py — Risk Manager with drawdown tracking."""
import os
from loguru import logger

MAX_DRAWDOWN   = float(os.getenv("MAX_DRAWDOWN",   "0.05"))
MAX_RISK_TRADE = float(os.getenv("MAX_RISK_TRADE", "0.01"))
PAUSE_DRAWDOWN = 0.03

class RiskManager:
    def __init__(self, start_balance: float = 10000.0):
        self.balance      = start_balance
        self.peak_balance = start_balance
        self.start        = start_balance

    @property
    def drawdown_pct(self) -> float:
        if self.peak_balance <= 0: return 0.0
        return (self.peak_balance - self.balance) / self.peak_balance * 100

    def can_trade(self, decision: dict = None) -> tuple:
        dd = self.drawdown_pct
        if dd >= MAX_DRAWDOWN * 100:
            logger.warning(f"🚫 Max drawdown {dd:.1f}% — halt")
            return False, f"MAX_DRAWDOWN {dd:.1f}%"
        if dd >= PAUSE_DRAWDOWN * 100:
            logger.warning(f"⚠️  Pause drawdown {dd:.1f}%")
            return False, f"PAUSE_DRAWDOWN {dd:.1f}%"
        return True, "OK"

    def position_size(self, stop_distance: float) -> float:
        risk_amt = self.balance * MAX_RISK_TRADE
        if stop_distance <= 0: return 0.0
        return round(risk_amt / stop_distance, 6)

    def update(self, pnl: float):
        self.balance += pnl
        if self.balance > self.peak_balance:
            self.peak_balance = self.balance
        logger.info(f"💰 Balance: {self.balance:.2f} | DD: {self.drawdown_pct:.2f}%")

    def get_stats(self) -> dict:
        return {
            "balance":    round(self.balance, 2),
            "peak":       round(self.peak_balance, 2),
            "drawdown":   round(self.drawdown_pct, 2),
            "total_pnl":  round(self.balance - self.start, 2),
        }
