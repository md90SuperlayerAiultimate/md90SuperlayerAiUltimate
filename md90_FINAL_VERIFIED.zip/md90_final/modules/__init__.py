"""MD90 Modules — Local production-grade components."""
