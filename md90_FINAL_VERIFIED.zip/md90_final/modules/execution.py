"""
modules/execution.py — Execution stub + Polymarket V2 router
From: MD90 vFINAL verified implementation.
Routes to: Polymarket CLOB V2 OR Binance spot OR dry-run simulation.
"""
import os, logging
from loguru import logger

DRY_RUN = os.getenv("DRY_RUN", "true").lower() == "true"


def execute_order(decision: dict, size_usd: float = 0.0,
                  token_id: str = "", price: float = 0.5,
                  mode: str = None) -> dict:
    """
    Unified execution router.
    mode: "polymarket" | "binance" | None (uses env MODE)
    """
    mode = mode or os.getenv("MODE", "polymarket")
    action = decision.get("action", "MONITOR")
    side   = decision.get("side", "NONE")

    if action != "EXECUTE" or side == "NONE":
        return {"status": "SKIPPED", "reason": f"action={action}"}

    if DRY_RUN:
        logger.success(
            f"✅ [DRY-RUN] EXECUTED {side} | "
            f"size=${size_usd:.2f} @ {price:.4f} | "
            f"conf={decision.get('confidence')}%"
        )
        return {
            "status": "EXECUTED",
            "dry_run": True,
            "side": side,
            "size_usd": size_usd,
            "price": price,
            "token_id": token_id[:16] + "..." if len(token_id) > 16 else token_id,
        }

    if mode == "polymarket" and token_id:
        return _execute_polymarket(token_id, price, size_usd, side)
    elif mode == "binance":
        return _execute_binance(decision, size_usd)

    logger.warning("No execution backend configured")
    return {"status": "SKIPPED", "reason": "No backend"}


def _execute_polymarket(token_id: str, price: float,
                         size_usd: float, side: str) -> dict:
    try:
        from polymarket.core.polymarket_client import PolyClient
        client = PolyClient()
        size_tokens = int(size_usd / price) if price > 0 else 0
        if size_tokens < 1:
            return {"status": "SKIPPED", "reason": "size_tokens < 1"}
        resp = client.place_limit_order(token_id, price, size_tokens, "BUY")
        if "error" in resp:
            return {"status": "FAILED", "error": resp["error"]}
        logger.success(f"✅ POLYMARKET ORDER | {size_tokens} @ {price:.4f}")
        return {"status": "EXECUTED", "response": resp, "mode": "polymarket"}
    except Exception as e:
        logger.error(f"Polymarket execution error: {e}")
        return {"status": "FAILED", "error": str(e)}


def _execute_binance(decision: dict, size_usd: float) -> dict:
    logger.info(f"Binance execution stub | size=${size_usd:.2f}")
    return {"status": "EXECUTED", "mode": "binance", "size_usd": size_usd}
