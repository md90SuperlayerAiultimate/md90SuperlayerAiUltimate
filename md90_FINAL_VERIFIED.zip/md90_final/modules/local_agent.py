"""
modules/local_agent.py — Local AI Agent (Ollama PRIMARY + Claude FALLBACK)
From: MD90 vFINAL + Claude Agent integration.

Priority:
  1. Ollama local (free, offline, private) — llama3.2 or any model
  2. Claude API fallback (if ANTHROPIC_API_KEY set)
  3. Rule-based fallback (always works)

Output: strict JSON {action, side, confidence, reasoning, sl, tp1}
"""
import json, os
from loguru import logger


SYSTEM_PROMPT = """You are MD90 Quant Agent. Analyze market context and return ONLY valid JSON.

Schema: {"action":"EXECUTE|MONITOR|FLATTEN","side":"BUY|SELL","confidence":int(0-100),"reasoning":"1 sentence","sl":"price or ATR-based","tp1":"price or ATR-based"}

Rules:
- EXECUTE: only if confidence>=78 AND regime not Chaotic AND persistence>=7
- FLATTEN: if regime=Chaotic OR drawdown>3%
- MONITOR: everything else
- Temperature 0.1 — be deterministic"""


class LocalMD90Agent:
    """Ollama-first, Claude-fallback, rule-based safety net."""

    def __init__(self, ollama_model: str = None,
                 claude_model: str = "claude-sonnet-4-6"):
        self.ollama_model = (ollama_model or
                             os.getenv("OLLAMA_MODEL", "llama3.2:latest"))
        self.claude_model  = claude_model
        self._ollama_ok    = self._check_ollama()
        self._claude_ok    = bool(os.getenv("ANTHROPIC_API_KEY", ""))

        if self._ollama_ok:
            logger.info(f"✅ Ollama agent ready: {self.ollama_model}")
        elif self._claude_ok:
            logger.info(f"✅ Claude agent ready: {self.claude_model}")
        else:
            logger.warning("⚠️  No AI backend — rule-based agent active")

    def _check_ollama(self) -> bool:
        try:
            import ollama
            ollama.list()
            return True
        except: return False

    def _build_prompt(self, context: dict) -> str:
        return f"""Market Analysis Request:
Regime: {context.get('regime','?')} | Persistence: {context.get('persistence',0)}
Clusters: {len(context.get('clusters',{}))} | Network Score: {context.get('network_score',0.5):.3f}
Bayesian Prior: {context.get('bayesian_prior',0.5):.3f}
MD90 Fusion: {context.get('fusion_status','?')} (score={context.get('fusion_score',0):.3f}, conf={context.get('confidence',0):.0f}%)
HMM Prob: {context.get('hmm_prob',0):.3f} | Drawdown: {context.get('drawdown',0):.2f}%
Market: {context.get('question','N/A')} @ {context.get('market_prob',0.5):.3f}
Edge: {context.get('edge',0):.4f} ({context.get('edge_pct',0):.1f}%)
News: {context.get('news','None')}

Return ONLY JSON (no markdown, no explanation)."""

    def decide(self, context: dict) -> dict:
        """Try Ollama → Claude → Rule-based."""
        if self._ollama_ok:
            result = self._ollama_decide(context)
            if result: return result

        if self._claude_ok:
            result = self._claude_decide(context)
            if result: return result

        return self._rule_based(context)

    def _ollama_decide(self, context: dict) -> dict:
        try:
            import ollama
            resp = ollama.chat(
                model   = self.ollama_model,
                messages= [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user",   "content": self._build_prompt(context)},
                ],
                options = {"temperature": 0.1}
            )
            text = resp["message"]["content"].strip()
            if text.startswith("```"):
                text = text.split("```")[1]
                if text.startswith("json"): text = text[4:]
            d = json.loads(text)
            logger.info(f"🦙 Ollama: {d.get('action')} conf={d.get('confidence')}%")
            return d
        except json.JSONDecodeError:
            logger.warning("Ollama JSON parse failed")
        except Exception as e:
            logger.warning(f"Ollama error: {e}")
            self._ollama_ok = False  # disable for this session
        return {}

    def _claude_decide(self, context: dict) -> dict:
        try:
            from anthropic import Anthropic
            client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
            resp = client.messages.create(
                model       = self.claude_model,
                max_tokens  = 400,
                temperature = 0.1,
                system      = SYSTEM_PROMPT,
                messages    = [{"role":"user","content":self._build_prompt(context)}]
            )
            text = resp.content[0].text.strip()
            if text.startswith("```"):
                text = text.split("```")[1]
                if text.startswith("json"): text = text[4:]
            d = json.loads(text)
            logger.info(f"🤖 Claude: {d.get('action')} conf={d.get('confidence')}%")
            return d
        except Exception as e:
            logger.warning(f"Claude error: {e}")
        return {}

    def _rule_based(self, context: dict) -> dict:
        regime      = context.get("regime", "Ranging")
        persistence = context.get("persistence", 0)
        confidence  = int(context.get("confidence", 50))
        fusion_ok   = context.get("fusion_status") == "ALL-IN"
        edge        = context.get("edge", 0)
        drawdown    = context.get("drawdown", 0)

        if regime == "Chaotic" or drawdown > 3.0:
            return {"action":"FLATTEN","side":"NONE","confidence":90,
                    "reasoning":f"Chaotic regime or drawdown {drawdown:.1f}%",
                    "sl":"0","tp1":"0"}

        if (fusion_ok and confidence >= 78 and
                persistence >= 7 and abs(edge) > 0.06):
            side = "BUY" if edge > 0 else "SELL"
            return {"action":"EXECUTE","side":side,"confidence":confidence,
                    "reasoning":f"ALL-IN fusion + edge {edge:.3f} + persistence {persistence}",
                    "sl":"ATR*1.5","tp1":"ATR*2.0"}

        return {"action":"MONITOR","side":"NONE","confidence":int(confidence*0.7),
                "reasoning":f"Waiting: persistence={persistence} fusion={fusion_ok}",
                "sl":"0","tp1":"0"}
