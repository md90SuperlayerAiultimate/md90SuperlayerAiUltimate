"""
modules/journal.py — SQLite Trade Journal
From: MD90 vFINAL verified implementation.
Records all trades, decisions, and performance metrics.
"""
import sqlite3, json, os
from datetime import datetime, timezone
from loguru import logger

DB_PATH = os.getenv("DB_PATH", "data/trades.db")

class TradingJournal:
    def __init__(self, db_path: str = DB_PATH):
        os.makedirs(os.path.dirname(db_path) if os.path.dirname(db_path) else ".", exist_ok=True)
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self._create_tables()

    def _create_tables(self):
        self.conn.executescript("""
        CREATE TABLE IF NOT EXISTS trades (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            market    TEXT,
            side      TEXT,
            regime    TEXT,
            persistence INTEGER,
            fusion_score REAL,
            confidence   REAL,
            edge         REAL,
            kelly_size   REAL,
            pnl          REAL DEFAULT 0,
            reasoning    TEXT,
            ollama_used  INTEGER DEFAULT 0,
            session      TEXT,
            status       TEXT DEFAULT 'open'
        );
        CREATE TABLE IF NOT EXISTS performance (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            date      TEXT,
            equity    REAL,
            daily_pnl REAL,
            win_rate  REAL,
            trades    INTEGER
        );
        CREATE TABLE IF NOT EXISTS regime_history (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            regime    TEXT,
            persistence INTEGER,
            hmm_prob  REAL
        );
        """)
        self.conn.commit()

    def log_trade(self, decision: dict, regime_info: dict,
                  market: str = "", edge: float = 0.0,
                  kelly_size: float = 0.0, session: str = ""):
        self.conn.execute("""
            INSERT INTO trades
            (timestamp,market,side,regime,persistence,fusion_score,
             confidence,edge,kelly_size,reasoning,ollama_used,session)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            datetime.now(timezone.utc).isoformat(),
            market,
            decision.get("side",""),
            regime_info.get("regime",""),
            regime_info.get("persistence",0),
            decision.get("fusion_score",0),
            decision.get("confidence",0),
            edge,
            kelly_size,
            decision.get("reasoning",""),
            1 if decision.get("agent_source","") == "ollama" else 0,
            session,
        ))
        self.conn.commit()
        logger.info(f"📒 Trade logged | {decision.get('side')} | conf={decision.get('confidence')}")

    def log_regime(self, regime: str, persistence: int, prob: float):
        self.conn.execute("""
            INSERT INTO regime_history (timestamp,regime,persistence,hmm_prob)
            VALUES (?,?,?,?)
        """, (datetime.now(timezone.utc).isoformat(), regime, persistence, prob))
        self.conn.commit()

    def update_pnl(self, trade_id: int, pnl: float):
        self.conn.execute("UPDATE trades SET pnl=?,status='closed' WHERE id=?",
                          (pnl, trade_id))
        self.conn.commit()

    def get_recent(self, n: int = 20) -> list:
        cur = self.conn.execute(
            "SELECT * FROM trades ORDER BY id DESC LIMIT ?", (n,))
        cols = [d[0] for d in cur.description]
        return [dict(zip(cols, row)) for row in cur.fetchall()]

    def get_stats(self) -> dict:
        cur = self.conn.execute("""
            SELECT COUNT(*) total,
                   SUM(CASE WHEN pnl>0 THEN 1 ELSE 0 END) wins,
                   SUM(pnl) total_pnl,
                   AVG(confidence) avg_conf
            FROM trades WHERE status='closed'
        """)
        row = cur.fetchone()
        if not row or not row[0]:
            return {"total":0,"wins":0,"win_rate":0,"total_pnl":0,"avg_conf":0}
        total, wins, total_pnl, avg_conf = row
        return {
            "total":     total or 0,
            "wins":      wins or 0,
            "win_rate":  round((wins or 0)/(total or 1)*100, 1),
            "total_pnl": round(total_pnl or 0, 2),
            "avg_conf":  round(avg_conf or 0, 1),
        }
