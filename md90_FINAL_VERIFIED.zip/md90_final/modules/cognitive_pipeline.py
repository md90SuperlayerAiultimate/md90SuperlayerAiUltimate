"""
modules/cognitive_pipeline.py
Cognitive Pipeline: Observe → Interpret → Model → Simulate → Evaluate → Execute → Audit → Learn
From: File 3 (Agentic Cognitive Systems deep dive)
This wraps the MD90 signal engine with explicit cognitive stage tracking.
"""
import time, logging
from dataclasses import dataclass, field
from typing import Any, Dict, Optional
from datetime import datetime, timezone

log = logging.getLogger("MD90.Cognitive")


@dataclass
class CognitiveState:
    """Full state snapshot at each pipeline stage."""
    # Stage 1: OBSERVE
    raw_data:        dict = field(default_factory=dict)
    data_quality:    float = 0.0

    # Stage 2: INTERPRET
    signals:         dict = field(default_factory=dict)
    regime:          str  = "UNKNOWN"
    session:         str  = "OTHER"

    # Stage 3: MODEL
    fusion_signal:   Any  = None
    hmm_state:       dict = field(default_factory=dict)
    network_state:   dict = field(default_factory=dict)
    probability:     float = 0.5

    # Stage 4: SIMULATE
    scenarios:       list = field(default_factory=list)
    worst_case_dd:   float = 0.0
    expected_value:  float = 0.0

    # Stage 5: EVALUATE
    edge:            float = 0.0
    kelly_size:      float = 0.0
    pass_threshold:  bool  = False
    reject_reason:   str   = ""

    # Stage 6: EXECUTE
    agent_decision:  dict  = field(default_factory=dict)
    order_result:    dict  = field(default_factory=dict)
    executed:        bool  = False

    # Stage 7: AUDIT
    audit_passed:    bool  = False
    audit_notes:     list  = field(default_factory=list)

    # Stage 8: LEARN
    lesson:          str   = ""
    bayesian_update: float = 0.0

    # Meta
    cycle_id:       str = ""
    start_time:     float = field(default_factory=time.time)
    end_time:       float = 0.0
    duration_ms:    float = 0.0


class CognitivePipeline:
    """
    8-stage cognitive pipeline wrapper.
    Each stage is instrumented for monitoring and learning.
    """

    def __init__(self, config: dict):
        self.cfg = config
        self.history: list = []

    # ── STAGE 1: OBSERVE ───────────────────────────────────────────
    def observe(self, state: CognitiveState, market_data, raw_context: dict) -> CognitiveState:
        state.raw_data = {
            "symbol":    raw_context.get("symbol"),
            "price":     market_data.current_price if market_data else 0,
            "atr":       market_data.atr if market_data else 0,
            "volume_ratio": market_data.volume_ratio if market_data else 1,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        # Data quality check
        quality_checks = [
            market_data is not None,
            bool(raw_context.get("symbol")),
            market_data.atr > 0 if market_data else False,
        ]
        state.data_quality = sum(quality_checks) / len(quality_checks)
        log.debug(f"[OBSERVE] quality={state.data_quality:.2f}")
        return state

    # ── STAGE 2: INTERPRET ─────────────────────────────────────────
    def interpret(self, state: CognitiveState, fusion_result,
                   hmm_info: dict, session: str) -> CognitiveState:
        state.regime  = hmm_info.get("regime", "RANGING")
        state.session = session
        if fusion_result:
            state.signals = {
                "fusion_score": fusion_result.fusion_score,
                "confidence":   fusion_result.confidence,
                "direction":    fusion_result.direction,
                "status":       fusion_result.execution_status,
                "gates":        fusion_result.all_gates_passed,
            }
        log.debug(f"[INTERPRET] regime={state.regime} session={state.session}")
        return state

    # ── STAGE 3: MODEL ─────────────────────────────────────────────
    def model(self, state: CognitiveState, fusion_result,
               hmm_state: dict, network_state: dict,
               bayesian_prior: float) -> CognitiveState:
        state.fusion_signal  = fusion_result
        state.hmm_state      = hmm_state
        state.network_state  = network_state
        # Composite probability model
        if fusion_result:
            fs = fusion_result.fusion_score
            cf = fusion_result.confidence / 100
            state.probability = 0.5 + (fs - 0.5) * cf * bayesian_prior * 2
            state.probability = max(0.0, min(1.0, state.probability))
        log.debug(f"[MODEL] probability={state.probability:.4f}")
        return state

    # ── STAGE 4: SIMULATE ──────────────────────────────────────────
    def simulate(self, state: CognitiveState,
                  market_data, edge: float) -> CognitiveState:
        """Simulate 3 scenarios: base, adverse, extreme."""
        price = market_data.current_price if market_data else 0
        atr   = market_data.atr if market_data else 0
        state.scenarios = [
            {"name": "base",    "pnl": price * edge * 0.01,  "prob": 0.60},
            {"name": "adverse", "pnl": -price * atr * 0.015, "prob": 0.30},
            {"name": "extreme", "pnl": -price * atr * 0.030, "prob": 0.10},
        ]
        state.expected_value = sum(
            s["pnl"] * s["prob"] for s in state.scenarios)
        state.worst_case_dd  = min(s["pnl"] for s in state.scenarios)
        log.debug(f"[SIMULATE] EV={state.expected_value:.4f}")
        return state

    # ── STAGE 5: EVALUATE ──────────────────────────────────────────
    def evaluate(self, state: CognitiveState, edge: float,
                  kelly_size: float, min_confidence: float = 75.0) -> CognitiveState:
        state.edge       = edge
        state.kelly_size = kelly_size

        checks = {
            "edge_ok":        abs(edge) >= 0.06,
            "confidence_ok":  state.signals.get("confidence", 0) >= min_confidence,
            "status_ok":      state.signals.get("status") in ("ALL-IN", "WAITING"),
            "regime_ok":      state.regime != "Chaotic",
            "ev_positive":    state.expected_value > 0,
            "quality_ok":     state.data_quality >= 0.66,
        }
        state.pass_threshold = all(checks.values())
        if not state.pass_threshold:
            fails = [k for k, v in checks.items() if not v]
            state.reject_reason = f"FAIL: {', '.join(fails)}"
        log.debug(f"[EVALUATE] pass={state.pass_threshold}")
        return state

    # ── STAGE 6: EXECUTE ───────────────────────────────────────────
    def execute(self, state: CognitiveState,
                 agent_decision: dict, order_result: dict) -> CognitiveState:
        state.agent_decision = agent_decision
        state.order_result   = order_result
        state.executed       = order_result.get("status") == "EXECUTED"
        log.debug(f"[EXECUTE] executed={state.executed}")
        return state

    # ── STAGE 7: AUDIT ─────────────────────────────────────────────
    def audit(self, state: CognitiveState) -> CognitiveState:
        notes = []
        # Check reasoning consistency
        if state.executed and not state.pass_threshold:
            notes.append("⚠️ Trade executed but evaluate failed — review logic")
        if not state.executed and state.pass_threshold:
            notes.append("ℹ️ All checks passed but agent said MONITOR")
        if abs(state.edge) > 0.20:
            notes.append(f"⚠️ Unusually large edge {state.edge:.4f} — verify data")
        if state.hmm_state.get("persistence",0) < 3:
            notes.append("ℹ️ Low HMM persistence — regime may be transitioning")
        state.audit_passed = not any("⚠️" in n for n in notes)
        state.audit_notes  = notes
        log.debug(f"[AUDIT] passed={state.audit_passed} notes={len(notes)}")
        return state

    # ── STAGE 8: LEARN ─────────────────────────────────────────────
    def learn(self, state: CognitiveState, bayesian_updater,
               market_id: str) -> CognitiveState:
        # Record lesson from this cycle
        if state.executed:
            state.lesson = (
                f"Executed {state.agent_decision.get('side')} "
                f"in {state.regime} regime with "
                f"edge={state.edge:.4f}"
            )
        else:
            state.lesson = f"Skipped: {state.reject_reason or 'MONITOR'}"

        state.end_time    = time.time()
        state.duration_ms = (state.end_time - state.start_time) * 1000
        self.history.append(state)
        if len(self.history) > 100:
            self.history = self.history[-100:]

        log.debug(f"[LEARN] cycle done in {state.duration_ms:.0f}ms")
        return state

    def run_full(self, symbol: str, market_data, fusion_result,
                  hmm_info: dict, session: str, network_state: dict,
                  bayesian_prior: float, edge: float, kelly_size: float,
                  agent_decision: dict, order_result: dict,
                  bayesian_updater, market_id: str) -> CognitiveState:
        """Run complete 8-stage pipeline."""
        import uuid
        state    = CognitiveState(cycle_id=str(uuid.uuid4())[:8])
        context  = {"symbol": symbol}

        state = self.observe(state, market_data, context)
        state = self.interpret(state, fusion_result, hmm_info, session)
        state = self.model(state, fusion_result, hmm_info, network_state, bayesian_prior)
        state = self.simulate(state, market_data, edge)
        state = self.evaluate(state, edge, kelly_size)
        state = self.execute(state, agent_decision, order_result)
        state = self.audit(state)
        state = self.learn(state, bayesian_updater, market_id)
        return state
