"""research/ — n8n research integration and data fetching."""
