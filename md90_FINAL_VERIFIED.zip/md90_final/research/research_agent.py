"""
research/research_agent.py — n8n Research Pipeline Integration
From: MD90 vFINAL verified implementation.
Fetches trending market data from n8n webhooks, Google Sheets, or CSV.
Can also pull Polymarket trending markets directly.
"""
import os, logging
import pandas as pd
import aiohttp

log = logging.getLogger("MD90.Research")

N8N_WEBHOOK  = os.getenv("N8N_WEBHOOK_URL",   "")
GSHEET_CSV   = os.getenv("GSHEET_CSV_URL",    "")
LOCAL_CSV    = os.getenv("RESEARCH_CSV_PATH", "data/research/trending.csv")


async def fetch_trending_async() -> list:
    """Async fetch trending markets — n8n webhook preferred."""
    if N8N_WEBHOOK:
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get(N8N_WEBHOOK, timeout=10) as r:
                    if r.status == 200:
                        data = await r.json(content_type=None)
                        log.info(f"n8n: {len(data)} records")
                        return data if isinstance(data, list) else []
        except Exception as e:
            log.warning(f"n8n fetch failed: {e}")

    if GSHEET_CSV:
        try:
            df = pd.read_csv(GSHEET_CSV)
            log.info(f"GSheet: {len(df)} rows")
            return df.to_dict(orient="records")
        except Exception as e:
            log.warning(f"GSheet fetch failed: {e}")

    return _load_local()


def fetch_trending_data() -> pd.DataFrame:
    """Sync fetch from local CSV (fallback)."""
    try:
        df = pd.read_csv(LOCAL_CSV)
        log.info(f"✅ Research CSV loaded: {len(df)} rows")
        return df
    except FileNotFoundError:
        log.warning(f"Research CSV not found: {LOCAL_CSV}")
        return pd.DataFrame()
    except Exception as e:
        log.error(f"Research load error: {e}")
        return pd.DataFrame()


def _load_local() -> list:
    df = fetch_trending_data()
    return df.to_dict(orient="records") if not df.empty else []


def get_market_context(symbol: str) -> dict:
    """
    Build market context dict for agent decisions.
    Combines: trending data + news sentiment summary.
    """
    df = fetch_trending_data()
    news_summary = "No research data available"

    if not df.empty:
        if "symbol" in df.columns:
            row = df[df["symbol"].str.upper() == symbol.upper()]
            if not row.empty:
                news_summary = str(row.iloc[0].to_dict())

    return {
        "symbol":       symbol,
        "news":         news_summary,
        "research_ok":  not df.empty,
        "rows":         len(df),
    }
