"""
n8n/webhook_server.py — MD90 FastAPI Webhook Server
n8n connects to these endpoints to:
  - Receive live signals from MD90
  - Trigger manual commands (flatten, pause, status)
  - Push market research data into bot
  - Receive Polymarket resolved markets

Run: uvicorn n8n.webhook_server:app --host 0.0.0.0 --port 8080

n8n Workflow connects:
  HTTP Request Node → http://YOUR_VPS:8080/signal
  HTTP Request Node → http://YOUR_VPS:8080/command
  HTTP Request Node → http://YOUR_VPS:8080/research
  Schedule Trigger  → http://YOUR_VPS:8080/status
"""
import json, os, logging
from datetime import datetime, timezone, timedelta
from typing import Optional

log = logging.getLogger("MD90.WebhookServer")
WITA = timezone(timedelta(hours=8))
WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET", "md90secret")

try:
    from fastapi import FastAPI, HTTPException, Header, Request
    from fastapi.responses import JSONResponse
    from pydantic import BaseModel
    HAS_FASTAPI = True
except ImportError:
    HAS_FASTAPI = False
    FastAPI = None

# ── Shared state written by bot, read by webhook ─────────────────
STATE_FILE = os.getenv("POLYMARKET_STATE_FILE", "data/polymarket_state.json")
CMD_FILE   = os.getenv("COMMAND_FILE",          "data/n8n_commands.json")

def _load_state() -> dict:
    try:
        if os.path.exists(STATE_FILE):
            return json.loads(open(STATE_FILE).read())
    except: pass
    return {}

def _write_command(cmd: str, params: dict = None):
    os.makedirs("data", exist_ok=True)
    existing = []
    if os.path.exists(CMD_FILE):
        try: existing = json.loads(open(CMD_FILE).read())
        except: pass
    existing.append({
        "cmd":       cmd,
        "params":    params or {},
        "timestamp": datetime.now(WITA).isoformat(),
        "processed": False,
    })
    with open(CMD_FILE, "w") as f:
        json.dump(existing, f, indent=2)


if HAS_FASTAPI:
    app = FastAPI(title="MD90 Webhook Server", version="4.0")

    # ── AUTH MIDDLEWARE ───────────────────────────────────────────
    def _auth(secret: str):
        if secret != WEBHOOK_SECRET:
            raise HTTPException(status_code=401, detail="Unauthorized")

    # ── ENDPOINTS ─────────────────────────────────────────────────

    @app.get("/")
    async def root():
        return {"status": "MD90 webhook server running",
                "time":   datetime.now(WITA).strftime("%Y-%m-%d %H:%M WITA")}

    @app.get("/status")
    async def get_status(x_secret: str = Header(default="")):
        _auth(x_secret)
        state = _load_state()
        return {
            "status":     "ok",
            "equity":     state.get("equity", 0),
            "positions":  len(state.get("positions", [])),
            "last_update":state.get("last_updated",""),
            "time_wita":  datetime.now(WITA).strftime("%H:%M:%S WITA"),
        }

    @app.get("/signal")
    async def get_signal(x_secret: str = Header(default="")):
        """n8n polls this to get latest MD90 signals for all pairs."""
        _auth(x_secret)
        state = _load_state()
        return {
            "signals":  state.get("positions", []),
            "equity":   state.get("equity", 0),
            "regime":   "—",
            "time":     datetime.now(WITA).isoformat(),
        }

    class ResearchPayload(BaseModel):
        symbol:    str = "BTC/USDT"
        news:      str = ""
        sentiment: float = 0.0
        source:    str = "n8n"
        extra:     dict = {}

    @app.post("/research")
    async def receive_research(payload: ResearchPayload,
                                x_secret: str = Header(default="")):
        """
        n8n pushes market research here.
        Bot reads data/research/trending.csv or latest.json.
        """
        _auth(x_secret)
        os.makedirs("data/research", exist_ok=True)
        data = {
            "symbol":    payload.symbol,
            "news":      payload.news,
            "sentiment": payload.sentiment,
            "source":    payload.source,
            "extra":     payload.extra,
            "received":  datetime.now(WITA).isoformat(),
        }
        # Write to latest.json (bot reads this)
        with open("data/latest/research_latest.json", "w") as f:
            json.dump(data, f, indent=2)
        log.info(f"Research received: {payload.symbol} sentiment={payload.sentiment}")
        return {"status": "received", "symbol": payload.symbol}

    class CommandPayload(BaseModel):
        command: str   # FLATTEN | PAUSE | RESUME | SET_PARAM | STATUS
        params:  dict = {}

    @app.post("/command")
    async def send_command(payload: CommandPayload,
                            x_secret: str = Header(default="")):
        """
        n8n sends commands to control the bot.
        Commands are written to file, bot reads and executes.
        """
        _auth(x_secret)
        valid_cmds = {"FLATTEN","PAUSE","RESUME","SET_PARAM","STATUS","STOP"}
        if payload.command not in valid_cmds:
            raise HTTPException(400, f"Unknown command. Valid: {valid_cmds}")
        _write_command(payload.command, payload.params)
        log.info(f"Command queued: {payload.command} {payload.params}")
        return {
            "status":  "queued",
            "command": payload.command,
            "time":    datetime.now(WITA).isoformat(),
        }

    class MarketResolvedPayload(BaseModel):
        market_id:   str
        question:    str = ""
        resolution:  str  # YES | NO
        volume:      float = 0.0

    @app.post("/market_resolved")
    async def market_resolved(payload: MarketResolvedPayload,
                               x_secret: str = Header(default="")):
        """
        n8n notifies bot when a Polymarket market resolves.
        Triggers Bayesian update + SelfLearner.
        """
        _auth(x_secret)
        os.makedirs("data/latest", exist_ok=True)
        event = {
            "type":       "MARKET_RESOLVED",
            "market_id":  payload.market_id,
            "question":   payload.question,
            "resolution": payload.resolution,
            "volume":     payload.volume,
            "time":       datetime.now(WITA).isoformat(),
        }
        with open("data/latest/resolved_latest.json", "w") as f:
            json.dump(event, f, indent=2)
        log.info(f"Market resolved: {payload.market_id[:20]} → {payload.resolution}")
        return {"status": "noted", "resolution": payload.resolution}

    @app.get("/ml_stats")
    async def get_ml_stats(x_secret: str = Header(default="")):
        """n8n dashboard: get ML/SelfLearner statistics."""
        _auth(x_secret)
        try:
            import json as _json
            path = "model/self_learner.json"
            if os.path.exists(path):
                d = _json.loads(open(path).read())
                trades = d.get("trade_count", 0)
                wins   = d.get("win_count",   0)
                wr     = wins/max(1,trades)*100
                th     = d.get("thresholds",  {})
                return {
                    "status":          "ok",
                    "trade_count":     trades,
                    "win_rate":        round(wr, 2),
                    "total_pnl":       d.get("total_pnl", 0),
                    "fusion_score_min":th.get("fusion_score_min", 0.55),
                    "confidence_min":  th.get("confidence_min",   75.0),
                    "min_persistence": th.get("min_persistence",  7),
                }
        except Exception as e:
            return {"status": "error", "detail": str(e)}
        return {"status": "no_data"}

else:
    # Fallback: simple aiohttp server if FastAPI not installed
    async def start_simple_server(host="0.0.0.0", port=8080):
        import aiohttp.web as web
        async def status(req):
            state = _load_state()
            return web.json_response({
                "status":  "ok",
                "equity":  state.get("equity", 0),
                "time":    datetime.now(WITA).strftime("%H:%M WITA"),
            })
        app = web.Application()
        app.router.add_get("/status", status)
        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, host, port)
        await site.start()
        log.info(f"Simple webhook server on {host}:{port}")
        return runner

# Ensure app is always defined at module level
if not HAS_FASTAPI:
    app = None  # fallback: use start_simple_server() instead
