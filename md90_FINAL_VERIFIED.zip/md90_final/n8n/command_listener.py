"""
n8n/command_listener.py — Bot reads n8n commands from file queue.
Called every scan loop by polymarket/bot.py.
Commands written by webhook_server.py, consumed here.
"""
import json, os, logging
from datetime import datetime, timezone, timedelta

log = logging.getLogger("MD90.CmdListener")
WITA     = timezone(timedelta(hours=8))
CMD_FILE = os.getenv("COMMAND_FILE", "data/n8n_commands.json")


def read_pending() -> list:
    """Return unprocessed commands, mark as processed."""
    if not os.path.exists(CMD_FILE):
        return []
    try:
        cmds = json.loads(open(CMD_FILE).read())
        pending = [c for c in cmds if not c.get("processed")]
        if pending:
            for c in cmds:
                c["processed"] = True
            with open(CMD_FILE, "w") as f:
                json.dump(cmds, f, indent=2)
        return pending
    except Exception as e:
        log.error(f"Command read: {e}")
        return []


def read_resolved_market() -> dict:
    """Read latest resolved market notification from n8n."""
    path = "data/latest/resolved_latest.json"
    if not os.path.exists(path):
        return {}
    try:
        d = json.loads(open(path).read())
        # Clear after reading
        os.remove(path)
        return d
    except:
        return {}


def read_research() -> dict:
    """Read latest research data pushed by n8n."""
    path = "data/latest/research_latest.json"
    if not os.path.exists(path):
        return {}
    try:
        return json.loads(open(path).read())
    except:
        return {}


async def process_commands(commands: list, bot_state: dict) -> dict:
    """
    Execute commands from n8n.
    Returns dict with actions to take in main loop.
    """
    actions = {"flatten": False, "pause": False, "resume": False,
               "stop": False, "params": {}}

    for cmd in commands:
        name   = cmd.get("cmd","").upper()
        params = cmd.get("params", {})
        log.info(f"[N8N CMD] {name} {params}")

        if name == "FLATTEN":
            actions["flatten"] = True
            log.warning("N8N: FLATTEN command received")

        elif name == "PAUSE":
            actions["pause"] = True
            log.warning("N8N: PAUSE command received")

        elif name == "RESUME":
            actions["resume"] = True
            log.info("N8N: RESUME command received")

        elif name == "STOP":
            actions["stop"] = True
            log.warning("N8N: STOP command received")

        elif name == "SET_PARAM":
            # e.g. {"fusion_score_min": 0.65, "confidence_min": 80}
            for k, v in params.items():
                if k in ("fusion_score_min","confidence_min",
                          "min_persistence","kelly_fraction"):
                    actions["params"][k] = v
                    log.info(f"N8N: SET {k}={v}")

    return actions
