"""n8n — Webhook integration for MD90 bot signals and alerts."""
