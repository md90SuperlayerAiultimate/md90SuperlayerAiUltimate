"""
MD90 Meridian - Risk Fortress (Advanced Risk Manager)
Kelly Criterion + Inventory Skew + Circuit Breakers + Adverse Selection
"""

import time
import logging
from typing import Dict, Tuple, Optional

logger = logging.getLogger(__name__)


class CircuitBreakers:
    """Circuit breaker: halt trading saat kondisi ekstrem"""

    def __init__(self,
                 daily_loss_limit:    float = 0.05,
                 volatility_threshold: float = 0.80,
                 cooldown_seconds:    int   = 300):
        self.daily_loss_limit     = daily_loss_limit
        self.volatility_threshold = volatility_threshold
        self.cooldown_seconds     = cooldown_seconds

        self._triggered      = False
        self._trigger_time   = 0.0
        self._trigger_reason = ""
        self.daily_loss_pct  = 0.0

    def check_daily_loss(self, current_loss_pct: float) -> bool:
        self.daily_loss_pct = current_loss_pct
        if current_loss_pct >= self.daily_loss_limit:
            self._trigger("DAILY_LOSS_LIMIT")
            return True
        return False

    def check_volatility(self, volatility: float) -> bool:
        if volatility >= self.volatility_threshold:
            self._trigger("HIGH_VOLATILITY")
            return True
        return False

    def _trigger(self, reason: str):
        if not self._triggered:
            self._triggered      = True
            self._trigger_time   = time.time()
            self._trigger_reason = reason
            logger.warning(f"🛑 Circuit Breaker TRIGGERED: {reason}")

    def manual_trigger(self, duration: int = 300):
        self._triggered    = True
        self._trigger_time = time.time()
        self.cooldown_seconds = duration
        self._trigger_reason = "MANUAL"

    def is_triggered(self) -> bool:
        if not self._triggered:
            return False
        # Auto-reset setelah cooldown
        if time.time() - self._trigger_time > self.cooldown_seconds:
            self._triggered = False
            logger.info(f"✅ Circuit Breaker reset after {self.cooldown_seconds}s cooldown")
            return False
        return True

    def reset(self):
        self._triggered = False

    @property
    def reason(self) -> str:
        return self._trigger_reason


class AdverseSelectionDetector:
    """
    Deteksi toxic order flow — informed traders yang bergerak melawan posisi kita.
    """

    def __init__(self, threshold: float = 0.001):
        self.threshold    = threshold
        self._flow_history: Dict[str, list] = {}

    def record_flow(self, market_id: str, side: str, size: float, informed: bool = False):
        if market_id not in self._flow_history:
            self._flow_history[market_id] = []
        self._flow_history[market_id].append({
            "side":      side,
            "size":      size,
            "informed":  informed,
            "timestamp": time.time(),
        })
        # Keep last 50 trades
        self._flow_history[market_id] = self._flow_history[market_id][-50:]

    def get_order_flow(self, market_id: str) -> dict:
        history = self._flow_history.get(market_id, [])
        if not history:
            return {"informed_metric": 0.0}
        # Simple proxy: ratio of YES vs NO recent flow
        yes_vol = sum(f["size"] for f in history if f["side"] == "YES")
        no_vol  = sum(f["size"] for f in history if f["side"] == "NO")
        total   = yes_vol + no_vol
        if total == 0:
            return {"informed_metric": 0.0}
        return {"informed_metric": (yes_vol - no_vol) / total}

    def is_adverse(self, signal: dict, market_id: str) -> bool:
        flow           = self.get_order_flow(market_id)
        informed_flow  = flow["informed_metric"]
        # Jika smart money bergerak melawan signal kita, abort
        if signal.get("side") == "YES" and informed_flow < -0.7:
            return True
        if signal.get("side") == "NO"  and informed_flow > 0.7:
            return True
        return False


class PortfolioTracker:
    """Track posisi dan exposure per market"""

    def __init__(self, max_position_usd: float = 1000, max_portfolio_usd: float = 10000):
        self.max_position_usd  = max_position_usd
        self.max_portfolio_usd = max_portfolio_usd
        self.positions: Dict[str, dict] = {}

    def get_exposure(self, market_id: str) -> float:
        pos = self.positions.get(market_id, {})
        return pos.get("size_usd", 0.0)

    def get_total_exposure(self) -> float:
        return sum(p.get("size_usd", 0) for p in self.positions.values())

    def get_inventory_skew(self) -> float:
        """Return YES/NO ratio skew (-1 to +1)"""
        yes_exp = sum(p["size_usd"] for p in self.positions.values()
                      if p.get("side") == "YES")
        no_exp  = sum(p["size_usd"] for p in self.positions.values()
                      if p.get("side") == "NO")
        total   = yes_exp + no_exp
        return (yes_exp - no_exp) / total if total > 0 else 0.0

    def open_position(self, market_id: str, side: str, size_usd: float):
        self.positions[market_id] = {
            "side":       side,
            "size_usd":   size_usd,
            "open_time":  time.time(),
        }

    def close_position(self, market_id: str, pnl: float = 0.0):
        self.positions.pop(market_id, None)


class PolymarketRiskManager:
    """
    Risk Fortress untuk Polymarket trading.
    Gabungan: Kelly Criterion + Circuit Breakers + Adverse Selection + Inventory Skew
    """

    def __init__(self, config: dict):
        self.max_position_usd  = config.get("max_position_usd",   1000)
        self.max_portfolio_usd = config.get("max_portfolio_usd",  10000)
        self.max_inventory_skew = config.get("max_inventory_skew", 0.30)
        self.kelly_fraction    = config.get("kelly_fraction",       0.25)

        self.circuit_breakers  = CircuitBreakers(
            daily_loss_limit     = config.get("circuit_breaker_drawdown", 0.05),
            cooldown_seconds     = config.get("cooldown_after_loss_seconds", 300),
        )
        self.adverse_detector  = AdverseSelectionDetector(
            threshold = config.get("adverse_selection_threshold", 0.001)
        )
        self.portfolio         = PortfolioTracker(
            max_position_usd  = self.max_position_usd,
            max_portfolio_usd = self.max_portfolio_usd,
        )

        self.daily_pnl         = 0.0
        self.start_capital     = config.get("total_usd", 5000)

    # ------------------------------------------------------------------
    def validate_signal(self, signal: dict) -> Tuple[bool, str]:
        """
        Validasi signal sebelum eksekusi.
        Return: (is_valid, reason_string)
        """
        market_id = signal.get("market_id", "")

        # 1. Circuit Breaker
        if self.circuit_breakers.is_triggered():
            return False, f"CIRCUIT_BREAKER: {self.circuit_breakers.reason}"

        # 2. Portfolio limit
        if self.portfolio.get_total_exposure() >= self.max_portfolio_usd:
            return False, "MAX_PORTFOLIO_REACHED"

        # 3. Position limit per market
        current_exp  = self.portfolio.get_exposure(market_id)
        proposed     = signal.get("size_suggestion", 0)
        if current_exp + proposed > self.max_position_usd:
            adjusted = self.max_position_usd - current_exp
            if adjusted < 10:
                return False, "MAX_EXPOSURE_REACHED"
            signal["size_suggestion"] = adjusted

        # 4. Inventory skew
        skew = self.portfolio.get_inventory_skew()
        if signal.get("side") == "YES" and skew >  self.max_inventory_skew:
            return False, "INVENTORY_LIMIT_LONG"
        if signal.get("side") == "NO"  and skew < -self.max_inventory_skew:
            return False, "INVENTORY_LIMIT_SHORT"

        # 5. Adverse selection
        if self.adverse_detector.is_adverse(signal, market_id):
            return False, "ADVERSE_SELECTION_DETECTED"

        return True, "OK"

    # ------------------------------------------------------------------
    def calculate_kelly_size(self, signal: dict) -> float:
        """
        Kelly Criterion position sizing.
        f* = (p*b - q) / b
        """
        win_prob = signal.get("confidence", 0.5)
        payoff   = signal.get("expected_payoff", 1.0)  # Expected odds

        q             = 1 - win_prob
        kelly_percent = (win_prob * payoff - q) / payoff
        kelly_percent = max(0.0, min(kelly_percent, 0.5))  # Cap 50%

        size = self.max_position_usd * kelly_percent * self.kelly_fraction
        return round(max(10.0, size), 2)  # Minimum $10

    # ------------------------------------------------------------------
    def record_pnl(self, pnl: float):
        self.daily_pnl += pnl
        loss_pct = abs(self.daily_pnl) / self.start_capital if self.daily_pnl < 0 else 0
        self.circuit_breakers.check_daily_loss(loss_pct)
        logger.info(f"Daily PnL: ${self.daily_pnl:.2f} ({loss_pct*100:.1f}% loss)")

    def reset_daily(self):
        self.daily_pnl = 0.0
        self.circuit_breakers.daily_loss_pct = 0.0
