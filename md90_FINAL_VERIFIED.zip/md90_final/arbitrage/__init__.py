"""arbitrage/ — Structural Arbitrage Engine. $40M strategy: speed+structure not prediction."""
