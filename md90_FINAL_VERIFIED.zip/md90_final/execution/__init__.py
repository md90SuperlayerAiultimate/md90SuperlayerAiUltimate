"""
MD90 — Execution Module
Binance Spot + Futures order executor.
Dry-run mode: print saja, tidak kirim order ke exchange.
Live mode: eksekusi via CCXT.

Support:
  - Market order (entry)
  - Stop Loss order (stop-market)
  - Take Profit order (take-profit-market)
  - Partial close (reduce-only)
  - Cancel all open orders untuk symbol tertentu
"""
import asyncio
from dataclasses import dataclass, field
from typing import List, Optional
from datetime import datetime, timezone, timedelta

WITA = timezone(timedelta(hours=8))


@dataclass
class OrderResult:
    success:   bool
    order_id:  str   = ""
    symbol:    str   = ""
    side:      str   = ""
    order_type:str   = ""
    price:     float = 0.0
    amount:    float = 0.0
    filled:    float = 0.0
    cost:      float = 0.0
    fee:       float = 0.0
    error:     str   = ""
    timestamp: str   = field(default_factory=lambda: datetime.now(WITA).strftime("%H:%M:%S WITA"))


class OrderExecutor:
    """
    Binance order executor.
    mode: "spot" atau "futures"
    dry_run=True → simulasi saja
    """

    def __init__(self, exchange_id: str = "binance",
                 api_key: str = "", api_secret: str = "",
                 mode: str = "spot", dry_run: bool = True):
        self.dry_run = dry_run
        self.mode    = mode
        self._exch   = None

        if not dry_run and api_key:
            try:
                import ccxt
                params = {
                    "apiKey":          api_key,
                    "secret":          api_secret,
                    "enableRateLimit": True,
                }
                if mode == "futures":
                    params["options"] = {"defaultType": "future"}
                    self._exch = ccxt.binance(params)
                else:
                    self._exch = ccxt.binance(params)
                print(f"[Executor] {mode.upper()} live mode connected")
            except Exception as e:
                print(f"[Executor] Init error: {e} — falling back to dry run")
                self.dry_run = True
        else:
            print(f"[Executor] DRY-RUN mode ({mode})")

    # ── Market buy ───────────────────────────────────────────────────
    async def market_buy(self, symbol: str, amount: float) -> OrderResult:
        if self.dry_run:
            print(f"  [DRY] MARKET BUY  {symbol} qty={amount:.6f}")
            return OrderResult(True, "DRY-BUY",  symbol, "buy",  "market", amount=amount, filled=amount)
        return await self._execute(symbol, "buy",  "market", amount)

    # ── Market sell ──────────────────────────────────────────────────
    async def market_sell(self, symbol: str, amount: float,
                          reduce_only: bool = False) -> OrderResult:
        if self.dry_run:
            print(f"  [DRY] MARKET SELL {symbol} qty={amount:.6f} reduce_only={reduce_only}")
            return OrderResult(True, "DRY-SELL", symbol, "sell", "market", amount=amount, filled=amount)
        params = {"reduceOnly": True} if reduce_only and self.mode == "futures" else {}
        return await self._execute(symbol, "sell", "market", amount, params=params)

    # ── Stop-loss order ──────────────────────────────────────────────
    async def place_stop_loss(self, symbol: str, side: str,
                               amount: float, stop_price: float) -> OrderResult:
        close_side = "sell" if side == "LONG" else "buy"
        if self.dry_run:
            print(f"  [DRY] STOP-LOSS {close_side} {symbol} qty={amount:.6f} stop={stop_price:.5f}")
            return OrderResult(True, "DRY-SL", symbol, close_side, "stop_market",
                               price=stop_price, amount=amount)
        params = {"stopPrice": stop_price, "reduceOnly": True, "closePosition": False}
        return await self._execute(symbol, close_side, "stop_market", amount, params=params)

    # ── Take-profit order ────────────────────────────────────────────
    async def place_take_profit(self, symbol: str, side: str,
                                 amount: float, tp_price: float) -> OrderResult:
        close_side = "sell" if side == "LONG" else "buy"
        if self.dry_run:
            print(f"  [DRY] TAKE-PROFIT {close_side} {symbol} qty={amount:.6f} tp={tp_price:.5f}")
            return OrderResult(True, "DRY-TP", symbol, close_side, "take_profit_market",
                               price=tp_price, amount=amount)
        params = {"stopPrice": tp_price, "reduceOnly": True}
        return await self._execute(symbol, close_side, "take_profit_market", amount, params=params)

    # ── Cancel all orders for symbol ─────────────────────────────────
    async def cancel_all(self, symbol: str) -> bool:
        if self.dry_run:
            print(f"  [DRY] CANCEL ALL orders for {symbol}")
            return True
        try:
            await asyncio.get_event_loop().run_in_executor(
                None, self._exch.cancel_all_orders, symbol)
            return True
        except Exception as e:
            print(f"  [Executor] Cancel error {symbol}: {e}")
            return False

    # ── Fetch balance ────────────────────────────────────────────────
    async def fetch_balance(self, currency: str = "USDT") -> float:
        if self.dry_run:
            return 0.0
        try:
            bal = await asyncio.get_event_loop().run_in_executor(
                None, self._exch.fetch_balance)
            return float(bal.get("free", {}).get(currency, 0))
        except Exception as e:
            print(f"  [Executor] Balance error: {e}")
            return 0.0

    # ── Internal execute ─────────────────────────────────────────────
    async def _execute(self, symbol: str, side: str, order_type: str,
                       amount: float, price: float = None,
                       params: dict = None) -> OrderResult:
        try:
            loop   = asyncio.get_event_loop()
            params = params or {}
            order  = await loop.run_in_executor(
                None,
                lambda: self._exch.create_order(
                    symbol, order_type, side, amount,
                    price, params
                )
            )
            return OrderResult(
                success    = True,
                order_id   = str(order.get("id", "")),
                symbol     = symbol,
                side       = side,
                order_type = order_type,
                price      = float(order.get("average") or order.get("price") or 0),
                amount     = float(order.get("amount", amount)),
                filled     = float(order.get("filled", 0)),
                cost       = float(order.get("cost", 0)),
                fee        = float((order.get("fee") or {}).get("cost", 0)),
            )
        except Exception as e:
            print(f"  [Executor] Order error {side} {symbol}: {e}")
            return OrderResult(False, error=str(e), symbol=symbol,
                               side=side, order_type=order_type)
