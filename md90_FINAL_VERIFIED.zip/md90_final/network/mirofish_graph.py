"""
network/mirofish_graph.py
MiroFish NetworkX Graph Engine.
Models: market → wallet relationships as directed graph.
Detects: clusters, conviction paths, convergence/divergence.
Based on "MiroFish BTC Graph Force Graph V4.2" seen in screenshots.

Nodes: wallets + markets
Edges: trade activity (direction, size, recency)
Metrics: centrality, cluster conviction, path strength
"""
import logging
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from datetime import datetime, timezone

log = logging.getLogger(__name__)


@dataclass
class ClusterResult:
    clusters:        List[List[str]]
    n_clusters:      int
    top_conviction:  float    # highest conviction cluster score
    network_score:   float    # overall network signal strength
    bull_paths:      int
    bear_paths:      int
    direction:       str      # BULLISH | BEARISH | MIXED | NEUTRAL
    centrality:      Dict[str, float] = field(default_factory=dict)


class MiroFishGraph:
    """
    NetworkX-based graph for wallet-market relationship analysis.
    Falls back to synthetic scoring if networkx unavailable.
    """

    def __init__(self):
        self._G          = None
        self._nx         = None
        self._wallets    = {}  # wallet_id → {trades, pnl, winrate}
        self._last_update= None
        self._init_nx()

    def _init_nx(self):
        try:
            import networkx as nx
            self._nx = nx
            self._G  = nx.DiGraph()
            log.info("MiroFish: NetworkX initialized")
        except ImportError:
            log.warning("networkx not installed — using synthetic graph scoring")

    def update_trades(self, trades:List[Dict]):
        """
        Update graph with new trade data.
        trades: list of {wallet, market_id, direction, size, pnl, timestamp}
        """
        self._last_update = datetime.now(timezone.utc)

        for t in trades:
            wallet = t.get("wallet","?")
            market = t.get("market_id","?")
            direction = t.get("direction", 1)   # 1=YES, -1=NO
            size      = float(t.get("size", 0))
            pnl       = float(t.get("pnl", 0))

            # Update wallet stats
            ws = self._wallets.setdefault(wallet, {
                "trades":0,"wins":0,"total_pnl":0.0,"last_trade":None})
            ws["trades"]    += 1
            ws["total_pnl"] += pnl
            if pnl > 0: ws["wins"] += 1
            ws["last_trade"] = t.get("timestamp")

            if self._nx and self._G is not None:
                # Add nodes
                if not self._G.has_node(wallet):
                    self._G.add_node(wallet, type="wallet",
                                      trades=ws["trades"], winrate=ws["wins"]/ws["trades"])
                if not self._G.has_node(market):
                    self._G.add_node(market, type="market")

                # Add/update edge
                if self._G.has_edge(wallet, market):
                    self._G[wallet][market]["weight"] += size
                    self._G[wallet][market]["trades"] += 1
                    self._G[wallet][market]["pnl"]    += pnl
                else:
                    self._G.add_edge(wallet, market,
                                     weight=size, direction=direction,
                                     trades=1, pnl=pnl)

    def detect_clusters(self) -> ClusterResult:
        """Detect wallet clusters and compute conviction scores."""
        if self._nx and self._G and len(self._G.nodes) >= 3:
            return self._nx_clusters()
        return self._synthetic_clusters()

    def _nx_clusters(self) -> ClusterResult:
        nx = self._nx; G = self._G
        try:
            # Undirected for community detection
            Gu = G.to_undirected()
            components = list(nx.connected_components(Gu))

            # Centrality
            try:
                centrality = nx.betweenness_centrality(G, normalized=True)
            except:
                centrality = {n: 1.0/len(G.nodes) for n in G.nodes}

            # Top centrality wallets
            top_wallets = sorted(centrality.items(), key=lambda x:-x[1])[:5]

            # Conviction: based on consistency of edge directions
            bull = sum(1 for _,_,d in G.edges(data=True) if d.get("direction",1) > 0)
            bear = sum(1 for _,_,d in G.edges(data=True) if d.get("direction",1) < 0)
            total_edges = bull + bear
            top_conv = max(bull,bear)/total_edges if total_edges > 0 else 0.5

            direction = ("BULLISH" if bull > bear*1.3 else
                        "BEARISH" if bear > bull*1.3 else "MIXED")

            network_score = (top_conv * 0.6 +
                             min(len(top_wallets)/10, 1.0) * 0.4)

            return ClusterResult(
                clusters        = [list(c) for c in components],
                n_clusters      = len(components),
                top_conviction  = round(top_conv, 4),
                network_score   = round(network_score, 4),
                bull_paths      = bull,
                bear_paths      = bear,
                direction       = direction,
                centrality      = {k:round(v,4) for k,v in top_wallets},
            )
        except Exception as e:
            log.error(f"NX cluster error: {e}")
            return self._synthetic_clusters()

    def _synthetic_clusters(self) -> ClusterResult:
        """Synthetic scoring from wallet win rates when networkx unavailable."""
        if not self._wallets:
            return ClusterResult([],0,0.5,0.5,0,0,"NEUTRAL")

        winrates = [v["wins"]/v["trades"] for v in self._wallets.values()
                    if v["trades"] > 0]
        if not winrates:
            return ClusterResult([],0,0.5,0.5,0,0,"NEUTRAL")

        avg_wr    = sum(winrates)/len(winrates)
        conviction= avg_wr            # average win rate as conviction proxy
        direction = ("BULLISH" if avg_wr > 0.6 else
                    "BEARISH" if avg_wr < 0.4 else "MIXED")
        net_score = conviction * 0.7

        return ClusterResult(
            clusters       = [list(self._wallets.keys())],
            n_clusters     = 1,
            top_conviction = round(conviction, 4),
            network_score  = round(net_score, 4),
            bull_paths     = sum(1 for v in self._wallets.values() if v["total_pnl"]>0),
            bear_paths     = sum(1 for v in self._wallets.values() if v["total_pnl"]<0),
            direction      = direction,
        )

    def get_wallet_scores(self, top_n:int=10) -> List[Tuple[str,float]]:
        """Return top wallets sorted by win rate × total trades."""
        scored = [
            (wid, v["wins"]/v["trades"] * min(v["trades"]/20, 1.0))
            for wid,v in self._wallets.items() if v["trades"] > 0
        ]
        return sorted(scored, key=lambda x:-x[1])[:top_n]
