from .graph import get_signal
