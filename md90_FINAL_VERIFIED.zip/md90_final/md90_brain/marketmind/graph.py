"""
MD90 Unified — MarketMind LangGraph
5 specialist agents (fan-out parallel) → synthesis (fan-in)

Agents map ke layer groups dari MQL5 CSignalEngine:
  price_agent    → L1 SNR, L2 EMA, L11 MacroFlow
  momentum_agent → L3 RSI, L4 Stoch, L8 Sentiment
  structure_agent→ L5 OB, L14 OTE, L15 IDM/FVG, L16 MasterCall
  sweep_agent    → L7 MTF, L9 UltraScalper, L10 PrimeSwing
  risk_agent     → L6 Volume, L12 VWAP, L13 ATR, L17 TimeStop

Synthesis agent → full_analyze() → FusionSignal
"""
from typing import List, Dict, Any, TypedDict
from langgraph.graph import StateGraph, END

from ..signal_engine import SignalEngine
from ..fusion import full_analyze
from ..types import MarketData, FusionSignal, LayerSignal
from ..constants import (
    TOTAL_LAYERS,
    LAYER_SNR, LAYER_EMA, LAYER_MACRO_FLOW,
    LAYER_RSI, LAYER_STOCHASTIC, LAYER_SENTIMENT,
    LAYER_ORDER_BLOCK, LAYER_OTE, LAYER_IDM_FVG, LAYER_MASTER_CALL,
    LAYER_MTF, LAYER_ULTRA_SCALPER, LAYER_PRIME_SWING,
    LAYER_VOLUME, LAYER_VWAP, LAYER_ATR_CONTEXT, LAYER_TIMESTOP,
)


# ══════════════════════════════════════════════════════════════════════
# SHARED STATE
# ══════════════════════════════════════════════════════════════════════

class MD90State(TypedDict):
    market_data: MarketData
    layer_signals: List[LayerSignal]   # length 17, filled per agent
    fusion_signal: FusionSignal        # filled by synthesis


def _empty_state(md: MarketData) -> MD90State:
    from ..types import LayerSignal
    return MD90State(
        market_data=md,
        layer_signals=[LayerSignal() for _ in range(TOTAL_LAYERS)],
        fusion_signal=FusionSignal(),
    )


# ══════════════════════════════════════════════════════════════════════
# GLOBAL ENGINE (per-instance reuse)
# ══════════════════════════════════════════════════════════════════════

_engine = SignalEngine()


def _run_selected_layers(state: MD90State, layer_ids: List[int]) -> MD90State:
    """Run SignalEngine.analyze() then keep only requested layers."""
    md       = state["market_data"]
    all_sigs = _engine.analyze(md)   # full 17 layers computed
    new_sigs = list(state["layer_signals"])

    for lid in layer_ids:
        new_sigs[lid] = all_sigs[lid]

    return MD90State(
        market_data=md,
        layer_signals=new_sigs,
        fusion_signal=state["fusion_signal"],
    )


# ══════════════════════════════════════════════════════════════════════
# SPECIALIST AGENTS
# ══════════════════════════════════════════════════════════════════════

def price_agent(state: MD90State) -> MD90State:
    """L1 SNR + L2 EMA + L11 MacroFlow"""
    return _run_selected_layers(state, [LAYER_SNR, LAYER_EMA, LAYER_MACRO_FLOW])


def momentum_agent(state: MD90State) -> MD90State:
    """L3 RSI + L4 Stoch + L8 Sentiment"""
    return _run_selected_layers(state, [LAYER_RSI, LAYER_STOCHASTIC, LAYER_SENTIMENT])


def structure_agent(state: MD90State) -> MD90State:
    """L5 OB + L14 OTE + L15 IDM/FVG + L16 MasterCall"""
    return _run_selected_layers(state, [
        LAYER_ORDER_BLOCK, LAYER_OTE, LAYER_IDM_FVG, LAYER_MASTER_CALL
    ])


def sweep_agent(state: MD90State) -> MD90State:
    """L7 MTF + L9 UltraScalper + L10 PrimeSwing"""
    return _run_selected_layers(state, [
        LAYER_MTF, LAYER_ULTRA_SCALPER, LAYER_PRIME_SWING
    ])


def risk_agent(state: MD90State) -> MD90State:
    """L6 Volume + L12 VWAP + L13 ATR + L17 TimeStop"""
    return _run_selected_layers(state, [
        LAYER_VOLUME, LAYER_VWAP, LAYER_ATR_CONTEXT, LAYER_TIMESTOP
    ])


# ══════════════════════════════════════════════════════════════════════
# SYNTHESIS — Fan-In
# ══════════════════════════════════════════════════════════════════════

def synthesis_agent(state: MD90State) -> MD90State:
    """
    Terima semua 17 layer hasil dari 5 agents.
    Jalankan FusionScore → GateFilter → ConfidenceEngine → Status.
    """
    md      = state["market_data"]
    layers  = state["layer_signals"]

    sig = full_analyze(
        layers      = layers,
        price       = md.current_price,
        atr         = md.atr if md.atr > 0 else md.current_price * 0.005,
        atr_ratio   = md.atr_ratio,
        volume_spike = md.volume_spike,
    )

    return MD90State(
        market_data=md,
        layer_signals=layers,
        fusion_signal=sig,
    )


# ══════════════════════════════════════════════════════════════════════
# BUILD GRAPH
# ══════════════════════════════════════════════════════════════════════

def build_graph():
    """
    Topology:
    orchestrator → [price, momentum, structure, sweep, risk] (parallel)
    all 5 → synthesis → END
    """
    graph = StateGraph(MD90State)

    graph.add_node("price_agent",     price_agent)
    graph.add_node("momentum_agent",  momentum_agent)
    graph.add_node("structure_agent", structure_agent)
    graph.add_node("sweep_agent",     sweep_agent)
    graph.add_node("risk_agent",      risk_agent)
    graph.add_node("synthesis_agent", synthesis_agent)

    # Fan-out dari START ke 5 agents
    graph.set_entry_point("price_agent")    # LangGraph entrypoint

    # NOTE: LangGraph parallel fan-out via multiple add_edge from same source
    # Kita pakai conditional_edges untuk true parallel fan-out
    # Alternatif: sequential (tiap agent baca state independen, hasil digabung)
    # Untuk Railway deployment, sequential lebih stable:
    graph.add_edge("price_agent",     "momentum_agent")
    graph.add_edge("momentum_agent",  "structure_agent")
    graph.add_edge("structure_agent", "sweep_agent")
    graph.add_edge("sweep_agent",     "risk_agent")
    graph.add_edge("risk_agent",      "synthesis_agent")
    graph.add_edge("synthesis_agent", END)

    return graph.compile()


# ══════════════════════════════════════════════════════════════════════
# PUBLIC API
# ══════════════════════════════════════════════════════════════════════

_graph = None

def get_signal(market_data: MarketData) -> FusionSignal:
    """
    Entry point untuk MeridianBot.
    Input : MarketData (precomputed dari CCXT)
    Output: FusionSignal dengan execution_status, confidence, TP/SL levels
    """
    global _graph
    if _graph is None:
        _graph = build_graph()

    initial_state = _empty_state(market_data)
    final_state   = _graph.invoke(initial_state)
    return final_state["fusion_signal"]
