"""
MD90 — QuadForce Engine
Port dari MQL5 MD90_ULTIMATE_FUSION_EA_v2-2 (4 sub-systems):

  1. HedgeFusion  : EMA stack + SNR + ADX + OrderFlow → tanh weighted
  2. MatariFusion : EMA12/26 cross + RSI + ATR regime detection
  3. MegaKonfluensi: MA + SuperTrend + MACD + MTF priority
  4. SupremeBattle : Multi-regime fusion + Stoch/MACD trigger

Output: QuadSignal (buy_score, sell_score, direction, confidence)
Digunakan sebagai additional input layer ke FusionScore.
"""
import math
from dataclasses import dataclass
from typing import List
from md90_brain.types import MarketData, SignalDirection

BUY  = int(SignalDirection.BUY)
SELL = int(SignalDirection.SELL)
NEUT = int(SignalDirection.NEUTRAL)


@dataclass
class QuadSignal:
    direction:  int
    buy_score:  float   # 0–100
    sell_score: float   # 0–100
    confidence: float   # 0–100
    hedge_score:   float = 0.0
    matari_score:  float = 0.0
    mega_score:    float = 0.0
    supreme_score: float = 0.0
    reason: str = ""


# ══════════════════════════════════════════════════════════════════════
# 1. HedgeFusion — tanh-weighted multi-factor
# ══════════════════════════════════════════════════════════════════════

def _hedge_fusion(md: MarketData) -> float:
    """
    Port of HedgeFusionSignals():
    Score = tanh( Σ weight_i × factor_i )
    Returns -1..+1 (negative=sell, positive=buy)
    """
    price  = md.current_price
    e8, e21, e50 = md.ema8, md.ema21, md.ema50
    adx    = md.adx
    di_p   = md.di_plus
    di_m   = md.di_minus
    rsi    = md.rsi
    macd_h = md.macd_hist

    factors = []

    # EMA stack
    if e8 > 0 and e21 > 0 and e50 > 0:
        if e8 > e21 > e50:
            factors.append(("ema_stack", 1.0, 0.30))
        elif e8 < e21 < e50:
            factors.append(("ema_stack", -1.0, 0.30))
        else:
            factors.append(("ema_stack", 0.0, 0.30))

    # ADX + DI
    if adx > 25:
        di_dir = 1.0 if di_p > di_m else -1.0
        strength = min(1.0, (adx - 25) / 50)
        factors.append(("adx_di", di_dir * strength, 0.25))

    # RSI normalized
    rsi_norm = (rsi - 50) / 50   # -1..+1
    factors.append(("rsi", rsi_norm, 0.20))

    # MACD histogram
    if md.atr > 0:
        macd_norm = max(-1.0, min(1.0, macd_h / md.atr * 100))
        factors.append(("macd", macd_norm, 0.25))

    if not factors:
        return 0.0

    weighted_sum = sum(v * w for _, v, w in factors)
    return math.tanh(weighted_sum * 2)   # tanh squash


# ══════════════════════════════════════════════════════════════════════
# 2. MatariFusion — EMA cross + ATR regime
# ══════════════════════════════════════════════════════════════════════

def _matari_fusion(md: MarketData) -> float:
    """
    Port of MatariFusionSignals():
    EMA12/26 cross (use EMA8/EMA21 as proxy)
    + ATR regime filter (high ATR = reduce signal)
    Returns -100..+100
    """
    score = 0.0
    price = md.current_price

    # EMA cross
    e8, e21 = md.ema8, md.ema21
    if e8 > 0 and e21 > 0:
        if e8 > e21:
            score += 40.0
        else:
            score -= 40.0

    # RSI confirm
    if md.rsi > 55: score += 20.0
    elif md.rsi < 45: score -= 20.0

    # ATR regime: high volatility → scale down
    atr_ratio = md.atr_ratio
    if atr_ratio > 2.0:
        score *= 0.5   # too volatile, reduce conviction
    elif atr_ratio < 0.7:
        score *= 0.7   # too quiet, reduce confidence

    return max(-100.0, min(100.0, score))


# ══════════════════════════════════════════════════════════════════════
# 3. MegaKonfluensi — MA + MACD + MTF priority
# ══════════════════════════════════════════════════════════════════════

def _mega_konfluensi(md: MarketData) -> float:
    """
    Port of MegaKonfluensiSignals():
    MA cross (e21 vs price) + MACD cross + MTF priority weighting
    Returns -100..+100
    """
    score = 0.0
    price = md.current_price

    # MA vs price
    if md.ema21 > 0:
        if price > md.ema21:
            score += 25.0
        else:
            score -= 25.0

    # MACD cross
    if md.macd_main > md.macd_signal:
        score += 25.0
    elif md.macd_main < md.macd_signal:
        score -= 25.0

    # MTF priority (count bull TFs vs bear TFs)
    bull_tfs = bear_tfs = 0
    for tf in ["1h", "4h", "1d"]:
        c = md.mtf_close.get(tf, 0)
        e = md.mtf_ema21.get(tf, 0)
        if c > 0 and e > 0:
            if c > e: bull_tfs += 1
            else:      bear_tfs += 1

    if bull_tfs > bear_tfs:
        score += (bull_tfs - bear_tfs) * 15.0
    elif bear_tfs > bull_tfs:
        score -= (bear_tfs - bull_tfs) * 15.0

    return max(-100.0, min(100.0, score))


# ══════════════════════════════════════════════════════════════════════
# 4. SupremeBattle — multi-regime Stoch + MACD trigger
# ══════════════════════════════════════════════════════════════════════

def _supreme_battle(md: MarketData) -> float:
    """
    Port of SupremeBattleSignals():
    Regime-aware: trending vs ranging determines which sub-signal leads.
    Trigger: Stochastic cross + MACD histogram sign.
    Returns -100..+100
    """
    score  = 0.0
    adx    = md.adx
    k, d   = md.stoch_k, md.stoch_d
    macd_h = md.macd_hist

    is_trending = adx > 25.0

    if is_trending:
        # Trend regime: use MACD as primary
        if macd_h > 0:
            score += 40.0
        elif macd_h < 0:
            score -= 40.0
        # Stoch as secondary confirm
        if k > d and k > 50: score += 20.0
        elif k < d and k < 50: score -= 20.0
    else:
        # Ranging regime: use Stoch as primary (mean reversion)
        if k < 20 and k > d:
            score += 50.0
        elif k > 80 and k < d:
            score -= 50.0
        elif k > d:
            score += 15.0
        elif k < d:
            score -= 15.0

    # Volume confirmation
    if md.volume_ratio > 1.5:
        score *= 1.2

    return max(-100.0, min(100.0, score))


# ══════════════════════════════════════════════════════════════════════
# MASTER QUAD FORCE ENGINE
# ══════════════════════════════════════════════════════════════════════

class QuadForceEngine:
    """
    Runs all 4 sub-systems and combines into QuadSignal.
    Weights: Hedge=0.30, Matari=0.25, Mega=0.25, Supreme=0.20
    """
    WEIGHTS = {
        "hedge":   0.30,
        "matari":  0.25,
        "mega":    0.25,
        "supreme": 0.20,
    }

    def analyze(self, md: MarketData) -> QuadSignal:
        hedge   = _hedge_fusion(md)    # -1..+1
        matari  = _matari_fusion(md)   # -100..+100
        mega    = _mega_konfluensi(md) # -100..+100
        supreme = _supreme_battle(md)  # -100..+100

        # Normalize all to -100..+100
        hedge_n = hedge * 100

        # Weighted combine
        combined = (
            hedge_n * self.WEIGHTS["hedge"]   +
            matari  * self.WEIGHTS["matari"]  +
            mega    * self.WEIGHTS["mega"]    +
            supreme * self.WEIGHTS["supreme"]
        )

        # Split to buy/sell scores
        buy_score  = max(0.0, combined)
        sell_score = max(0.0, -combined)
        confidence = min(100.0, abs(combined))

        direction = NEUT
        if buy_score > 50:   direction = BUY
        elif sell_score > 50: direction = SELL

        return QuadSignal(
            direction    = direction,
            buy_score    = round(buy_score,  2),
            sell_score   = round(sell_score, 2),
            confidence   = round(confidence, 2),
            hedge_score  = round(hedge_n,   2),
            matari_score = round(matari,    2),
            mega_score   = round(mega,      2),
            supreme_score= round(supreme,   2),
            reason       = (
                f"H={hedge_n:.0f} M={matari:.0f} "
                f"K={mega:.0f} S={supreme:.0f} "
                f"→{combined:.0f}"
            ),
        )
