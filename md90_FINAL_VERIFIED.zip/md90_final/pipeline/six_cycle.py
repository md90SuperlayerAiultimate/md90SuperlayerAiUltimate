"""
MD90 v4 — 6-Cycle Execution Pipeline
Exact replica dari sistem viral (Chinese Engineer / Marketing101 style):

  CYCLE 1 — SCAN:     Temukan markets dengan liquidity dan volume tinggi
  CYCLE 2 — PREDICT:  Jalankan MD90 17-layer signal engine
  CYCLE 3 — VALIDATE: Gate filter + risk validation + edge check
  CYCLE 4 — SIZE:     Kelly criterion position sizing
  CYCLE 5 — FILL:     Execute CLOB order (atau Binance spot)
  CYCLE 6 — SETTLE:   Monitor sampai resolusi, record hasil

Each cycle dipanggil secara sequential.
State disimpan di CycleState untuk tracking dan dashboard.
"""
import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Optional, List, Dict, Any

from md90_brain.types import FusionSignal, MarketData, SignalDirection
from md90_brain.session_manager import SessionManager, SessionState
from md90_brain.regime_engine import RegimeEngine, RegimeState
from md90_brain.risk_calculator import DynamicRiskCalculator, RiskState
from md90_brain.quad_force import QuadForceEngine, QuadSignal
from md90_brain.regime_strategies import RegimeStrategyEngine, RegimeSignal
from md90_brain.marketmind.graph import get_signal
from polymarket.signal_mapper import SignalMapper, MappedSignal
from polymarket.core.executor import Executor
from risk.risk_manager import PolymarketRiskManager
from stats.statistics_engine import StatisticsEngine, TradeResult
from ml import AdaptiveWeights
from notifications import TelegramNotifier

log = logging.getLogger("MD90.6Cycle")
WITA = timezone(timedelta(hours=8))

BUY  = int(SignalDirection.BUY)
SELL = int(SignalDirection.SELL)
NEUT = int(SignalDirection.NEUTRAL)


@dataclass
class CycleState:
    """Live state for each execution cycle. Persisted to StateManager."""
    cycle_num:   int   = 0
    cycle_name:  str   = "IDLE"
    symbol:      str   = ""
    timestamp:   str   = ""

    # Cycle 1 — SCAN
    markets_scanned:  int  = 0
    markets_qualified:int  = 0
    best_market:      dict = field(default_factory=dict)

    # Cycle 2 — PREDICT
    fusion:     Optional[FusionSignal]  = None
    quad:       Optional[QuadSignal]    = None
    regime_sig: Optional[RegimeSignal]  = None
    session:    Optional[SessionState]  = None
    regime:     Optional[RegimeState]   = None

    # Cycle 3 — VALIDATE
    risk_state:  Optional[RiskState]    = None
    mapped:      Optional[MappedSignal] = None
    is_valid:    bool = False
    reject_reason: str = ""

    # Cycle 4 — SIZE
    final_size_usd: float = 0.0
    kelly_pct:      float = 0.0

    # Cycle 5 — FILL
    order_id:    str   = ""
    fill_price:  float = 0.0
    fill_size:   float = 0.0
    fill_status: str   = "PENDING"

    # Cycle 6 — SETTLE
    resolved:    bool  = False
    pnl:         float = 0.0
    win:         bool  = False
    settle_reason: str = ""

    # Counters
    total_cycles:   int   = 0
    wins_today:     int   = 0
    losses_today:   int   = 0
    pnl_today:      float = 0.0


class SixCyclePipeline:
    """
    The 6-cycle execution engine.
    Runs one full cycle per loop iteration.
    Handles Polymarket + Binance execution paths.
    """

    def __init__(self, cfg: dict, data_provider,
                 gamma_client, clob_executor,
                 risk_mgr: PolymarketRiskManager,
                 stats: StatisticsEngine,
                 ml: AdaptiveWeights,
                 notif: TelegramNotifier,
                 state_mgr):
        self.cfg   = cfg
        self.dp    = data_provider
        self.gamma = gamma_client
        self.clob  = clob_executor
        self.risk  = risk_mgr
        self.stats = stats
        self.ml    = ml
        self.notif = notif
        self.state = state_mgr

        self.session_mgr   = SessionManager()
        self.regime_engine = RegimeEngine()
        self.regime_strat  = RegimeStrategyEngine()
        self.quad_force    = QuadForceEngine()
        self.risk_calc     = DynamicRiskCalculator(
            base_risk=cfg.get("base_risk", 0.01),
            max_risk =cfg.get("max_risk",  0.03),
            min_risk =cfg.get("min_risk",  0.003),
        )
        self.signal_mapper = SignalMapper(cfg)

        self._cycle_state = CycleState()
        self._open_positions: Dict[str, dict] = {}   # condition_id → position
        self._equity = cfg.get("start_equity", 2000.0)

    # ══════════════════════════════════════════════════════════════════
    # MASTER RUN — one full 6-cycle iteration
    # ══════════════════════════════════════════════════════════════════

    async def run_cycle(self, symbol: str) -> CycleState:
        now = datetime.now(WITA)
        self._cycle_state.cycle_num    += 1
        self._cycle_state.symbol        = symbol
        self._cycle_state.timestamp     = now.strftime("%Y-%m-%d %H:%M:%S WITA")

        log.info(f"\n{'═'*55}")
        log.info(f"  6-CYCLE #{self._cycle_state.cycle_num} | {symbol}")
        log.info(f"  {now.strftime('%H:%M:%S WITA')}")
        log.info(f"{'═'*55}")

        try:
            # CYCLE 1: SCAN
            self._cycle_state.cycle_name = "SCAN"
            md, markets = await self._cycle1_scan(symbol)
            if md is None:
                log.warning("C1 FAIL: No market data")
                return self._cycle_state

            # CYCLE 2: PREDICT
            self._cycle_state.cycle_name = "PREDICT"
            fusion, quad, regime_sig, session, regime = await self._cycle2_predict(md)
            self._cycle_state.fusion     = fusion
            self._cycle_state.quad       = quad
            self._cycle_state.regime_sig = regime_sig
            self._cycle_state.session    = session
            self._cycle_state.regime     = regime

            # Export state for dashboard
            self._export_to_state(symbol, md, fusion, quad, session, regime)

            # CYCLE 3: VALIDATE
            self._cycle_state.cycle_name = "VALIDATE"
            is_valid, reject_reason, mapped, risk_state = await self._cycle3_validate(
                fusion, quad, regime_sig, session, regime, markets, md)

            self._cycle_state.is_valid     = is_valid
            self._cycle_state.reject_reason= reject_reason
            self._cycle_state.mapped       = mapped
            self._cycle_state.risk_state   = risk_state

            if not is_valid:
                log.info(f"C3 SKIP: {reject_reason}")
                self._update_positions(md.current_price)
                return self._cycle_state

            # CYCLE 4: SIZE
            self._cycle_state.cycle_name = "SIZE"
            final_size = await self._cycle4_size(mapped, risk_state)
            self._cycle_state.final_size_usd = final_size

            # CYCLE 5: FILL
            self._cycle_state.cycle_name = "FILL"
            order_id, fill_price, fill_size, fill_ok = await self._cycle5_fill(
                mapped, final_size)
            self._cycle_state.order_id    = order_id
            self._cycle_state.fill_price  = fill_price
            self._cycle_state.fill_size   = fill_size
            self._cycle_state.fill_status = "FILLED" if fill_ok else "FAILED"

            if fill_ok:
                # Register open position
                cid = mapped.condition_id
                self._open_positions[cid] = {
                    "symbol":       symbol,
                    "side":         mapped.side,
                    "size_usd":     fill_size,
                    "entry_price":  fill_price,
                    "our_prob":     mapped.our_probability,
                    "edge":         mapped.edge,
                    "open_time":    now.isoformat(),
                    "open_wita":    now.strftime("%H:%M WITA"),
                    "question":     mapped.market_question,
                    "end_date":     mapped.market_end_date,
                    "layers":       [ls.direction for ls in fusion.layer_signals],
                    "session":      session.name,
                    "regime":       regime.name,
                    "confidence":   fusion.confidence,
                }
                self.risk.portfolio.open_position(cid, mapped.side, fill_size)
                await self.notif.trade_open(
                    side       = mapped.side,
                    symbol     = symbol,
                    price      = fill_price,
                    size       = fill_size,
                    sl         = mapped.market_price * 0.1,
                    tp1        = mapped.expected_payoff,
                    session    = session.name,
                    regime     = regime.name,
                    risk_pct   = risk_state.final_risk_pct,
                    confidence = fusion.confidence,
                    status     = fusion.execution_status,
                    lot_mult   = fusion.lot_multiplier,
                )

            # CYCLE 6: SETTLE (check existing open positions)
            self._cycle_state.cycle_name = "SETTLE"
            await self._cycle6_settle()

        except Exception as e:
            log.error(f"Cycle error: {e}", exc_info=True)
            self.state.log_error(f"6-cycle error: {e}")

        self._cycle_state.total_cycles += 1
        return self._cycle_state

    # ══════════════════════════════════════════════════════════════════
    # CYCLE 1 — SCAN
    # ══════════════════════════════════════════════════════════════════

    async def _cycle1_scan(self, symbol: str):
        """Fetch market data + scan Polymarket for opportunities."""
        # Fetch OHLCV
        md = await self.dp.fetch(symbol, self.cfg.get("timeframe", "15m"))

        # Scan Polymarket markets
        markets = []
        if self.cfg.get("mode") == "polymarket":
            try:
                markets = await self.gamma.scan_for_opportunities(
                    min_volume   = self.cfg.get("poly_min_volume",    10000),
                    min_liquidity= self.cfg.get("poly_min_liquidity", 5000),
                    max_spread   = self.cfg.get("poly_max_spread",    0.05),
                    keywords     = self.cfg.get("poly_keywords", ["btc","bitcoin"]),
                )
                self._cycle_state.markets_scanned   = len(markets) + 50  # estimate scanned
                self._cycle_state.markets_qualified = len(markets)
                if markets:
                    self._cycle_state.best_market = markets[0]
            except Exception as e:
                log.warning(f"C1 Gamma scan error: {e}")

        n_q = self._cycle_state.markets_qualified
        log.info(f"C1 SCAN: {symbol} data={'OK' if md else 'FAIL'} | "
                 f"Poly markets qualified: {n_q}")
        return md, markets

    # ══════════════════════════════════════════════════════════════════
    # CYCLE 2 — PREDICT
    # ══════════════════════════════════════════════════════════════════

    async def _cycle2_predict(self, md: MarketData):
        """Run all prediction engines."""
        now_utc = datetime.now(timezone.utc)
        session = self.session_mgr.detect(now_utc)
        regime  = self.regime_engine.analyze(
            md.closes, md.highs, md.lows,
            md.atr, md.adx, md.di_plus, md.di_minus, md.volume_ratio)

        # QuadForce (fast)
        quad = self.quad_force.analyze(md)

        # RegimeStrategy
        regime_sig = self.regime_strat.analyze(md, regime)

        # MD90 Brain — 17-layer LangGraph
        fusion = get_signal(md)

        dir_str = {BUY:"BUY", SELL:"SELL", NEUT:"---"}.get(fusion.direction, "?")
        log.info(
            f"C2 PREDICT: {dir_str} | "
            f"Fusion={fusion.execution_status}({fusion.fusion_score:.3f}) | "
            f"Conf={fusion.confidence:.1f}% | "
            f"Quad={quad.confidence:.0f}% | "
            f"Regime={regime.name} | Session={session.name}"
        )
        return fusion, quad, regime_sig, session, regime

    # ══════════════════════════════════════════════════════════════════
    # CYCLE 3 — VALIDATE
    # ══════════════════════════════════════════════════════════════════

    async def _cycle3_validate(self, fusion, quad, regime_sig,
                                session, regime, markets, md):
        """Triple-confirm + risk gate + edge validation."""

        # Risk gate
        risk_state = self.risk_calc.calculate(
            session, regime,
            equity  = self._equity,
            balance = self._equity,
        )
        if not risk_state.trading_allowed:
            return False, f"RISK_GATE: {risk_state.block_reason}", None, risk_state

        if self.risk.circuit_breakers.is_triggered():
            return False, f"CIRCUIT_BREAKER: {self.risk.circuit_breakers.reason}", None, risk_state

        # Triple confirmation (same as bot_v4 synthesis)
        q_dir  = quad.direction
        rs_dir = regime_sig.direction
        f_dir  = fusion.direction
        dirs   = [q_dir, rs_dir, f_dir]
        buy_agree  = sum(1 for d in dirs if d == BUY)
        sell_agree = sum(1 for d in dirs if d == SELL)

        if max(buy_agree, sell_agree) < 2:
            return False, "TRIPLE_CONFIRM_FAIL: no 2/3 agreement", None, risk_state

        composite = (
            quad.confidence / 100 * 0.25 +
            max(regime_sig.buy_score, regime_sig.sell_score) / 100 * 0.25 +
            fusion.confidence / 100 * 0.50
        )

        allin_th = self.cfg.get("composite_allin", 0.72)
        wait_th  = self.cfg.get("composite_wait",  0.55)

        if fusion.execution_status == "ABORT":
            return False, "FUSION_ABORT", None, risk_state

        if composite < wait_th:
            return False, f"COMPOSITE_LOW: {composite:.3f} < {wait_th}", None, risk_state

        # Map to Polymarket if mode=polymarket
        mapped = None
        mode = self.cfg.get("mode", "polymarket")
        if mode == "polymarket" and markets:
            # Try each market until we find valid edge
            for market in markets[:5]:
                mapped = self.signal_mapper.map(fusion, market)
                if mapped.is_valid:
                    break
            if mapped is None or not mapped.is_valid:
                reject = mapped.reject_reason if mapped else "NO_MARKETS"
                return False, f"POLY_MAP_FAIL: {reject}", mapped, risk_state
        else:
            # Binance mode — create synthetic mapped signal
            mapped = self._synthetic_mapped(fusion, md)
            if not mapped.is_valid:
                return False, f"SIGNAL_INVALID: {mapped.reject_reason}", mapped, risk_state

        log.info(
            f"C3 VALIDATE: ✅ | "
            f"side={mapped.side} | "
            f"prob={mapped.our_probability:.3f} | "
            f"edge={mapped.edge:.3f}({mapped.edge_pct:.1f}%) | "
            f"composite={composite:.3f}"
        )
        return True, "", mapped, risk_state

    def _synthetic_mapped(self, fusion: FusionSignal,
                           md: MarketData) -> MappedSignal:
        """Create mapped signal for Binance spot mode."""
        from polymarket.signal_mapper import MappedSignal
        our_prob = self.signal_mapper._estimate_probability(fusion)
        if our_prob < 0.55:
            return MappedSignal(
                direction=fusion.direction, fusion_score=fusion.fusion_score,
                confidence=fusion.confidence, execution_status=fusion.execution_status,
                market_question=f"{md.symbol} directional",
                condition_id="", yes_token_id="", no_token_id="",
                side="NONE", our_probability=our_prob, market_price=0.5,
                edge=our_prob-0.5, edge_pct=(our_prob-0.5)*200,
                kelly_size_usd=0, recommended_size=0, min_rr=0,
                expected_payoff=0, is_valid=False,
                reject_reason=f"Win prob too low: {our_prob:.2f}",
            )
        side = "LONG" if fusion.direction == BUY else "SHORT"
        size = self.signal_mapper._kelly(our_prob, 2.0) * self._equity * self.signal_mapper.kelly_fraction
        size = max(self.signal_mapper.min_size, min(self.signal_mapper.max_size, size))
        return MappedSignal(
            direction=fusion.direction, fusion_score=fusion.fusion_score,
            confidence=fusion.confidence, execution_status=fusion.execution_status,
            market_question=f"{md.symbol} {side} {fusion.execution_status}",
            condition_id=md.symbol, yes_token_id="", no_token_id="",
            side=side, our_probability=our_prob, market_price=0.5,
            edge=our_prob-0.5, edge_pct=(our_prob-0.5)*200,
            kelly_size_usd=size, recommended_size=size,
            min_rr=2.0, expected_payoff=2.0, is_valid=True,
            market_volume=0, market_liquidity=0,
        )

    # ══════════════════════════════════════════════════════════════════
    # CYCLE 4 — SIZE
    # ══════════════════════════════════════════════════════════════════

    async def _cycle4_size(self, mapped: MappedSignal,
                            risk_state: RiskState) -> float:
        """Final position sizing: Kelly × session_mult × regime_mult."""
        base_size = mapped.recommended_size

        # Apply dynamic risk multipliers
        sess_mult   = risk_state.session_mult
        regime_mult = risk_state.regime_mult
        risk_adj    = sess_mult * regime_mult

        final_size = base_size * risk_adj
        final_size = max(self.cfg.get("poly_min_size_usd", 10),
                         min(self.cfg.get("poly_max_size_usd", 500), final_size))

        log.info(
            f"C4 SIZE: base=${base_size:.2f} "
            f"× sess={sess_mult:.2f} × regime={regime_mult:.2f} "
            f"= ${final_size:.2f}"
        )
        return final_size

    # ══════════════════════════════════════════════════════════════════
    # CYCLE 5 — FILL
    # ══════════════════════════════════════════════════════════════════

    async def _cycle5_fill(self, mapped: MappedSignal,
                            size_usd: float):
        """Execute order — CLOB for Polymarket, ccxt for Binance."""
        mode = self.cfg.get("mode", "polymarket")

        if mode == "polymarket" and mapped.yes_token_id:
            token_id = (mapped.yes_token_id if mapped.side == "YES"
                        else mapped.no_token_id)
            decision_dict = {
                "action":       "BUY_YES" if mapped.side == "YES" else "BUY_NO",
                "market_prob":  mapped.market_price,
                "edge":         mapped.edge,
                "sizing":       {"position_usdc": size_usd},
            }
            token_ids_dict = {
                "yes": mapped.yes_token_id,
                "no":  mapped.no_token_id,
            }
            result = self.clob.execute_signal(
                market={},
                decision=decision_dict,
                token_ids=token_ids_dict,
            )
            fill_ok   = result.get("status") == "EXECUTED"
            order_id  = result.get("order_id", "")
            fill_price = mapped.market_price
            fill_size  = size_usd

        else:
            # Dry/binance mode
            fill_ok    = not self.cfg.get("dry_run", True)
            order_id   = f"SIM_{int(datetime.now().timestamp())}"
            fill_price = mapped.market_price
            fill_size  = size_usd
            if self.cfg.get("dry_run", True):
                fill_ok = True   # simulate success in dry run
                log.info(f"  [DRY-FILL] {mapped.side} ${size_usd:.2f} "
                         f"@ {fill_price:.4f} | {mapped.market_question[:60]}")

        log.info(
            f"C5 FILL: {'✅' if fill_ok else '❌'} "
            f"id={order_id} price={fill_price:.4f} size=${fill_size:.2f}"
        )
        return order_id, fill_price, fill_size, fill_ok

    # ══════════════════════════════════════════════════════════════════
    # CYCLE 6 — SETTLE
    # ══════════════════════════════════════════════════════════════════

    async def _cycle6_settle(self):
        """
        Check all open positions for resolution.
        For Polymarket: check if market resolved.
        For Binance: check if SL/TP hit.
        """
        closed = []
        for cid, pos in self._open_positions.items():
            resolved, pnl, reason = await self._check_resolution(cid, pos)
            if resolved:
                self._equity += pnl
                self.risk_calc.record_trade_result(pnl)
                self.risk.record_pnl(pnl)
                self._cycle_state.pnl_today += pnl
                if pnl > 0:
                    self._cycle_state.wins_today += 1
                else:
                    self._cycle_state.losses_today += 1

                # Statistics
                self.stats.record(
                    TradeResult(
                        pnl=pnl, risk=pos["size_usd"] * 0.5,
                        rr_ratio=abs(pnl/pos["size_usd"]) if pos["size_usd"] > 0 else 0,
                        session=pos.get("session",""), regime=pos.get("regime",""),
                        duration_m=0,
                    ),
                    equity_after=self._equity
                )

                # ML recording
                layers = pos.get("layers", [])
                trade_dir = BUY if pos["side"] in ("YES","LONG") else SELL
                if len(layers) == 17:
                    self.ml.record(layers, trade_dir, pnl)

                self.risk.portfolio.close_position(cid, pnl)
                closed.append(cid)

                log.info(
                    f"C6 SETTLE: {pos['side']} [{reason}] "
                    f"pnl=${pnl:+.2f} equity=${self._equity:.2f}"
                )
                await self.notif.trade_close(
                    side=pos["side"], symbol=pos["symbol"],
                    entry=pos["entry_price"], exit_price=pos["entry_price"]*(1+pnl/pos["size_usd"]),
                    pnl=pnl, reason=reason, equity=self._equity)

        for cid in closed:
            del self._open_positions[cid]

        # Update state
        self.state.update_many({
            "equity":      self._equity,
            "positions":   list(self._open_positions.values()),
            "daily_pnl":   self._cycle_state.pnl_today,
        })

    async def _check_resolution(self, cid: str, pos: dict):
        """
        Check if position should be closed.
        Polymarket: check if market resolved.
        Binance/sim: use time-based or SL/TP simulation.
        """
        mode = self.cfg.get("mode", "polymarket")

        if mode == "polymarket" and self.gamma:
            try:
                market = await self.gamma.get_market_by_slug(cid)
                if market and market.get("closed"):
                    resolution = market.get("resolution", "")
                    side = pos["side"]
                    won = (resolution == "YES" and side == "YES" or
                           resolution == "NO"  and side == "NO")
                    payoff = (1.0 - pos["entry_price"]) / pos["entry_price"]
                    pnl = pos["size_usd"] * payoff if won else -pos["size_usd"]
                    return True, pnl, f"RESOLVED_{resolution}"
            except:
                pass

        # Sim: close after 2 cycles (dry run / demo)
        if self.cfg.get("dry_run", True):
            open_time = datetime.fromisoformat(pos.get("open_time",
                datetime.now(timezone.utc).isoformat()))
            age_mins = (datetime.now(timezone.utc) - open_time.replace(tzinfo=timezone.utc)).seconds / 60
            if age_mins > 30:  # simulate 30-min hold
                win = pos.get("our_prob", 0.5) > 0.55
                pnl = pos["size_usd"] * (pos.get("edge", 0.1) * 2) if win else -pos["size_usd"] * 0.8
                return True, pnl, "SIM_TIMEOUT"

        return False, 0.0, ""

    def _update_positions(self, current_price: float):
        """Update position unrealized PnL."""
        pass  # For Polymarket, PnL only realized on resolution

    def _export_to_state(self, symbol, md: MarketData,
                          fusion: FusionSignal,
                          quad: QuadSignal,
                          session: SessionState,
                          regime: RegimeState):
        """Export signal state to StateManager for dashboard."""
        layer_dirs = [ls.direction for ls in fusion.layer_signals]
        layer_strs = [ls.strength  for ls in fusion.layer_signals]
        self.state.update_pair(symbol, {
            "direction":        fusion.direction,
            "fusion_score":     fusion.fusion_score,
            "confidence":       fusion.confidence,
            "execution_status": fusion.execution_status,
            "quad_confidence":  quad.confidence,
            "gate1": fusion.gate1_passed, "gate2": fusion.gate2_passed,
            "gate3": fusion.gate3_passed, "gate4": fusion.gate4_passed,
            "gate5": fusion.gate5_passed,
            "sl":  fusion.stop_loss,
            "tp1": fusion.take_profit[0] if fusion.take_profit else 0,
            "tp2": fusion.take_profit[1] if len(fusion.take_profit)>1 else 0,
            "session":  session.name,
            "regime":   regime.name,
            "layer_directions": layer_dirs,
            "layer_strengths":  layer_strs,
            "price":        md.current_price,
            "atr":          md.atr,
            "rsi":          md.rsi,
            "volume_ratio": md.volume_ratio,
            "composite":    quad.confidence/100,
        })
