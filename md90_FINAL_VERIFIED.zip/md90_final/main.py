#!/usr/bin/env python3
"""
MD90 ULTIMATE FUSION v4 — UNIFIED ENTRY POINT (FINAL SYNCHRONIZED)
All imports verified against canonical module paths post-deduplication.

Modes:
  polymarket  → Polymarket CLOB V2 bot (Ollama/Claude + HMM + MiroFish + 17L)
  binance     → Binance spot + 6-cycle pipeline
  backtest    → Walk-forward backtest with full statistics
  dashboard   → Streamlit monitoring only

Usage:
  python main.py                          # from .env MODE
  python main.py --mode polymarket
  python main.py --mode backtest --symbol BTC/USDT --start 2024-01-01
  streamlit run dashboard/app.py
"""
import asyncio, sys, os, argparse, logging
from datetime import datetime, timezone, timedelta

os.makedirs("logs",   exist_ok=True)
os.makedirs("model",  exist_ok=True)
os.makedirs("data/models",    exist_ok=True)
os.makedirs("data/research",  exist_ok=True)
os.makedirs("data/latest",    exist_ok=True)
os.makedirs("data/historical",exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("logs/md90.log", mode="a"),
    ]
)
log = logging.getLogger("MD90")
WITA = timezone(timedelta(hours=8))


def parse_args():
    p = argparse.ArgumentParser(description="MD90 Ultimate Fusion v4")
    p.add_argument("--mode",    choices=["polymarket","binance","backtest","dashboard"])
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--symbol",  default=None)
    p.add_argument("--start",   default=None)
    p.add_argument("--end",     default=None)
    p.add_argument("--tf",      default=None)
    return p.parse_args()


async def run():
    args = parse_args()
    from config import CFG

    if args.mode:    CFG["mode"]      = args.mode
    if args.dry_run: CFG["dry_run"]   = True
    if args.symbol:  CFG["symbol"]    = args.symbol
    if args.start:   CFG["bt_start"]  = args.start
    if args.end:     CFG["bt_end"]    = args.end
    if args.tf:      CFG["timeframe"] = args.tf

    mode = CFG.get("mode", "polymarket")

    log.info("=" * 60)
    log.info("  MD90 ULTIMATE FUSION v4 — FINAL BUILD")
    log.info(f"  Mode: {mode.upper()} | DryRun: {CFG.get('dry_run')}")
    log.info(f"  {datetime.now(WITA).strftime('%Y-%m-%d %H:%M:%S WITA')}")
    log.info("=" * 60)

    if mode == "polymarket":
        from polymarket.bot import main_loop
        await main_loop(CFG)

    elif mode == "omni":
        # FINAL unified bot: Arbitrage + Latency + Evolution + Memory
        import bot as omni_bot
        await omni_bot.run(CFG)

    elif mode == "binance":
        from pipeline.six_cycle          import SixCyclePipeline
        from data_provider               import DataProvider
        from polymarket.core.scanner     import MarketScanner
        from polymarket.core.executor    import Executor
        from risk.risk_manager           import PolymarketRiskManager
        from stats.statistics_engine     import StatisticsEngine
        from ml                          import AdaptiveWeights
        from notifications               import TelegramNotifier
        from state_manager               import StateManager

        dp       = DataProvider(CFG["exchange"], CFG.get("api_key",""), CFG.get("api_secret",""))
        sm       = StateManager()
        scanner  = MarketScanner()
        risk_mgr = PolymarketRiskManager({
            "max_position_usd":         CFG["start_equity"]*0.3,
            "max_portfolio_usd":        CFG["start_equity"],
            "kelly_fraction":           CFG["kelly_fraction"],
            "circuit_breaker_drawdown": CFG["max_daily_loss"],
            "cooldown_after_loss_seconds": 300,
            "total_usd":                CFG["start_equity"],
        })
        stats    = StatisticsEngine("logs/statistics.json")
        ml_w     = AdaptiveWeights("model/adaptive_weights.json")
        notif    = TelegramNotifier(CFG["telegram_token"], CFG["telegram_chat_id"])

        from execution import OrderExecutor
        clob = OrderExecutor(
            CFG["exchange"], CFG.get("api_key",""),
            CFG.get("api_secret",""), "spot", CFG["dry_run"]
        )

        pipeline = SixCyclePipeline(CFG, dp, scanner, clob, risk_mgr, stats, ml_w, notif, sm)
        sm.update("status", "RUNNING")
        symbol = CFG["symbol"]
        while True:
            await pipeline.run_cycle(symbol)
            await asyncio.sleep(CFG.get("loop_sec", 60))

    elif mode == "backtest":
        from backtest.engine import BacktestEngine
        import json
        engine  = BacktestEngine(CFG)
        symbol  = CFG.get("symbol",    "BTC/USDT")
        tf      = CFG.get("timeframe", "15m")
        start   = CFG.get("bt_start",  "2024-01-01")
        end     = CFG.get("bt_end",    "2024-12-31")
        log.info(f"Backtest: {symbol} {tf} {start}→{end}")
        results = await engine.run(symbol, start, end, tf)
        print("\n" + results.report())
        with open("logs/backtest_results.json","w") as f:
            json.dump({
                "symbol":        results.symbol,
                "timeframe":     results.timeframe,
                "start":         results.start_date,
                "end":           results.end_date,
                "initial_cap":   results.initial_cap,
                "final_cap":     results.final_cap,
                "total_trades":  results.total_trades,
                "win_rate":      results.win_rate,
                "profit_factor": results.profit_factor,
                "sharpe":        results.sharpe,
                "sortino":       results.sortino,
                "max_dd_pct":    results.max_dd_pct,
                "equity_curve":  results.equity_curve,
            }, f, indent=2)
        log.info("Results saved: logs/backtest_results.json")

    elif mode == "dashboard":
        import subprocess
        subprocess.run(["streamlit","run","dashboard/app.py","--server.port","8501"])


if __name__ == "__main__":
    asyncio.run(run())
