"""
MD90 — Statistics Engine
Port dari MQL5 MD90_COMPLETE_ANALYSIS Section 21 + Section 27

Metrics:
  Win Rate, Profit Factor, Recovery Factor
  Sharpe Ratio, Sortino Ratio
  Expectancy, Average RR
  Max Drawdown (value + percent)
  Largest Win / Loss, Average Win / Loss
"""
import math
import json
import os
from dataclasses import dataclass, field, asdict
from typing import List, Optional
from datetime import datetime, timezone


@dataclass
class TradeResult:
    pnl:        float
    risk:       float   # amount risked
    rr_ratio:   float
    session:    str
    regime:     str
    duration_m: float   # minutes held
    timestamp:  str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass
class StatsSnapshot:
    total_trades:      int   = 0
    winning:           int   = 0
    losing:            int   = 0
    win_rate:          float = 0.0
    total_pnl:         float = 0.0
    gross_profit:      float = 0.0
    gross_loss:        float = 0.0
    profit_factor:     float = 0.0
    recovery_factor:   float = 0.0
    sharpe_ratio:      float = 0.0
    sortino_ratio:     float = 0.0
    expectancy:        float = 0.0
    avg_rr:            float = 0.0
    avg_win:           float = 0.0
    avg_loss:          float = 0.0
    largest_win:       float = 0.0
    largest_loss:      float = 0.0
    max_drawdown_pct:  float = 0.0
    max_drawdown_val:  float = 0.0
    consecutive_wins:  int   = 0
    consecutive_losses:int   = 0
    # Best regime / session
    best_regime:       str   = ""
    best_session:      str   = ""


class StatisticsEngine:
    """
    Full statistics engine. Dipersisten ke JSON.
    """
    RISK_FREE_RATE = 0.0   # daily risk-free rate

    def __init__(self, save_path: str = "logs/statistics.json"):
        self.save_path   = save_path
        self._results:   List[TradeResult] = []
        self._equity_curve: List[float]    = []
        self._peak_equity   = 0.0
        self._max_dd_val    = 0.0
        self._max_dd_pct    = 0.0
        self._consec_wins   = 0
        self._consec_losses = 0
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        self._load()

    # ── Record ───────────────────────────────────────────────────────
    def record(self, result: TradeResult, equity_after: float):
        self._results.append(result)
        self._equity_curve.append(equity_after)

        # Drawdown tracking
        if equity_after > self._peak_equity:
            self._peak_equity = equity_after
        if self._peak_equity > 0:
            dd_val = self._peak_equity - equity_after
            dd_pct = dd_val / self._peak_equity * 100
            if dd_pct > self._max_dd_pct:
                self._max_dd_pct = dd_pct
                self._max_dd_val = dd_val

        # Consecutive
        if result.pnl > 0:
            self._consec_wins   += 1
            self._consec_losses  = 0
        else:
            self._consec_losses += 1
            self._consec_wins    = 0

        self._save()

    # ── Compute all metrics ──────────────────────────────────────────
    def snapshot(self) -> StatsSnapshot:
        results = self._results
        if not results:
            return StatsSnapshot()

        s = StatsSnapshot()
        s.total_trades = len(results)
        pnls  = [r.pnl for r in results]
        wins  = [p for p in pnls if p > 0]
        losses= [p for p in pnls if p <= 0]

        s.winning       = len(wins)
        s.losing        = len(losses)
        s.win_rate      = s.winning / s.total_trades * 100 if s.total_trades else 0
        s.total_pnl     = sum(pnls)
        s.gross_profit  = sum(wins) if wins else 0
        s.gross_loss    = abs(sum(losses)) if losses else 0
        s.profit_factor = s.gross_profit / s.gross_loss if s.gross_loss > 0 else 0
        s.largest_win   = max(wins)  if wins   else 0
        s.largest_loss  = min(losses) if losses else 0
        s.avg_win       = sum(wins)/len(wins)     if wins   else 0
        s.avg_loss      = sum(losses)/len(losses) if losses else 0
        s.max_drawdown_pct = self._max_dd_pct
        s.max_drawdown_val = self._max_dd_val
        s.consecutive_wins   = self._consec_wins
        s.consecutive_losses = self._consec_losses

        # RR
        rrs = [r.rr_ratio for r in results if r.rr_ratio > 0]
        s.avg_rr = sum(rrs) / len(rrs) if rrs else 0

        # Recovery Factor = net_pnl / max_drawdown
        s.recovery_factor = (s.total_pnl / self._max_dd_val
                             if self._max_dd_val > 0 else 0)

        # Expectancy = (win_rate * avg_win) - (loss_rate * avg_loss)
        lrate = 1.0 - s.win_rate / 100
        s.expectancy = (s.win_rate / 100 * s.avg_win) - (lrate * abs(s.avg_loss))

        # Sharpe Ratio (daily returns)
        if len(pnls) >= 2:
            mean_r  = sum(pnls) / len(pnls)
            var_r   = sum((p - mean_r)**2 for p in pnls) / len(pnls)
            std_r   = math.sqrt(var_r)
            s.sharpe_ratio = ((mean_r - self.RISK_FREE_RATE) / std_r
                              if std_r > 0 else 0) * math.sqrt(252)

        # Sortino Ratio (only downside deviation)
        if len(pnls) >= 2:
            mean_r   = sum(pnls) / len(pnls)
            down_var = sum((p - mean_r)**2 for p in pnls if p < mean_r)
            if down_var > 0 and losses:
                down_std = math.sqrt(down_var / len(losses))
                s.sortino_ratio = ((mean_r - self.RISK_FREE_RATE) / down_std
                                   if down_std > 0 else 0) * math.sqrt(252)

        # Best regime / session
        regime_pnl: dict = {}
        session_pnl: dict = {}
        for r in results:
            regime_pnl[r.regime]   = regime_pnl.get(r.regime, 0)   + r.pnl
            session_pnl[r.session] = session_pnl.get(r.session, 0) + r.pnl
        if regime_pnl:
            s.best_regime  = max(regime_pnl,  key=regime_pnl.get)
        if session_pnl:
            s.best_session = max(session_pnl, key=session_pnl.get)

        return s

    # ── Report ───────────────────────────────────────────────────────
    def report(self) -> str:
        s = self.snapshot()
        lines = [
            "╔══════════════════════════════════════════════════════╗",
            "║           MD90 PERFORMANCE STATISTICS               ║",
            "╠══════════════════════════════════════════════════════╣",
            f"║  Total Trades    : {s.total_trades:<34}║",
            f"║  Win Rate        : {s.win_rate:.1f}% ({s.winning}W / {s.losing}L){'':<20}║",
            f"║  Total PnL       : ${s.total_pnl:+,.2f}{'':<28}║",
            "╠══════════════════════════════════════════════════════╣",
            f"║  Profit Factor   : {s.profit_factor:.3f}{'':<31}║",
            f"║  Recovery Factor : {s.recovery_factor:.3f}{'':<31}║",
            f"║  Sharpe Ratio    : {s.sharpe_ratio:.3f}{'':<31}║",
            f"║  Sortino Ratio   : {s.sortino_ratio:.3f}{'':<31}║",
            f"║  Expectancy      : ${s.expectancy:+,.2f}/trade{'':<24}║",
            f"║  Avg RR          : {s.avg_rr:.2f}x{'':<31}║",
            "╠══════════════════════════════════════════════════════╣",
            f"║  Avg Win         : ${s.avg_win:+,.2f}{'':<29}║",
            f"║  Avg Loss        : ${s.avg_loss:+,.2f}{'':<29}║",
            f"║  Largest Win     : ${s.largest_win:+,.2f}{'':<29}║",
            f"║  Largest Loss    : ${s.largest_loss:+,.2f}{'':<29}║",
            f"║  Max Drawdown    : {s.max_drawdown_pct:.2f}% (${s.max_drawdown_val:,.2f}){'':<17}║",
            "╠══════════════════════════════════════════════════════╣",
            f"║  Consecutive W   : {s.consecutive_wins:<34}║",
            f"║  Consecutive L   : {s.consecutive_losses:<34}║",
            f"║  Best Regime     : {s.best_regime:<34}║",
            f"║  Best Session    : {s.best_session:<34}║",
            "╚══════════════════════════════════════════════════════╝",
        ]
        return "\n".join(lines)

    # ── Persistence ──────────────────────────────────────────────────
    def _save(self):
        try:
            data = {
                "results":  [asdict(r) for r in self._results[-500:]],  # last 500
                "equity_curve": self._equity_curve[-500:],
                "peak_equity":  self._peak_equity,
                "max_dd_val":   self._max_dd_val,
                "max_dd_pct":   self._max_dd_pct,
                "consec_wins":  self._consec_wins,
                "consec_losses":self._consec_losses,
            }
            with open(self.save_path, "w") as f:
                json.dump(data, f, indent=2)
        except Exception:
            pass

    def _load(self):
        try:
            if not os.path.exists(self.save_path):
                return
            with open(self.save_path) as f:
                data = json.load(f)
            self._results       = [TradeResult(**r) for r in data.get("results", [])]
            self._equity_curve  = data.get("equity_curve", [])
            self._peak_equity   = data.get("peak_equity", 0.0)
            self._max_dd_val    = data.get("max_dd_val", 0.0)
            self._max_dd_pct    = data.get("max_dd_pct", 0.0)
            self._consec_wins   = data.get("consec_wins", 0)
            self._consec_losses = data.get("consec_losses", 0)
        except Exception:
            pass
