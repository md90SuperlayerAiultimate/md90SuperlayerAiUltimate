"""polymarket/L5_distribution/telegram_alerts.py — Telegram notifications."""
import os, requests, logging
log = logging.getLogger(__name__)


def send_alert(message:str, parse_mode:str="Markdown") -> bool:
    token   = os.getenv("TELEGRAM_TOKEN","")
    chat_id = os.getenv("TELEGRAM_CHAT_ID","")
    if not token or not chat_id: return False
    try:
        r = requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            json={"chat_id":chat_id,"text":message,"parse_mode":parse_mode},
            timeout=10)
        return r.status_code == 200
    except Exception as e:
        log.error(f"Telegram: {e}"); return False
