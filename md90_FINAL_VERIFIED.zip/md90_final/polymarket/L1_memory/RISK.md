# RISK.md — Max position $20 | Max exposure $60 | Kelly 0.25 | Daily limit $5
