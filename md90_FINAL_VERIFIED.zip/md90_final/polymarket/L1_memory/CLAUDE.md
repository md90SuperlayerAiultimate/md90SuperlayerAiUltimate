# CLAUDE.md — MD90 Polymarket Bot Rules
## Core: Only trade vol>$5K, edge>6%, max 3 positions, Kelly 0.25x, max $20/market
## Stop: daily_loss>$5 → 24h halt | drawdown>15% → liquidate all
## APIs: Gamma(public) + CLOB V2(auth) + Data(public)
