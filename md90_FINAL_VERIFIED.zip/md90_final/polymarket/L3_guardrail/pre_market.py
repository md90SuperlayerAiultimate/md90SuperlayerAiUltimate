"""polymarket/L3_guardrail/pre_market.py — Pre-market connection check."""
import logging
log = logging.getLogger(__name__)

def run_premarket_check() -> bool:
    from polymarket.core.polymarket_client import PolyClient
    c = PolyClient()
    ok = c.test_connection()
    if ok:
        bal = c.get_balance()
        log.info(f"Pre-market: connected | balance={bal}")
    else:
        log.error("Pre-market: connection FAILED")
    return ok
