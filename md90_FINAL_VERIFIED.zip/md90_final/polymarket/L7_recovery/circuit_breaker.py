"""polymarket/L7_recovery/circuit_breaker.py — Multi-level circuit breaker."""
import os, logging
from datetime import datetime, timedelta, timezone
log = logging.getLogger(__name__)
DAILY_LIMIT = float(os.getenv("POLYMARKET_DAILY_LOSS_LIMIT","5.0"))


class CircuitBreaker:
    def __init__(self):
        self.trades_today  = []
        self.today         = datetime.now(timezone.utc).date()
        self.breach_count  = 0
        self.paused_until  = None
        self.consec_losses = 0
        self.reason        = ""

    def record_trade(self, pnl:float):
        today = datetime.now(timezone.utc).date()
        if today != self.today:
            self.trades_today = []
            self.today        = today
        self.trades_today.append(pnl)
        if pnl < 0:
            self.consec_losses += 1
        else:
            self.consec_losses = 0

    def is_triggered(self) -> bool:
        now = datetime.now(timezone.utc)
        if self.paused_until and now < self.paused_until:
            self.reason = f"Paused until {self.paused_until.strftime('%H:%M UTC')}"
            return True

        daily_pnl = sum(self.trades_today)
        if daily_pnl < -DAILY_LIMIT:
            self.breach_count += 1
            hours = min(24 * (2 ** (self.breach_count - 1)), 168)
            self.paused_until = now + timedelta(hours=hours)
            self.reason = f"Daily loss ${abs(daily_pnl):.2f} > ${DAILY_LIMIT}"
            log.warning(f"CIRCUIT BREAKER: {self.reason} — paused {hours}h")
            return True

        if self.consec_losses >= 3:
            self.paused_until = now + timedelta(hours=2)
            self.reason = "3 consecutive losses"
            log.warning(f"CIRCUIT BREAKER: {self.reason}")
            return True

        return False

    def is_breached(self) -> bool:
        return self.is_triggered()
