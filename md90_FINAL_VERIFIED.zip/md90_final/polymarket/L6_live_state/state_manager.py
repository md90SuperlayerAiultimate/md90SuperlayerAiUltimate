"""polymarket/L6_live_state/state_manager.py — Persistent live state."""
import json, os, logging
from datetime import datetime, timezone

log = logging.getLogger(__name__)
STATE_FILE = os.getenv("POLYMARKET_STATE_FILE", "data/polymarket_state.json")


class PolyStateManager:
    def __init__(self):
        os.makedirs(os.path.dirname(STATE_FILE) if os.path.dirname(STATE_FILE) else ".", exist_ok=True)
        self.state = self._load()

    def _load(self) -> dict:
        if os.path.exists(STATE_FILE):
            try:
                with open(STATE_FILE) as f:
                    return json.load(f)
            except Exception:
                pass
        return {"positions": [], "equity": 0.0, "snapshots": [],
                "trades_today": [], "last_updated": None}

    def save(self):
        self.state["last_updated"] = datetime.now(timezone.utc).isoformat()
        try:
            with open(STATE_FILE, "w") as f:
                json.dump(self.state, f, indent=2, default=str)
        except Exception as e:
            log.error(f"State save: {e}")

    def update_equity(self, eq: float):
        self.state["equity"] = round(float(eq), 4)
        self.state.setdefault("snapshots", []).append({
            "time": datetime.now(timezone.utc).isoformat(),
            "equity": round(float(eq), 4),
        })
        if len(self.state["snapshots"]) > 500:
            self.state["snapshots"] = self.state["snapshots"][-500:]
        self.save()

    def update_positions(self, positions: list):
        # Ensure positions are JSON-serializable dicts
        safe = []
        for p in positions:
            if isinstance(p, dict):
                safe.append(p)
            else:
                try:
                    safe.append(dict(p))
                except Exception:
                    safe.append({"raw": str(p)})
        self.state["positions"] = safe
        self.save()

    def record_trade(self, pnl: float, market_id: str, action: str):
        self.state.setdefault("trades_today", []).append({
            "pnl": round(float(pnl), 4), "market": str(market_id)[:40],
            "action": action,
            "time": datetime.now(timezone.utc).isoformat(),
        })
        self.save()

    def get_pnl_today(self) -> float:
        today = datetime.now(timezone.utc).date().isoformat()
        return round(sum(
            t.get("pnl", 0) for t in self.state.get("trades_today", [])
            if str(t.get("time", "")).startswith(today)
        ), 4)
