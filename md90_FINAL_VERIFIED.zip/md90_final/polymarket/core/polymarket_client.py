"""
polymarket/core/polymarket_client.py
MD90 — Polymarket CLOB V2 Client (VERIFIED against official docs)

CRITICAL: Uses py-clob-client-v2 — V1 is dead since April 28, 2026.
  Docs: https://docs.polymarket.com/developers/CLOB/introduction
  Auth: L1 (EIP-712 private key) → derive L2 (HMAC API creds)
  Method: create_or_derive_api_key() [NOT create_api_key()]
"""
import os, logging
from dotenv import load_dotenv
load_dotenv()
log = logging.getLogger(__name__)


class PolyClient:
    """
    Polymarket CLOB V2 Client.
    L1: EIP-712 signature (private key) - derive credentials
    L2: HMAC-SHA256 (api_key, secret, passphrase) - trading
    """

    def __init__(self):
        self.host          = os.getenv("POLYMARKET_CLOB_HOST",  "https://clob.polymarket.com")
        self.chain_id      = int(os.getenv("POLYMARKET_CHAIN_ID", "137"))
        self.private_key   = os.getenv("POLYMARKET_PRIVATE_KEY", "")
        self.funder        = os.getenv("POLYMARKET_FUNDER",      "")
        self.sig_type      = int(os.getenv("POLYMARKET_SIGNATURE_TYPE", "1"))
        self._creds        = None
        self._client       = None
        if not self.private_key:
            log.warning("POLYMARKET_PRIVATE_KEY not set — read-only mode")

    def _get_creds(self):
        if self._creds: return self._creds
        try:
            from py_clob_client_v2 import ClobClient, ApiCreds
            temp = ClobClient(host=self.host, chain_id=self.chain_id, key=self.private_key)
            # Verified method from official docs (NOT create_api_key)
            d = temp.create_or_derive_api_key()
            self._creds = ApiCreds(
                api_key       = d.get("apiKey", d.get("key", "")),
                api_secret    = d.get("secret",     ""),
                api_passphrase= d.get("passphrase", ""),
            )
            log.info("API credentials derived successfully")
        except ImportError:
            log.warning("py-clob-client-v2 not installed — install: pip install py-clob-client-v2")
            self._creds = None
        except Exception as e:
            log.error(f"Credential derivation failed: {e}")
            self._creds = None
        return self._creds

    def get_client(self):
        if self._client: return self._client
        creds = self._get_creds()
        if not creds:
            return None
        try:
            from py_clob_client_v2 import ClobClient
            self._client = ClobClient(
                host          = self.host,
                chain_id      = self.chain_id,
                key           = self.private_key,
                creds         = creds,
                signature_type= self.sig_type,
                funder        = self.funder or None,
            )
        except Exception as e:
            log.error(f"Client init failed: {e}")
        return self._client

    def get_balance(self) -> dict:
        c = self.get_client()
        if not c: return {"balance": 0.0}
        try:
            return c.get_balance()
        except Exception as e:
            log.error(f"get_balance: {e}"); return {"balance": 0.0}

    def get_positions(self) -> list:
        c = self.get_client()
        if not c: return []
        try:
            return c.get_positions() or []
        except Exception as e:
            log.error(f"get_positions: {e}"); return []

    def place_limit_order(self, token_id: str, price: float,
                          size: int, side: str) -> dict:
        c = self.get_client()
        if not c: return {"error": "No client"}
        try:
            from py_clob_client_v2 import OrderArgs, OrderType, PartialCreateOrderOptions
            from py_clob_client_v2.order_builder.constants import BUY, SELL
            side_const = BUY if side.upper() == "BUY" else SELL
            resp = c.create_and_post_order(
                order_args=OrderArgs(token_id=token_id, side=side_const,
                                     price=price, size=size),
                options=PartialCreateOrderOptions(tick_size="0.01"),
                order_type=OrderType.GTC,
            )
            log.info(f"Order placed: {side} {size} @ {price}")
            return resp
        except Exception as e:
            log.error(f"place_limit_order: {e}"); return {"error": str(e)}

    def cancel_all_orders(self) -> dict:
        c = self.get_client()
        if not c: return {"error": "No client"}
        try:
            return c.cancel_all()
        except Exception as e:
            return {"error": str(e)}

    def test_connection(self) -> bool:
        try:
            c = self.get_client()
            if not c: return False
            c.get_balance()
            log.info("Polymarket connection OK")
            return True
        except Exception as e:
            log.error(f"Connection test failed: {e}"); return False
