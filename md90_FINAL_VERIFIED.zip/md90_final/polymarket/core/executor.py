"""
polymarket/core/executor.py — CLOB V2 Order Executor (final sync)
Wraps PolyClient for order placement and position management.
"""
import logging
from polymarket.core.polymarket_client import PolyClient

log = logging.getLogger(__name__)


class Executor:
    def __init__(self):
        self.client = PolyClient()

    def execute_signal(self, market: dict, decision: dict,
                        token_ids: dict) -> dict:
        """
        Execute a strategy decision on Polymarket CLOB V2.
        decision keys: action (BUY_YES|BUY_NO|SKIP), sizing.position_usdc,
                       market_prob, edge
        token_ids:    {"yes": token_id_str, "no": token_id_str}
        """
        action = decision.get("action", "SKIP")
        if action not in ("BUY_YES", "BUY_NO"):
            return {"status": "SKIPPED", "reason": decision.get("reason", action)}

        sizing = decision.get("sizing", {})
        amount = float(sizing.get("position_usdc", 0))
        if amount <= 0:
            return {"status": "SKIPPED", "reason": "Size zero"}

        mprob = float(decision.get("market_prob", 0.5))

        if action == "BUY_YES":
            token = token_ids.get("yes", "")
            price = max(0.01, min(0.99, mprob))
        else:
            token = token_ids.get("no", "")
            price = max(0.01, min(0.99, 1.0 - mprob))

        if not token:
            return {"status": "SKIPPED", "reason": "No token_id"}

        size = int(amount / price) if price > 0 else 0
        if size < 1:
            return {"status": "SKIPPED", "reason": "size_tokens < 1"}

        result = self.client.place_limit_order(
            token_id=token, price=price, size=size, side="BUY")

        if isinstance(result, dict) and "error" in result:
            log.error(f"Order failed: {result['error']}")
            return {"status": "FAILED", "error": result["error"]}

        log.info(f"ORDER: {action} {size}tok @ {price:.4f} amt=${amount:.2f}")
        return {
            "status":      "EXECUTED",
            "action":      action,
            "token_id":    (token[:12] + "...") if len(token) > 12 else token,
            "size":        size,
            "price":       price,
            "amount_usdc": amount,
            "edge":        decision.get("edge", 0),
        }

    def close_all(self) -> dict:
        """Cancel all open orders — circuit breaker response."""
        try:
            self.client.cancel_all_orders()
            return {"status": "CLOSED", "reason": "Circuit breaker"}
        except Exception as e:
            log.error(f"close_all error: {e}")
            return {"status": "ERROR", "error": str(e)}

    def get_positions(self) -> list:
        """Wrapper for PolyClient.get_positions()."""
        try:
            return self.client.get_positions() or []
        except Exception as e:
            log.warning(f"get_positions: {e}")
            return []
