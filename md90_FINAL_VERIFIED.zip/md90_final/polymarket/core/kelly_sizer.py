"""
polymarket/core/kelly_sizer.py
Kelly Criterion — f* = (bp - q) / b
  b = net odds (decimal_odds - 1)
  p = win probability
  q = 1 - p
Reference: Kelly, J.L. (1956) "A New Interpretation of Information Rate"
Fractional Kelly: 0.25x reduces volatility, retains growth (professional standard)
"""
import os, logging
log = logging.getLogger(__name__)


def kelly_criterion(win_prob:float, net_odds:float) -> float:
    if net_odds <= 0: return 0.0
    q = 1.0 - win_prob
    return max(0.0, min(1.0, (win_prob * net_odds - q) / net_odds))


def fractional_kelly(win_prob:float, odds_decimal:float,
                     fraction:float=None, max_risk:float=0.20) -> dict:
    if fraction is None:
        fraction = float(os.getenv("POLYMARKET_KELLY_FRACTION","0.25"))
    b = odds_decimal - 1.0
    if b <= 0:
        return {"optimal_fraction":0.0,"position_usdc":0.0,"edge":0.0,
                "full_kelly":0.0,"reason":"No edge — odds too low"}
    full_k    = kelly_criterion(win_prob, b)
    optimal_f = min(full_k * fraction, max_risk)
    edge      = (win_prob * b) - (1.0 - win_prob)
    return {
        "optimal_fraction": round(optimal_f, 4),
        "position_usdc":    0.0,
        "full_kelly":       round(full_k, 4),
        "edge":             round(edge, 4),
        "reason": ("Strong edge" if edge>0.10 else "Moderate edge" if edge>0.05
                   else "Weak edge" if edge>0 else "No edge — skip"),
    }


def bet_size_usdc(equity:float, win_prob:float, odds_decimal:float) -> dict:
    result = fractional_kelly(win_prob, odds_decimal)
    result["position_usdc"] = round(equity * result["optimal_fraction"], 2)
    max_exp = float(os.getenv("POLYMARKET_MAX_EXPOSURE","20.0"))
    if result["position_usdc"] > max_exp:
        result["position_usdc"] = max_exp
        result["note"] = f"Capped at max_exposure ${max_exp}"
    return result
