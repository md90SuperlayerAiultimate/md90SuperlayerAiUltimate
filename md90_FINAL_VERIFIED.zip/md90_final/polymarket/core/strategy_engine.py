"""
polymarket/core/strategy_engine.py
Evaluates mispricing signals + Bayesian prior + MD90 boost → Kelly sizing.
Always returns market_prob in result dict (fixes executor KeyError).
"""
import os, logging
from typing import Optional
from polymarket.core.kelly_sizer import bet_size_usdc

log = logging.getLogger(__name__)


class StrategyEngine:
    def __init__(self):
        self.max_pos = int(os.getenv("POLYMARKET_MAX_POSITIONS","3"))
        self.max_exp = float(os.getenv("POLYMARKET_MAX_EXPOSURE","20.0"))

    def evaluate_mispricing(self, market: dict, scanner_mispricing: dict,
                             equity: float, bayesian_prior: Optional[float]=None,
                             md90_signal=None) -> dict:
        edge       = scanner_mispricing.get("edge", 0)
        signal     = scanner_mispricing.get("signal")
        mprob      = float(scanner_mispricing.get("market_prob", 0.5))

        # Bayesian adjustment
        adj_edge = edge * 0.7 + (bayesian_prior - 0.5) * 0.3 if bayesian_prior else edge

        # MD90 signal boost (+2% if same direction)
        if md90_signal is not None:
            md90_dir = md90_signal.direction
            if ((signal == "BUY_YES" and md90_dir == 1) or
                    (signal == "BUY_NO"  and md90_dir == -1)):
                adj_edge += 0.02

        base_result = {"market_prob": mprob, "edge": round(adj_edge, 4)}

        if abs(adj_edge) < 0.06:
            return {**base_result, "action": "SKIP",
                    "reason": f"Edge {adj_edge:.4f} < 0.06"}

        if signal not in ("BUY_YES", "BUY_NO"):
            return {**base_result, "action": "SKIP", "reason": "No clear signal"}

        if signal == "BUY_YES":
            odds_decimal = 1.0 / mprob if mprob > 0 else 1.0
            win_prob     = min(0.95, 0.5 + abs(adj_edge))
        else:
            odds_decimal = 1.0 / (1.0 - mprob) if mprob < 1.0 else 1.0
            win_prob     = min(0.95, 0.5 + abs(adj_edge))

        sizing = bet_size_usdc(equity, win_prob, odds_decimal)

        if sizing.get("position_usdc", 0) <= 0 or sizing.get("edge", 0) <= 0:
            return {**base_result, "action": "SKIP",
                    "reason": "Kelly→0", "sizing": sizing}

        return {
            **base_result,
            "action":       signal,
            "odds_decimal": round(odds_decimal, 4),
            "win_prob":     round(win_prob, 4),
            "sizing":       sizing,
            "reason":       sizing.get("reason", ""),
        }
