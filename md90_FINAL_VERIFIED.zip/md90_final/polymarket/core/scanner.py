"""
polymarket/core/scanner.py
Gamma API Scanner — public, no auth needed.
Base: https://gamma-api.polymarket.com
Docs: https://docs.polymarket.com/developers/gamma-markets-api/get-markets

VERIFIED: clobTokenIds[0]=YES, clobTokenIds[1]=NO
"""
import os, json, logging
from typing import List, Dict, Optional
import aiohttp

log = logging.getLogger(__name__)
GAMMA_HOST = os.getenv("POLYMARKET_GAMMA_HOST", "https://gamma-api.polymarket.com")


class MarketScanner:

    async def fetch_markets(self, limit:int=50, active:bool=True,
                             closed:bool=False, tag:str=None,
                             min_volume:float=5000.0) -> List[Dict]:
        params = {"active":str(active).lower(),"closed":str(closed).lower(),"limit":limit}
        if tag: params["tags"] = tag
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get(f"{GAMMA_HOST}/markets", params=params, timeout=15) as r:
                    if r.status != 200:
                        log.error(f"Gamma API {r.status}"); return []
                    markets = await r.json(content_type=None)
                    if not isinstance(markets, list): markets = []
                    filtered = [m for m in markets
                                if float(m.get("volume",0) or m.get("volume24hr",0) or 0) >= min_volume]
                    log.info(f"Scanner: {len(filtered)} markets (vol>=${min_volume:.0f})")
                    return filtered
        except Exception as e:
            log.error(f"Scanner error: {e}"); return []

    async def fetch_market_by_id(self, market_id:str) -> Optional[Dict]:
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get(f"{GAMMA_HOST}/markets/{market_id}", timeout=10) as r:
                    return await r.json(content_type=None) if r.status==200 else None
        except: return None

    async def search_markets(self, query:str, limit:int=20) -> List[Dict]:
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get(f"{GAMMA_HOST}/public-search",
                                  params={"query":query,"limit_per_type":limit},
                                  timeout=10) as r:
                    if r.status==200:
                        d = await r.json(content_type=None)
                        return d.get("markets",[]) if isinstance(d,dict) else []
        except: pass
        return []

    @staticmethod
    def get_token_ids(market:Dict) -> tuple:
        """Returns (yes_token_id, no_token_id). clobTokenIds[0]=YES, [1]=NO (verified)."""
        ids = market.get("clobTokenIds", [])
        if isinstance(ids, str):
            try: ids = json.loads(ids)
            except: return (None, None)
        return (ids[0], ids[1]) if len(ids) >= 2 else (None, None)

    @staticmethod
    def find_mispricing(market:Dict, our_probability:float) -> dict:
        """
        Detect edge: our probability vs market implied.
        Edge > 6% = tradeable signal.
        Market probability from outcome price (YES token price).
        """
        outcomes = market.get("outcomes", [])
        if isinstance(outcomes, str):
            try: outcomes = json.loads(outcomes)
            except: outcomes = []

        market_price = 0.5
        if outcomes and isinstance(outcomes, list) and len(outcomes) > 0:
            first = outcomes[0]
            if isinstance(first, dict):
                market_price = float(first.get("price", 0.5) or 0.5)
            else:
                market_price = float(first) if first else 0.5

        edge = our_probability - market_price
        signal = None
        if edge > 0.06:   signal = "BUY_YES"
        elif edge < -0.06: signal = "BUY_NO"

        return {
            "edge":        round(edge, 4),
            "market_prob": market_price,
            "our_prob":    our_probability,
            "signal":      signal,
        }
