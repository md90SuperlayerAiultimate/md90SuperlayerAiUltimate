"""
polymarket/bot.py — MD90 Polymarket Bot (FINAL SYNCHRONIZED v4)

Pipeline:
  DataProvider (ccxt)
    → MD90 17-Layer Signal (exact MQL5 port)
    → HMM 6-state Regime (hmmlearn)
    → MiroFish NetworkX Graph
    → Ollama Agent (primary) / Claude API (fallback)
    → 8-stage Cognitive Pipeline
    → Polymarket CLOB V2 Execution
    → SelfLearner (autonomous learning after every trade)
    → GitHub push every 24h
"""
import asyncio
import os
import logging
import time
import pandas as pd
from datetime import datetime, timezone, timedelta
from typing import Optional

log = logging.getLogger("md90.polymarket")
WITA     = timezone(timedelta(hours=8))
INTERVAL = int(os.getenv("LOOP_SEC", "900"))   # 15 min default


async def main_loop(cfg: dict):
    # ── CANONICAL IMPORTS ──────────────────────────────────────────
    from data_provider                            import DataProvider
    from md90_brain.marketmind.graph              import get_signal
    from md90_brain.session_manager               import SessionManager

    from polymarket.core.scanner                  import MarketScanner
    from polymarket.core.polymarket_client        import PolyClient
    from polymarket.core.strategy_engine          import StrategyEngine
    from polymarket.core.executor                 import Executor
    from polymarket.core.kelly_sizer              import bet_size_usdc

    from polymarket.L3_guardrail.pre_market       import run_premarket_check
    from polymarket.L5_distribution.telegram_alerts import send_alert
    from polymarket.L6_live_state.state_manager   import PolyStateManager
    from polymarket.L7_recovery.circuit_breaker   import CircuitBreaker
    from polymarket.L8_learning.bayesian_updater  import BayesianUpdater

    # Canonical single-source modules (post-dedup)
    from hmm.regime_engine                        import HMMRegimeEngine
    from network.mirofish_graph                   import MiroFishGraph
    from modules.local_agent                      import LocalMD90Agent
    from modules.risk_manager                     import RiskManager
    from modules.journal                          import TradingJournal
    from modules.cognitive_pipeline               import CognitivePipeline
    from ml.self_learner                          import SelfLearner, TradeRecord
    from ml.github_sync                           import push_model, pull_latest
    from research.research_agent                  import get_market_context

    log.info("=" * 60)
    log.info("  MD90 POLYMARKET BOT — FINAL v4")
    log.info(f"  {datetime.now(WITA).strftime('%Y-%m-%d %H:%M WITA')}")
    log.info(f"  Mode: {'DRY-RUN' if cfg.get('dry_run') else '⚠️ LIVE'}")
    log.info("=" * 60)

    # L3: Pull latest model from GitHub before starting
    pull_latest()

    # L3: Pre-market check
    if not run_premarket_check():
        log.error("Pre-market check FAILED — check credentials")
        send_alert("❌ MD90: pre-market check FAILED")
        if not cfg.get("dry_run"):
            return

    # ── INIT ALL COMPONENTS ────────────────────────────────────────
    dp        = DataProvider(cfg["exchange"], cfg.get("api_key",""), cfg.get("api_secret",""))
    scanner   = MarketScanner()
    strategy  = StrategyEngine()
    executor  = Executor()
    state_mgr = PolyStateManager()
    cb        = CircuitBreaker()
    bayesian  = BayesianUpdater()
    sess_mgr  = SessionManager()

    hmm       = HMMRegimeEngine(n_components=6)
    mirofish  = MiroFishGraph()
    agent     = LocalMD90Agent()
    risk_mgr  = RiskManager(start_balance=cfg.get("start_equity", 2000.0))
    journal   = TradingJournal()
    cognition = CognitivePipeline(cfg)
    learner   = SelfLearner()       # ← autonomous self-learning

    send_alert(
        f"🚀 *MD90 Bot started*\n"
        f"Mode: `{'DRY-RUN' if cfg.get('dry_run') else 'LIVE'}`\n"
        f"Equity: `${cfg.get('start_equity', 2000):.2f}`\n"
        f"Trades in memory: `{learner._trade_count}`"
    )

    hmm_fitted    = False
    cycle_num     = 0
    last_gh_push  = time.time()
    GH_PUSH_EVERY = 86400   # 24h in seconds
    open_positions: dict = {}  # condition_id → trade info

    while True:
        cycle_num += 1
        now_utc  = datetime.now(timezone.utc)
        now_wita = datetime.now(WITA)

        try:
            symbol = cfg.get("symbol", "BTC/USDT")

            # ── FETCH OHLCV ─────────────────────────────────────
            md = await dp.fetch(symbol, cfg.get("timeframe", "15m"))
            if md is None:
                log.warning("No market data — skip cycle")
                await asyncio.sleep(60); continue

            # ── HMM FIT (once on first run) ──────────────────
            if not hmm_fitted and len(md.closes) >= 100:
                hist_df = pd.DataFrame({
                    "close":  md.closes, "high":   md.highs,
                    "low":    md.lows,   "volume": md.volumes,
                })
                hmm.train_or_load(hist_df)
                hmm_fitted = True
                log.info("HMM fitted on startup data")

            # HMM predict current regime
            hmm_df = pd.DataFrame({
                "close":  md.closes, "high":   md.highs,
                "low":    md.lows,   "volume": md.volumes,
            })
            regime_id, hmm_prob = hmm.predict(hmm_df)
            hmm_info = hmm.get_info()

            # ── CIRCUIT BREAKER ──────────────────────────────
            if cb.is_triggered():
                log.warning(f"CIRCUIT BREAKER: {cb.reason}")
                await asyncio.sleep(300); continue

            # ── RISK GATE ────────────────────────────────────
            risk_stats = risk_mgr.get_stats()
            tradeable, block_reason = risk_mgr.can_trade()
            if not tradeable:
                log.warning(f"RISK GATE: {block_reason}")
                await asyncio.sleep(INTERVAL); continue

            # ── FLATTEN ON CHAOTIC ───────────────────────────
            if hmm.is_chaotic():
                log.warning("CHAOTIC regime — FLATTEN all")
                executor.close_all()
                send_alert("⚡ MD90: CHAOTIC — positions flattened")
                await asyncio.sleep(INTERVAL); continue

            # ── MD90 17-LAYER SIGNAL ─────────────────────────
            fusion = get_signal(md)

            # ── SESSION ──────────────────────────────────────
            session = sess_mgr.detect(now_utc)

            # Get optimized thresholds from learner
            thresholds = learner.get_thresholds()
            regime_weights = learner.get_weights(hmm_info.get("regime",""))

            # ── MIROFISH GRAPH ───────────────────────────────
            clusters   = mirofish.detect_clusters()
            net_score  = mirofish.network_score()

            # ── SCAN POLYMARKET ──────────────────────────────
            markets = await scanner.fetch_markets(
                limit=50, active=True,
                min_volume=cfg.get("poly_min_volume", 5000))

            if not markets:
                log.info(f"Cycle {cycle_num}: No qualifying markets")
                await asyncio.sleep(INTERVAL); continue

            log.info(
                f"[{now_wita.strftime('%H:%M WITA')}] #{cycle_num} | "
                f"MD90={fusion.execution_status}({fusion.fusion_score:.3f}) | "
                f"HMM={hmm_info['regime']}(p={hmm_info['persistence']}) | "
                f"Mkts={len(markets)} | DD={risk_stats['drawdown']:.1f}%"
            )

            # ── EVALUATE EACH MARKET ─────────────────────────
            for market in markets[:8]:
                mkt_id   = str(market.get("id") or market.get("conditionId",""))
                question = market.get("question","")

                # L8: Bayesian prior for this market
                bayes_prior = bayesian.get_probability(mkt_id)

                # Mispricing detection
                mispricing = scanner.find_mispricing(market, bayes_prior)
                edge       = mispricing.get("edge", 0)

                # Strategy eval (with MD90 boost)
                decision = strategy.evaluate_mispricing(
                    market=market,
                    scanner_mispricing=mispricing,
                    equity=risk_stats["balance"],
                    bayesian_prior=bayes_prior,
                    md90_signal=fusion,
                )
                if decision["action"] == "SKIP":
                    continue

                kelly_size = decision.get("sizing",{}).get("position_usdc", 0)

                # ── AGENT DECISION ────────────────────────────
                research_ctx = get_market_context(symbol)
                agent_ctx = {
                    "regime":        hmm_info["regime"],
                    "persistence":   hmm_info["persistence"],
                    "clusters":      clusters,
                    "network_score": net_score,
                    "bayesian_prior":bayes_prior,
                    "fusion_score":  fusion.fusion_score,
                    "fusion_status": fusion.execution_status,
                    "confidence":    fusion.confidence,
                    "gate1":         fusion.gate1_passed,
                    "gate2":         fusion.gate2_passed,
                    "gate3":         fusion.gate3_passed,
                    "hmm_prob":      hmm_prob,
                    "drawdown":      risk_stats["drawdown"],
                    "question":      question,
                    "market_prob":   mispricing.get("market_prob", 0.5),
                    "edge":          edge,
                    "edge_pct":      edge * 100,
                    "news":          research_ctx.get("news",""),
                }
                agent_decision = agent.decide(agent_ctx)

                # ── EXECUTE GATE ──────────────────────────────
                min_conf  = thresholds.get("confidence_min",    cfg.get("confidence_min", 78.0))
                min_pers  = thresholds.get("min_persistence",   cfg.get("min_persistence", 7))
                min_fs    = thresholds.get("fusion_score_min",  cfg.get("fusion_score_min", 0.55))

                can_execute = (
                    agent_decision.get("action") == "EXECUTE" and
                    agent_decision.get("confidence", 0) >= min_conf and
                    hmm_info["persistence"] >= min_pers and
                    fusion.fusion_score >= min_fs and
                    fusion.execution_status in ("ALL-IN", "WAITING") and
                    len(open_positions) < cfg.get("max_positions", 3)
                )

                if not can_execute:
                    log.debug(
                        f"SKIP {question[:40]} | "
                        f"agent={agent_decision.get('action')} "
                        f"conf={agent_decision.get('confidence',0):.0f}% "
                        f"pers={hmm_info['persistence']}"
                    )
                    continue

                # ── FILL ORDER ────────────────────────────────
                token_ids = scanner.get_token_ids(market)
                if not token_ids[0]:
                    log.warning("No token IDs — skip")
                    continue

                result = executor.execute_signal(
                    market=market,
                    decision=decision,
                    token_ids={"yes": token_ids[0], "no": token_ids[1]},
                )

                if result.get("status") != "EXECUTED":
                    log.warning(f"Order not filled: {result}")
                    continue

                # ── COGNITIVE PIPELINE ────────────────────────
                _ = cognition.run_full(
                    symbol=symbol, market_data=md,
                    fusion_result=fusion, hmm_info=hmm_info,
                    session=session.name,
                    network_state={"clusters": len(clusters), "score": net_score},
                    bayesian_prior=bayes_prior, edge=edge,
                    kelly_size=kelly_size, agent_decision=agent_decision,
                    order_result=result, bayesian_updater=bayesian,
                    market_id=mkt_id,
                )

                # Record open position
                open_positions[mkt_id] = {
                    "question":   question[:60],
                    "side":       "YES" if decision["action"] == "BUY_YES" else "NO",
                    "size_usd":   kelly_size,
                    "entry_price":decision.get("market_prob", 0.5),
                    "our_prob":   bayes_prior,
                    "edge":       edge,
                    "open_time":  now_utc.isoformat(),
                    "regime":     hmm_info["regime"],
                    "session":    session.name,
                    "layers":     [ls.direction for ls in fusion.layer_signals],
                    "confidence": fusion.confidence,
                    "fusion_score": fusion.fusion_score,
                }

                # Journal + risk tracking
                journal.log_trade(
                    decision=agent_decision, regime_info=hmm_info,
                    market=question[:60], edge=edge,
                    kelly_size=kelly_size, session=session.name,
                )
                mirofish.save()

                log.info(
                    f"✅ EXECUTED | {decision['action']} ${kelly_size:.2f} "
                    f"edge={edge:.4f} conf={agent_decision.get('confidence')}%"
                )
                send_alert(
                    f"📊 *Trade Executed*\n"
                    f"Action: `{decision['action']}`\n"
                    f"Edge: `{edge:.1%}`\n"
                    f"Size: `${kelly_size:.2f}`\n"
                    f"Agent: `{agent_decision.get('confidence')}%`\n"
                    f"HMM: `{hmm_info['regime']}` p={hmm_info['persistence']}\n"
                    f"Market: _{question[:60]}_"
                )

            # ── CHECK POSITION RESOLUTIONS ───────────────────
            closed_ids = []
            for cid, pos in open_positions.items():
                try:
                    mkt = await scanner.fetch_market_by_id(cid)
                    if mkt and mkt.get("closed"):
                        resolution = mkt.get("resolution","")
                        won = ((resolution == "YES" and pos["side"] == "YES") or
                               (resolution == "NO"  and pos["side"] == "NO"))
                        ep  = pos["entry_price"]
                        payoff = (1.0 - ep) / ep if ep > 0 else 1.0
                        pnl = pos["size_usd"] * payoff if won else -pos["size_usd"]

                        # SelfLearner — learns from this trade
                        record = TradeRecord(
                            layer_dirs   = pos.get("layers",[0]*17),
                            layer_strs   = [0.5]*17,
                            trade_dir    = 1 if pos["side"]=="YES" else -1,
                            pnl          = pnl,
                            fusion_score = pos.get("fusion_score", 0.5),
                            confidence   = pos.get("confidence", 50.0),
                            regime       = pos.get("regime","RANGING"),
                            session      = pos.get("session","OTHER"),
                        )
                        learner.learn(record)    # ← BOT BELAJAR SENDIRI

                        # Update Bayesian prior
                        bayesian.update(cid, won)

                        # Risk tracking
                        risk_mgr.update(pnl)
                        cb.record_trade(pnl)

                        closed_ids.append(cid)
                        log.info(
                            f"{'🏆' if won else '❌'} SETTLED {pos['side']} "
                            f"{resolution} pnl=${pnl:+.2f} "
                            f"equity=${risk_mgr.balance:.2f}"
                        )
                        send_alert(
                            f"{'🏆' if won else '❌'} *Trade Settled*\n"
                            f"Result: `{resolution}`\n"
                            f"PnL: `${pnl:+.2f}`\n"
                            f"Equity: `${risk_mgr.balance:.2f}`\n"
                            f"WR: `{learner._win_count/max(1,learner._trade_count)*100:.1f}%` "
                            f"({learner._trade_count} trades)"
                        )
                except Exception as e:
                    log.debug(f"Resolution check {cid[:12]}: {e}")

            for cid in closed_ids:
                open_positions.pop(cid, None)

            # ── STATE UPDATE ─────────────────────────────────
            state_mgr.update_equity(risk_mgr.balance)
            state_mgr.update_positions([
                {"id": cid, **pos} for cid, pos in open_positions.items()
            ])

            # ── GITHUB PUSH (every 24h) ───────────────────────
            now_ts = time.time()
            if now_ts - last_gh_push >= GH_PUSH_EVERY:
                stats = learner.get_stats()
                push_model(
                    f"Auto-update | WR={stats['win_rate']:.1f}% | "
                    f"n={stats['total_trades']} | "
                    f"PnL={stats['total_pnl']:+.2f}"
                )
                last_gh_push = now_ts

            # ── DAILY REPORT ──────────────────────────────────
            if now_utc.hour == 0 and now_utc.minute < (INTERVAL//60 + 1):
                stats = learner.get_stats()
                thlds = learner.get_thresholds()
                send_alert(
                    f"📅 *Daily Report*\n"
                    f"Equity: `${risk_mgr.balance:.2f}`\n"
                    f"PnL: `${risk_mgr.balance - risk_mgr.start:.2f}`\n"
                    f"DD: `{risk_mgr.drawdown_pct:.2f}%`\n"
                    f"Trades: `{stats['total_trades']}` | WR: `{stats['win_rate']:.1f}%`\n"
                    f"Regime: `{hmm_info['regime']}`\n"
                    f"fs_min: `{thlds['fusion_score_min']:.3f}` | "
                    f"conf_min: `{thlds['confidence_min']:.1f}`"
                )

        except KeyboardInterrupt:
            log.info("Bot stopped by user"); break
        except Exception as e:
            log.error(f"Loop error cycle {cycle_num}: {e}", exc_info=True)
            send_alert(f"⚠️ MD90 error cycle {cycle_num}: {str(e)[:80]}")
            await asyncio.sleep(30)

        await asyncio.sleep(INTERVAL)

    await dp.close()
    learner._save()
    log.info("MD90 Bot stopped cleanly")


if __name__ == "__main__":
    from config import CFG
    asyncio.run(main_loop(CFG))
