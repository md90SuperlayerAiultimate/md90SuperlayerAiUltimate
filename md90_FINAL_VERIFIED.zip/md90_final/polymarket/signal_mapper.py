"""
MD90 v4 — Polymarket Signal Mapper
Converts MD90 FusionSignal (BUY/SELL) → Polymarket YES/NO probability.

Core insight:
  MD90 says BUY BTC with 85% confidence
  → "Will BTC be ABOVE $X at time Y?" → YES with adjusted probability

The mapping accounts for:
  - Fusion score (0.55-1.0) → raw win probability
  - Time-to-resolution decay (longer = less certain)
  - Market type (directional, level, range)
  - Current market price (Polymarket YES token price = market's implied prob)
  - Our edge = our probability - market's implied probability
"""
from dataclasses import dataclass
from typing import Optional, Tuple
import math

from md90_brain.types import FusionSignal, SignalDirection

BUY  = int(SignalDirection.BUY)
SELL = int(SignalDirection.SELL)


@dataclass
class MappedSignal:
    """MD90 signal mapped to Polymarket YES/NO trade."""
    # Original signal
    direction:         int     # BUY or SELL
    fusion_score:      float
    confidence:        float
    execution_status:  str

    # Polymarket target
    market_question:   str
    condition_id:      str
    yes_token_id:      str
    no_token_id:       str

    # Trade decision
    side:             str    # "YES" or "NO"
    our_probability:  float  # our estimated win probability
    market_price:     float  # current YES token price (market's implied prob)
    edge:             float  # our_probability - market_price
    edge_pct:         float  # edge as % of market_price

    # Sizing
    kelly_size_usd:   float
    recommended_size: float
    min_rr:           float
    expected_payoff:  float

    # Validity
    is_valid:         bool
    reject_reason:    str = ""

    # Metadata
    market_end_date:  str = ""
    market_volume:    float = 0.0
    market_liquidity: float = 0.0


class SignalMapper:
    """
    Maps MD90 FusionSignal to Polymarket trade recommendations.

    Algorithm:
    1. Determine YES/NO side from signal direction
    2. Estimate our win probability from fusion_score + confidence
    3. Compute edge vs current market price
    4. Validate minimum edge threshold
    5. Calculate Kelly position size
    """

    # Thresholds
    MIN_EDGE           = 0.05   # Minimum 5% edge vs market price
    MIN_WIN_PROB       = 0.55   # Never bet below 55% win probability
    MIN_KELLY_FRACTION = 0.05   # Minimum fractional Kelly
    KELLY_CAP          = 0.25   # Max Kelly fraction (safety cap)

    def __init__(self, config: dict):
        self.cfg = config
        self.kelly_fraction = config.get("kelly_fraction", 0.25)
        self.max_size       = config.get("poly_max_size_usd", 500)
        self.min_size       = config.get("poly_min_size_usd", 10)
        self.capital        = config.get("start_equity", 2000)

    def map(self, signal: FusionSignal, market: dict) -> MappedSignal:
        """
        Map FusionSignal to a Polymarket trade recommendation.

        market dict keys:
          question, condition_id, yes_token_id, no_token_id,
          yes_price, no_price, volume, liquidity, spread,
          end_date, market_type
        """
        question   = market.get("question", "")
        yes_price  = float(market.get("yes_price", 0.5))
        cid        = market.get("condition_id", "")
        yes_tid    = market.get("yes_token_id", "")
        no_tid     = market.get("no_token_id", "")
        end_date   = market.get("end_date", "")
        volume     = float(market.get("volume", 0))
        liquidity  = float(market.get("liquidity", 0))

        # Determine trade side
        # BUY signal = expect price to go UP = bet YES on "will price be ABOVE X"
        # SELL signal = expect price to go DOWN = bet YES on "will price be BELOW X"
        # For generic crypto markets, BUY → YES, SELL → NO
        q_lower = question.lower()
        is_above_market = any(kw in q_lower for kw in
                              ["above", "higher", "reach", "hit", "exceed", "surpass"])
        is_below_market = any(kw in q_lower for kw in
                              ["below", "lower", "fall", "drop", "under"])

        if signal.direction == BUY:
            if is_above_market:
                side       = "YES"
                our_price  = yes_price    # we're buying YES
                payoff_mult = (1.0 - yes_price) / yes_price if yes_price > 0 else 0
            elif is_below_market:
                side       = "NO"        # price going UP → "below X" → NO
                our_price  = market.get("no_price", 1 - yes_price)
                payoff_mult = yes_price / (1 - yes_price) if yes_price < 1 else 0
            else:
                # Ambiguous: default BUY → YES
                side       = "YES"
                our_price  = yes_price
                payoff_mult = (1.0 - yes_price) / yes_price if yes_price > 0 else 0

        elif signal.direction == SELL:
            if is_below_market:
                side       = "YES"       # price going DOWN → "below X" → YES
                our_price  = yes_price
                payoff_mult = (1.0 - yes_price) / yes_price if yes_price > 0 else 0
            elif is_above_market:
                side       = "NO"
                our_price  = market.get("no_price", 1 - yes_price)
                payoff_mult = yes_price / (1 - yes_price) if yes_price < 1 else 0
            else:
                side       = "NO"
                our_price  = market.get("no_price", 1 - yes_price)
                payoff_mult = yes_price / (1 - yes_price) if yes_price < 1 else 0
        else:
            return self._reject(signal, market, "NEUTRAL signal — no trade")

        # Estimate our probability from signal
        our_prob = self._estimate_probability(signal)

        # Market's implied probability for our side
        mkt_implied = our_price

        # Edge = our estimate - market price
        edge     = our_prob - mkt_implied
        edge_pct = (edge / mkt_implied * 100) if mkt_implied > 0 else 0

        # Validate edge
        if our_prob < self.MIN_WIN_PROB:
            return self._reject(signal, market,
                f"Win prob too low: {our_prob:.2f} < {self.MIN_WIN_PROB}")

        if edge < self.MIN_EDGE:
            return self._reject(signal, market,
                f"Insufficient edge: {edge:.3f} ({edge_pct:.1f}%) < {self.MIN_EDGE}")

        if signal.execution_status == "ABORT":
            return self._reject(signal, market, "Fusion status ABORT")

        # Kelly sizing
        # f* = (p*b - q) / b  where b = payoff_mult, p = our_prob, q = 1-p
        kelly_pct = self._kelly(our_prob, payoff_mult)
        kelly_size = self.capital * kelly_pct * self.kelly_fraction
        kelly_size = max(self.min_size, min(self.max_size, kelly_size))

        # Adjust size by lot multiplier from confidence
        kelly_size *= signal.lot_multiplier

        # Min RR: payoff must be at least 2x risk
        min_rr = payoff_mult
        rr_ok  = payoff_mult >= self.cfg.get("rr_minimum", 2.0)

        return MappedSignal(
            direction         = signal.direction,
            fusion_score      = signal.fusion_score,
            confidence        = signal.confidence,
            execution_status  = signal.execution_status,
            market_question   = question,
            condition_id      = cid,
            yes_token_id      = yes_tid,
            no_token_id       = no_tid,
            side              = side,
            our_probability   = round(our_prob, 4),
            market_price      = round(mkt_implied, 4),
            edge              = round(edge, 4),
            edge_pct          = round(edge_pct, 2),
            kelly_size_usd    = round(kelly_size, 2),
            recommended_size  = round(min(kelly_size, self.max_size), 2),
            min_rr            = round(min_rr, 2),
            expected_payoff   = round(payoff_mult, 3),
            is_valid          = True,
            market_end_date   = str(end_date),
            market_volume     = volume,
            market_liquidity  = liquidity,
        )

    def _estimate_probability(self, signal: FusionSignal) -> float:
        """
        Convert fusion score + confidence to win probability estimate.

        Calibration:
          fusion_score 0.55 + confidence 75% → ~62% win prob
          fusion_score 0.70 + confidence 85% → ~72% win prob
          fusion_score 0.85 + confidence 90% → ~82% win prob

        Formula: linear blend weighted by confidence level
        """
        # Base from fusion score (0.55-1.0 → 0.55-0.90)
        fs_prob = 0.50 + signal.fusion_score * 0.40

        # Confidence adjustment (0-100 → 0.0-1.0 modifier)
        conf_adj = (signal.confidence - 50) / 200   # -0.25 to +0.25

        raw_prob = fs_prob + conf_adj

        # Gate boosts
        if signal.all_gates_passed:
            raw_prob *= 1.05  # 5% boost when all gates pass

        # Confidence level boost (from lot_multiplier)
        mult = signal.lot_multiplier
        if mult >= 2.0:    # ULTRA
            raw_prob *= 1.03
        elif mult >= 1.5:  # HIGH
            raw_prob *= 1.02

        return max(0.50, min(0.95, raw_prob))

    def _kelly(self, p: float, b: float) -> float:
        """
        Kelly criterion: f* = (p*b - q) / b
        Returns fraction of capital to bet (0-KELLY_CAP).
        """
        if b <= 0:
            return 0.0
        q      = 1.0 - p
        kelly  = (p * b - q) / b
        return max(0.0, min(self.KELLY_CAP, kelly))

    def _reject(self, signal: FusionSignal, market: dict,
                reason: str) -> MappedSignal:
        return MappedSignal(
            direction        = signal.direction,
            fusion_score     = signal.fusion_score,
            confidence       = signal.confidence,
            execution_status = signal.execution_status,
            market_question  = market.get("question", ""),
            condition_id     = market.get("condition_id", ""),
            yes_token_id     = market.get("yes_token_id", ""),
            no_token_id      = market.get("no_token_id", ""),
            side             = "NONE",
            our_probability  = 0.0,
            market_price     = float(market.get("yes_price", 0.5)),
            edge             = 0.0, edge_pct=0.0,
            kelly_size_usd   = 0.0, recommended_size=0.0,
            min_rr           = 0.0, expected_payoff=0.0,
            is_valid         = False,
            reject_reason    = reason,
        )
