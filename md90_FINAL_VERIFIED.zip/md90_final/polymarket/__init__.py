"""
MD90-Polymarket: Prediction Market Trading Module
8-Layer Architecture:
  L1: Memory Layer    (CLAUDE.md, RISK.md)
  L2: Knowledge Layer (Playbooks)
  L3: Guardrail Layer (Pre-market checks)
  L4: Delegation Layer(Sub-agents)
  L5: Distribution    (Telegram alerts)
  L6: Live State      (State Manager)
  L7: Recovery        (Circuit Breaker)
  L8: Learning        (Bayesian Updater)

NOTE: Requires py-clob-client-v2 (V2 SDK — CLOB V2 live April 28 2026)
      V1 py-clob-client no longer supported on production.
"""
