"""
polymarket/L8_learning/bayesian_updater.py
Bayesian Beta-Bernoulli updater — P(win) = alpha/(alpha+beta)
Persists priors to disk after every update.
"""
import json, os, logging
from datetime import datetime, timezone

log = logging.getLogger(__name__)
PRIORS_FILE = os.getenv("BAYESIAN_PRIORS_FILE", "data/polymarket_priors.json")


class BayesianUpdater:
    def __init__(self, alpha: float = 1.0, beta: float = 1.0):
        self.alpha0 = alpha
        self.beta0  = beta
        self.priors = self._load()

    def _load(self) -> dict:
        os.makedirs(os.path.dirname(PRIORS_FILE) if os.path.dirname(PRIORS_FILE) else ".", exist_ok=True)
        if os.path.exists(PRIORS_FILE):
            try:
                with open(PRIORS_FILE) as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    def _save(self):
        try:
            with open(PRIORS_FILE, "w") as f:
                json.dump(self.priors, f, indent=2)
        except Exception as e:
            log.error(f"Bayesian save failed: {e}")

    def get_probability(self, market_id: str) -> float:
        """P(win) = alpha / (alpha + beta)"""
        e = self.priors.get(str(market_id), {})
        a = e.get("alpha", self.alpha0)
        b = e.get("beta",  self.beta0)
        return a / (a + b) if (a + b) > 0 else 0.5

    def update(self, market_id: str, won: bool) -> float:
        """Update Beta posterior and return new P(win)."""
        key = str(market_id)
        e   = self.priors.setdefault(key, {
            "alpha": self.alpha0, "beta": self.beta0,
            "wins": 0, "total": 0, "last_update": None
        })
        if won:
            e["alpha"] += 1
            e["wins"]   = e.get("wins", 0) + 1
        else:
            e["beta"] += 1
        e["total"]       = e.get("total", 0) + 1
        e["last_update"] = datetime.now(timezone.utc).isoformat()
        self._save()
        prob = self.get_probability(key)
        log.info(f"Bayesian update [{key[:20]}] → P={prob:.4f} n={e['total']} wins={e['wins']}")
        return prob

    def get_all_stats(self) -> dict:
        """Return summary stats for dashboard."""
        stats = {}
        for k, v in self.priors.items():
            a = v.get("alpha", 1); b = v.get("beta", 1)
            stats[k] = {
                "prob":  round(a/(a+b), 4),
                "total": v.get("total", 0),
                "wins":  v.get("wins", 0),
            }
        return stats
