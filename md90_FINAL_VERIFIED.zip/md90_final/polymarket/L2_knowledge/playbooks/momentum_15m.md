# Momentum 15m: Entry when price>2% move+volume spike, Kelly f*=(bp-q)/b @ 0.25x
