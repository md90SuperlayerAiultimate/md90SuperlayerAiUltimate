"""
ml/__init__.py — ML Module
AdaptiveWeights: legacy interface (delegates to SelfLearner)
SelfLearner:     autonomous engine (primary)
"""
import json, os, logging
from typing import List
log = logging.getLogger("MD90.ML")

class AdaptiveWeights:
    """Legacy interface — delegates to SelfLearner for full functionality."""
    DEFAULT = [0.08,0.07,0.06,0.05,0.08,0.06,0.07,0.04,
               0.07,0.08,0.07,0.04,0.04,0.06,0.06,0.05,0.02]

    def __init__(self, save_path: str = "model/adaptive_weights.json"):
        self.path   = save_path
        self._w     = list(self.DEFAULT)
        self._count = 0
        self._learner = None
        self._load()
        try:
            from ml.self_learner import SelfLearner
            self._learner = SelfLearner()
        except Exception as e:
            log.debug(f"SelfLearner init: {e}")

    def _load(self):
        if os.path.exists(self.path):
            try:
                d = json.load(open(self.path))
                self._w     = d.get("weights", self.DEFAULT)
                self._count = d.get("count",   0)
            except: pass

    def _save(self):
        os.makedirs(os.path.dirname(self.path) if os.path.dirname(self.path) else ".", exist_ok=True)
        try:
            with open(self.path, "w") as f:
                json.dump({"weights": self._w, "count": self._count}, f, indent=2)
        except Exception as e:
            log.error(f"Save weights: {e}")

    def record(self, layer_directions: List[int],
               trade_direction: int, pnl: float):
        """Record trade — delegates to SelfLearner if available."""
        self._count += 1
        if self._learner:
            from ml.self_learner import TradeRecord
            try:
                rec = TradeRecord(
                    layer_dirs   = layer_directions[:17],
                    layer_strs   = [0.5]*17,
                    trade_dir    = trade_direction,
                    pnl          = pnl,
                    fusion_score = 0.6,
                    confidence   = 70.0,
                    regime       = "RANGING",
                    session      = "OTHER",
                )
                self._learner.learn(rec)
                self._w = self._learner.get_weights()
            except Exception as e:
                log.debug(f"SelfLearner record: {e}")
        if self._count % 10 == 0:
            self._save()

    def get_weights(self) -> List[float]:
        if self._learner:
            try:
                return self._learner.get_weights()
            except: pass
        return list(self._w)

    def report(self) -> str:
        if self._learner:
            try: return self._learner.get_stats().__str__()
            except: pass
        return f"AdaptiveWeights: {self._count} trades recorded"
