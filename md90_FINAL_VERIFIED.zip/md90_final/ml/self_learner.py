"""
ml/self_learner.py — MD90 Autonomous Self-Learning Engine
Bot belajar sendiri — TANPA campur tangan manusia.

Pipeline belajar:
  Trade closed
    → Online update (real-time, tiap trade)
    → Batch Optuna (tiap 50 trade)
    → Meta-Learning per regime (tiap 100 trade)
    → GitHub push model terbaru (tiap 24 jam)

3 level learning:
  L1: Online SGD  — update weight instan setiap trade
  L2: Bayesian Opt — Optuna TPE cari threshold optimal
  L3: Meta-Learning — bobot berbeda per HMM regime
"""
import json, os, time, logging, threading
from datetime import datetime, timezone, timedelta
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
import numpy as np

log = logging.getLogger("MD90.SelfLearner")
WITA = timezone(timedelta(hours=8))

MODEL_DIR   = os.getenv("MODEL_DIR",   "model")
RETRAIN_N   = int(os.getenv("ML_RETRAIN_EVERY", "20"))   # online: tiap 20 trade
OPTUNA_N    = int(os.getenv("ML_OPTUNA_EVERY",  "50"))   # Optuna: tiap 50 trade
META_N      = int(os.getenv("ML_META_EVERY",   "100"))   # meta: tiap 100 trade
LR          = float(os.getenv("ML_LR",          "0.05")) # learning rate
MIN_W       = float(os.getenv("ML_MIN_WEIGHT",  "0.01"))
MAX_W       = float(os.getenv("ML_MAX_WEIGHT",  "0.20"))
N_LAYERS    = 17


@dataclass
class TradeRecord:
    """Satu record trade untuk training."""
    layer_dirs:   List[int]    # 17 layer directions: 1=BUY, -1=SELL, 0=NEUT
    layer_strs:   List[float]  # 17 layer strengths: 0.0-1.0
    trade_dir:    int          # actual trade: 1=BUY, -1=SELL
    pnl:          float        # realized PnL
    fusion_score: float
    confidence:   float
    regime:       str
    session:      str
    timestamp:    str = field(default_factory=lambda: datetime.now(WITA).isoformat())

    @property
    def won(self) -> bool:
        return self.pnl > 0

    def to_dict(self) -> dict:
        return {
            "layer_dirs":   self.layer_dirs,
            "layer_strs":   self.layer_strs,
            "trade_dir":    self.trade_dir,
            "pnl":          self.pnl,
            "fusion_score": self.fusion_score,
            "confidence":   self.confidence,
            "regime":       self.regime,
            "session":      self.session,
            "timestamp":    self.timestamp,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "TradeRecord":
        return cls(
            layer_dirs   = d["layer_dirs"],
            layer_strs   = d.get("layer_strs", [0.5]*17),
            trade_dir    = d["trade_dir"],
            pnl          = d["pnl"],
            fusion_score = d.get("fusion_score", 0.5),
            confidence   = d.get("confidence", 50.0),
            regime       = d.get("regime", "RANGING"),
            session      = d.get("session", "OTHER"),
            timestamp    = d.get("timestamp", ""),
        )


class SelfLearner:
    """
    Autonomous learning engine.
    Dipanggil oleh polymarket/bot.py setelah setiap trade closed.
    Belajar sendiri — tidak perlu intervensi manual.
    """

    REGIME_LIST = [
        "Bull Trending", "Bear Trending", "Ranging",
        "Chaotic", "Event Driven", "Low Vol Expansion"
    ]
    SESSION_LIST = [
        "LONDON", "NY", "OVERLAP_LN", "ASIA",
        "AL_OVERLAP", "NIGHT", "WEEKEND", "OTHER"
    ]

    # Default MQL5 weights
    DEFAULT_WEIGHTS = [
        0.08, 0.07, 0.06, 0.05, 0.08,
        0.06, 0.07, 0.04, 0.07, 0.08,
        0.07, 0.04, 0.04, 0.06, 0.06,
        0.05, 0.02,
    ]

    def __init__(self):
        os.makedirs(MODEL_DIR, exist_ok=True)
        self._lock = threading.Lock()

        # Global weights (all regimes)
        self._weights: List[float] = list(self.DEFAULT_WEIGHTS)

        # Per-regime weights
        self._regime_weights: Dict[str, List[float]] = {
            r: list(self.DEFAULT_WEIGHTS) for r in self.REGIME_LIST
        }

        # Per-layer performance tracking
        self._layer_wins   = [0] * N_LAYERS
        self._layer_total  = [0] * N_LAYERS
        self._layer_pnl    = [0.0] * N_LAYERS

        # Trade history (for batch training)
        self._trades: List[TradeRecord] = []
        self._trade_count = 0

        # Performance tracking
        self._total_pnl   = 0.0
        self._win_count   = 0
        self._last_optuna = time.time()
        self._last_meta   = time.time()
        self._last_github = time.time()

        # Thresholds (tunable)
        self.fusion_score_min = float(os.getenv("FUSION_SCORE_MIN", "0.55"))
        self.confidence_min   = float(os.getenv("CONFIDENCE_MIN",   "75.0"))
        self.min_persistence  = int(os.getenv("MIN_PERSISTENCE",    "7"))

        self._load()
        log.info(f"✅ SelfLearner ready | {self._trade_count} trades in memory")

    # ══════════════════════════════════════════════════════════════
    # PUBLIC: Called after every closed trade
    # ══════════════════════════════════════════════════════════════

    def learn(self, record: TradeRecord):
        """
        MASTER ENTRY POINT — dipanggil setiap trade closed.
        Thread-safe, non-blocking (heavy work di background thread).
        """
        with self._lock:
            self._trades.append(record)
            self._trade_count += 1
            self._total_pnl   += record.pnl
            if record.won:
                self._win_count += 1

            # L1: Online update (immediate, every trade)
            self._online_update(record)

            # L2: Optuna batch (every OPTUNA_N trades, background)
            if self._trade_count % OPTUNA_N == 0:
                threading.Thread(
                    target=self._optuna_tune, daemon=True).start()

            # L3: Meta-learning (every META_N trades, background)
            if self._trade_count % META_N == 0:
                threading.Thread(
                    target=self._meta_learn, daemon=True).start()

            self._save()

        win_rate = self._win_count / self._trade_count * 100
        top = self._top_layers(3)
        log.info(
            f"[LEARN] #{self._trade_count} | "
            f"WR={win_rate:.1f}% | "
            f"PnL={self._total_pnl:+.2f} | "
            f"Top: {top}"
        )

    # ══════════════════════════════════════════════════════════════
    # L1: ONLINE SGD — Real-time weight update
    # ══════════════════════════════════════════════════════════════

    def _online_update(self, record: TradeRecord):
        """
        Inkremental update bobot setiap trade.
        Formula: w += LR * signal * reward
          signal = 1 jika layer agree dengan trade, -1 jika tidak
          reward = PnL normalized (positif = reinforcement, negatif = punishment)
        """
        reward = np.tanh(record.pnl / 10.0)  # normalize: tanh(-inf..+inf) → [-1,1]

        for i in range(N_LAYERS):
            ld = record.layer_dirs[i]
            if ld == 0:
                continue

            # Update layer performance counters
            self._layer_total[i] += 1
            agrees = (ld == record.trade_dir)

            if agrees and record.won:
                self._layer_wins[i] += 1
                self._layer_pnl[i]  += record.pnl
                # Reward: increase weight
                delta = LR * record.layer_strs[i] * reward
                self._weights[i] = min(MAX_W, self._weights[i] + delta)
            elif not agrees and record.won:
                # Layer was wrong but trade won — small penalty
                delta = LR * 0.3 * abs(reward)
                self._weights[i] = max(MIN_W, self._weights[i] - delta)
            elif agrees and not record.won:
                # Layer was right direction but trade lost — small penalty
                delta = LR * 0.5 * abs(reward)
                self._weights[i] = max(MIN_W, self._weights[i] - delta)
            else:
                # Both wrong — punish
                delta = LR * abs(reward)
                self._weights[i] = max(MIN_W, self._weights[i] - delta)

            if record.won:
                self._layer_wins[i] = self._layer_wins[i]  # already updated
            else:
                pass  # losses already handled above

        # Renormalize weights sum = 1.0
        self._normalize_weights(self._weights)

        # Per-regime weights update
        regime = record.regime
        if regime in self._regime_weights:
            rw = self._regime_weights[regime]
            for i in range(N_LAYERS):
                ld = record.layer_dirs[i]
                if ld == 0: continue
                agrees = (ld == record.trade_dir)
                if agrees and record.won:
                    rw[i] = min(MAX_W, rw[i] * (1 + LR * 0.5))
                elif not agrees and not record.won:
                    rw[i] = max(MIN_W, rw[i] * (1 - LR * 0.5))
            self._normalize_weights(rw)

    # ══════════════════════════════════════════════════════════════
    # L2: OPTUNA BAYESIAN OPTIMIZATION
    # ══════════════════════════════════════════════════════════════

    def _optuna_tune(self):
        """
        Optuna TPE — cari kombinasi threshold optimal.
        Objective: maximize Sharpe Ratio pada trade history.
        Berjalan di background thread.
        """
        if len(self._trades) < 30:
            return

        try:
            import optuna
            optuna.logging.set_verbosity(optuna.logging.WARNING)

            trades_snapshot = list(self._trades)

            def objective(trial):
                fs_min  = trial.suggest_float("fusion_score_min", 0.50, 0.80)
                conf_min= trial.suggest_float("confidence_min",   60.0, 90.0)
                min_pers= trial.suggest_int("min_persistence",    3, 15)
                kelly_f = trial.suggest_float("kelly_fraction",   0.10, 0.35)

                # Filter trades with these params
                filtered_pnls = [
                    t.pnl for t in trades_snapshot
                    if (t.fusion_score >= fs_min and
                        t.confidence   >= conf_min)
                ]

                if len(filtered_pnls) < 5:
                    return -999.0  # too few trades = penalty

                pnls = np.array(filtered_pnls)
                mean = np.mean(pnls)
                std  = np.std(pnls) + 1e-8

                # Objective: Sharpe + win rate bonus
                sharpe   = mean / std * np.sqrt(252)
                win_rate = np.mean(pnls > 0)
                pf       = pnls[pnls > 0].sum() / (abs(pnls[pnls < 0].sum()) + 1e-8)

                return sharpe * 0.5 + win_rate * 0.3 + min(pf, 5.0) * 0.2

            study = optuna.create_study(
                direction="maximize",
                sampler=optuna.samplers.TPESampler(seed=42),
            )
            study.optimize(objective, n_trials=100, show_progress_bar=False)

            best = study.best_params
            old_fs   = self.fusion_score_min
            old_conf = self.confidence_min

            self.fusion_score_min = round(best["fusion_score_min"], 4)
            self.confidence_min   = round(best["confidence_min"], 2)
            self.min_persistence  = best["min_persistence"]

            log.info(
                f"[OPTUNA] Trade #{self._trade_count} | "
                f"fusion_score: {old_fs:.3f}→{self.fusion_score_min:.3f} | "
                f"confidence: {old_conf:.1f}→{self.confidence_min:.1f} | "
                f"persistence: {self.min_persistence} | "
                f"Sharpe: {study.best_value:.4f}"
            )
            self._save()

        except Exception as e:
            log.error(f"[OPTUNA] Error: {e}")

    # ══════════════════════════════════════════════════════════════
    # L3: META-LEARNING — Per-Regime Specialization
    # ══════════════════════════════════════════════════════════════

    def _meta_learn(self):
        """
        Belajar bobot berbeda per regime.
        Bull Trending → layer berbeda yang bagus vs Ranging.
        Berjalan di background thread setiap META_N trades.
        """
        if len(self._trades) < 50:
            return

        try:
            from scipy.optimize import differential_evolution

            for regime in self.REGIME_LIST:
                regime_trades = [t for t in self._trades if t.regime == regime]
                if len(regime_trades) < 10:
                    continue

                def neg_sharpe(weights):
                    w = np.array(weights)
                    w = np.clip(w, MIN_W, MAX_W)
                    w /= w.sum()

                    pnls = []
                    for t in regime_trades:
                        # Weighted score of layers
                        score = sum(
                            w[i] * t.layer_dirs[i] * t.layer_strs[i]
                            for i in range(N_LAYERS)
                            if t.layer_dirs[i] != 0
                        )
                        # Trade if score > 0 and matches trade direction
                        if score * t.trade_dir > 0:
                            pnls.append(t.pnl)

                    if len(pnls) < 3:
                        return 999.0

                    arr  = np.array(pnls)
                    mean = np.mean(arr)
                    std  = np.std(arr) + 1e-8
                    return -(mean / std)  # minimize negative Sharpe

                bounds = [(MIN_W, MAX_W)] * N_LAYERS
                x0     = self._regime_weights[regime]

                result = differential_evolution(
                    neg_sharpe,
                    bounds=bounds,
                    x0=x0,
                    maxiter=100,
                    seed=42,
                    tol=0.01,
                    workers=1,
                )

                if result.success or result.fun < 0:
                    opt_w = np.array(result.x)
                    opt_w = np.clip(opt_w, MIN_W, MAX_W)
                    opt_w /= opt_w.sum()
                    self._regime_weights[regime] = opt_w.tolist()
                    log.info(
                        f"[META] {regime} | "
                        f"n={len(regime_trades)} | "
                        f"Sharpe={-result.fun:.3f}"
                    )

            self._save()

        except Exception as e:
            log.error(f"[META] Error: {e}")

    # ══════════════════════════════════════════════════════════════
    # PUBLIC GETTERS
    # ══════════════════════════════════════════════════════════════

    def get_weights(self, regime: str = None) -> List[float]:
        """
        Get current weights.
        If regime provided AND meta-learning has regime data → use regime-specific.
        """
        if regime and regime in self._regime_weights:
            rw = self._regime_weights[regime]
            if rw and sum(rw) > 0:
                return list(rw)
        return list(self._weights)

    def get_thresholds(self) -> dict:
        """Current optimal thresholds from Optuna."""
        return {
            "fusion_score_min": self.fusion_score_min,
            "confidence_min":   self.confidence_min,
            "min_persistence":  self.min_persistence,
        }

    def get_layer_report(self) -> List[dict]:
        """Per-layer performance for dashboard."""
        from md90_brain.constants import LAYER_NAMES
        out = []
        for i in range(N_LAYERS):
            total = self._layer_total[i]
            wins  = self._layer_wins[i]
            out.append({
                "layer":    f"L{i+1:02d}",
                "name":     LAYER_NAMES[i] if i < len(LAYER_NAMES) else f"L{i+1}",
                "weight":   round(self._weights[i], 4),
                "win_rate": round(wins / total * 100, 1) if total > 0 else None,
                "calls":    total,
                "pnl":      round(self._layer_pnl[i], 2),
            })
        return out

    def get_stats(self) -> dict:
        wr = self._win_count / self._trade_count * 100 if self._trade_count else 0
        return {
            "total_trades":      self._trade_count,
            "win_rate":          round(wr, 2),
            "total_pnl":         round(self._total_pnl, 2),
            "fusion_score_min":  self.fusion_score_min,
            "confidence_min":    self.confidence_min,
            "min_persistence":   self.min_persistence,
            "top_layers":        self._top_layers(5),
            "weak_layers":       self._weak_layers(3),
        }

    # ══════════════════════════════════════════════════════════════
    # HELPERS
    # ══════════════════════════════════════════════════════════════

    def _normalize_weights(self, weights: List[float]):
        total = sum(weights)
        if total <= 0:
            for i in range(len(weights)):
                weights[i] = 1.0 / len(weights)
            return
        for i in range(len(weights)):
            weights[i] = weights[i] / total

    def _top_layers(self, n: int = 3) -> List[str]:
        try:
            from md90_brain.constants import LAYER_NAMES
            ranked = sorted(
                range(N_LAYERS),
                key=lambda i: (
                    self._layer_wins[i] / max(1, self._layer_total[i])
                    * min(self._layer_total[i] / 10, 1.0)
                ),
                reverse=True
            )
            return [LAYER_NAMES[i] if i < len(LAYER_NAMES) else f"L{i+1}"
                    for i in ranked[:n]]
        except Exception:
            return []

    def _weak_layers(self, n: int = 3) -> List[str]:
        try:
            from md90_brain.constants import LAYER_NAMES
            ranked = sorted(
                [i for i in range(N_LAYERS) if self._layer_total[i] >= 5],
                key=lambda i: self._layer_wins[i] / max(1, self._layer_total[i])
            )
            return [LAYER_NAMES[i] if i < len(LAYER_NAMES) else f"L{i+1}"
                    for i in ranked[:n]]
        except Exception:
            return []

    # ══════════════════════════════════════════════════════════════
    # PERSISTENCE
    # ══════════════════════════════════════════════════════════════

    def _save(self):
        path = os.path.join(MODEL_DIR, "self_learner.json")
        try:
            data = {
                "version":        "v4",
                "trade_count":    self._trade_count,
                "win_count":      self._win_count,
                "total_pnl":      self._total_pnl,
                "weights":        self._weights,
                "regime_weights": self._regime_weights,
                "layer_wins":     self._layer_wins,
                "layer_total":    self._layer_total,
                "layer_pnl":      self._layer_pnl,
                "thresholds": {
                    "fusion_score_min": self.fusion_score_min,
                    "confidence_min":   self.confidence_min,
                    "min_persistence":  self.min_persistence,
                },
                "trades": [t.to_dict() for t in self._trades[-500:]],
                "saved_at": datetime.now(WITA).isoformat(),
            }
            with open(path, "w") as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            log.error(f"Save failed: {e}")

    def _load(self):
        path = os.path.join(MODEL_DIR, "self_learner.json")
        if not os.path.exists(path):
            return
        try:
            data = json.loads(open(path).read())
            self._trade_count    = data.get("trade_count",   0)
            self._win_count      = data.get("win_count",     0)
            self._total_pnl      = data.get("total_pnl",     0.0)
            self._weights        = data.get("weights",       self._weights)
            self._regime_weights = data.get("regime_weights",self._regime_weights)
            self._layer_wins     = data.get("layer_wins",    [0]*N_LAYERS)
            self._layer_total    = data.get("layer_total",   [0]*N_LAYERS)
            self._layer_pnl      = data.get("layer_pnl",     [0.0]*N_LAYERS)
            th = data.get("thresholds", {})
            self.fusion_score_min = th.get("fusion_score_min", self.fusion_score_min)
            self.confidence_min   = th.get("confidence_min",   self.confidence_min)
            self.min_persistence  = th.get("min_persistence",  self.min_persistence)
            raw_trades = data.get("trades", [])
            self._trades = [TradeRecord.from_dict(d) for d in raw_trades]
            log.info(f"Loaded: {self._trade_count} trades, WR={self._win_count/max(1,self._trade_count)*100:.1f}%")
        except Exception as e:
            log.error(f"Load failed: {e}")
