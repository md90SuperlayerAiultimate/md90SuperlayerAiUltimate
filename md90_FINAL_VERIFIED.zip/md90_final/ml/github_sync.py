"""
ml/github_sync.py — GitHub Model Sync
Bot otomatis push model terbaru ke GitHub setiap 24 jam.
Dan pull model terbaru saat startup.

Setup:
  GITHUB_REPO_URL=https://github.com/username/md90-models.git
  GITHUB_TOKEN=ghp_xxxx
  GITHUB_BRANCH=main

Model yang di-sync:
  model/self_learner.json    ← weights + thresholds
  model/hmm_model.pkl        ← HMM regime model
  model/adaptive_weights.json ← legacy weights
  data/polymarket_priors.json ← Bayesian priors
"""
import os, json, logging, shutil
from datetime import datetime, timezone, timedelta
from pathlib import Path

log = logging.getLogger("MD90.GithubSync")
WITA = timezone(timedelta(hours=8))

REPO_URL    = os.getenv("GITHUB_REPO_URL",  "")
GITHUB_TOKEN= os.getenv("GITHUB_TOKEN",     "")
BRANCH      = os.getenv("GITHUB_BRANCH",    "main")
LOCAL_REPO  = os.getenv("GITHUB_LOCAL_DIR", "model/git_repo")

MODEL_FILES = [
    "model/self_learner.json",
    "model/adaptive_weights.json",
    "model/hmm_model.pkl",
    "data/polymarket_priors.json",
]


def _auth_url() -> str:
    """Inject token into HTTPS URL."""
    if not GITHUB_TOKEN or not REPO_URL:
        return REPO_URL
    if REPO_URL.startswith("https://"):
        return REPO_URL.replace("https://", f"https://{GITHUB_TOKEN}@")
    return REPO_URL


def pull_latest() -> bool:
    """
    Pull latest model dari GitHub saat startup.
    Jika repo belum ada → clone dulu.
    """
    if not REPO_URL:
        log.info("GitHub sync disabled — set GITHUB_REPO_URL to enable")
        return False

    try:
        import git
        repo_path = Path(LOCAL_REPO)

        if repo_path.exists():
            repo = git.Repo(LOCAL_REPO)
            origin = repo.remotes.origin
            origin.set_url(_auth_url())
            origin.pull(BRANCH)
            log.info(f"✅ Pulled latest model from GitHub ({BRANCH})")
        else:
            os.makedirs(LOCAL_REPO, exist_ok=True)
            git.Repo.clone_from(_auth_url(), LOCAL_REPO, branch=BRANCH)
            log.info(f"✅ Cloned model repo from GitHub")

        # Copy model files from repo to working dir
        for mf in MODEL_FILES:
            src = Path(LOCAL_REPO) / Path(mf).name
            dst = Path(mf)
            if src.exists():
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
                log.debug(f"  Restored: {mf}")

        return True

    except ImportError:
        log.warning("gitpython not installed — pip install gitpython")
        return False
    except Exception as e:
        log.warning(f"GitHub pull skipped: {e}")
        return False


def push_model(message: str = None) -> bool:
    """
    Push model terbaru ke GitHub.
    Dipanggil otomatis oleh SelfLearner setiap 24 jam.
    """
    if not REPO_URL:
        return False

    try:
        import git
        repo_path = Path(LOCAL_REPO)

        # Init/clone if needed
        if not repo_path.exists():
            pull_latest()

        repo = git.Repo(LOCAL_REPO)

        # Copy current model files into repo
        changed = []
        for mf in MODEL_FILES:
            src = Path(mf)
            dst = Path(LOCAL_REPO) / src.name
            if src.exists():
                shutil.copy2(src, dst)
                changed.append(str(dst))
                repo.index.add([src.name])

        if not changed:
            log.info("No model files to push")
            return False

        # Commit
        now_wita = datetime.now(WITA).strftime("%Y-%m-%d %H:%M WITA")
        msg = message or f"Auto-update model | {now_wita} | bot learning"
        repo.index.commit(msg)

        # Push
        origin = repo.remotes.origin
        origin.set_url(_auth_url())
        origin.push(BRANCH)

        log.info(f"✅ GitHub push: {len(changed)} files | '{msg}'")
        return True

    except Exception as e:
        log.error(f"GitHub push failed: {e}")
        return False


def setup_github_actions() -> str:
    """
    Generate .github/workflows/model-update.yml
    GitHub Actions akan auto-test model setiap push.
    """
    yml = """name: MD90 Model Validation

on:
  push:
    branches: [main]
    paths:
      - 'self_learner.json'
      - 'adaptive_weights.json'

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Setup Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'

      - name: Validate model JSON
        run: |
          python3 -c "
          import json, sys
          files = ['self_learner.json', 'adaptive_weights.json']
          for f in files:
              try:
                  d = json.load(open(f))
                  trades = d.get('trade_count', 0)
                  wr = d.get('win_count', 0) / max(1, trades) * 100
                  print(f'{f}: trades={trades} WR={wr:.1f}%')
              except FileNotFoundError:
                  print(f'{f}: not found (OK for new repo)')
              except Exception as e:
                  print(f'ERROR {f}: {e}'); sys.exit(1)
          print('All models valid')
          "

      - name: Model Stats Summary
        run: |
          python3 -c "
          import json, os
          if os.path.exists('self_learner.json'):
              d = json.load(open('self_learner.json'))
              print('=== MD90 Model Stats ===')
              print(f'Trades: {d.get(\"trade_count\", 0)}')
              wr = d.get('win_count',0)/max(1,d.get('trade_count',1))*100
              print(f'Win Rate: {wr:.1f}%')
              print(f'Total PnL: {d.get(\"total_pnl\", 0):.2f}')
              th = d.get('thresholds', {})
              print(f'Thresholds: fs={th.get(\"fusion_score_min\")} conf={th.get(\"confidence_min\")}')
          "
"""
    path = Path(LOCAL_REPO) / ".github" / "workflows"
    path.mkdir(parents=True, exist_ok=True)
    with open(path / "model-update.yml", "w") as f:
        f.write(yml)
    log.info("✅ GitHub Actions workflow created")
    return yml
