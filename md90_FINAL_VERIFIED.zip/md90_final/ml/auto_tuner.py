"""
ml/auto_tuner.py — Optuna Hyperparameter Auto-Tuner
Bot tuning parameter sendiri menggunakan Bayesian Optimization.
Target: maximize Profit Factor dari 68% → 75%+ WR

Parameters yang di-tune:
  - fusion_score_min    (0.45 - 0.75)
  - confidence_min      (60 - 90)
  - kelly_fraction      (0.10 - 0.35)
  - min_persistence     (3 - 15)
  - composite_allin     (0.60 - 0.85)
  - composite_wait      (0.45 - 0.65)
  - atr_sl_mult         (1.0 - 2.5)
  - poly_edge_min       (0.04 - 0.12)
"""
import json
import os
import logging
import numpy as np
from typing import Dict, List, Callable, Optional, Tuple
from datetime import datetime

log = logging.getLogger("MD90.AutoTuner")

STUDY_PATH  = "model/optuna_study.json"
RESULTS_PATH= "model/best_params.json"


class AutoTuner:
    """
    Optuna-based hyperparameter optimizer.
    Objective: maximize profit_factor × win_rate from replay buffer.
    Runs in background thread — non-blocking.
    """

    PARAM_SPACE = {
        "fusion_score_min":  (0.45, 0.75),
        "confidence_min":    (60.0, 92.0),
        "kelly_fraction":    (0.10, 0.35),
        "min_persistence":   (3,    15),
        "composite_allin":   (0.60, 0.88),
        "composite_wait":    (0.40, 0.68),
        "poly_edge_min":     (0.03, 0.15),
        "rr_minimum":        (1.5,  4.0),
    }

    def __init__(self, replay_buffer=None, n_trials: int = 100):
        self.replay    = replay_buffer
        self.n_trials  = n_trials
        self.best      = self._load_best()

    def _objective(self, trial) -> float:
        """Optuna objective — maximize profit_factor × win_rate."""
        if not self.replay or len(self.replay) < 20:
            return 0.0

        # Sample hyperparameters
        params = {
            "fusion_score_min": trial.suggest_float(
                "fusion_score_min", *self.PARAM_SPACE["fusion_score_min"]),
            "confidence_min":   trial.suggest_float(
                "confidence_min",   *self.PARAM_SPACE["confidence_min"]),
            "kelly_fraction":   trial.suggest_float(
                "kelly_fraction",   *self.PARAM_SPACE["kelly_fraction"]),
            "min_persistence":  trial.suggest_int(
                "min_persistence",  *self.PARAM_SPACE["min_persistence"]),
            "composite_allin":  trial.suggest_float(
                "composite_allin",  *self.PARAM_SPACE["composite_allin"]),
            "composite_wait":   trial.suggest_float(
                "composite_wait",   *self.PARAM_SPACE["composite_wait"]),
            "poly_edge_min":    trial.suggest_float(
                "poly_edge_min",    *self.PARAM_SPACE["poly_edge_min"]),
            "rr_minimum":       trial.suggest_float(
                "rr_minimum",       *self.PARAM_SPACE["rr_minimum"]),
        }

        # Simulate on replay buffer with these params
        pnls   = []
        trades = self.replay.buffer if hasattr(self.replay, "buffer") else []

        for t in trades:
            # Filter: apply param thresholds
            if t.fusion_score < params["fusion_score_min"]:
                continue
            if t.confidence < params["confidence_min"]:
                continue
            pnls.append(t.pnl)

        if len(pnls) < 10:
            return 0.0

        wins    = [p for p in pnls if p > 0]
        losses  = [p for p in pnls if p <= 0]
        win_rate= len(wins) / len(pnls)
        g_profit= sum(wins)
        g_loss  = abs(sum(losses)) if losses else 1.0
        pf      = g_profit / g_loss if g_loss > 0 else 0

        # Score: profit_factor × win_rate (maximize both)
        score = pf * win_rate
        return score

    def run(self, n_trials: int = None, callback: Optional[Callable] = None):
        """
        Run Optuna optimization.
        callback(best_params) called when new best found.
        """
        try:
            import optuna
            optuna.logging.set_verbosity(optuna.logging.WARNING)

            study = optuna.create_study(
                direction        = "maximize",
                study_name       = "md90_tuning",
                sampler          = optuna.samplers.TPESampler(seed=42),
                pruner           = optuna.pruners.MedianPruner(),
            )

            n = n_trials or self.n_trials

            def wrapped_objective(trial):
                val = self._objective(trial)
                if study.best_value is not None and val > study.best_value:
                    if callback:
                        callback(trial.params)
                return val

            study.optimize(wrapped_objective, n_trials=n,
                           timeout=120, show_progress_bar=False)

            self.best = study.best_params
            self.best["score"]    = study.best_value
            self.best["n_trials"] = n
            self.best["tuned_at"] = datetime.now().isoformat()
            self._save_best()

            log.info(
                f"AutoTune done | "
                f"best score={study.best_value:.4f} | "
                f"best_params={self.best}"
            )
            return self.best

        except ImportError:
            log.warning("optuna not installed — skipping AutoTuner")
            return {}
        except Exception as e:
            log.error(f"AutoTuner error: {e}")
            return {}

    def get_best_params(self) -> Dict:
        return self.best or {}

    def apply_to_config(self, cfg: dict) -> dict:
        """Merge best params into running config."""
        if not self.best:
            return cfg
        mapping = {
            "fusion_score_min": "fusion_score_min",
            "confidence_min":   "confidence_min",
            "kelly_fraction":   "kelly_fraction",
            "min_persistence":  "min_persistence",
            "composite_allin":  "composite_allin",
            "composite_wait":   "composite_wait",
            "rr_minimum":       "rr_minimum",
        }
        updated = dict(cfg)
        for opt_key, cfg_key in mapping.items():
            if opt_key in self.best:
                updated[cfg_key] = self.best[opt_key]
                log.info(f"Config updated: {cfg_key} = {self.best[opt_key]:.4f}")
        return updated

    def _save_best(self):
        os.makedirs(os.path.dirname(RESULTS_PATH), exist_ok=True)
        with open(RESULTS_PATH, "w") as f:
            json.dump(self.best, f, indent=2)

    def _load_best(self) -> dict:
        if os.path.exists(RESULTS_PATH):
            try:
                with open(RESULTS_PATH) as f:
                    d = json.load(f)
                log.info(f"Best params loaded (score={d.get('score',0):.4f})")
                return d
            except Exception:
                pass
        return {}
