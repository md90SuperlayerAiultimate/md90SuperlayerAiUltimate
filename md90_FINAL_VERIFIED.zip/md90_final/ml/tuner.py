"""
ml/tuner.py — ML Tuning Orchestrator
Run manual: python ml/tuner.py
Atau otomatis dari bot setiap 24 jam.

Tuning sequence:
  1. Load trade history dari SQLite journal
  2. Layer attribution analysis
  3. Optuna full optimization (300 trials)
  4. Meta-learning per regime
  5. Kelly fraction optimization
  6. Save + GitHub push
"""
import json, os, sys, logging
import numpy as np
from datetime import datetime, timezone, timedelta
from typing import List

log = logging.getLogger("MD90.Tuner")
WITA = timezone(timedelta(hours=8))

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))


def load_trades_from_db(db_path: str = "data/trades.db") -> List[dict]:
    """Load all closed trades from SQLite journal."""
    import sqlite3
    if not os.path.exists(db_path):
        log.warning(f"DB not found: {db_path}")
        return []
    try:
        conn = sqlite3.connect(db_path)
        cur  = conn.execute(
            "SELECT * FROM trades WHERE status='closed' ORDER BY id")
        cols = [d[0] for d in cur.description]
        rows = [dict(zip(cols, r)) for r in cur.fetchall()]
        conn.close()
        log.info(f"Loaded {len(rows)} closed trades from DB")
        return rows
    except Exception as e:
        log.error(f"DB load error: {e}")
        return []


def load_trades_from_learner(model_dir: str = "model") -> List[dict]:
    """Load trades from self_learner.json."""
    path = os.path.join(model_dir, "self_learner.json")
    if not os.path.exists(path):
        return []
    try:
        d = json.loads(open(path).read())
        return d.get("trades", [])
    except Exception as e:
        log.error(f"Learner load: {e}")
        return []


def run_layer_attribution(trades: List[dict]) -> dict:
    """
    Analisis kontribusi setiap layer ke profit/loss.
    Returns: per-layer stats.
    """
    N = 17
    wins    = [0] * N
    total   = [0] * N
    pnl_sum = [0.0] * N

    for t in trades:
        dirs = t.get("layer_dirs", [])
        td   = t.get("trade_dir", 0)
        pnl  = t.get("pnl", 0)
        won  = pnl > 0

        if len(dirs) != N:
            continue

        for i, ld in enumerate(dirs):
            if ld == 0:
                continue
            total[i] += 1
            if (ld == td) == won:
                wins[i] += 1
            if won:
                pnl_sum[i] += pnl

    try:
        from md90_brain.constants import LAYER_NAMES
        names = LAYER_NAMES
    except Exception:
        names = [f"L{i+1}" for i in range(N)]

    result = {}
    for i in range(N):
        wr = wins[i] / total[i] * 100 if total[i] >= 5 else None
        result[names[i]] = {
            "win_rate": round(wr, 1) if wr else None,
            "calls":    total[i],
            "pnl":      round(pnl_sum[i], 2),
            "quality":  "STRONG" if wr and wr >= 65 else
                       ("WEAK" if wr and wr < 45 else "NEUTRAL"),
        }
    return result


def run_optuna_full(trades: List[dict], n_trials: int = 300) -> dict:
    """Full Optuna optimization — thresholds + layer weights."""
    if len(trades) < 20:
        print("Not enough trades for Optuna (need ≥20)")
        return {}

    try:
        import optuna
        optuna.logging.set_verbosity(optuna.logging.WARNING)

        pnls_all = [t["pnl"] for t in trades]
        fs_all   = [t.get("fusion_score", 0.5) for t in trades]
        cf_all   = [t.get("confidence", 50.0) for t in trades]

        def objective(trial):
            fs   = trial.suggest_float("fusion_score_min", 0.45, 0.85)
            conf = trial.suggest_float("confidence_min",   55.0, 92.0)
            pers = trial.suggest_int("min_persistence",    3, 15)

            filtered = [pnls_all[i] for i in range(len(trades))
                       if fs_all[i] >= fs and cf_all[i] >= conf]

            if len(filtered) < 5:
                return -999.0

            arr  = np.array(filtered)
            mean = np.mean(arr)
            std  = np.std(arr) + 1e-9
            wr   = np.mean(arr > 0)
            pf   = arr[arr > 0].sum() / (abs(arr[arr < 0].sum()) + 1e-9)
            sharpe = mean / std * np.sqrt(252)

            return sharpe * 0.4 + wr * 100 * 0.35 + min(pf, 10) * 0.25

        study = optuna.create_study(
            direction="maximize",
            sampler=optuna.samplers.TPESampler(seed=42),
        )
        study.optimize(objective, n_trials=n_trials, show_progress_bar=True)

        best = study.best_params
        val  = study.best_value
        print(f"\n✅ Optuna done | best_value={val:.4f}")
        print(f"   fusion_score_min : {best['fusion_score_min']:.4f}")
        print(f"   confidence_min   : {best['confidence_min']:.2f}")
        print(f"   min_persistence  : {best['min_persistence']}")

        return best

    except ImportError:
        print("optuna not installed — pip install optuna")
        return {}


def run_kelly_optimization(trades: List[dict]) -> dict:
    """
    Cari Kelly fraction optimal untuk maksimalkan growth rate.
    f* yang memaksimalkan E[log(1 + f*pnl)] per trade.
    """
    if len(trades) < 20:
        return {"kelly_fraction": 0.25}

    pnls = np.array([t["pnl"] for t in trades])

    try:
        from scipy.optimize import minimize_scalar

        def neg_log_growth(f):
            """Minimize negative log-growth."""
            # Normalize PnL sebagai fraction of stake
            normalized = pnls / max(abs(pnls)) * f
            growth = np.log1p(normalized)
            return -np.mean(growth)

        result = minimize_scalar(
            neg_log_growth,
            bounds=(0.05, 0.50),
            method="bounded",
        )

        optimal_f = round(result.x, 4)
        # Safety cap: never more than 30%
        safe_f = min(optimal_f, 0.30)
        # Conservative: use 60% of optimal Kelly
        conservative_f = round(safe_f * 0.60, 4)

        print(f"\n✅ Kelly Optimization:")
        print(f"   Full Kelly   : {optimal_f:.4f} ({optimal_f*100:.1f}%)")
        print(f"   Safe Kelly   : {safe_f:.4f} ({safe_f*100:.1f}%)")
        print(f"   Conservative : {conservative_f:.4f} ({conservative_f*100:.1f}%)")
        print(f"   (Using 60% of safe Kelly for live trading)")

        return {
            "full_kelly":     optimal_f,
            "safe_kelly":     safe_f,
            "recommended":    conservative_f,
            "kelly_fraction": conservative_f,
        }
    except ImportError:
        return {"kelly_fraction": 0.25}


def apply_results(optuna_best: dict, kelly_result: dict,
                   model_dir: str = "model"):
    """Write tuning results ke self_learner.json dan .env patch."""
    path = os.path.join(model_dir, "self_learner.json")
    if os.path.exists(path):
        data = json.loads(open(path).read())
    else:
        data = {"version": "v4", "trade_count": 0}

    # Update thresholds
    th = data.setdefault("thresholds", {})
    if optuna_best:
        th["fusion_score_min"] = round(optuna_best.get("fusion_score_min", 0.55), 4)
        th["confidence_min"]   = round(optuna_best.get("confidence_min",   75.0), 2)
        th["min_persistence"]  = optuna_best.get("min_persistence", 7)

    # Update Kelly
    data["kelly_fraction"] = kelly_result.get("recommended", 0.25)
    data["tuned_at"]       = datetime.now(WITA).isoformat()

    with open(path, "w") as f:
        json.dump(data, f, indent=2)

    # Write .env patch file
    patch_path = os.path.join(model_dir, "tuning_results.env")
    lines = [
        f"# MD90 Tuning Results — {datetime.now(WITA).strftime('%Y-%m-%d %H:%M WITA')}",
        f"# Apply these to .env to use optimized parameters",
        f"",
    ]
    if optuna_best:
        lines += [
            f"FUSION_SCORE_MIN={th['fusion_score_min']}",
            f"CONFIDENCE_MIN={th['confidence_min']}",
            f"MIN_PERSISTENCE={th['min_persistence']}",
        ]
    if kelly_result:
        lines.append(f"POLYMARKET_KELLY_FRACTION={kelly_result.get('recommended', 0.25)}")

    with open(patch_path, "w") as f:
        f.write("\n".join(lines))

    print(f"\n✅ Results saved:")
    print(f"   {path}")
    print(f"   {patch_path}")
    print(f"\n💡 Apply to .env:")
    for l in lines[3:]:
        if l and not l.startswith("#"):
            print(f"   {l}")


def run_full_tuning(push_to_github: bool = False):
    """Master tuning pipeline — run all steps."""
    print("=" * 55)
    print("  MD90 ML TUNING — FULL PIPELINE")
    print(f"  {datetime.now(WITA).strftime('%Y-%m-%d %H:%M WITA')}")
    print("=" * 55)

    # Load trades
    trades = load_trades_from_learner() or load_trades_from_db()
    if not trades:
        print("❌ No trades found. Run bot in dry-run first to collect data.")
        return

    print(f"\n📊 Loaded {len(trades)} trades")
    pnls = [t.get("pnl", 0) for t in trades]
    wins = sum(1 for p in pnls if p > 0)
    wr   = wins / len(pnls) * 100
    mean_pnl = np.mean(pnls)
    std_pnl  = np.std(pnls) + 1e-9
    sharpe   = mean_pnl / std_pnl * np.sqrt(252)

    print(f"   Win Rate    : {wr:.1f}%")
    print(f"   Avg PnL     : ${mean_pnl:+.4f}")
    print(f"   Sharpe      : {sharpe:.3f}")
    print(f"   Total PnL   : ${sum(pnls):+.2f}")

    # Step 1: Layer Attribution
    print("\n📊 Step 1: Layer Attribution Analysis")
    attribution = run_layer_attribution(trades)
    strong = [(k, v) for k, v in attribution.items() if v["quality"] == "STRONG"]
    weak   = [(k, v) for k, v in attribution.items() if v["quality"] == "WEAK"]
    print(f"   STRONG layers ({len(strong)}): {[s[0] for s in strong[:5]]}")
    print(f"   WEAK layers   ({len(weak)}): {[w[0] for w in weak[:5]]}")

    # Step 2: Optuna
    print("\n🔍 Step 2: Optuna Threshold Optimization (300 trials)")
    optuna_best = run_optuna_full(trades, n_trials=300)

    # Step 3: Kelly
    print("\n💰 Step 3: Kelly Fraction Optimization")
    kelly_result = run_kelly_optimization(trades)

    # Step 4: Apply & Save
    print("\n💾 Step 4: Applying Results")
    apply_results(optuna_best, kelly_result)

    # Step 5: GitHub
    if push_to_github:
        print("\n🐙 Step 5: Pushing to GitHub")
        from ml.github_sync import push_model
        success = push_model(
            f"Tuning update | WR={wr:.1f}% | Sharpe={sharpe:.3f}"
        )
        print(f"   GitHub push: {'✅ OK' if success else '⚠️ Skipped (set GITHUB_REPO_URL)'}")

    print("\n" + "=" * 55)
    print("  TUNING COMPLETE")
    print("=" * 55)


if __name__ == "__main__":
    import argparse
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s: %(message)s")
    p = argparse.ArgumentParser()
    p.add_argument("--github", action="store_true", help="Push to GitHub after tuning")
    p.add_argument("--trials", type=int, default=300, help="Optuna trials")
    args = p.parse_args()
    run_full_tuning(push_to_github=args.github)
