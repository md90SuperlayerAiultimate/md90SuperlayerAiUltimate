"""
evolution/engine.py — 6-Step Self-Evolution Engine
Phantom AI pattern: Observe→Critique→Propose→Validate→Apply→Verify
LLM Judge validates BEFORE any change is applied.
Bot cannot modify itself without explicit LLM approval.
"""
import json, logging, os, time
from datetime import datetime, timezone, timedelta
from typing import Optional

log = logging.getLogger("MD90.Evolution")
WITA = timezone(timedelta(hours=8))
EVO_FILE = os.getenv("EVOLUTION_LOG", "data/evolution_log.json")


class SelfEvolutionEngine:
    """
    6-step validated self-evolution.
    Runs after every N trades or when performance degrades.
    """
    def __init__(self, llm_agent=None):
        self._agent = llm_agent
        self._history = self._load()

    def _load(self) -> list:
        try:
            if os.path.exists(EVO_FILE):
                return json.loads(open(EVO_FILE).read())
        except: pass
        return []

    def _save(self):
        os.makedirs(os.path.dirname(EVO_FILE) if os.path.dirname(EVO_FILE) else ".", exist_ok=True)
        with open(EVO_FILE,"w") as f:
            json.dump(self._history[-50:], f, indent=2)

    async def evolve(self, cycle_result: dict, current_cfg: dict) -> dict:
        """
        Main entry point. Run after every 20 trades.
        Returns: {"applied":bool, "changes":dict, "reasoning":str}
        """
        t0 = time.time()
        log.info("[EVO] Starting evolution cycle...")

        # Step 1: OBSERVE
        obs = self._observe(cycle_result)
        log.info(f"[EVO] 1-OBSERVE: wr={obs['win_rate']:.1f}% pf={obs['profit_factor']:.2f}")

        # Step 2: CRITIQUE
        critique = self._critique(obs)
        log.info(f"[EVO] 2-CRITIQUE: {critique['issue']}")

        if not critique["needs_change"]:
            log.info("[EVO] Performance OK — no evolution needed")
            return {"applied":False,"changes":{},"reason":"performance_ok"}

        # Step 3: PROPOSE
        proposal = self._propose(critique, current_cfg)
        log.info(f"[EVO] 3-PROPOSE: {proposal}")

        # Step 4: VALIDATE (LLM Judge)
        valid, reason = await self._validate(proposal, obs, current_cfg)
        log.info(f"[EVO] 4-VALIDATE: {'PASS' if valid else 'FAIL'} — {reason}")

        if not valid:
            return {"applied":False,"changes":{},"reason":f"validation_failed:{reason}"}

        # Step 5: APPLY
        applied = self._apply(proposal, current_cfg)
        log.info(f"[EVO] 5-APPLY: {applied}")

        # Step 6: VERIFY
        ok = self._verify(applied)
        log.info(f"[EVO] 6-VERIFY: {'OK' if ok else 'ROLLBACK'}")

        if not ok:
            return {"applied":False,"changes":{},"reason":"verify_failed_rollback"}

        record = {
            "ts":       datetime.now(WITA).isoformat(),
            "obs":      obs, "critique":critique,
            "proposal": proposal, "applied":applied,
            "duration_ms": round((time.time()-t0)*1000),
        }
        self._history.append(record)
        self._save()
        log.info(f"[EVO] ✅ Evolution applied in {record['duration_ms']}ms")
        return {"applied":True,"changes":applied,"reason":reason}

    def _observe(self, r: dict) -> dict:
        trades = r.get("trades",[])
        pnls   = [t.get("pnl",0) for t in trades] if trades else r.get("recent_pnls",[])
        wins   = sum(1 for p in pnls if p > 0)
        total  = len(pnls) or 1
        gp     = sum(p for p in pnls if p>0)
        gl     = abs(sum(p for p in pnls if p<0)) or 1e-9
        return {
            "win_rate":      round(wins/total*100,2),
            "profit_factor": round(gp/gl,3),
            "total_pnl":     round(sum(pnls),2),
            "trade_count":   total,
            "avg_pnl":       round(sum(pnls)/total,4),
        }

    def _critique(self, obs: dict) -> dict:
        wr = obs["win_rate"]; pf = obs["profit_factor"]
        if wr < 45 and pf < 1.0:
            return {"needs_change":True,"issue":"LOW_WR_AND_PF",
                    "severity":"HIGH","target_param":"fusion_score_min"}
        if wr < 50:
            return {"needs_change":True,"issue":"LOW_WIN_RATE",
                    "severity":"MEDIUM","target_param":"confidence_min"}
        if pf < 1.2:
            return {"needs_change":True,"issue":"LOW_PROFIT_FACTOR",
                    "severity":"MEDIUM","target_param":"min_persistence"}
        return {"needs_change":False,"issue":"PERFORMANCE_OK","severity":"NONE"}

    def _propose(self, critique: dict, cfg: dict) -> dict:
        param = critique.get("target_param","fusion_score_min")
        sev   = critique.get("severity","LOW")
        delta = {"HIGH":0.05,"MEDIUM":0.03,"LOW":0.01}.get(sev,0.02)
        current = float(cfg.get(param, 0.55))
        proposed = round(min(0.85, current + delta), 4)
        return {"param":param,"old_value":current,"new_value":proposed,"delta":delta}

    async def _validate(self, proposal: dict, obs: dict, cfg: dict) -> tuple:
        """LLM Judge: validates proposal before applying."""
        if self._agent:
            try:
                ctx = {
                    "fusion_status": "WAITING", "regime": "RANGING",
                    "persistence": 5, "clusters": 0, "network_score": 0.5,
                    "bayesian_prior": 0.5, "confidence": 60,
                    "fusion_score": 0.5, "gate1":False,"gate2":False,"gate3":False,
                    "hmm_prob": 0.5, "drawdown": 0,
                    "question": f"Evolution proposal: increase {proposal['param']} "
                                f"from {proposal['old_value']} to {proposal['new_value']}. "
                                f"Current WR={obs['win_rate']:.1f}% PF={obs['profit_factor']:.2f}. "
                                f"Should this change be applied? Reply EXECUTE=yes or MONITOR=no.",
                    "market_prob": 0.5, "edge": 0.1, "edge_pct": 10, "news":"",
                }
                decision = self._agent.decide(ctx)
                if decision.get("action") == "EXECUTE":
                    return True, decision.get("reasoning","LLM approved")
                return False, decision.get("reasoning","LLM rejected")
            except Exception as e:
                log.warning(f"LLM judge error: {e}")
        # Rule-based fallback: approve if WR < 55%
        if obs["win_rate"] < 55:
            return True, f"rule_based: WR={obs['win_rate']:.1f}% < 55%"
        return False, f"rule_based: WR={obs['win_rate']:.1f}% OK"

    def _apply(self, proposal: dict, cfg: dict) -> dict:
        cfg[proposal["param"]] = proposal["new_value"]
        return {proposal["param"]: proposal["new_value"]}

    def _verify(self, applied: dict) -> bool:
        for k, v in applied.items():
            if not isinstance(v, (int,float)): return False
            if v <= 0 or v > 10: return False
        return True
