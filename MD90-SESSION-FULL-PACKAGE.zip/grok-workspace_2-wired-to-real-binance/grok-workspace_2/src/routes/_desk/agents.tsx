import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Panel } from "@/components/panels";
import { Button } from "@/components/ui/button";
import { askDeskBrief } from "@/lib/md90/brief";
import { agentVotes } from "@/lib/md90/engine";
import { copy } from "@/lib/md90/i18n";
import { useDesk } from "@/lib/md90/store";

export const Route = createFileRoute("/_desk/agents")({ component: Agents });

function Agents() {
  const locale = useDesk((s) => s.locale);
  const t = copy[locale];
  const fusion = useDesk((s) => s.fusion);
  const instrumentId = useDesk((s) => s.instrumentId);
  const votes = fusion ? agentVotes(fusion.layers) : [];
  const bull = votes.filter((v) => v.direction === "BUY");
  const bear = votes.filter((v) => v.direction === "SELL");
  const [brief, setBrief] = useState<string>("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function runBrief() {
    if (!fusion || busy) return;
    setBusy(true);
    setErr(null);
    const prompt = `Instrument ${instrumentId}. Fusion ${fusion.fusionScore.toFixed(2)} ${fusion.direction} conf ${fusion.confidence.toFixed(0)} status ${fusion.status} regime ${fusion.regime.name}. Layers: ${fusion.layers.map((l) => `${l.name}:${l.direction}:${l.strength.toFixed(2)}`).join(", ")}. Write a 6-line paper-only desk brief.`;
    const result = await askDeskBrief({ data: { prompt } });
    if (!result.ok) setErr(result.error);
    else setBrief(result.text);
    setBusy(false);
  }

  return (
    <div className="space-y-5">
      <div>
        <p className="font-mono text-xs tracking-[0.18em] text-accent">{t.agents}</p>
        <h1 className="mt-1 text-3xl font-medium tracking-tight">See the debate, not only BUY/SELL</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted">
          Five layer agents from MD90 MarketMind. Bull and bear desks argue from evidence. Optional Grok brief is
          user-initiated and advisory.
        </p>
      </div>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        {votes.map((v) => (
          <div key={v.name} className="rounded-lg border border-border bg-surface p-4">
            <div className="font-mono text-xs text-subtle">{v.name.replace("_", " ")}</div>
            <div
              className={
                v.direction === "BUY"
                  ? "mt-2 text-lg text-long"
                  : v.direction === "SELL"
                    ? "mt-2 text-lg text-short"
                    : "mt-2 text-lg text-muted"
              }
            >
              {v.direction === "NEUTRAL" ? "—" : v.direction}
            </div>
            <div className="mt-1 font-mono text-xs text-subtle">{(v.conviction * 100).toFixed(0)} conv</div>
            <p className="mt-3 text-xs leading-relaxed text-muted">{v.notes[0]}</p>
          </div>
        ))}
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel kicker="BULL" title={`Researchers ${bull.length}`}>
          <ul className="space-y-2 text-sm">
            {bull.length ? bull.map((v) => <li key={v.name}>{v.notes.join(" · ")}</li>) : <li className="text-muted">No bull case yet.</li>}
          </ul>
        </Panel>
        <Panel kicker="BEAR" title={`Researchers ${bear.length}`}>
          <ul className="space-y-2 text-sm">
            {bear.length ? bear.map((v) => <li key={v.name}>{v.notes.join(" · ")}</li>) : <li className="text-muted">No bear case yet.</li>}
          </ul>
        </Panel>
      </div>
      <Panel
        kicker="RESEARCH MANAGER"
        title="Grok brief"
        action={
          <Button size="sm" disabled={busy || !fusion} onClick={runBrief}>
            {busy ? "Running…" : "Run brief"}
          </Button>
        }
      >
        {err ? <p className="text-sm text-short">{err}</p> : null}
        {brief ? <p className="whitespace-pre-wrap text-sm leading-relaxed text-muted">{brief}</p> : <p className="text-sm text-muted">No model call until you ask. Deterministic agents remain the source of truth.</p>}
      </Panel>
    </div>
  );
}
