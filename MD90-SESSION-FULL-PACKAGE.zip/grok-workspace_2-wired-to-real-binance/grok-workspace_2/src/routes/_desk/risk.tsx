import { createFileRoute } from "@tanstack/react-router";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Panel } from "@/components/panels";
import { Button } from "@/components/ui/button";
import { dailyLossPct, drawdownPct, kellyFraction } from "@/lib/md90/paper";
import { copy } from "@/lib/md90/i18n";
import { useDesk } from "@/lib/md90/store";
import { formatUsd, pct } from "@/lib/utils";

export const Route = createFileRoute("/_desk/risk")({ component: RiskLab });

function RiskLab() {
  const locale = useDesk((s) => s.locale);
  const t = copy[locale];
  const account = useDesk((s) => s.account);
  const curve = useDesk((s) => s.equityCurve);
  const fusion = useDesk((s) => s.fusion);
  const risk = useDesk((s) => s.riskChecks);
  const dd = useDesk((s) => drawdownPct(s.account));
  const daily = useDesk((s) => dailyLossPct(s.account));
  const resetPaper = useDesk((s) => s.resetPaper);
  const fills = useDesk((s) => s.fills);
  const wins = fills.filter((f) => f.note.startsWith("TP")).length;
  const losses = fills.filter((f) => f.note === "Stop hit").length;
  const wr = wins + losses ? wins / (wins + losses) : 0;
  const kelly = kellyFraction(wr || 0.45, fusion?.riskReward[0] ?? 2);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="font-mono text-xs tracking-[0.18em] text-accent">{t.risk}</p>
          <h1 className="mt-1 text-3xl font-medium tracking-tight">Survivor caps</h1>
          <p className="mt-2 max-w-xl text-sm text-muted">
            Daily 3% · drawdown 10% · 3 consecutive · 8 trades/day · live route disabled.
          </p>
        </div>
        <Button variant="ghost" onClick={resetPaper}>
          Reset paper ledger
        </Button>
      </div>
      <div className="grid gap-3 sm:grid-cols-4">
        <Box label="Equity" value={formatUsd(account.equity)} />
        <Box label="Daily loss" value={pct(daily)} hot={daily >= 3} />
        <Box label="Drawdown" value={pct(dd)} hot={dd >= 10} />
        <Box label="Kelly (capped)" value={pct(kelly * 100)} />
      </div>
      <Panel kicker="EQUITY" title="Paper curve">
        <div className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={curve}>
              <XAxis dataKey="t" hide />
              <YAxis hide domain={["auto", "auto"]} />
              <Tooltip
                contentStyle={{
                  background: "var(--color-surface)",
                  border: "1px solid var(--color-border)",
                  fontSize: 12,
                  color: "var(--color-fg)",
                }}
                labelFormatter={() => "equity"}
                formatter={(v: number) => formatUsd(v)}
              />
              <Area type="monotone" dataKey="equity" stroke="var(--color-accent)" fill="color-mix(in oklab, var(--color-accent) 20%, transparent)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </Panel>
      <Panel kicker="BREAKERS" title="Pre-trade checks">
        <ul className="grid gap-2 sm:grid-cols-2">
          {risk.map((row) => (
            <li key={row.code} className="flex items-start justify-between rounded-md bg-elevated px-3 py-3">
              <span>
                <span className="block text-sm">{row.label}</span>
                <span className="text-xs text-muted">{row.detail}</span>
              </span>
              <span className={row.ok ? "font-mono text-xs text-long" : "font-mono text-xs text-short"}>
                {row.ok ? "PASS" : "TRIP"}
              </span>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}

function Box({ label, value, hot }: { label: string; value: string; hot?: boolean }) {
  return (
    <div className="rounded-lg border border-border bg-surface px-4 py-3">
      <div className="font-mono text-xs text-subtle">{label}</div>
      <div className={hot ? "mt-1 font-mono text-xl text-short" : "mt-1 font-mono text-xl"}>{value}</div>
    </div>
  );
}
