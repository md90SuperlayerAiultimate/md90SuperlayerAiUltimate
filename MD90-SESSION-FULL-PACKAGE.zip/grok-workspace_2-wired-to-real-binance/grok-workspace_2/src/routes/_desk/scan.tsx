import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { Panel } from "@/components/panels";
import { Button } from "@/components/ui/button";
import { copy } from "@/lib/md90/i18n";
import { COPY_TEMPLATES, SCANNER_REGISTRY, scanArb } from "@/lib/md90/scan";
import { useDesk } from "@/lib/md90/store";
import { dash, pct } from "@/lib/utils";

export const Route = createFileRoute("/_desk/scan")({ component: ScanDesk });

function ScanDesk() {
  const locale = useDesk((s) => s.locale);
  const t = copy[locale];
  const markets = useDesk((s) => s.markets);
  const applyCopy = useDesk((s) => s.applyCopy);
  const submitClob = useDesk((s) => s.submitClob);
  const submitPaper = useDesk((s) => s.submitPaper);
  const radar = useDesk((s) => s.radar);
  const setInstrument = useDesk((s) => s.setInstrument);
  const gaps = scanArb(markets);

  return (
    <div className="space-y-5">
      <div>
        <p className="font-mono text-xs tracking-[0.18em] text-accent">{t.scan}</p>
        <h1 className="mt-1 text-3xl font-medium tracking-tight">
          {locale === "ID" ? "Pindai, jangan kejar." : "Scan, don't chase."}
        </h1>
        <p className="mt-2 max-w-2xl text-sm text-muted">
          {locale === "ID"
            ? "Arb YES+NO, template copy paper, dan registry scanner. Live copy dan wallet tetap terkunci."
            : "YES+NO arb, paper copy templates, and the scanner registry. Live copy and wallets stay locked."}
        </p>
      </div>

      <Panel kicker={t.radar} title={locale === "ID" ? "Deteksi 17-layer · 5 simbol" : "17-layer detect · 5 symbols"}>
        {radar.length === 0 ? (
          <p className="text-sm text-muted">Radar booting…</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="font-mono text-xs text-subtle">
                <tr>
                  <th className="pb-2">Sym</th>
                  <th className="pb-2">Dir</th>
                  <th className="pb-2">Score</th>
                  <th className="pb-2">Conf</th>
                  <th className="pb-2">Gates</th>
                  <th className="pb-2">Status</th>
                  <th className="pb-2">Action</th>
                </tr>
              </thead>
              <tbody>
                {radar.map((hit) => (
                  <tr key={hit.id} className="border-t border-border">
                    <td className="py-3 pr-3">
                      <button className="font-mono text-xs text-fg" onClick={() => setInstrument(hit.id)}>
                        {hit.id}
                      </button>
                    </td>
                    <td className={hit.direction === "BUY" ? "font-mono text-long" : hit.direction === "SELL" ? "font-mono text-short" : "font-mono text-subtle"}>
                      {hit.direction === "NEUTRAL" ? "—" : hit.direction}
                    </td>
                    <td className="font-mono tabular-nums">{hit.score.toFixed(2)}</td>
                    <td className="font-mono tabular-nums">{hit.confidence.toFixed(0)}</td>
                    <td className="font-mono">{hit.gatesPassed}/5</td>
                    <td className={hit.candidate ? "font-mono text-xs text-accent" : "font-mono text-xs text-subtle"}>
                      {hit.candidate ? "ARM" : hit.status}
                    </td>
                    <td>
                      <Button
                        size="sm"
                        variant="quiet"
                        disabled={!hit.candidate}
                        onClick={() => toast(submitPaper({ mode: "AUTO", hit }))}
                      >
                        {hit.candidate ? "PAPER" : "HOLD"}
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>

      <Panel kicker="YES+NO" title="Simulated CLOB gap">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="font-mono text-xs text-subtle">
              <tr>
                <th className="pb-2">Market</th>
                <th className="pb-2">YES</th>
                <th className="pb-2">NO</th>
                <th className="pb-2">Sum</th>
                <th className="pb-2">Gap</th>
                <th className="pb-2">Action</th>
              </tr>
            </thead>
            <tbody>
              {gaps.map((g) => (
                <tr key={g.slug} className="border-t border-border">
                  <td className="py-3 pr-3">{g.question}</td>
                  <td className="font-mono text-long">{g.yes.toFixed(2)}</td>
                  <td className="font-mono text-short">{g.no.toFixed(2)}</td>
                  <td className="font-mono">{dash(g.sum, 3)}</td>
                  <td className="font-mono text-xs">{g.gapBps} bps</td>
                  <td>
                    {g.side === "NONE" ? (
                      <span className="font-mono text-xs text-subtle">—</span>
                    ) : (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          const result = submitClob(g.slug, "YES", 75);
                          toast(`${g.side} · ${result}`);
                        }}
                      >
                        {g.side}
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>

      <div className="grid gap-4 lg:grid-cols-2">
        <Panel kicker="COPY" title="Paper templates">
          <ul className="space-y-3">
            {COPY_TEMPLATES.map((row) => (
              <li key={row.id} className="flex items-start justify-between gap-3 border-b border-border pb-3">
                <div>
                  <div className="text-sm">{row.name}</div>
                  <div className="text-xs text-muted">
                    {row.source} · {pct(row.riskPct, 1)} risk
                  </div>
                  <div className="mt-1 text-xs text-subtle">{row.note}</div>
                </div>
                <Button
                  size="sm"
                  variant={row.status === "BLOCKED" ? "ghost" : "quiet"}
                  disabled={row.status === "BLOCKED"}
                  onClick={() => toast(applyCopy(row.id))}
                >
                  {row.status}
                </Button>
              </li>
            ))}
          </ul>
        </Panel>
        <Panel kicker="REGISTRY" title="Scanner families">
          <ul className="space-y-3">
            {SCANNER_REGISTRY.map((row) => (
              <li key={row.name} className="grid gap-1 sm:grid-cols-[1fr_7rem]">
                <div>
                  <div className="text-sm">{row.name}</div>
                  <div className="text-xs text-muted">
                    {row.family} · {row.note}
                  </div>
                </div>
                <span
                  className={
                    row.status === "BLOCKED"
                      ? "font-mono text-xs text-short"
                      : row.status === "SHADOW" || row.status === "PENDING"
                        ? "font-mono text-xs text-warn"
                        : "font-mono text-xs text-long"
                  }
                >
                  {row.status}
                </span>
              </li>
            ))}
          </ul>
        </Panel>
      </div>
    </div>
  );
}
