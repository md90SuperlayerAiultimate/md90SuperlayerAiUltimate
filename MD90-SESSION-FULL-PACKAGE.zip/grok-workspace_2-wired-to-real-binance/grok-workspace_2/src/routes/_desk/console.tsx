import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Panel } from "@/components/panels";
import { CLI_HELP } from "@/lib/md90/cli";
import { copy } from "@/lib/md90/i18n";
import { useDesk } from "@/lib/md90/store";

export const Route = createFileRoute("/_desk/console")({ component: ConsoleDesk });

function ConsoleDesk() {
  const locale = useDesk((s) => s.locale);
  const t = copy[locale];
  const lines = useDesk((s) => s.consoleLines);
  const runCommand = useDesk((s) => s.runCommand);
  const navigate = useNavigate();
  const [value, setValue] = useState("");

  function submit() {
    const raw = value.trim();
    if (!raw) return;
    const parsed = runCommand(raw);
    if (parsed.ok && parsed.action.type === "goto") void navigate({ to: parsed.action.path });
    if (parsed.ok && parsed.action.type === "scan") void navigate({ to: "/scan" });
    if (parsed.ok && parsed.action.type === "lab") void navigate({ to: "/replay" });
    setValue("");
  }

  return (
    <div className="space-y-5">
      <div>
        <p className="font-mono text-xs tracking-[0.18em] text-accent">{t.console}</p>
        <h1 className="mt-1 text-3xl font-medium tracking-tight">polyterm · honest tape</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted">
          {t.noLive} Commands mutate the paper ledger only.
        </p>
      </div>
      <Panel kicker="REPL" title="md90>">
        <div className="mb-4 max-h-80 overflow-auto rounded-md bg-elevated p-3 font-mono text-xs leading-relaxed">
          {lines.map((line, i) => (
            <div
              key={`${line.ts}-${i}`}
              className={
                line.kind === "in" ? "text-accent" : line.kind === "err" ? "text-short" : "text-muted"
              }
            >
              <span className="text-subtle">{line.kind === "in" ? ">" : "·"} </span>
              <span className="whitespace-pre-wrap">{line.text}</span>
            </div>
          ))}
        </div>
        <input
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") submit();
          }}
          placeholder="help · paper · lab · scan · clob btc-15m-up YES 100"
          className="h-12 w-full rounded-md border border-border bg-bg px-3 font-mono text-sm text-fg outline-none"
        />
      </Panel>
      <Panel kicker="HELP" title="Surface, not a second engine">
        <pre className="overflow-x-auto font-mono text-xs leading-relaxed text-muted">{CLI_HELP.join("\n")}</pre>
      </Panel>
    </div>
  );
}
