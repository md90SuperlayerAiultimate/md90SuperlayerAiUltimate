import { createFileRoute } from "@tanstack/react-router";
import { Panel } from "@/components/panels";
import { copy } from "@/lib/md90/i18n";
import { useDesk } from "@/lib/md90/store";
import { dash, formatClock, formatUsd } from "@/lib/utils";

export const Route = createFileRoute("/_desk/journal")({ component: Journal });

function Journal() {
  const locale = useDesk((s) => s.locale);
  const t = copy[locale];
  const journal = useDesk((s) => s.journal);
  const fills = useDesk((s) => s.fills);
  const clobFills = useDesk((s) => s.clobFills);
  const positions = useDesk((s) => s.positions);

  return (
    <div className="space-y-5">
      <div>
        <p className="font-mono text-xs tracking-[0.18em] text-accent">{t.journal}</p>
        <h1 className="mt-1 text-3xl font-medium tracking-tight">Every claim has a trail</h1>
      </div>
      <Panel kicker="POSITIONS" title="Paper book">
        {positions.length === 0 ? (
          <p className="text-sm text-muted">No open or historic paper positions in this browser ledger.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="font-mono text-xs text-subtle">
                <tr>
                  <th className="pb-2">Symbol</th>
                  <th className="pb-2">Side</th>
                  <th className="pb-2">Qty</th>
                  <th className="pb-2">Entry</th>
                  <th className="pb-2">Status</th>
                  <th className="pb-2">uPnL</th>
                </tr>
              </thead>
              <tbody>
                {positions.map((p) => (
                  <tr key={p.id} className="border-t border-border font-mono text-xs">
                    <td className="py-2">{p.symbol}</td>
                    <td className={p.side === "BUY" ? "text-long" : "text-short"}>{p.side}</td>
                    <td>{dash(p.qty, 4)}</td>
                    <td>{dash(p.entry, 2)}</td>
                    <td>{p.status}</td>
                    <td className={p.unrealized >= 0 ? "text-long" : "text-short"}>{formatUsd(p.unrealized)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel kicker={t.tape} title="Fills">
          {fills.length === 0 && clobFills.length === 0 ? (
            <p className="text-sm text-muted">Tape empty.</p>
          ) : (
            <ul className="space-y-2">
              {fills.map((f) => (
                <li key={f.id} className="flex flex-wrap justify-between gap-2 font-mono text-xs">
                  <span className={f.side === "BUY" ? "text-long" : "text-short"}>{f.side}</span>
                  <span>{f.symbol}</span>
                  <span>{dash(f.price, 2)}</span>
                  <span className="text-subtle">{f.note}</span>
                </li>
              ))}
              {clobFills.map((f) => (
                <li key={f.id} className="flex flex-wrap justify-between gap-2 font-mono text-xs">
                  <span className={f.side === "YES" ? "text-long" : "text-short"}>{f.side}</span>
                  <span>{f.slug}</span>
                  <span>{dash(f.avgPrice, 3)}</span>
                  <span className="text-subtle">{f.note}</span>
                </li>
              ))}
            </ul>
          )}
        </Panel>
        <Panel kicker="EVENTS" title="Decision log">
          {journal.length === 0 ? (
            <p className="text-sm text-muted">No events yet.</p>
          ) : (
            <ul className="space-y-3">
              {journal.map((e, i) => (
                <li key={`${e.ts}-${i}`}>
                  <div className="font-mono text-xs text-accent">{e.event}</div>
                  <p className="text-sm text-muted">{e.detail}</p>
                  <div className="font-mono text-xs text-subtle">{formatClock(e.ts)}</div>
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>
    </div>
  );
}
