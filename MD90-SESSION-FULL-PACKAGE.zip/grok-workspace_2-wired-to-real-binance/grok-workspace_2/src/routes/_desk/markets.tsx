import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { Panel } from "@/components/panels";
import { Button } from "@/components/ui/button";
import { copy } from "@/lib/md90/i18n";
import { useDesk } from "@/lib/md90/store";
import { dash, formatClock } from "@/lib/utils";

export const Route = createFileRoute("/_desk/markets")({ component: Markets });

function Markets() {
  const locale = useDesk((s) => s.locale);
  const t = copy[locale];
  const markets = useDesk((s) => s.markets);
  const clobFills = useDesk((s) => s.clobFills);
  const submitClob = useDesk((s) => s.submitClob);

  return (
    <div className="space-y-5">
      <div>
        <p className="font-mono text-xs tracking-[0.18em] text-accent">{t.markets}</p>
        <h1 className="mt-1 text-3xl font-medium tracking-tight">CLOB watch · no keys</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted">
          {t.noLive} {t.lagged} {t.outage} Feed label is always <span className="text-fg">sim_book</span>.
        </p>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        {markets.map((m) => (
          <Panel
            key={m.slug}
            kicker={`${m.category} · ${m.feed}`}
            title={m.question}
            action={
              <span className="font-mono text-xs text-subtle">{m.resolution === "none" ? "—" : m.resolution}</span>
            }
          >
            <div className="mb-4 grid grid-cols-3 gap-3">
              <Stat label="YES" value={m.yes.toFixed(2)} tone="long" />
              <Stat label="NO" value={m.no.toFixed(2)} tone="short" />
              <Stat label="Spread" value={m.spread.toFixed(3)} />
            </div>
            <div className="grid grid-cols-2 gap-4 font-mono text-xs">
              <div>
                <div className="mb-2 text-subtle">BIDS</div>
                {m.bids.length ? (
                  m.bids.map((b, i) => (
                    <div key={i} className="flex justify-between text-long">
                      <span>{b.price.toFixed(2)}</span>
                      <span>{b.size}</span>
                    </div>
                  ))
                ) : (
                  <div className="text-muted">—</div>
                )}
              </div>
              <div>
                <div className="mb-2 text-subtle">ASKS</div>
                {m.asks.length ? (
                  m.asks.map((a, i) => (
                    <div key={i} className="flex justify-between text-short">
                      <span>{a.price.toFixed(2)}</span>
                      <span>{a.size}</span>
                    </div>
                  ))
                ) : (
                  <div className="text-muted">—</div>
                )}
              </div>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <Button
                size="sm"
                onClick={() => toast(`YES · ${submitClob(m.slug, "YES", 100)}`)}
              >
                Paper YES 100
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => toast(`NO · ${submitClob(m.slug, "NO", 100)}`)}
              >
                Paper NO 100
              </Button>
            </div>
            <div className="mt-4 border-t border-border pt-3">
              <div className="mb-2 font-mono text-xs text-subtle">{t.lagged}</div>
              {m.laggedPrints.length === 0 ? (
                <p className="text-sm text-muted">prints this session: 0</p>
              ) : (
                m.laggedPrints.map((p) => (
                  <div key={p.ts} className="flex justify-between font-mono text-xs text-muted">
                    <span>{p.side}</span>
                    <span>{dash(p.price, 2)}</span>
                    <span>{p.size}</span>
                    <span>lag=true</span>
                    <span>{formatClock(p.ts).slice(11, 19)}</span>
                  </div>
                ))
              )}
            </div>
          </Panel>
        ))}
      </div>
      <Panel kicker="CLOB TAPE" title="Paper fills">
        {clobFills.length === 0 ? (
          <p className="text-sm text-muted">Empty CLOB tape. Outage stays empty.</p>
        ) : (
          <ul className="space-y-2 font-mono text-xs">
            {clobFills.map((f) => (
              <li key={f.id} className="flex flex-wrap justify-between gap-2">
                <span className={f.side === "YES" ? "text-long" : "text-short"}>{f.side}</span>
                <span>{f.slug}</span>
                <span>{dash(f.avgPrice, 3)}</span>
                <span>{dash(f.shares, 2)} sh</span>
                <span className="text-subtle">{f.note}</span>
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone?: "long" | "short" }) {
  return (
    <div>
      <div className="font-mono text-xs text-subtle">{label}</div>
      <div
        className={
          tone === "long"
            ? "font-mono text-2xl text-long"
            : tone === "short"
              ? "font-mono text-2xl text-short"
              : "font-mono text-2xl"
        }
      >
        {value}
      </div>
    </div>
  );
}
