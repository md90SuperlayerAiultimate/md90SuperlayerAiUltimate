import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { CandleChart } from "@/components/candle-chart";
import { Panel } from "@/components/panels";
import { Button } from "@/components/ui/button";
import { copy } from "@/lib/md90/i18n";
import { LAB_STRATEGIES } from "@/lib/md90/lab";
import { useDesk } from "@/lib/md90/store";
import { cn, dash, pct } from "@/lib/utils";

export const Route = createFileRoute("/_desk/replay")({ component: LabDesk });

const STAGE_TONE: Record<string, string> = {
  raw: "text-fg",
  normalized: "text-muted",
  features: "text-accent",
  weights: "text-warn",
  pnl: "text-long",
};

function LabDesk() {
  const locale = useDesk((s) => s.locale);
  const t = copy[locale];
  const candles = useDesk((s) => s.candles);
  const fusion = useDesk((s) => s.fusion);
  const replayIndex = useDesk((s) => s.replayIndex);
  const setReplay = useDesk((s) => s.setReplay);
  const lab = useDesk((s) => s.lab);
  const runLab = useDesk((s) => s.runLab);
  const lastPrice = useDesk((s) => s.lastPrice);
  const max = 180;

  useEffect(() => {
    if (!useDesk.getState().lab) useDesk.getState().runLab();
  }, []);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="font-mono text-xs tracking-[0.18em] text-accent">{t.lab}</p>
          <h1 className="mt-1 text-3xl font-medium tracking-tight">
            {locale === "ID" ? "Tabel adalah node. Step adalah tepi." : "The table is the node. The step is the edge."}
          </h1>
          <p className="mt-2 max-w-2xl text-sm text-muted">
            {locale === "ID"
              ? "Pipeline Qanat: raw → normalized → features → weights → pnl. Net adalah headline, bukan gross. Bobot bukan order."
              : "Qanat pipeline: raw → normalized → features → weights → pnl. Net is the headline, not gross. Weights are not orders."}
          </p>
        </div>
        <Button onClick={runLab}>{locale === "ID" ? "Jalankan walk-forward" : "Run walk-forward"}</Button>
      </div>

      <Panel kicker="CURSOR" title={`Bar ${replayIndex ?? candles.length}`}>
        <input
          type="range"
          min={40}
          max={max}
          value={replayIndex ?? candles.length}
          onChange={(e) => setReplay(Number(e.target.value))}
          className="w-full accent-accent"
        />
        <div className="mt-2 flex justify-between font-mono text-xs text-subtle">
          <span>40</span>
          <button className="text-accent" onClick={() => setReplay(null)}>
            Live simulated head
          </button>
          <span>{max}</span>
        </div>
      </Panel>

      <Panel kicker={fusion?.status ?? "—"} title={`${fusion?.direction ?? "WATCH"} ${dash(fusion?.entry, 2)}`}>
        <div className="h-64">
          <CandleChart candles={candles} smc={fusion?.smc ?? []} last={lastPrice || fusion?.entry} height={260} />
        </div>
      </Panel>

      {lab ? (
        <>
          <Panel kicker="DAG" title={`${lab.tables.length} tables · rebalance ${lab.rebalanceBars} · fee ${lab.feeBps}bps`}>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
              {lab.tables.map((table) => (
                <div key={table.name} className="rounded-lg border border-border bg-elevated p-3">
                  <div className={cn("font-mono text-xs tracking-[0.14em]", STAGE_TONE[table.stage])}>
                    {table.stage}
                  </div>
                  <div className="mt-1 text-sm">{table.name}</div>
                  <div className="font-mono text-xs text-subtle">
                    {table.step} · {table.rows} rows
                  </div>
                  <div className="mt-2 space-y-1 font-mono text-[11px] text-muted">
                    {table.preview.slice(0, 3).map((row, i) => (
                      <div key={i} className="truncate">
                        {Object.values(row).slice(0, 3).join(" · ")}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </Panel>
          <Panel kicker="NET" title="Believe the out-of-sample line">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="font-mono text-xs text-subtle">
                  <tr>
                    <th className="pb-2">Strategy</th>
                    <th className="pb-2">Gross</th>
                    <th className="pb-2">Fees</th>
                    <th className="pb-2">Slip</th>
                    <th className="pb-2">Net</th>
                    <th className="pb-2">Hit</th>
                    <th className="pb-2">IS</th>
                    <th className="pb-2">OOS</th>
                  </tr>
                </thead>
                <tbody>
                  {lab.totals.map((row) => {
                    const label = LAB_STRATEGIES.find((s) => s.id === row.strategy)?.label ?? row.strategy;
                    return (
                      <tr key={row.strategy} className="border-t border-border font-mono text-xs">
                        <td className="py-2">{label}</td>
                        <td>{pct(row.gross * 100, 2)}</td>
                        <td className="text-short">{pct(row.fees * 100, 2)}</td>
                        <td className="text-short">{pct(row.slippage * 100, 2)}</td>
                        <td className={row.net >= 0 ? "text-long" : "text-short"}>{pct(row.net * 100, 2)}</td>
                        <td>{pct(row.hitRate * 100, 0)}</td>
                        <td>{pct(row.inSampleNet * 100, 2)}</td>
                        <td>{pct(row.outSampleNet * 100, 2)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <ul className="mt-4 space-y-1 text-xs text-muted">
              {lab.notes.map((note) => (
                <li key={note}>{note}</li>
              ))}
            </ul>
          </Panel>
        </>
      ) : (
        <Panel kicker="IDLE" title="No walk-forward yet">
          <p className="text-sm text-muted">
            Run the lab to materialize the five-stage table graph. Synthetic universe, no API keys.
          </p>
        </Panel>
      )}
    </div>
  );
}
