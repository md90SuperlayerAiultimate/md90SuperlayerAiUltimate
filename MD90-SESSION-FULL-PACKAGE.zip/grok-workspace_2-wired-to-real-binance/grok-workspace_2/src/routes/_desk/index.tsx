import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Area, AreaChart, ResponsiveContainer } from "recharts";
import { toast } from "sonner";
import { CandleChart } from "@/components/candle-chart";
import { Kpi, Panel, QuoteTape, StageRail } from "@/components/panels";
import { Button } from "@/components/ui/button";
import { agentVotes, getInstrument } from "@/lib/md90/engine";
import { copy } from "@/lib/md90/i18n";
import { LAB_STRATEGIES } from "@/lib/md90/lab";
import { dailyLossPct, drawdownPct } from "@/lib/md90/paper";
import { simFlow, simHealth, simNews } from "@/lib/md90/shadow";
import { useDesk } from "@/lib/md90/store";
import { cn, dash, formatUsd, pct } from "@/lib/utils";

export const Route = createFileRoute("/_desk/")({ component: Overview });

function GrowingCurve({ points }: { points: { equity: number }[] }) {
  const [n, setN] = useState(2);
  useEffect(() => {
    setN(2);
    const id = window.setInterval(() => {
      setN((v) => (points.length < 2 ? 2 : v >= points.length ? 2 : v + 1));
    }, 280);
    return () => window.clearInterval(id);
  }, [points.length]);
  const data = points.slice(0, Math.max(2, Math.min(n, points.length))).map((p, i) => ({ i, eq: p.equity }));
  const last = data.at(-1)?.eq ?? 1;
  return (
    <div>
      <div className="mb-2 flex items-baseline justify-between font-mono text-xs">
        <span className="text-accent">
          LIVE REPLAY {data.length}/{points.length || 0}
        </span>
        <span className={last >= 1 ? "text-long" : "text-short"}>{last.toFixed(4)}</span>
      </div>
      <div className="h-36">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <Area
              type="monotone"
              dataKey="eq"
              stroke="var(--color-long)"
              fill="color-mix(in oklab, var(--color-long) 16%, transparent)"
              isAnimationActive={false}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function Overview() {
  const locale = useDesk((s) => s.locale);
  const t = copy[locale];
  const fusion = useDesk((s) => s.fusion);
  const candles = useDesk((s) => s.candles);
  const account = useDesk((s) => s.account);
  const fills = useDesk((s) => s.fills);
  const risk = useDesk((s) => s.riskChecks);
  const instrumentId = useDesk((s) => s.instrumentId);
  const operating = useDesk((s) => s.operating);
  const submitPaper = useDesk((s) => s.submitPaper);
  const lab = useDesk((s) => s.lab);
  const runLab = useDesk((s) => s.runLab);
  const autopilot = useDesk((s) => s.autopilot);
  const setAutopilot = useDesk((s) => s.setAutopilot);
  const radar = useDesk((s) => s.radar);
  const lastPrice = useDesk((s) => s.lastPrice);
  const lastTickAt = useDesk((s) => s.lastTickAt);
  const positions = useDesk((s) => s.positions);
  const tickTape = useDesk((s) => s.tickTape);
  const priceSpark = useDesk((s) => s.priceSpark);
  const tickSeq = useDesk((s) => s.tickSeq);
  const labStatus = useDesk((s) => s.labStatus);
  const ensureLab = useDesk((s) => s.ensureLab);
  const curve = useDesk((s) => s.equityCurve);
  const digits = getInstrument(instrumentId).digits;
  const printDelta = tickTape[0]?.delta ?? 0;
  const open = positions.filter((p) => p.status !== "CLOSED");
  const clear = risk.length > 0 && risk.every((r) => r.ok);
  const dirTone = fusion?.direction === "BUY" ? "long" : fusion?.direction === "SELL" ? "short" : "warn";
  const wins = fills.filter((f) => f.note.startsWith("TP")).length;
  const losses = fills.filter((f) => f.note === "Stop hit").length;
  const sample = wins + losses;
  const wr = sample ? (wins / sample) * 100 : null;
  const fees = fills.reduce((a, f) => a + f.fee, 0);
  const dd = drawdownPct(account);
  const daily = dailyLossPct(account);
  const votes = fusion ? agentVotes(fusion.layers) : [];
  const health = simHealth(lastTickAt);
  const news = simNews(lastTickAt || Date.now());
  const flow = simFlow(tickTape);
  const prior = candles.at(-2)?.c ?? lastPrice;
  const bt = lab?.curves.fusion ?? [];

  useEffect(() => {
    if (candles.length >= 56 && !lab && labStatus !== "running") ensureLab();
  }, [candles.length, lab, labStatus, ensureLab]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="font-mono text-xs tracking-[0.2em] text-accent">
            LIVE FLOOR · {t.simulated} · {t.liveLocked}
          </p>
          <h1 className="mt-1 text-2xl font-medium tracking-tight sm:text-3xl">
            {instrumentId}{" "}
            <em className={cn("not-italic", dirTone === "long" ? "text-long" : dirTone === "short" ? "text-short" : "text-muted")}>
              {fusion?.direction ?? "WATCH"} {fusion?.status ?? "BOOT"}
            </em>
          </h1>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant={autopilot === "PAPER" ? "primary" : "ghost"}
            onClick={() => setAutopilot(autopilot === "PAPER" ? "OFF" : "PAPER")}
          >
            {autopilot === "PAPER" ? t.disarm : t.arm}
          </Button>
          <Button
            variant="quiet"
            onClick={() => {
              const result = submitPaper({ mode: "AUTO" });
              toast(result === "FILLED" ? `${t.submitPaper} · FILLED` : `${t.blocked} · ${result}`);
            }}
          >
            {clear ? t.submitPaper : t.blocked}
          </Button>
          <Button variant="ghost" onClick={runLab}>
            Lab
          </Button>
        </div>
      </div>

      <QuoteTape
        symbol={instrumentId}
        last={lastPrice}
        prior={prior}
        digits={digits}
        spark={priceSpark}
        tickSeq={tickSeq}
        bid={lastPrice ? lastPrice * 0.99996 : 0}
        ask={lastPrice ? lastPrice * 1.00004 : 0}
      />

      <div className="grid gap-2 sm:grid-cols-3 lg:grid-cols-6">
        <Kpi
          label={t.lastPrint}
          value={dash(lastPrice, digits)}
          hint={`${printDelta >= 0 ? "+" : ""}${dash(printDelta, digits)} · ${instrumentId}`}
          tone={printDelta >= 0 ? "long" : "short"}
        />
        <Kpi label="Equity" value={formatUsd(account.equity, 0)} hint={`${formatUsd(fees, 2)} fees`} />
        <Kpi
          label="Daily"
          value={formatUsd(account.dailyPnl)}
          tone={account.dailyPnl >= 0 ? "long" : "short"}
          hint={`loss cap ${pct(daily)}`}
        />
        <Kpi label="Max DD" value={pct(dd)} hint="paper peak-to-trough" tone={dd >= 8 ? "short" : "fg"} />
        <Kpi
          label="Win / n"
          value={wr == null ? "—" : pct(wr, 0)}
          hint={sample ? `${wins}W ${losses}L · n=${sample}` : "n=0 · no fake ROI"}
        />
        <Kpi
          label="Fusion"
          value={fusion ? fusion.fusionScore.toFixed(2) : "—"}
          hint={fusion?.regime.name ?? "PENDING"}
          tone={dirTone}
        />
      </div>

      <div className="grid gap-3 lg:grid-cols-12">
        <Panel
          kicker={`${t.simulated} · ${instrumentId}`}
          title={`OHLC · SL/TP · last ${dash(lastPrice, digits)}`}
          className="lg:col-span-8"
          action={<span className="font-mono text-xs text-subtle">forming · SIM</span>}
        >
          <div className="h-96">
            <CandleChart
              candles={candles}
              smc={fusion?.smc ?? []}
              last={lastPrice || fusion?.entry}
              stop={open[0]?.stop ?? fusion?.stop}
              takeProfits={open[0]?.takeProfits ?? fusion?.takeProfits}
              entries={open.map((p) => ({ price: p.entry, side: p.side }))}
            />
          </div>
        </Panel>
        <Panel
          kicker={t.radar}
          title={`${radar.filter((r) => r.candidate).length} armed`}
          className="lg:col-span-4"
        >
          {radar.length === 0 ? (
            <p className="text-sm text-muted">Radar booting…</p>
          ) : (
            <ul className="space-y-2">
              {radar.map((hit) => (
                <li key={hit.id} className="flex items-center justify-between gap-2 font-mono text-xs">
                  <button className="min-h-10 text-left text-sm text-fg" onClick={() => useDesk.getState().setInstrument(hit.id)}>
                    {hit.id}
                  </button>
                  <span className={hit.direction === "BUY" ? "text-long" : hit.direction === "SELL" ? "text-short" : "text-subtle"}>
                    {hit.direction === "NEUTRAL" ? "—" : hit.direction}
                  </span>
                  <span className="tabular-nums">{hit.score.toFixed(2)}</span>
                  <span className={cn("text-subtle", hit.candidate && "text-accent")}>{hit.candidate ? "ARM" : hit.status}</span>
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>

      <Panel kicker="FSM" title={`${operating?.stage ?? "INGEST"} · ${operating?.outcome ?? "RUNNING"}`}>
        <StageRail current={operating?.stage ?? "INGEST"} events={operating?.events} />
        {operating?.events?.length ? (
          <p className="mt-3 font-mono text-xs text-muted">{operating.events.at(-1)?.detail}</p>
        ) : null}
      </Panel>

      <div className="grid gap-3 lg:grid-cols-12">
        <Panel kicker="EQUITY" title="Realized path" className="lg:col-span-4">
          <div className="h-36">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={curve}>
                <Area
                  type="monotone"
                  dataKey="equity"
                  stroke="var(--color-accent)"
                  fill="color-mix(in oklab, var(--color-accent) 18%, transparent)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <p className="mt-2 font-mono text-xs text-muted">
            {lab
              ? `Lab ${lab.runId} · fusion net ${pct((lab.totals.find((row) => row.strategy === "fusion")?.net ?? 0) * 100, 2)}`
              : "Curve is paper mark-to-market. Not a live P&L certificate."}
          </p>
        </Panel>
        <Panel kicker="BOOK" title={`${open.length} open`} className="lg:col-span-4">
          {open.length === 0 ? (
            <p className="text-sm text-muted">No open paper. Autopilot fills when radar arms.</p>
          ) : (
            <ul className="space-y-2">
              {open.map((p) => (
                <li key={p.id} className="flex min-h-10 items-center justify-between gap-2 font-mono text-xs">
                  <span className={p.side === "BUY" ? "text-long" : "text-short"}>{p.side}</span>
                  <span>{p.symbol}</span>
                  <span className="tabular-nums">{dash(p.entry, 2)}</span>
                  <span className={p.unrealized >= 0 ? "text-long" : "text-short"}>{formatUsd(p.unrealized)}</span>
                </li>
              ))}
            </ul>
          )}
        </Panel>
        <Panel kicker={t.tape} title="Immutable fills" className="lg:col-span-4">
          {fills.length === 0 ? (
            <p className="text-sm text-muted">Empty tape. Missing stays empty.</p>
          ) : (
            <ul className="space-y-1 font-mono text-xs">
              {fills.slice(0, 7).map((fill) => (
                <li key={fill.id} className="flex justify-between gap-2">
                  <span className={fill.side === "BUY" ? "text-long" : "text-short"}>{fill.side}</span>
                  <span>{fill.symbol}</span>
                  <span className="tabular-nums">{dash(fill.price, 2)}</span>
                  <span className="truncate text-subtle">{fill.note.split("·")[0]}</span>
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>

      <Panel
        kicker="WALK-FORWARD"
        title={lab ? `${lab.periods.length} rebalances · fee ${lab.feeBps} bps` : "Backtest booting"}
        action={
          <Button size="sm" variant="quiet" onClick={runLab}>
            {locale === "ID" ? "Jalankan ulang" : "Re-run"}
          </Button>
        }
      >
        {lab ? (
          <div className="space-y-4">
            <GrowingCurve points={bt} />
            <p className="font-mono text-xs text-muted">
              Qanat-style: the curve grows one rebalance at a time. Synthetic. Not a live broker and not a certificate.
            </p>
            <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="font-mono text-xs text-subtle">
                <tr>
                  <th className="pb-2">Alpha</th>
                  <th className="pb-2">Gross</th>
                  <th className="pb-2">Fees</th>
                  <th className="pb-2">Net</th>
                  <th className="pb-2">Hit</th>
                  <th className="pb-2">IS</th>
                  <th className="pb-2">OOS</th>
                </tr>
              </thead>
              <tbody>
                {lab.totals.map((row) => (
                  <tr key={row.strategy} className="border-t border-border font-mono text-xs">
                    <td className="py-2">{LAB_STRATEGIES.find((s) => s.id === row.strategy)?.label ?? row.strategy}</td>
                    <td>{pct(row.gross * 100, 2)}</td>
                    <td className="text-short">{pct(row.fees * 100, 2)}</td>
                    <td className={row.net >= 0 ? "text-long" : "text-short"}>{pct(row.net * 100, 2)}</td>
                    <td>{pct(row.hitRate * 100, 0)}</td>
                    <td>{pct(row.inSampleNet * 100, 2)}</td>
                    <td className={row.outSampleNet >= 0 ? "text-long" : "text-short"}>{pct(row.outSampleNet * 100, 2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p className="mt-2 font-mono text-xs text-muted">
              Net compounds after fees/slip. OOS is the headline. Weights are not orders. {lab.digest}
            </p>
            </div>
          </div>
        ) : (
          <p className="text-sm text-muted">
            {locale === "ID"
              ? "Walk-forward Qanat jalan sendiri setelah tape hidup. Bukan sertifikat profit."
              : "Qanat walk-forward runs once the tape is live. Not a profitability certificate."}
          </p>
        )}
      </Panel>

      <div className="grid gap-3 lg:grid-cols-12">
        <Panel kicker={t.layers} title="17-layer stack" className="lg:col-span-5">
          <div className="grid grid-cols-17 gap-1 sm:grid-cols-9">
            {(fusion?.layers ?? []).map((layer) => (
              <div
                key={layer.id}
                title={`${layer.name} ${layer.direction} ${layer.strength.toFixed(2)}`}
                className={cn(
                  "flex h-10 items-center justify-center rounded-sm font-mono text-xs",
                  layer.direction === "BUY" && "bg-long/20 text-long",
                  layer.direction === "SELL" && "bg-short/20 text-short",
                  layer.direction === "NEUTRAL" && "bg-elevated text-subtle",
                )}
              >
                {String(layer.id + 1).padStart(2, "0")}
              </div>
            ))}
          </div>
          <ul className="mt-3 space-y-1">
            {(fusion?.layers ?? []).slice(0, 5).map((layer) => (
              <li key={layer.id} className="flex justify-between gap-2 text-xs">
                <span className="text-muted">{layer.name}</span>
                <span className={layer.direction === "BUY" ? "text-long" : layer.direction === "SELL" ? "text-short" : "text-subtle"}>
                  {layer.direction === "NEUTRAL" ? "—" : layer.direction}
                </span>
              </li>
            ))}
          </ul>
        </Panel>
        <Panel kicker="BRAIN" title="No order authority" className="lg:col-span-3">
          {votes.length === 0 ? (
            <p className="text-sm text-muted">Agents wait on fusion.</p>
          ) : (
            <ul className="space-y-2">
              {votes.map((v) => (
                <li key={v.name} className="flex justify-between gap-2 font-mono text-xs">
                  <span className="text-muted">{v.name.replace("_", " ")}</span>
                  <span className={v.direction === "BUY" ? "text-long" : v.direction === "SELL" ? "text-short" : "text-subtle"}>
                    {v.direction === "NEUTRAL" ? "—" : v.direction}
                  </span>
                </li>
              ))}
            </ul>
          )}
          <Link to="/agents" className="mt-3 inline-flex h-10 items-center text-sm text-accent">
            {t.agents}
          </Link>
        </Panel>
        <Panel kicker="HEALTH" title="Observability" className="lg:col-span-4">
          <ul className="space-y-2">
            {health.map((row) => (
              <li key={row.code} className="flex items-start justify-between gap-2 text-xs">
                <span>
                  <span className="block font-mono text-accent">{row.code}</span>
                  <span className="text-muted">{row.detail}</span>
                </span>
                <span className={row.ok ? "font-mono text-long" : "font-mono text-short"}>{row.ok ? "OK" : "OFF"}</span>
              </li>
            ))}
          </ul>
        </Panel>
      </div>

      <div className="grid gap-3 lg:grid-cols-12">
        <Panel kicker="NEWS" title="SIM headlines" className="lg:col-span-5">
          <ul className="space-y-2">
            {news.map((n) => (
              <li key={n.text} className="text-sm">
                <span className="font-mono text-xs text-accent">{n.tag}</span>{" "}
                <span className="text-muted">{n.text}</span>
                <span className="ml-2 font-mono text-xs text-subtle">{n.freshness}</span>
              </li>
            ))}
          </ul>
        </Panel>
        <Panel kicker="FLOW" title="SIM size tape" className="lg:col-span-3">
          {flow.length === 0 ? (
            <p className="text-sm text-muted">No prints yet.</p>
          ) : (
            <ul className="space-y-1 font-mono text-xs">
              {flow.map((f) => (
                <li key={f.t} className="flex justify-between gap-2">
                  <span className={f.side === "LIFT" ? "text-long" : "text-short"}>{f.side}</span>
                  <span>{f.id}</span>
                  <span className="tabular-nums">{dash(f.size, 1)}</span>
                </li>
              ))}
            </ul>
          )}
        </Panel>
        <Panel kicker="TICK" title="Heartbeat" className="lg:col-span-4">
          {tickTape.length === 0 ? (
            <p className="text-sm text-muted">Waiting for first print.</p>
          ) : (
            <ul className="space-y-1 font-mono text-xs">
              {tickTape.slice(0, 7).map((p) => (
                <li key={p.t} className="flex justify-between gap-2">
                  <span className="text-subtle">{new Date(p.t).toISOString().slice(11, 19)}</span>
                  <span>{p.id}</span>
                  <span className={p.delta >= 0 ? "text-long" : "text-short"}>{dash(p.price, digits)}</span>
                </li>
              ))}
            </ul>
          )}
          <div className="mt-3 flex flex-wrap gap-2">
            <Link to="/signal-room" className="inline-flex h-10 items-center rounded-md bg-elevated px-3 text-sm">
              {t.openSignal}
            </Link>
            <Link to="/journal" className="inline-flex h-10 items-center rounded-md px-3 text-sm text-muted">
              Journal
            </Link>
          </div>
        </Panel>
      </div>
    </div>
  );
}
