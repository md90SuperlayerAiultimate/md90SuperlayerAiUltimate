import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { CandleChart } from "@/components/candle-chart";
import { Panel } from "@/components/panels";
import { Button } from "@/components/ui/button";
import { getInstrument } from "@/lib/md90/engine";
import { copy } from "@/lib/md90/i18n";
import { useDesk } from "@/lib/md90/store";
import { dash, pct } from "@/lib/utils";

export const Route = createFileRoute("/_desk/signal-room")({ component: SignalRoom });

function SignalRoom() {
  const locale = useDesk((s) => s.locale);
  const t = copy[locale];
  const fusion = useDesk((s) => s.fusion);
  const candles = useDesk((s) => s.candles);
  const submitPaper = useDesk((s) => s.submitPaper);
  const risk = useDesk((s) => s.riskChecks);
  const instrumentId = useDesk((s) => s.instrumentId);
  const lastPrice = useDesk((s) => s.lastPrice);
  const autopilot = useDesk((s) => s.autopilot);
  const digits = getInstrument(instrumentId).digits;
  const clear = risk.length > 0 && risk.every((r) => r.ok);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="font-mono text-xs tracking-[0.18em] text-accent">
            {t.signalRoom} · {instrumentId} · {autopilot}
          </p>
          <h1 className="mt-1 text-3xl font-medium tracking-tight">
            {fusion?.direction ?? "WATCH"}{" "}
            <em className="text-muted not-italic">{dash(lastPrice || fusion?.entry, digits)}</em>
          </h1>
          <p className="mt-2 max-w-xl text-sm text-muted">{t.blurb}</p>
        </div>
        <Button
          onClick={() => {
            const result = submitPaper({ mode: "AUTO" });
            toast(result === "FILLED" ? t.submitPaper + " · FILLED" : `${t.blocked} · ${result}`);
          }}
        >
          {clear ? t.submitPaper : t.blocked}
        </Button>
      </div>

      <div className="grid gap-3 sm:grid-cols-4">
        <Metric label="Composite" value={fusion ? fusion.fusionScore.toFixed(2) : "—"} />
        <Metric label="Confidence" value={fusion ? pct(fusion.confidence, 0) : "—"} />
        <Metric label="R:R TP1" value={fusion ? `${dash(fusion.riskReward[0], 2)}R` : "—"} />
        <Metric label="Status" value={fusion?.status ?? "—"} />
      </div>

      <Panel kicker="LIVE / PAPER" title="Primary tape">
        <div className="h-72">
          <CandleChart candles={candles} smc={fusion?.smc ?? []} height={300} />
        </div>
        <div className="mt-3 flex flex-wrap gap-2 font-mono text-xs text-muted">
          {(fusion?.smc ?? []).slice(-6).map((z, i) => (
            <span key={i} className="rounded-sm border border-border px-2 py-1">
              {z.kind} {z.side}
            </span>
          ))}
        </div>
      </Panel>

      <div className="grid gap-4 lg:grid-cols-5">
        <Panel kicker={t.layers} title={t.signalRoom} className="lg:col-span-3">
          <div className="space-y-2">
            {(fusion?.layers ?? []).map((layer) => (
              <div key={layer.id} className="grid grid-cols-[2rem_7rem_1fr_4rem] items-center gap-2">
                <span className="font-mono text-xs text-subtle">{String(layer.id + 1).padStart(2, "0")}</span>
                <span className="text-sm">{layer.name}</span>
                <div className="h-1.5 rounded-full bg-elevated">
                  <i
                    className={
                      layer.direction === "SELL"
                        ? "block h-1.5 rounded-full bg-short"
                        : "block h-1.5 rounded-full bg-long"
                    }
                    style={{ width: `${Math.round(layer.strength * 100)}%` }}
                  />
                </div>
                <span
                  className={
                    layer.direction === "BUY"
                      ? "text-right font-mono text-xs text-long"
                      : layer.direction === "SELL"
                        ? "text-right font-mono text-xs text-short"
                        : "text-right font-mono text-xs text-subtle"
                  }
                >
                  {layer.direction === "NEUTRAL" ? "—" : layer.direction}
                </span>
              </div>
            ))}
          </div>
        </Panel>
        <div className="space-y-4 lg:col-span-2">
          <Panel kicker="6-TP" title="Stop / take ladder">
            <ul className="space-y-2 font-mono text-sm">
              <li className="flex justify-between">
                <span className="text-muted">Entry</span>
                <span>{dash(fusion?.entry, digits)}</span>
              </li>
              <li className="flex justify-between text-short">
                <span>Stop</span>
                <span>{dash(fusion?.stop, digits)}</span>
              </li>
              {(fusion?.takeProfits ?? []).map((tp, i) => (
                <li key={tp} className="flex justify-between text-long">
                  <span>TP{i + 1}</span>
                  <span>
                    {dash(tp, digits)} · {dash(fusion?.riskReward[i], 1)}R
                  </span>
                </li>
              ))}
            </ul>
          </Panel>
          <Panel kicker={t.riskGate} title="Five gates">
            <ul className="space-y-2">
              {(fusion?.gates ?? []).map((g) => (
                <li key={g.id} className="flex items-start justify-between gap-2 text-sm">
                  <span>
                    {g.label}
                    <span className="block text-xs text-muted">{g.detail}</span>
                  </span>
                  <b className={g.passed ? "font-mono text-xs text-long" : "font-mono text-xs text-short"}>
                    {g.passed ? "PASS" : "HOLD"}
                  </b>
                </li>
              ))}
            </ul>
          </Panel>
        </div>
      </div>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border bg-surface px-4 py-3">
      <div className="font-mono text-xs text-subtle">{label}</div>
      <div className="mt-1 font-mono text-xl tabular-nums">{value}</div>
    </div>
  );
}
