import { createFileRoute } from "@tanstack/react-router";
import { ENGINE_VERSION } from "@/lib/md90/constants";
import { snapshotChecksum } from "@/lib/md90/engine";
import { copy } from "@/lib/md90/i18n";
import { SHADOW_REGISTRY } from "@/lib/md90/markets";
import { useDesk } from "@/lib/md90/store";
import { Panel, StageRail } from "@/components/panels";

export const Route = createFileRoute("/_desk/audit")({ component: Audit });

function Audit() {
  const locale = useDesk((s) => s.locale);
  const t = copy[locale];
  const fusion = useDesk((s) => s.fusion);
  const instrumentId = useDesk((s) => s.instrumentId);
  const operating = useDesk((s) => s.operating);
  const checksum = snapshotChecksum(
    `${ENGINE_VERSION}:${instrumentId}:${fusion?.entry ?? 0}:${fusion?.status ?? "NA"}`,
  );

  const sources = [
    { name: "MQL5 Fusion v4 OnTick", role: "Canonical EA loop", status: "PORTED" },
    { name: "Python md90_final", role: "17-layer + HMM + cognitive 8-stage", status: "PORTED" },
    { name: "Superlayer cockpit", role: "10-stage operating + protective policy", status: "PORTED" },
    { name: "Qanat table lab", role: "raw→weights→pnl walk-forward", status: "PORTED" },
    { name: "Vibe-Trading / TradingAgents", role: "Agent swarm + bull/bear desk", status: "PATTERN" },
    { name: "Fincept / PolyTerm chrome", role: "Honest watch labels + CLI", status: "PATTERN" },
    { name: "Polymarket CLOB / arb family", role: "Sim book + paper fill", status: "PATTERN" },
    { name: "WS latency / wallet / live CLOB", role: "Network execution", status: "BLOCKED" },
  ];

  return (
    <div className="space-y-5">
      <div>
        <p className="font-mono text-xs tracking-[0.18em] text-accent">{t.audit}</p>
        <h1 className="mt-1 text-3xl font-medium tracking-tight">Parity and provenance</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted">
          Readiness: PAPER / SHADOW only. Not a market-data vendor, not a broker, not a profitability certificate.
        </p>
      </div>
      <Panel kicker="FSM" title={`${operating?.outcome ?? "RUNNING"} · ${operating?.events.length ?? 0}/10`}>
        <StageRail current={operating?.stage ?? "AUDIT"} events={operating?.events} />
        <ul className="mt-4 space-y-2">
          {(operating?.events ?? []).map((event) => (
            <li key={event.eventId} className="grid gap-1 border-b border-border pb-2 font-mono text-xs sm:grid-cols-[8rem_6rem_1fr]">
              <span>{event.stage}</span>
              <span className={event.evidence === "BLOCKED" ? "text-short" : event.evidence === "PENDING" ? "text-subtle" : "text-long"}>
                {event.evidence}
              </span>
              <span className="text-muted">{event.detail}</span>
            </li>
          ))}
        </ul>
      </Panel>
      <Panel kicker={t.checksum} title={checksum}>
        <p className="font-mono text-xs text-muted">{ENGINE_VERSION}</p>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="font-mono text-xs text-subtle">
              <tr>
                <th className="pb-2">Source</th>
                <th className="pb-2">Role</th>
                <th className="pb-2">Status</th>
              </tr>
            </thead>
            <tbody>
              {sources.map((row) => (
                <tr key={row.name} className="border-t border-border">
                  <td className="py-2">{row.name}</td>
                  <td className="py-2 text-muted">{row.role}</td>
                  <td
                    className={
                      row.status === "BLOCKED"
                        ? "py-2 font-mono text-xs text-short"
                        : "py-2 font-mono text-xs text-long"
                    }
                  >
                    {row.status}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
      <Panel kicker="SHADOW REGISTRY" title="Capability map">
        <ul className="space-y-3">
          {SHADOW_REGISTRY.map((cap) => (
            <li key={cap.family} className="grid gap-1 border-b border-border pb-3 sm:grid-cols-[9rem_8rem_1fr]">
              <span className="text-sm">{cap.family}</span>
              <span
                className={
                  cap.status === "BLOCKED"
                    ? "font-mono text-xs text-short"
                    : cap.status === "SHADOW"
                      ? "font-mono text-xs text-warn"
                      : "font-mono text-xs text-long"
                }
              >
                {cap.status}
              </span>
              <span className="text-xs text-muted">
                {cap.source} — {cap.note}
              </span>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}
