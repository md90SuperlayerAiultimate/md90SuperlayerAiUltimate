import { createFileRoute, Outlet } from "@tanstack/react-router";
import { TerminalShell } from "@/components/terminal-shell";

export const Route = createFileRoute("/_desk")({
  component: DeskLayout,
});

function DeskLayout() {
  return (
    <TerminalShell>
      <Outlet />
    </TerminalShell>
  );
}
