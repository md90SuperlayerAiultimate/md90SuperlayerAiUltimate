import {
  AGENT_LAYER_MAP,
  ATR_SL_MULT,
  ATR_TP_MULTS,
  CONFIDENCE_MIN,
  FUSION_SCORE_MIN,
  INSTRUMENTS,
  LAYER,
  LAYER_NAMES,
  LAYER_WEIGHTS,
  RR_MINIMUM,
  TF_MS,
  TICK_MS,
  TOTAL_LAYERS,
  type Instrument,
  type InstrumentId,
  type Timeframe,
} from "./constants";

export type Direction = "BUY" | "SELL" | "NEUTRAL";
export type ExecStatus = "ALL-IN" | "WAITING" | "ABORT";
export type RegimeName =
  | "UNDEFINED"
  | "SIDEWAYS"
  | "TREND_UP"
  | "TREND_DOWN"
  | "VOLATILE"
  | "BREAKOUT"
  | "RANGING"
  | "TRANSITION";

export type Candle = {
  t: number;
  o: number;
  h: number;
  l: number;
  c: number;
  v: number;
  forming?: boolean;
};

export type LayerSignal = {
  id: number;
  name: string;
  weight: number;
  direction: Direction;
  strength: number;
  note: string;
};

export type SmcZone = {
  kind: "FVG" | "OB" | "SWEEP";
  side: "BULL" | "BEAR";
  top: number;
  bottom: number;
  bar: number;
};

export type FusionResult = {
  direction: Direction;
  fusionScore: number;
  confidence: number;
  confidenceLevel: "ULTRA" | "HIGH" | "MEDIUM" | "LOW";
  lotMult: number;
  slMult: number;
  buyVotes: number;
  sellVotes: number;
  neutralVotes: number;
  gates: { id: number; label: string; passed: boolean; detail: string }[];
  allGates: boolean;
  status: ExecStatus;
  entry: number;
  stop: number;
  takeProfits: number[];
  riskReward: number[];
  layers: LayerSignal[];
  regime: RegimeState;
  smc: SmcZone[];
  atr: number;
  rsi: number;
  adx: number;
};

export type RegimeState = {
  name: RegimeName;
  confidence: number;
  adx: number;
  diPlus: number;
  diMinus: number;
  volPct: number;
  rangePct: number;
  riskMult: number;
};

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a += 0x6d2b79f5;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hashStr(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
  return h >>> 0;
}

export function getInstrument(id: string): Instrument {
  return INSTRUMENTS.find((item) => item.id === id) ?? INSTRUMENTS[0];
}

export { TF_MS };

function shockBar(
  rng: () => number,
  open: number,
  base: number,
  i: number,
): { h: number; l: number; c: number; v: number } {
  const regime = Math.sin(i / 18) + (rng() - 0.5) * 0.4;
  const drift = regime * 0.00035 * base;
  const vol = (0.0018 + rng() * 0.0012) * base;
  const shock = (rng() - 0.48) * vol + drift;
  const c = Math.max(0.01, open + shock);
  const wick = vol * (0.25 + rng() * 0.7);
  const h = Math.max(open, c) + wick * rng();
  const l = Math.min(open, c) - wick * rng();
  const v = 800 + rng() * 2200 + (Math.abs(shock) / vol) * 900;
  return { h, l, c, v };
}

export function generateCandles(
  instrumentId: InstrumentId,
  timeframe: Timeframe,
  count = 180,
  now = Date.now(),
): Candle[] {
  const inst = getInstrument(instrumentId);
  const step = TF_MS[timeframe];
  const lastClosedStart = Math.floor(now / step) * step - step;
  const first = lastClosedStart - (count - 1) * step;
  const candles: Candle[] = [];
  let price: number = inst.base;
  for (let i = 0; i < count; i++) {
    const t = first + i * step;
    const rng = mulberry32(hashStr(`${instrumentId}:${timeframe}:${t}`));
    const o = price;
    const bar = shockBar(rng, o, inst.base, i);
    candles.push({ t, o, h: bar.h, l: bar.l, c: bar.c, v: bar.v });
    price = bar.c;
  }
  return candles;
}

export function walkFormingCandle(
  instrumentId: InstrumentId,
  timeframe: Timeframe,
  openPrice: number,
  barStart: number,
  now = Date.now(),
  barTicks?: number,
): Candle {
  const inst = getInstrument(instrumentId);
  const rng = mulberry32(hashStr(`${instrumentId}:${timeframe}:${barStart}:form`));
  const elapsed = Math.max(0, now - barStart);
  const fromClock = Math.max(1, Math.floor(elapsed / TICK_MS));
  const cap = Math.max(8, Math.floor(TF_MS[timeframe] / TICK_MS));
  const ticks = Math.max(1, Math.min(barTicks ?? fromClock, cap));
  const vol = 0.00135 * inst.base;
  let c = openPrice;
  let h = openPrice;
  let l = openPrice;
  let v = 220;
  for (let i = 0; i < ticks; i++) {
    const shock = (rng() - 0.48) * vol * (0.9 + rng() * 0.75);
    c = Math.max(0.01, c + shock);
    h = Math.max(h, c);
    l = Math.min(l, c);
    v += 18 + rng() * 55;
  }
  const printRng = mulberry32(hashStr(`${instrumentId}:${barStart}:${ticks}:${Math.floor(now / 40)}`));
  const wave = Math.sin(now / 180) * vol * 0.28;
  const print = (printRng() - 0.5) * vol * 0.9;
  c = Math.max(0.01, c + wave + print);
  h = Math.max(h, c);
  l = Math.min(l, c);
  return { t: barStart, o: openPrice, h, l, c, v, forming: true };
}

export function generateLiveSeries(
  instrumentId: InstrumentId,
  timeframe: Timeframe,
  count = 180,
  now = Date.now(),
  barTicks?: number,
): { candles: Candle[]; lastPrice: number; barStart: number } {
  const step = TF_MS[timeframe];
  const barStart = Math.floor(now / step) * step;
  const closed = generateCandles(instrumentId, timeframe, count, barStart - 1);
  const open = closed.at(-1)?.c ?? getInstrument(instrumentId).base;
  const forming = walkFormingCandle(instrumentId, timeframe, open, barStart, now, barTicks);
  const candles = [...closed, forming];
  return { candles, lastPrice: forming.c, barStart };
}

function ema(values: number[], period: number): number {
  if (values.length < period) return values.at(-1) ?? 0;
  const k = 2 / (period + 1);
  let e = values.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < values.length; i++) e = values[i] * k + e * (1 - k);
  return e;
}

function rsi(closes: number[], period = 14): number {
  if (closes.length < period + 1) return 50;
  let gain = 0;
  let loss = 0;
  for (let i = closes.length - period; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    if (d >= 0) gain += d;
    else loss -= d;
  }
  if (loss === 0) return 100;
  const rs = gain / loss;
  return 100 - 100 / (1 + rs);
}

function stoch(candles: Candle[], period = 14): { k: number; d: number } {
  const slice = candles.slice(-period);
  if (!slice.length) return { k: 50, d: 50 };
  const hh = Math.max(...slice.map((c) => c.h));
  const ll = Math.min(...slice.map((c) => c.l));
  const k = hh === ll ? 50 : ((slice.at(-1)!.c - ll) / (hh - ll)) * 100;
  const prev = candles.slice(-period - 2, -1);
  const d =
    prev.length < 3
      ? k
      : (k +
          prev.slice(-2).reduce((acc, _, i) => {
            const w = candles.slice(-period - (2 - i), candles.length - (2 - i));
            const h2 = Math.max(...w.map((c) => c.h));
            const l2 = Math.min(...w.map((c) => c.l));
            return acc + (h2 === l2 ? 50 : ((w.at(-1)!.c - l2) / (h2 - l2)) * 100);
          }, 0)) /
        3;
  return { k, d };
}

function atr(candles: Candle[], period = 14): number {
  if (candles.length < 2) return 0;
  const trs: number[] = [];
  for (let i = 1; i < candles.length; i++) {
    const c = candles[i];
    const p = candles[i - 1];
    trs.push(Math.max(c.h - c.l, Math.abs(c.h - p.c), Math.abs(c.l - p.c)));
  }
  const slice = trs.slice(-period);
  return slice.reduce((a, b) => a + b, 0) / slice.length;
}

function adx(candles: Candle[], period = 14): { adx: number; plus: number; minus: number } {
  if (candles.length < period + 2) return { adx: 20, plus: 20, minus: 20 };
  let plus = 0;
  let minus = 0;
  let tr = 0;
  for (let i = candles.length - period; i < candles.length; i++) {
    const up = candles[i].h - candles[i - 1].h;
    const dn = candles[i - 1].l - candles[i].l;
    plus += up > dn && up > 0 ? up : 0;
    minus += dn > up && dn > 0 ? dn : 0;
    tr += Math.max(
      candles[i].h - candles[i].l,
      Math.abs(candles[i].h - candles[i - 1].c),
      Math.abs(candles[i].l - candles[i - 1].c),
    );
  }
  const pdi = tr ? (100 * plus) / tr : 0;
  const mdi = tr ? (100 * minus) / tr : 0;
  const dx = pdi + mdi === 0 ? 0 : (100 * Math.abs(pdi - mdi)) / (pdi + mdi);
  return { adx: dx, plus: pdi, minus: mdi };
}

function vwap(candles: Candle[]): number {
  let pv = 0;
  let vol = 0;
  const slice = candles.slice(-48);
  for (const c of slice) {
    const tp = (c.h + c.l + c.c) / 3;
    pv += tp * c.v;
    vol += c.v;
  }
  return vol ? pv / vol : candles.at(-1)?.c ?? 0;
}

function obv(candles: Candle[]): { now: number; prev: number } {
  let o = 0;
  let prev = 0;
  for (let i = 1; i < candles.length; i++) {
    prev = o;
    if (candles[i].c > candles[i - 1].c) o += candles[i].v;
    else if (candles[i].c < candles[i - 1].c) o -= candles[i].v;
  }
  return { now: o, prev };
}

function mfi(candles: Candle[], period = 14): number {
  const slice = candles.slice(-(period + 1));
  let pos = 0;
  let neg = 0;
  for (let i = 1; i < slice.length; i++) {
    const tp = (slice[i].h + slice[i].l + slice[i].c) / 3;
    const ptp = (slice[i - 1].h + slice[i - 1].l + slice[i - 1].c) / 3;
    const mf = tp * slice[i].v;
    if (tp > ptp) pos += mf;
    else neg += mf;
  }
  if (!neg) return 80;
  const ratio = pos / neg;
  return 100 - 100 / (1 + ratio);
}

function swings(candles: Candle[], len = 5) {
  const highs: { i: number; p: number }[] = [];
  const lows: { i: number; p: number }[] = [];
  for (let i = len; i < candles.length - len; i++) {
    const h = candles[i].h;
    const l = candles[i].l;
    let isH = true;
    let isL = true;
    for (let j = 1; j <= len; j++) {
      if (candles[i - j].h >= h || candles[i + j].h >= h) isH = false;
      if (candles[i - j].l <= l || candles[i + j].l <= l) isL = false;
    }
    if (isH) highs.push({ i, p: h });
    if (isL) lows.push({ i, p: l });
  }
  return { highs, lows, lastHigh: highs.at(-1), lastLow: lows.at(-1) };
}

function detectSmc(candles: Candle[], atrVal: number): SmcZone[] {
  const zones: SmcZone[] = [];
  const last = candles.length - 1;
  for (let i = 3; i < candles.length; i++) {
    const a = candles[i - 2];
    const b = candles[i - 1];
    const c = candles[i];
    if (c.l > a.h && b.c > b.o) {
      zones.push({ kind: "FVG", side: "BULL", top: c.l, bottom: a.h, bar: i });
    }
    if (c.h < a.l && b.c < b.o) {
      zones.push({ kind: "FVG", side: "BEAR", top: a.l, bottom: c.h, bar: i });
    }
  }
  for (let i = 8; i < candles.length; i++) {
    const impulse = Math.abs(candles[i].c - candles[i - 3].o);
    if (impulse > atrVal * 1.4) {
      const bull = candles[i].c > candles[i - 3].o;
      const ob = candles[i - 3];
      zones.push({
        kind: "OB",
        side: bull ? "BULL" : "BEAR",
        top: ob.h,
        bottom: ob.l,
        bar: i - 3,
      });
    }
  }
  const sw = swings(candles);
  const lastC = candles[last];
  if (sw.lastHigh && lastC.h > sw.lastHigh.p && lastC.c < sw.lastHigh.p) {
    zones.push({
      kind: "SWEEP",
      side: "BEAR",
      top: lastC.h,
      bottom: lastC.c,
      bar: last,
    });
  }
  if (sw.lastLow && lastC.l < sw.lastLow.p && lastC.c > sw.lastLow.p) {
    zones.push({
      kind: "SWEEP",
      side: "BULL",
      top: lastC.c,
      bottom: lastC.l,
      bar: last,
    });
  }
  return zones.slice(-18);
}

function ls(id: number, direction: Direction, strength: number, note: string): LayerSignal {
  return { id, name: LAYER_NAMES[id], weight: LAYER_WEIGHTS[id], direction, strength, note };
}

function detectRegime(candles: Candle[], atrVal: number, adxPack: { adx: number; plus: number; minus: number }): RegimeState {
  const last = candles.at(-1)!;
  const window = candles.slice(-24);
  const hi = Math.max(...window.map((c) => c.h));
  const lo = Math.min(...window.map((c) => c.l));
  const rangePct = ((hi - lo) / last.c) * 100;
  const volPct = (atrVal / last.c) * 100;
  let name: RegimeName = "TRANSITION";
  if (adxPack.adx < 15 && rangePct < 1) name = "SIDEWAYS";
  else if (adxPack.adx > 25 && adxPack.plus > adxPack.minus) name = "TREND_UP";
  else if (adxPack.adx > 25 && adxPack.minus > adxPack.plus) name = "TREND_DOWN";
  else if (volPct > 0.35) name = "VOLATILE";
  else if (last.c > hi * 0.998 || last.c < lo * 1.002) name = "BREAKOUT";
  else if (rangePct > 1 && rangePct < 2) name = "RANGING";
  const riskMap: Record<RegimeName, number> = {
    SIDEWAYS: 0.7,
    RANGING: 0.7,
    TREND_UP: 1.2,
    TREND_DOWN: 1.2,
    VOLATILE: 0.5,
    BREAKOUT: 1.3,
    TRANSITION: 0.8,
    UNDEFINED: 0.5,
  };
  const confidence = Math.min(96, 40 + adxPack.adx);
  return {
    name,
    confidence,
    adx: adxPack.adx,
    diPlus: adxPack.plus,
    diMinus: adxPack.minus,
    volPct,
    rangePct,
    riskMult: riskMap[name],
  };
}

export function analyze(candles: Candle[]): FusionResult {
  const closes = candles.map((c) => c.c);
  const last = candles.at(-1)!;
  const price = last.c;
  const atrVal = atr(candles);
  const e8 = ema(closes, 8);
  const e21 = ema(closes, 21);
  const e50 = ema(closes, 50);
  const e200 = ema(closes, Math.min(200, closes.length));
  const r = rsi(closes);
  const { k, d } = stoch(candles);
  const adxPack = adx(candles);
  const vw = vwap(candles);
  const ob = obv(candles);
  const mfiVal = mfi(candles);
  const sw = swings(candles);
  const smc = detectSmc(candles, atrVal);
  const regime = detectRegime(candles, atrVal, adxPack);
  const volAvg = candles.slice(-20).reduce((a, c) => a + c.v, 0) / 20;
  const volRatio = last.v / (volAvg || 1);
  const volumeSpike = volRatio > 1.5;
  const atrMean = atr(candles.slice(0, -14)) || atrVal;
  const atrRatio = atrMean ? atrVal / atrMean : 1;

  const lastFvg = [...smc].reverse().find((z) => z.kind === "FVG");
  const lastOb = [...smc].reverse().find((z) => z.kind === "OB");
  const lastSweep = [...smc].reverse().find((z) => z.kind === "SWEEP");
  const inBullOb = lastOb?.side === "BULL" && price <= lastOb.top && price >= lastOb.bottom;
  const inBearOb = lastOb?.side === "BEAR" && price <= lastOb.top && price >= lastOb.bottom;

  const distSup = sw.lastLow && atrVal ? (price - sw.lastLow.p) / atrVal : 999;
  const distRes = sw.lastHigh && atrVal ? (sw.lastHigh.p - price) / atrVal : 999;

  const layers: LayerSignal[] = new Array(TOTAL_LAYERS);

  layers[LAYER.SNR] =
    distSup < 0.5
      ? ls(LAYER.SNR, "BUY", 0.7, `Near support Δ=${distSup.toFixed(2)}ATR`)
      : distRes < 0.5
        ? ls(LAYER.SNR, "SELL", 0.7, `Near resistance Δ=${distRes.toFixed(2)}ATR`)
        : ls(LAYER.SNR, "NEUTRAL", 0, "No clear S/R");

  if (e8 > e21 && e21 > e50) {
    layers[LAYER.EMA] = ls(LAYER.EMA, "BUY", e200 > 0 && e8 > e200 ? 0.8 : 0.6, "EMA bull stack 8>21>50");
  } else if (e8 < e21 && e21 < e50) {
    layers[LAYER.EMA] = ls(LAYER.EMA, "SELL", e200 > 0 && e8 < e200 ? 0.8 : 0.6, "EMA bear stack 8<21<50");
  } else if (e8 > e21) layers[LAYER.EMA] = ls(LAYER.EMA, "BUY", 0.4, "EMA8>EMA21 partial bull");
  else if (e8 < e21) layers[LAYER.EMA] = ls(LAYER.EMA, "SELL", 0.4, "EMA8<EMA21 partial bear");
  else layers[LAYER.EMA] = ls(LAYER.EMA, "NEUTRAL", 0, "EMA flat");

  layers[LAYER.RSI] =
    r <= 30
      ? ls(LAYER.RSI, "BUY", 0.8, `RSI oversold ${r.toFixed(1)}`)
      : r >= 70
        ? ls(LAYER.RSI, "SELL", 0.8, `RSI overbought ${r.toFixed(1)}`)
        : r > 50
          ? ls(LAYER.RSI, "BUY", 0.5, `RSI bullish ${r.toFixed(1)}`)
          : r < 50
            ? ls(LAYER.RSI, "SELL", 0.5, `RSI bearish ${r.toFixed(1)}`)
            : ls(LAYER.RSI, "NEUTRAL", 0, "RSI neutral");

  layers[LAYER.STOCHASTIC] =
    k <= 20 && k > d
      ? ls(LAYER.STOCHASTIC, "BUY", 0.7, `Stoch OS cross-up K=${k.toFixed(1)}`)
      : k >= 80 && k < d
        ? ls(LAYER.STOCHASTIC, "SELL", 0.7, `Stoch OB cross-dn K=${k.toFixed(1)}`)
        : k > d
          ? ls(LAYER.STOCHASTIC, "BUY", 0.3, "Stoch bullish K>D")
          : k < d
            ? ls(LAYER.STOCHASTIC, "SELL", 0.3, "Stoch bearish K<D")
            : ls(LAYER.STOCHASTIC, "NEUTRAL", 0, "Stoch neutral");

  layers[LAYER.ORDER_BLOCK] = inBullOb
    ? ls(LAYER.ORDER_BLOCK, "BUY", 0.75, "Inside bullish OB")
    : inBearOb
      ? ls(LAYER.ORDER_BLOCK, "SELL", 0.75, "Inside bearish OB")
      : ls(LAYER.ORDER_BLOCK, "NEUTRAL", 0, "No active OB");

  if (ob.now > ob.prev && ob.prev !== 0) {
    layers[LAYER.VOLUME] = ls(LAYER.VOLUME, "BUY", volRatio > 1.5 ? 0.7 : 0.4, `OBV rising ratio=${volRatio.toFixed(2)}`);
  } else if (ob.now < ob.prev && ob.prev !== 0) {
    layers[LAYER.VOLUME] = ls(LAYER.VOLUME, "SELL", volRatio > 1.5 ? 0.7 : 0.4, `OBV falling ratio=${volRatio.toFixed(2)}`);
  } else if (volRatio > 1.5) {
    layers[LAYER.VOLUME] = ls(LAYER.VOLUME, last.c > last.o ? "BUY" : "SELL", 0.5, `Vol spike ${volRatio.toFixed(2)}`);
  } else {
    layers[LAYER.VOLUME] = ls(LAYER.VOLUME, "NEUTRAL", 0, `Normal volume ${volRatio.toFixed(2)}`);
  }

  const mtfBull =
    (price > e21 ? 1 : 0) + (e8 > e21 ? 1 : 0) + (e21 > e50 ? 1 : 0) + (price > vw ? 1 : 0) + (adxPack.plus > adxPack.minus ? 1 : 0);
  const mtfBear = 5 - mtfBull;
  layers[LAYER.MTF] =
    mtfBull >= 4
      ? ls(LAYER.MTF, "BUY", 0.8, `MTF ${mtfBull}/5 bullish`)
      : mtfBear >= 4
        ? ls(LAYER.MTF, "SELL", 0.8, `MTF ${mtfBear}/5 bearish`)
        : mtfBull > mtfBear
          ? ls(LAYER.MTF, "BUY", 0.4, `MTF majority bull ${mtfBull}vs${mtfBear}`)
          : mtfBear > mtfBull
            ? ls(LAYER.MTF, "SELL", 0.4, `MTF majority bear ${mtfBear}vs${mtfBull}`)
            : ls(LAYER.MTF, "NEUTRAL", 0, "MTF mixed");

  layers[LAYER.SENTIMENT] =
    mfiVal <= 20
      ? ls(LAYER.SENTIMENT, "BUY", 0.7, `MFI oversold ${mfiVal.toFixed(1)}`)
      : mfiVal >= 80
        ? ls(LAYER.SENTIMENT, "SELL", 0.7, `MFI overbought ${mfiVal.toFixed(1)}`)
        : mfiVal > 55
          ? ls(LAYER.SENTIMENT, "BUY", 0.4, `Buy pressure MFI=${mfiVal.toFixed(1)}`)
          : mfiVal < 45
            ? ls(LAYER.SENTIMENT, "SELL", 0.4, `Sell pressure MFI=${mfiVal.toFixed(1)}`)
            : ls(LAYER.SENTIMENT, "NEUTRAL", 0, `Neutral MFI=${mfiVal.toFixed(1)}`);

  layers[LAYER.ULTRA_SCALPER] = lastSweep
    ? lastSweep.side === "BULL"
      ? ls(LAYER.ULTRA_SCALPER, "BUY", 0.8, "Buy sweep confirmed")
      : ls(LAYER.ULTRA_SCALPER, "SELL", 0.8, "Sell sweep confirmed")
    : ls(LAYER.ULTRA_SCALPER, "NEUTRAL", 0, "No sweep detected");

  const discount = sw.lastLow && sw.lastHigh ? price < sw.lastLow.p + (sw.lastHigh.p - sw.lastLow.p) * 0.5 : false;
  const premium = sw.lastLow && sw.lastHigh ? price > sw.lastLow.p + (sw.lastHigh.p - sw.lastLow.p) * 0.5 : false;
  const bullStruct = (sw.highs.at(-1)?.p ?? 0) > (sw.highs.at(-2)?.p ?? 0) && (sw.lows.at(-1)?.p ?? 0) > (sw.lows.at(-2)?.p ?? 0);
  const bearStruct = (sw.highs.at(-1)?.p ?? 0) < (sw.highs.at(-2)?.p ?? Infinity) && (sw.lows.at(-1)?.p ?? 0) < (sw.lows.at(-2)?.p ?? Infinity);

  if (bullStruct && discount) layers[LAYER.PRIME_SWING] = ls(LAYER.PRIME_SWING, "BUY", 0.9, "CHoCH bullish at discount");
  else if (bearStruct && premium) layers[LAYER.PRIME_SWING] = ls(LAYER.PRIME_SWING, "SELL", 0.9, "CHoCH bearish at premium");
  else if (bullStruct) layers[LAYER.PRIME_SWING] = ls(LAYER.PRIME_SWING, "BUY", 0.5, "Bullish structure HH+HL");
  else if (bearStruct) layers[LAYER.PRIME_SWING] = ls(LAYER.PRIME_SWING, "SELL", 0.5, "Bearish structure LH+LL");
  else layers[LAYER.PRIME_SWING] = ls(LAYER.PRIME_SWING, "NEUTRAL", 0, "No clear structure");

  layers[LAYER.MACRO_FLOW] =
    adxPack.adx > 25 && price > e200
      ? ls(LAYER.MACRO_FLOW, "BUY", 0.7, `ADX ${adxPack.adx.toFixed(1)} above EMA200`)
      : adxPack.adx > 25 && price < e200
        ? ls(LAYER.MACRO_FLOW, "SELL", 0.7, `ADX ${adxPack.adx.toFixed(1)} below EMA200`)
        : ls(LAYER.MACRO_FLOW, "NEUTRAL", 0.2, `Macro quiet ADX ${adxPack.adx.toFixed(1)}`);

  layers[LAYER.VWAP] =
    price > vw * 1.001
      ? ls(LAYER.VWAP, "BUY", 0.55, "Price above VWAP")
      : price < vw * 0.999
        ? ls(LAYER.VWAP, "SELL", 0.55, "Price below VWAP")
        : ls(LAYER.VWAP, "NEUTRAL", 0, "At VWAP");

  layers[LAYER.ATR] =
    atrRatio > 1.6
      ? ls(LAYER.ATR, "NEUTRAL", 0.3, `ATR expanded ${atrRatio.toFixed(2)}x`)
      : atrRatio < 0.7
        ? ls(LAYER.ATR, "NEUTRAL", 0.4, `ATR compressed ${atrRatio.toFixed(2)}x`)
        : ls(LAYER.ATR, last.c > last.o ? "BUY" : "SELL", 0.4, `ATR normal ${atrRatio.toFixed(2)}x`);

  const eq = sw.lastLow && sw.lastHigh ? sw.lastLow.p + (sw.lastHigh.p - sw.lastLow.p) * 0.62 : price;
  layers[LAYER.OTE] =
    Math.abs(price - eq) / (atrVal || 1) < 0.4
      ? ls(LAYER.OTE, discount ? "BUY" : "SELL", 0.7, "At OTE 0.62 zone")
      : ls(LAYER.OTE, "NEUTRAL", 0, "Off OTE");

  layers[LAYER.IDM_FVG] = lastFvg
    ? lastFvg.side === "BULL"
      ? ls(LAYER.IDM_FVG, "BUY", price <= lastFvg.top && price >= lastFvg.bottom ? 0.85 : 0.55, "Bullish FVG in play")
      : ls(LAYER.IDM_FVG, "SELL", price <= lastFvg.top && price >= lastFvg.bottom ? 0.85 : 0.55, "Bearish FVG in play")
    : ls(LAYER.IDM_FVG, "NEUTRAL", 0, "No FVG");

  const aligned =
    layers[LAYER.EMA].direction !== "NEUTRAL" &&
    layers[LAYER.EMA].direction === layers[LAYER.PRIME_SWING].direction &&
    layers[LAYER.EMA].direction === layers[LAYER.MTF].direction;
  layers[LAYER.MASTER_CALL] = aligned
    ? ls(LAYER.MASTER_CALL, layers[LAYER.EMA].direction, 0.85, "Master confluence EMA+MTF+structure")
    : ls(LAYER.MASTER_CALL, "NEUTRAL", 0.2, "Master call waiting");

  const sessionOk = isKillzone(last.t);
  layers[LAYER.TIMESTOP] = sessionOk
    ? ls(LAYER.TIMESTOP, layers[LAYER.EMA].direction === "NEUTRAL" ? "NEUTRAL" : layers[LAYER.EMA].direction, 0.7, "Killzone window open")
    : ls(LAYER.TIMESTOP, "NEUTRAL", 0.3, "Outside killzone — time stop risk");

  let wBuy = 0;
  let wSell = 0;
  let wTot = 0;
  let buyVotes = 0;
  let sellVotes = 0;
  let neutralVotes = 0;
  for (const layer of layers) {
    wTot += layer.weight;
    if (layer.direction === "BUY") {
      wBuy += layer.weight * layer.strength;
      buyVotes += 1;
    } else if (layer.direction === "SELL") {
      wSell += layer.weight * layer.strength;
      sellVotes += 1;
    } else neutralVotes += 1;
  }
  const bs = wTot ? wBuy / wTot : 0;
  const ss = wTot ? wSell / wTot : 0;
  let direction: Direction = "NEUTRAL";
  let fusionScore = 0;
  if (bs > ss) {
    direction = "BUY";
    fusionScore = bs;
  } else if (ss > bs) {
    direction = "SELL";
    fusionScore = ss;
  }

  const slMult = 1;
  const slDist = atrVal * ATR_SL_MULT * slMult;
  const stop = direction === "BUY" ? price - slDist : price + slDist;
  const takeProfits = ATR_TP_MULTS.map((m) => (direction === "BUY" ? price + atrVal * m : price - atrVal * m));
  const risk = Math.abs(price - stop);
  const riskReward = takeProfits.map((tp) => (risk ? Math.abs(tp - price) / risk : 0));

  const gate1 =
    layers[LAYER.EMA].direction !== "NEUTRAL" &&
    layers[LAYER.EMA].direction === layers[LAYER.MTF].direction &&
    layers[LAYER.MTF].direction === layers[LAYER.PRIME_SWING].direction;
  const gate2 =
    (layers[LAYER.OTE].direction !== "NEUTRAL" && layers[LAYER.OTE].direction === layers[LAYER.IDM_FVG].direction) ||
    layers[LAYER.IDM_FVG].strength > 0.8;
  const agree3 = [
    layers[LAYER.RSI].direction === direction,
    layers[LAYER.STOCHASTIC].direction === direction,
    layers[LAYER.VOLUME].direction === direction,
    layers[LAYER.VWAP].direction === direction,
  ].filter(Boolean).length;
  const gate3 = agree3 >= 3;
  const gate4 =
    layers[LAYER.MASTER_CALL].direction === direction &&
    (layers[LAYER.ULTRA_SCALPER].direction === direction || layers[LAYER.MASTER_CALL].strength > 0.8);
  const gate5 = riskReward[0] >= RR_MINIMUM;
  const gates = [
    { id: 1, label: "Trend stack", passed: gate1, detail: "EMA + MTF + PrimeSwing agree" },
    { id: 2, label: "SMC zone", passed: gate2, detail: "OTE and IDM/FVG confluence" },
    { id: 3, label: "Momentum", passed: gate3, detail: `${agree3}/4 RSI·Stoch·Vol·VWAP` },
    { id: 4, label: "Master + sweep", passed: gate4, detail: "MasterCall with UltraScalper" },
    { id: 5, label: "R:R TP1", passed: gate5, detail: `TP1 R:R ${riskReward[0]?.toFixed(2) ?? "—"}` },
  ];

  let bonus = 0;
  let penalty = 0;
  if (layers[LAYER.MTF].strength > 0.7) bonus += 5;
  if (volumeSpike) bonus += 5;
  if (layers[LAYER.IDM_FVG].strength > 0.8) bonus += 5;
  if (layers[LAYER.MASTER_CALL].strength > 0.8) bonus += 3;
  const confCount = layers.filter((l) => l.direction === direction).length;
  if (confCount >= 12) bonus += 10;
  else if (confCount >= 10) bonus += 5;
  if (layers[LAYER.MTF].direction !== direction) penalty += 5;
  if (layers[LAYER.VOLUME].strength < 0.3) penalty += 3;
  if (layers[LAYER.TIMESTOP].strength < 0.5) penalty += 6;
  if (atrRatio > 2) penalty += 5;
  const confidence = Math.max(0, Math.min(100, fusionScore * 100 + bonus - penalty));

  let confidenceLevel: FusionResult["confidenceLevel"] = "LOW";
  let lotMult = 0.5;
  let slM = 1.2;
  if (confidence >= 90) {
    confidenceLevel = "ULTRA";
    lotMult = 2;
    slM = 0.8;
  } else if (confidence >= 80) {
    confidenceLevel = "HIGH";
    lotMult = 1.5;
    slM = 0.9;
  } else if (confidence >= 65) {
    confidenceLevel = "MEDIUM";
    lotMult = 1;
    slM = 1;
  }

  const passed = gates.filter((g) => g.passed).length;
  let status: ExecStatus = "WAITING";
  if (direction === "NEUTRAL" || fusionScore < 0.2) status = "ABORT";
  else if (passed >= 4 && fusionScore >= FUSION_SCORE_MIN && confidence >= CONFIDENCE_MIN) status = "ALL-IN";
  else status = "WAITING";

  return {
    direction,
    fusionScore,
    confidence,
    confidenceLevel,
    lotMult,
    slMult: slM,
    buyVotes,
    sellVotes,
    neutralVotes,
    gates,
    allGates: gates.every((g) => g.passed),
    status,
    entry: price,
    stop,
    takeProfits,
    riskReward,
    layers,
    regime,
    smc,
    atr: atrVal,
    rsi: r,
    adx: adxPack.adx,
  };
}

export function isKillzone(ts = Date.now()): boolean {
  const h = new Date(ts).getUTCHours();
  return [2, 3, 8, 9, 10, 13, 14, 15].includes(h);
}

export function utcSession(ts = Date.now()): "ASIA" | "LONDON" | "NY" | "OVERLAP" | "OFF" {
  const h = new Date(ts).getUTCHours();
  if (h >= 13 && h < 17) return "OVERLAP";
  if (h >= 8 && h < 17) return "LONDON";
  if (h >= 13 && h < 22) return "NY";
  if (h >= 0 && h < 9) return "ASIA";
  return "OFF";
}

export function agentVotes(layers: LayerSignal[]) {
  return Object.entries(AGENT_LAYER_MAP).map(([name, ids]) => {
    const pack = ids.map((id) => layers[id]);
    const buy = pack.filter((l) => l.direction === "BUY").length;
    const sell = pack.filter((l) => l.direction === "SELL").length;
    const direction: Direction = buy === sell ? "NEUTRAL" : buy > sell ? "BUY" : "SELL";
    const conviction = pack.reduce((a, l) => a + l.strength, 0) / pack.length;
    return { name, direction, conviction, notes: pack.map((l) => l.note) };
  });
}

export function snapshotChecksum(payload: string): string {
  let h = 2166136261;
  for (let i = 0; i < payload.length; i++) h = Math.imul(h ^ payload.charCodeAt(i), 16777619);
  return `md90-${(h >>> 0).toString(16).padStart(8, "0")}`;
}

export function barStartFor(timeframe: Timeframe, now = Date.now()): number {
  return Math.floor(now / TF_MS[timeframe]) * TF_MS[timeframe];
}
