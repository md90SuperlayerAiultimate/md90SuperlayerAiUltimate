import {
  AUTO_CONF_FLOOR,
  AUTO_GATES_FLOOR,
  AUTO_SCORE_FLOOR,
  DEFAULT_RISK_PCT,
  MAX_CONSECUTIVE_LOSSES,
  MAX_DAILY_LOSS_PCT,
  MAX_DRAWDOWN_PCT,
  MAX_POSITIONS,
  MAX_TRADES_PER_DAY,
  PARTIAL_PCT,
  STARTING_EQUITY,
  type RiskMode,
} from "./constants";
import type { Direction, FusionResult } from "./engine";

export type PaperSide = "BUY" | "SELL";
export type PaperStatus = "OPEN" | "PARTIAL" | "CLOSED" | "BLOCKED";

export type PaperFill = {
  id: string;
  symbol: string;
  side: PaperSide;
  qty: number;
  price: number;
  fee: number;
  slippageBps: number;
  ts: number;
  note: string;
};

export type PaperPosition = {
  id: string;
  symbol: string;
  side: PaperSide;
  qty: number;
  entry: number;
  stop: number;
  takeProfits: number[];
  tpHit: number;
  openedAt: number;
  status: PaperStatus;
  unrealized: number;
  realized: number;
  riskPct: number;
  correlationId: string;
};

export type RiskCheck = {
  code: string;
  label: string;
  ok: boolean;
  detail: string;
};

export type AccountState = {
  cash: number;
  equity: number;
  peakEquity: number;
  dailyStart: number;
  dailyPnl: number;
  consecutiveLosses: number;
  tradesToday: number;
  dayKey: string;
};

export function freshAccount(now = Date.now()): AccountState {
  return {
    cash: STARTING_EQUITY,
    equity: STARTING_EQUITY,
    peakEquity: STARTING_EQUITY,
    dailyStart: STARTING_EQUITY,
    dailyPnl: 0,
    consecutiveLosses: 0,
    tradesToday: 0,
    dayKey: new Date(now).toISOString().slice(0, 10),
  };
}

export function drawdownPct(account: AccountState): number {
  if (!account.peakEquity) return 0;
  return Math.max(0, ((account.peakEquity - account.equity) / account.peakEquity) * 100);
}

export function dailyLossPct(account: AccountState): number {
  if (!account.dailyStart) return 0;
  return Math.max(0, ((account.dailyStart - account.equity) / account.dailyStart) * 100);
}

export function evaluateRisk(input: {
  fusion: FusionResult;
  account: AccountState;
  openCount: number;
  session: string;
  liveRequested?: boolean;
  mode?: RiskMode;
}): RiskCheck[] {
  const dd = drawdownPct(input.account);
  const daily = dailyLossPct(input.account);
  const auto = input.mode === "AUTO";
  const passed = input.fusion.gates.filter((g) => g.passed).length;
  const scoreOk = auto
    ? input.fusion.fusionScore >= AUTO_SCORE_FLOOR && input.fusion.status !== "ABORT"
    : input.fusion.fusionScore >= 0.45 && input.fusion.status !== "ABORT";
  const confOk = auto ? input.fusion.confidence >= AUTO_CONF_FLOOR : input.fusion.confidence >= 75;
  const gatesOk = auto ? passed >= AUTO_GATES_FLOOR : input.fusion.allGates;
  return [
    {
      code: "LIVE_ROUTE",
      label: "Live route",
      ok: !input.liveRequested,
      detail: "LIVE LOCKED — custody and broker route disabled",
    },
    {
      code: "FUSION_FLOOR",
      label: "Fusion floor",
      ok: scoreOk,
      detail: `Score ${input.fusion.fusionScore.toFixed(2)} · ${input.fusion.status} · ${auto ? "AUTO" : "STRICT"}`,
    },
    {
      code: "CONFIDENCE",
      label: "Confidence",
      ok: confOk,
      detail: `${input.fusion.confidence.toFixed(1)} / ${auto ? AUTO_CONF_FLOOR : 75} min`,
    },
    {
      code: "GATES",
      label: auto ? "Evidence floor" : "Five gates",
      ok: gatesOk,
      detail: `${passed}/5 passed${auto ? ` · auto floor ${AUTO_GATES_FLOOR}` : ""}`,
    },
    {
      code: "RR",
      label: "R:R TP1",
      ok: auto ? (input.fusion.riskReward[0] ?? 0) >= 1.5 : (input.fusion.riskReward[0] ?? 0) >= 2,
      detail: `${(input.fusion.riskReward[0] ?? 0).toFixed(2)}R`,
    },
    {
      code: "SESSION",
      label: "Session",
      ok: true,
      detail: `${input.session} · 24/7 paper · advisory`,
    },
    {
      code: "DAILY_LOSS",
      label: "Daily loss",
      ok: daily < MAX_DAILY_LOSS_PCT,
      detail: `${daily.toFixed(2)}% / ${MAX_DAILY_LOSS_PCT}% cap`,
    },
    {
      code: "DRAWDOWN",
      label: "Drawdown",
      ok: dd < MAX_DRAWDOWN_PCT,
      detail: `${dd.toFixed(2)}% / ${MAX_DRAWDOWN_PCT}% cap`,
    },
    {
      code: "STREAK",
      label: "Loss streak",
      ok: input.account.consecutiveLosses < MAX_CONSECUTIVE_LOSSES,
      detail: `${input.account.consecutiveLosses} consecutive`,
    },
    {
      code: "FREQUENCY",
      label: "Daily trades",
      ok: input.account.tradesToday < MAX_TRADES_PER_DAY,
      detail: `${input.account.tradesToday}/${MAX_TRADES_PER_DAY}`,
    },
    {
      code: "BOOK",
      label: "Open book",
      ok: input.openCount < MAX_POSITIONS,
      detail: `${input.openCount}/${MAX_POSITIONS}`,
    },
  ];
}

export function kellyFraction(winRate: number, payoff: number): number {
  if (payoff <= 0) return 0;
  const f = winRate - (1 - winRate) / payoff;
  return Math.max(0, Math.min(0.25, f));
}

export function sizePosition(equity: number, entry: number, stop: number, lotMult: number, riskPct = DEFAULT_RISK_PCT) {
  const risk = Math.abs(entry - stop);
  if (!risk) return 0;
  const dollars = equity * (riskPct / 100) * lotMult;
  return dollars / risk;
}

export function paperFillPrice(entry: number, side: PaperSide, slippageBps: number): number {
  const slip = entry * (slippageBps / 10_000);
  return side === "BUY" ? entry + slip : entry - slip;
}

export function feeOn(notional: number): number {
  return notional * 0.0004;
}

export function markPosition(pos: PaperPosition, price: number): PaperPosition {
  const dir = pos.side === "BUY" ? 1 : -1;
  const unrealized = (price - pos.entry) * pos.qty * dir;
  return { ...pos, unrealized };
}

export function hitStops(pos: PaperPosition, candle: { h: number; l: number; c: number }): {
  pos: PaperPosition;
  fills: PaperFill[];
  closedPnl: number;
} {
  const fills: PaperFill[] = [];
  let next = { ...pos };
  let closedPnl = 0;
  const hitStop = pos.side === "BUY" ? candle.l <= pos.stop : candle.h >= pos.stop;
  if (hitStop && next.qty > 0) {
    const pnl = (pos.stop - pos.entry) * next.qty * (pos.side === "BUY" ? 1 : -1);
    fills.push({
      id: `${pos.id}-sl`,
      symbol: pos.symbol,
      side: pos.side === "BUY" ? "SELL" : "BUY",
      qty: next.qty,
      price: pos.stop,
      fee: feeOn(pos.stop * next.qty),
      slippageBps: 0,
      ts: Date.now(),
      note: "Stop hit",
    });
    closedPnl += pnl;
    next = { ...next, qty: 0, status: "CLOSED", realized: next.realized + pnl, unrealized: 0 };
    return { pos: next, fills, closedPnl };
  }
  while (next.tpHit < PARTIAL_PCT.length && next.qty > 0) {
    const tp = pos.takeProfits[next.tpHit];
    const hit = pos.side === "BUY" ? candle.h >= tp : candle.l <= tp;
    if (!hit) break;
    const pct = PARTIAL_PCT[next.tpHit] / 100;
    const closeQty = next.qty * (next.tpHit === PARTIAL_PCT.length - 1 ? 1 : pct / (1 - PARTIAL_PCT.slice(0, next.tpHit).reduce((a, b) => a + b, 0) / 100 || 1));
    const qty = Math.min(next.qty, closeQty || next.qty * pct);
    const pnl = (tp - pos.entry) * qty * (pos.side === "BUY" ? 1 : -1);
    fills.push({
      id: `${pos.id}-tp${next.tpHit + 1}`,
      symbol: pos.symbol,
      side: pos.side === "BUY" ? "SELL" : "BUY",
      qty,
      price: tp,
      fee: feeOn(tp * qty),
      slippageBps: 0,
      ts: Date.now(),
      note: `TP${next.tpHit + 1} ${PARTIAL_PCT[next.tpHit]}%`,
    });
    closedPnl += pnl;
    next = {
      ...next,
      qty: next.qty - qty,
      tpHit: next.tpHit + 1,
      status: next.qty - qty <= 0 ? "CLOSED" : "PARTIAL",
      realized: next.realized + pnl,
    };
  }
  return { pos: markPosition(next, candle.c), fills, closedPnl };
}

export function openPaper(input: {
  symbol: string;
  fusion: FusionResult;
  account: AccountState;
  correlationId: string;
  sizeMult?: number;
  note?: string;
}): { position: PaperPosition; fill: PaperFill } | { blocked: string } {
  if (input.fusion.direction === "NEUTRAL" || input.fusion.status === "ABORT") {
    return { blocked: "Fusion status is ABORT" };
  }
  const side = input.fusion.direction as Direction as PaperSide;
  const slippageBps = 3 + Math.round((input.fusion.atr / input.fusion.entry) * 10_000 * 0.15);
  const price = paperFillPrice(input.fusion.entry, side, slippageBps);
  const sizeMult = input.sizeMult ?? 1;
  const qty = sizePosition(input.account.equity, price, input.fusion.stop, input.fusion.lotMult * sizeMult);
  if (qty <= 0) return { blocked: "Size resolved to zero" };
  const id = `pp-${input.correlationId.slice(-8)}`;
  const fill: PaperFill = {
    id: `${id}-in`,
    symbol: input.symbol,
    side,
    qty,
    price,
    fee: feeOn(price * qty),
    slippageBps,
    ts: Date.now(),
    note: input.note ?? "Paper broker fill · no network order",
  };
  const position: PaperPosition = {
    id,
    symbol: input.symbol,
    side,
    qty,
    entry: price,
    stop: input.fusion.stop,
    takeProfits: input.fusion.takeProfits,
    tpHit: 0,
    openedAt: fill.ts,
    status: "OPEN",
    unrealized: 0,
    realized: 0,
    riskPct: DEFAULT_RISK_PCT * input.fusion.lotMult * sizeMult,
    correlationId: input.correlationId,
  };
  return { position, fill };
}
