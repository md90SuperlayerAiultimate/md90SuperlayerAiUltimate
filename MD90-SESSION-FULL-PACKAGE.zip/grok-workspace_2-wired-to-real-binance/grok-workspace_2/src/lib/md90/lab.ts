import { INSTRUMENTS, type InstrumentId, type Timeframe } from "./constants";
import { analyze, generateCandles, type Candle, type FusionResult } from "./engine";
import type { PaperFill } from "./paper";

export type LabStage = "raw" | "normalized" | "features" | "weights" | "pnl";
export type LabStatus = "ok" | "idle" | "running";

export const LAB_STRATEGIES = [
  { id: "fusion", label: "MD90 Fusion", kind: "canonical" as const },
  { id: "momentum", label: "Momentum", kind: "shelf" as const },
  { id: "reversal", label: "Reversal", kind: "shelf" as const },
  { id: "low_vol", label: "Low vol", kind: "shelf" as const },
  { id: "neutral_momentum", label: "Neutral momentum", kind: "shelf" as const },
] as const;

export type LabStrategyId = (typeof LAB_STRATEGIES)[number]["id"];

export type LabTable = {
  name: string;
  stage: LabStage;
  step: string;
  rows: number;
  columns: string[];
  preview: Record<string, string | number>[];
  status: LabStatus;
};

export type LabPeriod = {
  asOf: number;
  strategy: LabStrategyId;
  holdings: number;
  turnover: number;
  gross: number;
  fees: number;
  slippage: number;
  net: number;
};

export type LabTotals = {
  strategy: LabStrategyId;
  gross: number;
  fees: number;
  slippage: number;
  net: number;
  hitRate: number;
  periods: number;
  inSampleNet: number;
  outSampleNet: number;
};

export type LabPoint = { t: number; equity: number };

export type LabRun = {
  runId: string;
  asOf: number;
  digest: string;
  rebalanceBars: number;
  feeBps: number;
  slippageBps: number;
  splitIndex: number;
  tables: LabTable[];
  periods: LabPeriod[];
  totals: LabTotals[];
  curves: Record<LabStrategyId, LabPoint[]>;
  notes: string[];
};

type Snap = {
  id: InstrumentId;
  ret20: number;
  ret5: number;
  vol: number;
  fusion: number;
  dir: number;
  last: number;
};

function preview(rows: Record<string, string | number>[], n = 6) {
  return rows.slice(-n);
}

function trailingReturn(candles: Candle[], lookback: number): number {
  if (candles.length < lookback + 1) return 0;
  const a = candles.at(-1)!.c;
  const b = candles[candles.length - 1 - lookback].c;
  return b ? a / b - 1 : 0;
}

function atrPct(candles: Candle[]): number {
  const slice = candles.slice(-14);
  if (slice.length < 2) return 0;
  let tr = 0;
  for (let i = 1; i < slice.length; i++) {
    tr += Math.max(
      slice[i].h - slice[i].l,
      Math.abs(slice[i].h - slice[i - 1].c),
      Math.abs(slice[i].l - slice[i - 1].c),
    );
  }
  const last = slice.at(-1)!.c;
  return last ? tr / (slice.length - 1) / last : 0;
}

function rankWeights(values: number[], longOnly: boolean): number[] {
  const n = values.length;
  if (!n) return [];
  const order = values.map((v, i) => ({ v, i })).sort((a, b) => b.v - a.v);
  const w = new Array(n).fill(0);
  if (longOnly) {
    const top = order.slice(0, Math.max(1, Math.ceil(n / 2)));
    const share = 1 / top.length;
    for (const item of top) w[item.i] = share;
    return w;
  }
  const half = Math.max(1, Math.floor(n / 2));
  const long = order.slice(0, half);
  const short = order.slice(-half);
  const share = 0.5 / long.length;
  for (const item of long) w[item.i] = share;
  for (const item of short) w[item.i] = -share;
  return w;
}

function weightsFor(strategy: LabStrategyId, snaps: Snap[]): number[] {
  if (strategy === "momentum") return rankWeights(snaps.map((s) => s.ret20), true);
  if (strategy === "reversal") return rankWeights(snaps.map((s) => -s.ret5), true);
  if (strategy === "low_vol") return rankWeights(snaps.map((s) => (s.vol ? 1 / s.vol : 0)), true);
  if (strategy === "neutral_momentum") return rankWeights(snaps.map((s) => s.ret20), false);
  return rankWeights(
    snaps.map((s) => s.fusion * (s.dir || 0)),
    false,
  );
}

function snapAt(
  series: { id: InstrumentId; candles: Candle[] }[],
  bars: number,
  cache: Map<string, FusionResult>,
): Snap[] {
  return series.map(({ id, candles }) => {
    const slice = candles.slice(0, Math.max(40, Math.min(bars, candles.length)));
    const key = `${id}:${slice.length}`;
    let fusion = cache.get(key);
    if (!fusion) {
      fusion = analyze(slice);
      cache.set(key, fusion);
    }
    const dir = fusion.direction === "BUY" ? 1 : fusion.direction === "SELL" ? -1 : 0;
    return {
      id,
      ret20: trailingReturn(slice, 20),
      ret5: trailingReturn(slice, 5),
      vol: atrPct(slice),
      fusion: fusion.fusionScore,
      dir,
      last: slice.at(-1)?.c ?? 0,
    };
  });
}

export function runLabPipeline(input: {
  candles: Candle[];
  fusion: FusionResult | null;
  fills: PaperFill[];
  instrumentId: string;
  timeframe?: Timeframe;
  now?: number;
  rebalanceBars?: number;
}): LabRun {
  const timeframe = input.timeframe ?? "M15";
  const now = input.now ?? Date.now();
  const rebalanceBars = input.rebalanceBars ?? 12;
  const feeBps = 5;
  const slippageBps = 10;
  const candles = input.candles;
  const fusion = input.fusion;

  const universe = INSTRUMENTS.map((inst) => ({
    id: inst.id,
    candles: inst.id === input.instrumentId ? candles : generateCandles(inst.id, timeframe, candles.length, now),
  }));

  const ohlcRows = candles.map((c) => ({
    t: c.t,
    o: Number(c.o.toFixed(4)),
    h: Number(c.h.toFixed(4)),
    l: Number(c.l.toFixed(4)),
    c: Number(c.c.toFixed(4)),
    v: Math.round(c.v),
  }));

  const normalizedRows = ohlcRows.map((r) => ({
    symbol: input.instrumentId,
    t: r.t,
    c: r.c,
    key: `${input.instrumentId}:${r.t}`,
  }));

  const featureRows = fusion
    ? fusion.layers.map((l) => ({
        layer: l.name,
        dir: l.direction,
        str: Number(l.strength.toFixed(3)),
        w: l.weight,
      }))
    : [];

  const cache = new Map<string, FusionResult>();
  const universeNow = snapAt(universe, candles.length, cache);
  const weightRows: Record<string, string | number>[] = [];
  for (const strat of LAB_STRATEGIES) {
    const w = weightsFor(strat.id, universeNow);
    universeNow.forEach((snap, i) => {
      if (Math.abs(w[i]) < 1e-6) return;
      weightRows.push({
        strategy: strat.id,
        symbol: snap.id,
        weight: Number(w[i].toFixed(4)),
        signal: Number((strat.id === "fusion" ? snap.fusion * snap.dir : snap.ret20).toFixed(4)),
      });
    });
  }

  const pnlFillRows = input.fills.map((f) => ({
    id: f.id,
    side: f.side,
    px: Number(f.price.toFixed(4)),
    qty: Number(f.qty.toFixed(4)),
    fee: Number(f.fee.toFixed(4)),
    note: f.note,
  }));

  const tables: LabTable[] = [
    {
      name: "raw.ohlc",
      stage: "raw",
      step: "ingest_ohlc",
      rows: ohlcRows.length,
      columns: ["t", "o", "h", "l", "c", "v"],
      preview: preview(ohlcRows),
      status: ohlcRows.length ? "ok" : "idle",
    },
    {
      name: "normalized.prices",
      stage: "normalized",
      step: "type_and_key",
      rows: normalizedRows.length,
      columns: ["symbol", "t", "c", "key"],
      preview: preview(normalizedRows),
      status: normalizedRows.length ? "ok" : "idle",
    },
    {
      name: "features.layers",
      stage: "features",
      step: "fuse_17_layers",
      rows: featureRows.length,
      columns: ["layer", "dir", "str", "w"],
      preview: preview(featureRows),
      status: featureRows.length ? "ok" : "idle",
    },
    {
      name: "weights.book",
      stage: "weights",
      step: "alphas_on_shelf",
      rows: weightRows.length,
      columns: ["strategy", "symbol", "weight", "signal"],
      preview: preview(weightRows, 8),
      status: weightRows.length ? "ok" : "idle",
    },
    {
      name: "pnl.ledger",
      stage: "pnl",
      step: "price_the_book",
      rows: pnlFillRows.length,
      columns: ["id", "side", "px", "qty", "fee", "note"],
      preview: preview(pnlFillRows),
      status: pnlFillRows.length ? "ok" : "idle",
    },
  ];

  const periods: LabPeriod[] = [];
  const prevW: Record<LabStrategyId, number[]> = {
    fusion: [],
    momentum: [],
    reversal: [],
    low_vol: [],
    neutral_momentum: [],
  };

  for (let bars = 56; bars <= candles.length; bars += rebalanceBars) {
    const snaps = snapAt(universe, bars, cache);
    const later = snapAt(universe, Math.min(candles.length, bars + rebalanceBars), cache);
    const rets = snaps.map((s) => {
      const nxt = later.find((n) => n.id === s.id);
      if (!nxt || !s.last) return 0;
      return nxt.last / s.last - 1;
    });

    for (const strat of LAB_STRATEGIES) {
      const w = weightsFor(strat.id, snaps);
      const prev = prevW[strat.id].length === w.length ? prevW[strat.id] : w.map(() => 0);
      let turnover = 0;
      let gross = 0;
      let holdings = 0;
      for (let i = 0; i < w.length; i++) {
        turnover += Math.abs(w[i] - prev[i]);
        gross += w[i] * (rets[i] ?? 0);
        if (Math.abs(w[i]) > 1e-6) holdings += 1;
      }
      const fees = turnover * (feeBps / 10_000);
      const slip = turnover * (slippageBps / 10_000);
      periods.push({
        asOf: candles[Math.min(candles.length - 1, bars - 1)]?.t ?? now,
        strategy: strat.id,
        holdings,
        turnover: Number(turnover.toFixed(4)),
        gross,
        fees,
        slippage: slip,
        net: gross - fees - slip,
      });
      prevW[strat.id] = w;
    }
  }

  const curves = Object.fromEntries(
    LAB_STRATEGIES.map((strat) => {
      let eq = 1;
      const startT = candles[Math.max(0, 55)]?.t ?? now;
      const series: LabPoint[] = [{ t: startT, equity: 1 }];
      for (const row of periods.filter((p) => p.strategy === strat.id)) {
        eq *= 1 + row.net;
        series.push({ t: row.asOf, equity: Number(eq.toFixed(6)) });
      }
      return [strat.id, series];
    }),
  ) as Record<LabStrategyId, LabPoint[]>;

  const totals: LabTotals[] = LAB_STRATEGIES.map((strat) => {
    const rows = periods.filter((p) => p.strategy === strat.id);
    const hits = rows.filter((p) => p.net > 0).length;
    const inRows = rows.slice(0, Math.ceil(rows.length / 2));
    const outRows = rows.slice(Math.ceil(rows.length / 2));
    const sum = (xs: LabPeriod[], key: keyof LabPeriod) => xs.reduce((a, p) => a + (p[key] as number), 0);
    return {
      strategy: strat.id,
      gross: sum(rows, "gross"),
      fees: sum(rows, "fees"),
      slippage: sum(rows, "slippage"),
      net: sum(rows, "net"),
      hitRate: rows.length ? hits / rows.length : 0,
      periods: rows.length,
      inSampleNet: sum(inRows, "net"),
      outSampleNet: sum(outRows, "net"),
    };
  });

  return {
    runId: `lab-${input.instrumentId}-${rebalanceBars}-${candles.length}`,
    asOf: candles.at(-1)?.t ?? now,
    digest: `${input.instrumentId}:${timeframe}:${rebalanceBars}:${fusion?.status ?? "NA"}`,
    rebalanceBars,
    feeBps,
    slippageBps,
    splitIndex: Math.floor(periods.length / 2),
    tables,
    periods,
    totals,
    curves,
    notes: [
      "The table is the node and the step is the edge.",
      "Net is the headline, not gross. Fees and slippage are charged on turnover.",
      "In-sample vs out-of-sample: believe the second line.",
      "Weights are a portfolio, not an order. LIVE LOCKED.",
      "No benchmark — a rising tape can flatter a long-only book.",
    ],
  };
}
