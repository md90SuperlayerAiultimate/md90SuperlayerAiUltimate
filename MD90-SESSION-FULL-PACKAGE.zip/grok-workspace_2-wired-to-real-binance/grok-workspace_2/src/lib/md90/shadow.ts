import type { TickPrint } from "./live";

export type HealthRow = { code: string; ok: boolean; detail: string };

export function simHealth(lastTickAt: number, now = Date.now()): HealthRow[] {
  const lag = lastTickAt ? now - lastTickAt : 0;
  return [
    { code: "FEED", ok: true, detail: "SIMULATED · seeded OHLC, not a vendor" },
    { code: "TICK", ok: lag > 0 && lag < 2500, detail: lastTickAt ? `${lag}ms since print` : "waiting first print" },
    { code: "WS", ok: false, detail: "NOT CONNECTED · no venue socket" },
    { code: "LIVE", ok: true, detail: "ROUTE LOCKED · no broker, no wallet" },
    { code: "PAPER", ok: true, detail: "READY · fills stay on this desk" },
  ];
}

const HEADLINES = [
  { tag: "MACRO", text: "Fed-cut narrative is a SIM headline, not a live wire." },
  { tag: "METALS", text: "Gold tape here is seeded. Treat it as a clock, not a quote." },
  { tag: "CRYPTO", text: "BTC print is deterministic walk. No exchange feed attached." },
  { tag: "FX", text: "EURUSD session label is UTC clock, not a bank stream." },
  { tag: "RISK", text: "Video ROI claims are marketing. This desk shows sample size." },
  { tag: "POLY", text: "YES+NO book is a paper CLOB. No wallet signs." },
];

export function simNews(now = Date.now()) {
  const start = Math.floor(now / 9000) % HEADLINES.length;
  return [0, 1, 2, 3].map((i) => {
    const row = HEADLINES[(start + i) % HEADLINES.length];
    return {
      ...row,
      age: `${((now / 1000) % 90 | 0) + i * 3}s`,
      freshness: "STALE · SIM",
    };
  });
}

export function simFlow(tape: TickPrint[]) {
  return tape.slice(0, 5).map((p) => ({
    t: p.t,
    id: p.id,
    price: p.price,
    size: Math.abs(p.delta) * 40 + 1,
    side: p.delta >= 0 ? "LIFT" : "HIT",
  }));
}
