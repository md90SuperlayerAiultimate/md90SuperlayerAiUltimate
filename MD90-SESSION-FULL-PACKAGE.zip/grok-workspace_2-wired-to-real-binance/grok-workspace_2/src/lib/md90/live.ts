import {
  AUTO_CONF_FLOOR,
  AUTO_GATES_FLOOR,
  AUTO_SCORE_FLOOR,
  INSTRUMENTS,
  type Autopilot,
  type InstrumentId,
  type Timeframe,
} from "./constants";
import { analyze, generateLiveSeries, type FusionResult } from "./engine";

export type RadarHit = {
  id: InstrumentId;
  label: string;
  price: number;
  direction: FusionResult["direction"];
  score: number;
  confidence: number;
  status: FusionResult["status"];
  gatesPassed: number;
  regime: string;
  candidate: boolean;
  reason: string;
  fusion: FusionResult;
};

export type TickPrint = {
  t: number;
  id: InstrumentId;
  price: number;
  delta: number;
};

export function classifyCandidate(fusion: FusionResult): { ok: boolean; reason: string } {
  if (fusion.direction === "NEUTRAL" || fusion.status === "ABORT") {
    return { ok: false, reason: "ABORT / NEUTRAL" };
  }
  const passed = fusion.gates.filter((g) => g.passed).length;
  if (fusion.fusionScore < AUTO_SCORE_FLOOR) {
    return { ok: false, reason: `score ${fusion.fusionScore.toFixed(2)} < ${AUTO_SCORE_FLOOR}` };
  }
  if (fusion.confidence < AUTO_CONF_FLOOR) {
    return { ok: false, reason: `conf ${fusion.confidence.toFixed(0)} < ${AUTO_CONF_FLOOR}` };
  }
  if (passed < AUTO_GATES_FLOOR) {
    return { ok: false, reason: `gates ${passed}/${AUTO_GATES_FLOOR}` };
  }
  if (fusion.status === "ALL-IN") return { ok: true, reason: "ALL-IN" };
  if (passed >= 3) return { ok: true, reason: "WAITING confluence" };
  return { ok: true, reason: "AUTO floor" };
}

export function scanInstrument(id: InstrumentId, timeframe: Timeframe, now = Date.now(), barTicks?: number): RadarHit {
  const live = generateLiveSeries(id, timeframe, 180, now, barTicks);
  const fusion = analyze(live.candles);
  const verdict = classifyCandidate(fusion);
  const inst = INSTRUMENTS.find((i) => i.id === id)!;
  return {
    id,
    label: inst.label,
    price: live.lastPrice,
    direction: fusion.direction,
    score: fusion.fusionScore,
    confidence: fusion.confidence,
    status: fusion.status,
    gatesPassed: fusion.gates.filter((g) => g.passed).length,
    regime: fusion.regime.name,
    candidate: verdict.ok,
    reason: verdict.reason,
    fusion,
  };
}

export function scanUniverse(timeframe: Timeframe, now = Date.now(), barTicks?: number): RadarHit[] {
  return INSTRUMENTS.map((inst) => scanInstrument(inst.id, timeframe, now, barTicks)).sort(
    (a, b) => b.score * (b.candidate ? 1.25 : 1) - a.score * (a.candidate ? 1.25 : 1),
  );
}

export function pickAutoTarget(
  radar: RadarHit[],
  openSymbols: Set<string>,
  lastBySymbol: Record<string, number>,
  now: number,
  cooldownMs: number,
): RadarHit | null {
  for (const hit of radar) {
    if (!hit.candidate) continue;
    if (openSymbols.has(hit.id)) continue;
    const last = lastBySymbol[hit.id] ?? 0;
    if (now - last < cooldownMs) continue;
    return hit;
  }
  return null;
}

export function pickProbeTarget(radar: RadarHit[], openSymbols: Set<string>): RadarHit | null {
  const ranked = [...radar].sort((a, b) => b.score - a.score);
  return ranked.find((hit) => hit.direction !== "NEUTRAL" && hit.status !== "ABORT" && !openSymbols.has(hit.id)) ?? null;
}

export function autopilotLabel(mode: Autopilot, locale: "ID" | "EN"): string {
  if (mode === "PAPER") return locale === "ID" ? "AUTO PAPER" : "AUTO PAPER";
  if (mode === "SHADOW") return locale === "ID" ? "SHADOW" : "SHADOW";
  return locale === "ID" ? "AUTO OFF" : "AUTO OFF";
}
