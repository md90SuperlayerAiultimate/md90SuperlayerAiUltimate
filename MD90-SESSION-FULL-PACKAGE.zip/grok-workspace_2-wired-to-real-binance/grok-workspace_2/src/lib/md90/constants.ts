export const LAYER_NAMES = [
  "SNR",
  "EMA",
  "RSI",
  "Stochastic",
  "OrderBlock",
  "Volume",
  "MTF",
  "Sentiment",
  "UltraScalper",
  "PrimeSwing",
  "MacroFlow",
  "VWAP",
  "ATR",
  "OTE",
  "IDM_FVG",
  "MasterCall",
  "TimeStop",
] as const;

export const LAYER_WEIGHTS = [
  0.08, 0.07, 0.06, 0.05, 0.08, 0.06, 0.07, 0.04, 0.07, 0.08, 0.07, 0.04, 0.04, 0.06, 0.06, 0.05,
  0.02,
];

export const TOTAL_LAYERS = 17;
export const FUSION_SCORE_MIN = 0.55;
export const CONFIDENCE_MIN = 75;
export const RR_MINIMUM = 2;
export const ATR_SL_MULT = 1.5;
/** ATR multiples so TP1 = 2R given SL = 1.5 ATR. */
export const ATR_TP_MULTS = [3, 4.5, 6, 7.5, 10.5, 15];
export const PARTIAL_PCT = [25, 25, 20, 15, 10];

export const LAYER = {
  SNR: 0,
  EMA: 1,
  RSI: 2,
  STOCHASTIC: 3,
  ORDER_BLOCK: 4,
  VOLUME: 5,
  MTF: 6,
  SENTIMENT: 7,
  ULTRA_SCALPER: 8,
  PRIME_SWING: 9,
  MACRO_FLOW: 10,
  VWAP: 11,
  ATR: 12,
  OTE: 13,
  IDM_FVG: 14,
  MASTER_CALL: 15,
  TIMESTOP: 16,
} as const;

export const AGENT_LAYER_MAP: Record<string, number[]> = {
  price_agent: [LAYER.SNR, LAYER.EMA, LAYER.MACRO_FLOW],
  momentum_agent: [LAYER.RSI, LAYER.STOCHASTIC, LAYER.SENTIMENT],
  structure_agent: [LAYER.ORDER_BLOCK, LAYER.OTE, LAYER.IDM_FVG, LAYER.MASTER_CALL],
  sweep_agent: [LAYER.MTF, LAYER.ULTRA_SCALPER, LAYER.PRIME_SWING],
  risk_agent: [LAYER.VOLUME, LAYER.ATR, LAYER.TIMESTOP, LAYER.VWAP],
};

export const OPERATING_STAGES = [
  "INGEST",
  "NORMALIZE",
  "PARITY",
  "CONFLUENCE",
  "RISK_GATE",
  "PAPER_DECISION",
  "PAPER_FILL",
  "POSITION",
  "JOURNAL",
  "AUDIT",
] as const;

export const STARTING_EQUITY = 10_000;
export const DEFAULT_RISK_PCT = 1;
export const MAX_DRAWDOWN_PCT = 10;
export const MAX_DAILY_LOSS_PCT = 3;
export const MAX_POSITIONS = 3;
export const MAX_TRADES_PER_DAY = 8;
export const MAX_CONSECUTIVE_LOSSES = 3;
export const ENGINE_VERSION = "MD90-SUPERLAYER-AIO-2";

export const TICK_MS = 220;
export const AUTO_COOLDOWN_MS = 6_000;
export const AUTO_SCORE_FLOOR = 0.24;
export const AUTO_CONF_FLOOR = 28;
export const AUTO_GATES_FLOOR = 1;

export const INSTRUMENTS = [
  { id: "XAUUSD", label: "XAU/USD", venue: "SIM-FX", assetClass: "METALS", base: 2648, digits: 2 },
  { id: "BTCUSDT", label: "BTC/USDT", venue: "SIM-CEX", assetClass: "CRYPTO", base: 67540, digits: 0 },
  { id: "ETHUSDT", label: "ETH/USDT", venue: "SIM-CEX", assetClass: "CRYPTO", base: 3482, digits: 1 },
  { id: "EURUSD", label: "EUR/USD", venue: "SIM-FX", assetClass: "FX", base: 1.0842, digits: 5 },
  { id: "SOLUSDT", label: "SOL/USDT", venue: "SIM-CEX", assetClass: "CRYPTO", base: 178.4, digits: 2 },
] as const;

export type InstrumentId = (typeof INSTRUMENTS)[number]["id"];
export type Instrument = (typeof INSTRUMENTS)[number];

export const TIMEFRAMES = ["M5", "M15", "H1", "H4"] as const;
export type Timeframe = (typeof TIMEFRAMES)[number];

export const TF_MS: Record<Timeframe, number> = {
  M5: 5 * 60_000,
  M15: 15 * 60_000,
  H1: 60 * 60_000,
  H4: 4 * 60 * 60_000,
};

export type Autopilot = "OFF" | "SHADOW" | "PAPER";
export type RiskMode = "STRICT" | "AUTO";
