import type { PredictionMarket } from "./markets";

export type ArbOpportunity = {
  slug: string;
  question: string;
  yes: number;
  no: number;
  sum: number;
  gapBps: number;
  side: "SELL_BOTH" | "BUY_BOTH" | "NONE";
  note: string;
};

export type CopyTemplate = {
  id: string;
  name: string;
  source: string;
  riskPct: number;
  status: "PAPER" | "BLOCKED";
  note: string;
};

export type ScannerRow = {
  name: string;
  family: string;
  status: "INTEGRATED" | "SHADOW" | "PENDING" | "BLOCKED";
  note: string;
};

export const COPY_TEMPLATES: CopyTemplate[] = [
  {
    id: "fusion-lead",
    name: "Fusion lead",
    source: "MD90 MasterCall",
    riskPct: 0.5,
    status: "PAPER",
    note: "Mirrors ALL-IN fusion at half size. Paper template only.",
  },
  {
    id: "structure-sweep",
    name: "Structure sweep",
    source: "SMC / ICT copy-bot family",
    riskPct: 0.5,
    status: "PAPER",
    note: "Enters after a labeled sweep. No wallet follow.",
  },
  {
    id: "clob-gap",
    name: "CLOB gap",
    source: "polymarket arb family",
    riskPct: 0.25,
    status: "PAPER",
    note: "Fades YES+NO dislocation on the simulated book.",
  },
  {
    id: "live-copy",
    name: "Live wallet copy",
    source: "copy-trading bots",
    riskPct: 0,
    status: "BLOCKED",
    note: "Custody and follow-wallet routes stay LIVE LOCKED.",
  },
];

export const SCANNER_REGISTRY: ScannerRow[] = [
  {
    name: "MD90 Fusion 17",
    family: "Canonical",
    status: "INTEGRATED",
    note: "Evidence-weighted composite with five gates",
  },
  {
    name: "SMC / ICT",
    family: "Canonical",
    status: "INTEGRATED",
    note: "FVG, order block, liquidity sweep",
  },
  {
    name: "Qanat walk-forward",
    family: "Research lab",
    status: "INTEGRATED",
    note: "Table pipeline: raw → features → weights → pnl",
  },
  {
    name: "YES+NO gap",
    family: "Microstructure",
    status: "INTEGRATED",
    note: "Simulated CLOB arithmetic, never a live arb bot",
  },
  {
    name: "TradingAgents desk",
    family: "Multi-agent",
    status: "INTEGRATED",
    note: "Deterministic layer agents + optional Grok brief",
  },
  {
    name: "External alpha / Phoenix",
    family: "Shadow",
    status: "SHADOW",
    note: "Named, not scored. No order side effect.",
  },
  {
    name: "Whale tape",
    family: "Shadow",
    status: "SHADOW",
    note: "Lagged prints labeled lag=true",
  },
  {
    name: "Live CLOB / wallet / copy",
    family: "Execution",
    status: "BLOCKED",
    note: "Keys, custody, and network orders disabled",
  },
];

export function scanArb(markets: PredictionMarket[]): ArbOpportunity[] {
  return markets.map((m) => {
    const sum = m.yes + m.no;
    const gapBps = Math.round(Math.abs(1 - sum) * 10_000);
    let side: ArbOpportunity["side"] = "NONE";
    let note = "Book sums to ~1. No paper arb.";
    if (sum > 1.02) {
      side = "SELL_BOTH";
      note = "YES+NO rich. Paper fade both sides of the sim book.";
    } else if (sum < 0.98) {
      side = "BUY_BOTH";
      note = "YES+NO cheap. Paper lift both sides of the sim book.";
    }
    return {
      slug: m.slug,
      question: m.question,
      yes: m.yes,
      no: m.no,
      sum,
      gapBps,
      side,
      note,
    };
  });
}
