export type BookLevel = { price: number; size: number };
export type Resolution = "none" | "pending" | "proposed" | "disputed" | "resolved";
export type FeedLabel = "sim_book" | "lagged_tape" | "outage" | "status_unknown";

export type PredictionMarket = {
  slug: string;
  question: string;
  category: string;
  yes: number;
  no: number;
  spread: number;
  volume: number;
  bids: BookLevel[];
  asks: BookLevel[];
  resolution: Resolution;
  feed: FeedLabel;
  laggedPrints: { ts: number; side: "YES" | "NO"; price: number; size: number; lag: true }[];
};

export type ClobFill = {
  id: string;
  slug: string;
  side: "YES" | "NO";
  usd: number;
  avgPrice: number;
  shares: number;
  fee: number;
  remaining: number;
  ts: number;
  note: string;
};

function clamp01(n: number) {
  return Math.min(0.97, Math.max(0.03, n));
}

export function buildPredictionMarkets(seedPrice: number, now = Date.now()): PredictionMarket[] {
  const drift = ((seedPrice % 100) / 100 - 0.5) * 0.08;
  const btcYes = clamp01(0.52 + drift);
  const ethYes = clamp01(0.47 + drift * 0.6);
  const wxYes = clamp01(0.61 - drift * 0.3);
  const polYes = clamp01(0.44 + Math.sin(now / 8e7) * 0.05);
  const arbYes = clamp01(0.33 + Math.abs(drift));
  const sportYes = clamp01(0.58 - drift * 0.2);

  const mk = (
    slug: string,
    question: string,
    category: string,
    yes: number,
    resolution: Resolution,
  ): PredictionMarket => {
    const spread = 0.01 + (yes % 0.02);
    const mid = yes;
    const bids: BookLevel[] = [0, 1, 2, 3, 4].map((i) => ({
      price: clamp01(mid - spread / 2 - i * 0.01),
      size: 1200 - i * 180,
    }));
    const asks: BookLevel[] = [0, 1, 2, 3, 4].map((i) => ({
      price: clamp01(mid + spread / 2 + i * 0.01),
      size: 1100 - i * 160,
    }));
    return {
      slug,
      question,
      category,
      yes: mid,
      no: 1 - mid,
      spread,
      volume: 40_000 + Math.round(mid * 90_000),
      bids,
      asks,
      resolution,
      feed: "sim_book",
      laggedPrints: [
        { ts: now - 180_000, side: "YES", price: clamp01(mid - 0.01), size: 220, lag: true },
        { ts: now - 90_000, side: "NO", price: clamp01(1 - mid + 0.01), size: 140, lag: true },
        { ts: now - 25_000, side: "YES", price: mid, size: 80, lag: true },
      ],
    };
  };

  return [
    mk("btc-15m-up", "Bitcoin up in the next 15 minutes?", "Crypto", btcYes, "none"),
    mk("eth-daily-close", "ETH closes above session VWAP?", "Crypto", ethYes, "none"),
    mk("wx-nyc-rain", "Rain in NYC before 21:00 UTC?", "Weather", wxYes, "pending"),
    mk("pol-rate-hold", "Policy rate held at next print?", "Macro", polYes, "none"),
    mk("arb-yes-no-gap", "YES+NO book gap exceeds 2¢?", "Microstructure", arbYes, "none"),
    mk("sport-total-over", "Listed total goes over?", "Sport", sportYes, "proposed"),
  ];
}

export function walkBook(levels: BookLevel[], usd: number): { avgPrice: number; shares: number; remaining: number } {
  let leftover = usd;
  let cost = 0;
  let shares = 0;
  for (const level of levels) {
    if (leftover <= 0) break;
    const levelNotional = level.price * level.size;
    const take = Math.min(leftover, levelNotional);
    const got = level.price > 0 ? take / level.price : 0;
    shares += got;
    cost += take;
    leftover -= take;
  }
  return {
    avgPrice: shares ? cost / shares : 0,
    shares,
    remaining: leftover,
  };
}

export function paperClobFill(market: PredictionMarket, side: "YES" | "NO", usd: number, now = Date.now()): ClobFill | { blocked: string } {
  if (usd <= 0) return { blocked: "Size resolved to zero" };
  if (market.feed === "outage" || market.feed === "status_unknown") {
    return { blocked: "Book outage — missing sides stay em dash, never 0" };
  }
  const levels = side === "YES" ? market.asks : market.bids;
  if (!levels.length) return { blocked: "Empty book is outage, not a fake 0" };
  const walked = walkBook(levels, usd);
  if (walked.shares <= 0) return { blocked: "ZERO_FILL" };
  const fee = walked.avgPrice * walked.shares * 0.002;
  return {
    id: `clob-${market.slug}-${now.toString(36)}`,
    slug: market.slug,
    side,
    usd,
    avgPrice: walked.avgPrice,
    shares: walked.shares,
    fee,
    remaining: walked.remaining,
    ts: now,
    note: walked.remaining > 0 ? "PARTIAL_FILL · sim_book" : "FULL_FILL · sim_book · no keys",
  };
}

export type ShadowCapability = {
  family: string;
  source: string;
  status: "PAPER" | "SHADOW" | "BLOCKED" | "ADVISORY";
  note: string;
};

export const SHADOW_REGISTRY: ShadowCapability[] = [
  { family: "CLOB watch", source: "PolyTerm / py-clob-client", status: "SHADOW", note: "Simulated top-of-book. Missing sides render as em dash, never 0." },
  { family: "Paper CLOB fills", source: "polymarket-paper-trader", status: "PAPER", note: "Walks a simulated book with fee and leftover. No keys." },
  { family: "Copy trading", source: "copy-bot family", status: "BLOCKED", note: "Live copy route disabled. Paper templates only." },
  { family: "Cross-venue arb", source: "arb bot family", status: "PAPER", note: "YES+NO gap scanner on simulated books." },
  { family: "Whale tape", source: "whale-watcher family", status: "SHADOW", note: "Lagged prints labeled lag=true." },
  { family: "Multi-agent desk", source: "TradingAgents / AI Hedge Fund / crewAI", status: "ADVISORY", note: "Deterministic layer agents. Optional Grok brief is user-initiated." },
  { family: "Qanat lab", source: "fidetolabs/qanat", status: "PAPER", note: "Table pipeline raw→normalized→features→weights→pnl. Weights are not orders." },
  { family: "Operating pipeline", source: "MD90 cockpit", status: "PAPER", note: "Ten-stage correlation machine. LIVE LOCKED." },
  { family: "MCP connectors", source: "tradingview-mcp / nango / mcp-polymarket", status: "ADVISORY", note: "Read-only future. No order authority." },
  { family: "Strategy lab", source: "freqtrade / hummingbot / nautilus / backtrader", status: "PAPER", note: "Replay and paper templates, not live bots." },
  { family: "Weather / sports PM", source: "weather & sports bot family", status: "SHADOW", note: "Simulated contracts. Resolution flags not invented grades." },
  { family: "Terminal chrome", source: "Fincept / polyterm", status: "PAPER", note: "Function-key desks, honest outage line, paper engine." },
];
