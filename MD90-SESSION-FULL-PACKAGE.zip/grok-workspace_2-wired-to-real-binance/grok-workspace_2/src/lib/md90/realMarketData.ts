/**
 * Real market data client — replaces engine.ts's generateCandles()/generateLiveSeries()
 * (seeded-random synthetic candles, mulberry32) with a real fetch against MD90's actual
 * backend, server/routers.ts's `market.history` tRPC query, which itself calls
 * publicHistory.ts -> Binance public klines (real, tested: publicHistory.test.ts 4/4).
 *
 * This NEVER silently falls back to synthetic data on failure — a network error or a
 * non-crypto instrument (market.history only serves CRYPTO; see routers.ts) surfaces as
 * an explicit `{ status: "error" | "blocked" }` result the UI must render as such, not as
 * a plausible-looking fake candle. Showing fabricated prices as if they were real is a
 * worse failure mode than an empty/error state — exactly the problem found in this UI's
 * previous generateCandles()-only implementation.
 */

export type RealCandle = { time: number; open: number; high: number; low: number; close: number; volume: number };

export type RealHistoryResult =
  | { status: "ready"; symbol: string; candles: RealCandle[]; lastPrice: number }
  | { status: "blocked"; symbol: string; reason: string }
  | { status: "error"; symbol: string; reason: string };

const DEFAULT_BACKEND_BASE_URL = "https://superlayerai-o5byspgg.manus.space";

function backendBaseUrl(): string {
  // Allow overriding at build time (e.g. VITE_MD90_BACKEND_URL=http://localhost:3000
  // for local dev against a locally running md90-superlayerai-cockpit-main).
  const fromEnv = (import.meta as unknown as { env?: Record<string, string> }).env?.VITE_MD90_BACKEND_URL;
  return fromEnv || DEFAULT_BACKEND_BASE_URL;
}

const intervalMap: Record<string, "1m" | "5m" | "15m" | "1h" | "4h" | "1d"> = {
  "1m": "1m",
  "5m": "5m",
  "15m": "15m",
  "1h": "1h",
  "4h": "4h",
  "1d": "1d",
};

export type LiveSeriesResult =
  | { source: "REAL_BINANCE"; candles: import("./engine").Candle[]; lastPrice: number; barStart: number }
  | { source: "SIMULATED"; reason: string };

/**
 * Drop-in replacement for engine.ts's generateLiveSeries(), but async and honest about
 * its source. Only CRYPTO instruments (BTCUSDT, ETHUSDT, SOLUSDT — matching the MD90
 * backend's own market.history constraint) can return REAL_BINANCE; everything else
 * (XAUUSD, EURUSD: no free public OHLC source wired into MD90's backend) returns
 * SIMULATED with an explicit reason, for the caller to render as sim/paper, not to
 * silently fall back to fetching fake data and labeling it the same as real.
 */
export async function fetchRealLiveSeries(instrumentId: string, timeframeMs: number): Promise<LiveSeriesResult> {
  const timeframe = timeframeMs <= 5 * 60_000 ? "5m" : timeframeMs <= 15 * 60_000 ? "15m" : timeframeMs <= 60 * 60_000 ? "1h" : "4h";
  const result = await fetchRealHistory(instrumentId, timeframe, 180);
  if (result.status !== "ready") {
    return { source: "SIMULATED", reason: result.status === "blocked" ? result.reason : `REAL_FETCH_FAILED: ${result.reason}` };
  }
  const candles = result.candles.map((c) => ({ t: c.time, o: c.open, h: c.high, l: c.low, c: c.close, v: c.volume }));
  const barStart = candles.at(-1)?.t ?? Date.now();
  return { source: "REAL_BINANCE", candles, lastPrice: result.lastPrice, barStart };
}

export async function fetchRealHistory(symbol: string, timeframe: string, limit = 120): Promise<RealHistoryResult> {
  const interval = intervalMap[timeframe] ?? "15m";
  const input = encodeURIComponent(JSON.stringify({ json: { symbol, interval, limit } }));
  const url = `${backendBaseUrl()}/api/trpc/market.history?input=${input}`;

  let response: Response;
  try {
    response = await fetch(url, { headers: { Accept: "application/json" } });
  } catch (error) {
    return { status: "error", symbol, reason: error instanceof Error ? error.message : "NETWORK_ERROR" };
  }

  if (!response.ok) {
    return { status: "error", symbol, reason: `HTTP_${response.status}` };
  }

  let body: unknown;
  try {
    body = await response.json();
  } catch {
    return { status: "error", symbol, reason: "INVALID_JSON_RESPONSE" };
  }

  const result = (body as { result?: { data?: { json?: { status: "ready" | "blocked"; reason?: string; series?: { candles?: RealCandle[] } } } } })?.result?.data?.json;
  if (!result) return { status: "error", symbol, reason: "UNEXPECTED_RESPONSE_SHAPE" };
  if (result.status === "blocked") return { status: "blocked", symbol, reason: result.reason ?? "BLOCKED" };

  const candles = result.series?.candles ?? [];
  if (candles.length === 0) return { status: "error", symbol, reason: "EMPTY_SERIES" };

  return { status: "ready", symbol, candles, lastPrice: candles[candles.length - 1].close };
}

/**
 * Lightweight poller: calls fetchRealHistory on an interval and invokes onUpdate with
 * every result (including error/blocked states — callers decide how to render those,
 * this never hides a failure by skipping the callback). Returns a stop function.
 */
export function pollRealHistory(symbol: string, timeframe: string, onUpdate: (result: RealHistoryResult) => void, intervalMs = 10_000): () => void {
  let stopped = false;
  const run = async () => {
    if (stopped) return;
    onUpdate(await fetchRealHistory(symbol, timeframe));
  };
  run();
  const handle = setInterval(run, intervalMs);
  return () => {
    stopped = true;
    clearInterval(handle);
  };
}
