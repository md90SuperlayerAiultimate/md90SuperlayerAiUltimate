export type Locale = "ID" | "EN";

type Copy = {
  product: string;
  kicker: string;
  overview: string;
  signalRoom: string;
  markets: string;
  agents: string;
  risk: string;
  lab: string;
  scan: string;
  console: string;
  audit: string;
  journal: string;
  liveLocked: string;
  paperEngine: string;
  simulated: string;
  hero: string;
  heroAccent: string;
  blurb: string;
  openSignal: string;
  evidence: string;
  riskGate: string;
  submitPaper: string;
  blocked: string;
  tape: string;
  layers: string;
  session: string;
  regime: string;
  checksum: string;
  command: string;
  language: string;
  paperNote: string;
  noLive: string;
  lagged: string;
  outage: string;
  workbench: string;
  allInOne: string;
  autopilot: string;
  arm: string;
  disarm: string;
  radar: string;
  lastPrint: string;
  autoPaper: string;
  shadow: string;
};

export const copy: Record<Locale, Copy> = {
  ID: {
    product: "MD90 Superlayer",
    kicker: "Terminal operator · AUTO PAPER / SHADOW",
    overview: "Meja",
    signalRoom: "Sinyal",
    markets: "Buku",
    agents: "Agen",
    risk: "Risiko",
    lab: "Lab",
    scan: "Pindai",
    console: "Konsol",
    audit: "Audit",
    journal: "Jurnal",
    liveLocked: "LIVE TERKUNCI",
    paperEngine: "Mesin paper",
    simulated: "SIMULASI",
    hero: "Deteksi jalan.",
    heroAccent: "Fill paper ikut.",
    blurb:
      "Tick simulasi, radar 5 simbol, auto-detect 17 layer, auto-fill paper. Bukan broker. Bukan wallet. Live order tetap terkunci.",
    openSignal: "Buka ruang sinyal",
    evidence: "Bukti keputusan",
    riskGate: "Gerbang risiko",
    submitPaper: "Kirim paper fill",
    blocked: "Ditahan kebijakan",
    tape: "Pita order paper",
    layers: "Tumpukan 17 layer",
    session: "Sesi UTC",
    regime: "Rezim",
    checksum: "Checksum snapshot",
    command: "Palet perintah",
    language: "Bahasa",
    paperNote: "AUTO PAPER adalah produk. Live adalah kunci.",
    noLive: "Tanpa kunci, tanpa order jaringan.",
    lagged: "Print tertinggal · lag=true",
    outage: "Jika buku dan tape kosong: outage, bukan 0.",
    workbench: "ALL-IN-ONE",
    allInOne: "Dari tick sampai fill yang bisa diaudit.",
    autopilot: "Autopilot",
    arm: "Arm auto",
    disarm: "Disarm",
    radar: "Radar universe",
    lastPrint: "Print terakhir",
    autoPaper: "AUTO PAPER",
    shadow: "SHADOW",
  },
  EN: {
    product: "MD90 Superlayer",
    kicker: "Operator terminal · AUTO PAPER / SHADOW",
    overview: "Desk",
    signalRoom: "Signal",
    markets: "Book",
    agents: "Agents",
    risk: "Risk",
    lab: "Lab",
    scan: "Scan",
    console: "Console",
    audit: "Audit",
    journal: "Journal",
    liveLocked: "LIVE LOCKED",
    paperEngine: "Paper engine",
    simulated: "SIMULATED",
    hero: "Detection runs.",
    heroAccent: "Paper fills follow.",
    blurb:
      "Simulated ticks, 5-symbol radar, 17-layer auto-detect, paper auto-fill. Not a broker. Not a wallet. Live orders stay locked.",
    openSignal: "Open signal room",
    evidence: "Decision evidence",
    riskGate: "Risk gates",
    submitPaper: "Submit paper fill",
    blocked: "Held by policy",
    tape: "Paper order tape",
    layers: "17-layer stack",
    session: "UTC session",
    regime: "Regime",
    checksum: "Snapshot checksum",
    command: "Command palette",
    language: "Language",
    paperNote: "AUTO PAPER is the product. Live is the lock.",
    noLive: "No keys. No network orders.",
    lagged: "Lagged prints · lag=true",
    outage: "Empty book and tape is outage, never a fake 0.",
    workbench: "ALL-IN-ONE",
    allInOne: "From tick to an auditable fill.",
    autopilot: "Autopilot",
    arm: "Arm auto",
    disarm: "Disarm",
    radar: "Universe radar",
    lastPrint: "Last print",
    autoPaper: "AUTO PAPER",
    shadow: "SHADOW",
  },
};
