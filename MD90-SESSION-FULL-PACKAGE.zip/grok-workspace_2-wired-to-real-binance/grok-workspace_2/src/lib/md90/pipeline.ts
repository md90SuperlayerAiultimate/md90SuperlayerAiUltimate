import { OPERATING_STAGES } from "./constants";
import { snapshotChecksum } from "./engine";

export type OperatingStage = (typeof OPERATING_STAGES)[number];
export type OperatingAuthority = "PAPER" | "SHADOW" | "DISABLED";
export type OperatingEvidence = "PENDING" | "READY" | "MATCH" | "MISMATCH" | "BLOCKED";
export type OperatingOutcome =
  | "RUNNING"
  | "PAPER_CANDIDATE"
  | "PAPER_BLOCKED"
  | "COMPLETED"
  | "FAILED";

export type OperatingBlockReason =
  | "PARITY_REQUIRED"
  | "RISK_POLICY_HOLD"
  | "PAPER_ONLY"
  | "LIVE_DISABLED"
  | "FUSION_ABORT";

export type OperatingEvent = {
  eventId: string;
  correlationId: string;
  stage: OperatingStage;
  type: string;
  symbol: string;
  occurredAt: number;
  evidence: OperatingEvidence;
  authority: OperatingAuthority;
  detail: string;
};

export type OperatingState = {
  correlationId: string;
  symbol: string;
  baseTimeframe: string;
  higherTimeframe: string;
  authority: OperatingAuthority;
  evidence: OperatingEvidence;
  stage: OperatingStage;
  outcome: OperatingOutcome;
  events: OperatingEvent[];
  blockReasons: OperatingBlockReason[];
  lastUpdatedAt: number;
};

const HTF: Record<string, string> = { M5: "M15", M15: "H1", H1: "H4", H4: "D1" };

export function higherTimeframe(tf: string): string {
  return HTF[tf] ?? "H4";
}

export function createOperatingState(input: {
  symbol: string;
  baseTimeframe: string;
  sourceChecksum?: string;
  now?: number;
}): OperatingState {
  const now = input.now ?? Date.now();
  const correlationId = snapshotChecksum(
    `${input.symbol}:${input.baseTimeframe}:${Math.floor(now / 60_000)}`,
  );
  const event: OperatingEvent = {
    eventId: `${correlationId}:ingest`,
    correlationId,
    stage: "INGEST",
    type: "OPERATING_RUN_STARTED",
    symbol: input.symbol,
    occurredAt: now,
    evidence: "PENDING",
    authority: "PAPER",
    detail: `Simulated OHLC · ${input.symbol} ${input.baseTimeframe}`,
  };
  return {
    correlationId,
    symbol: input.symbol,
    baseTimeframe: input.baseTimeframe,
    higherTimeframe: higherTimeframe(input.baseTimeframe),
    authority: "PAPER",
    evidence: "PENDING",
    stage: "INGEST",
    outcome: "RUNNING",
    events: [event],
    blockReasons: [],
    lastUpdatedAt: now,
  };
}

export function deriveOperating(input: {
  symbol: string;
  timeframe: string;
  fusionStatus: "ALL-IN" | "WAITING" | "ABORT" | null;
  fusionScore: number;
  allGates: boolean;
  riskClear: boolean;
  hasOpen: boolean;
  hasFills: boolean;
  hasJournal: boolean;
  now?: number;
}): OperatingState {
  const now = input.now ?? Date.now();
  const state = createOperatingState({
    symbol: input.symbol,
    baseTimeframe: input.timeframe,
    now,
  });
  const push = (stage: OperatingStage, type: string, detail: string, evidence: OperatingEvidence) => {
    state.events.push({
      eventId: `${state.correlationId}:${stage.toLowerCase()}`,
      correlationId: state.correlationId,
      stage,
      type,
      symbol: state.symbol,
      occurredAt: now,
      evidence,
      authority: "PAPER",
      detail,
    });
    state.stage = stage;
    state.evidence = evidence;
    state.lastUpdatedAt = now;
  };

  push("NORMALIZE", "OHLC_NORMALIZED", "Seeded candles, no vendor feed claimed", "READY");
  push("PARITY", "PARITY_SHADOW", "Internal fusion vector vs paper book", input.fusionStatus ? "MATCH" : "MISMATCH");
  push(
    "CONFLUENCE",
    "FUSION_SCORED",
    `Score ${input.fusionScore.toFixed(2)} · ${input.fusionStatus ?? "PENDING"}`,
    input.fusionStatus === "ABORT" ? "BLOCKED" : input.fusionStatus ? "READY" : "PENDING",
  );

  const fusionAbort = input.fusionStatus === "ABORT";
  push(
    "RISK_GATE",
    input.riskClear && !fusionAbort ? "RISK_CLEARED" : "RISK_HOLD",
    input.riskClear && !fusionAbort ? "Survivor caps pass" : "A pre-trade breaker is open",
    input.riskClear && !fusionAbort ? "READY" : "BLOCKED",
  );
  push(
    "PAPER_DECISION",
    input.riskClear && !fusionAbort ? (input.allGates ? "PAPER_CANDIDATE" : "PAPER_STAGED") : "PAPER_HELD",
    !input.riskClear || fusionAbort
      ? "Decision recorded, not sent"
      : input.allGates
        ? "Five gates aligned"
        : "Waiting on remaining gates",
    input.riskClear && !fusionAbort ? "READY" : "BLOCKED",
  );
  push(
    "PAPER_FILL",
    input.hasFills ? "PAPER_FILL_RECORDED" : "PAPER_FILL_EMPTY",
    input.hasFills ? "In-process broker, no network order" : "No fill yet — tape stays empty",
    input.hasFills ? "MATCH" : "PENDING",
  );
  push(
    "POSITION",
    input.hasOpen ? "POSITION_MARKED" : "POSITION_FLAT",
    input.hasOpen ? "Open book marked to last simulated print" : "Flat book",
    input.hasOpen ? "MATCH" : "PENDING",
  );
  push(
    "JOURNAL",
    input.hasJournal ? "JOURNAL_LINKED" : "JOURNAL_EMPTY",
    input.hasJournal ? "Correlation retained in local ledger" : "Ledger empty until the first event",
    input.hasJournal ? "MATCH" : "PENDING",
  );
  push("AUDIT", "AUDIT_CLOSED", "Chain closed. Live route remains LIVE LOCKED", "MATCH");

  if (state.events[0]) state.events[0].evidence = input.fusionStatus ? "READY" : "PENDING";

  if (fusionAbort) {
    state.outcome = "PAPER_BLOCKED";
    state.blockReasons = ["FUSION_ABORT", "LIVE_DISABLED", "PAPER_ONLY"];
    state.authority = "DISABLED";
  } else if (!input.riskClear) {
    state.outcome = "PAPER_BLOCKED";
    state.blockReasons = ["RISK_POLICY_HOLD", "LIVE_DISABLED", "PAPER_ONLY"];
    state.authority = "DISABLED";
  } else if (input.hasFills && input.hasJournal) {
    state.outcome = "COMPLETED";
    state.blockReasons = ["LIVE_DISABLED", "PAPER_ONLY"];
  } else {
    state.outcome = "PAPER_CANDIDATE";
    state.blockReasons = ["LIVE_DISABLED", "PAPER_ONLY"];
  }
  state.stage = "AUDIT";
  return state;
}

export function humanizeBlock(reason: OperatingBlockReason, locale: "ID" | "EN"): string {
  const map: Record<OperatingBlockReason, [string, string]> = {
    PARITY_REQUIRED: ["Parity source vector diperlukan", "Source parity vector is required"],
    RISK_POLICY_HOLD: ["Kebijakan risiko menahan keputusan", "Risk policy is holding the decision"],
    PAPER_ONLY: ["Keputusan hanya PAPER", "Decision is PAPER-only"],
    LIVE_DISABLED: ["Live execution dinonaktifkan", "Live execution is disabled"],
    FUSION_ABORT: ["Fusion ABORT — tidak ada kandidat", "Fusion ABORT — no candidate"],
  };
  return map[reason][locale === "ID" ? 0 : 1];
}
