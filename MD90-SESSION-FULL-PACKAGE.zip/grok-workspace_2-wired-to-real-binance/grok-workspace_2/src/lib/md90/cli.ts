import { INSTRUMENTS, TIMEFRAMES, type Autopilot, type InstrumentId, type Timeframe } from "./constants";

export const CLI_DESKS = {
  overview: "/",
  home: "/",
  signal: "/signal-room",
  "signal-room": "/signal-room",
  markets: "/markets",
  book: "/markets",
  agents: "/agents",
  risk: "/risk",
  lab: "/replay",
  replay: "/replay",
  scan: "/scan",
  arb: "/scan",
  console: "/console",
  audit: "/audit",
  journal: "/journal",
  ledger: "/journal",
} as const;

export type DeskPath = (typeof CLI_DESKS)[keyof typeof CLI_DESKS];

export type CliAction =
  | { type: "goto"; path: DeskPath }
  | { type: "paper" }
  | { type: "reset" }
  | { type: "instrument"; id: InstrumentId }
  | { type: "tf"; tf: Timeframe }
  | { type: "lab" }
  | { type: "scan" }
  | { type: "clob"; slug: string; side: "YES" | "NO"; usd: number }
  | { type: "copy"; id: string }
  | { type: "help" }
  | { type: "status" }
  | { type: "auto"; mode: Autopilot };

export type CliParse = { ok: true; action: CliAction; echo: string } | { ok: false; echo: string };

const HELP = [
  "MD90 Superlayer · paper console",
  "goto <desk>          open a desk",
  "paper                submit a STRICT paper fill if gates clear",
  "auto on|paper        arm AUTO PAPER (detect + fill)",
  "auto shadow          detect only, never fill",
  "auto off             disarm autopilot",
  "reset                wipe the local paper ledger",
  "instrument XAUUSD    switch simulated instrument",
  "tf M15               switch timeframe",
  "lab                  run the Qanat-style walk-forward",
  "scan                 open arb / copy / scanner desk",
  "clob <slug> YES 100  paper-fill the simulated CLOB",
  "copy fusion-lead     apply a paper copy template",
  "status               print fusion, auto, equity",
  "help                 this list",
  "LIVE LOCKED · no keys · no network orders",
];

export function parseCommand(raw: string): CliParse {
  const line = raw.trim();
  if (!line) return { ok: false, echo: "empty" };
  const parts = line.split(/\s+/);
  const cmd = parts[0].toLowerCase();

  if (cmd === "help" || cmd === "?") return { ok: true, action: { type: "help" }, echo: HELP.join("\n") };

  if (cmd === "goto" || cmd === "open") {
    const key = (parts[1] ?? "").toLowerCase() as keyof typeof CLI_DESKS;
    const path = CLI_DESKS[key];
    if (!path) return { ok: false, echo: `unknown desk · try ${Object.keys(CLI_DESKS).slice(0, 8).join(" ")}` };
    return { ok: true, action: { type: "goto", path }, echo: `open ${path}` };
  }

  if (cmd === "paper" || cmd === "fill") return { ok: true, action: { type: "paper" }, echo: "submit paper" };
  if (cmd === "reset") return { ok: true, action: { type: "reset" }, echo: "reset paper ledger" };
  if (cmd === "lab" || cmd === "backtest") return { ok: true, action: { type: "lab" }, echo: "run lab" };
  if (cmd === "scan" || cmd === "arb") return { ok: true, action: { type: "scan" }, echo: "open scan" };
  if (cmd === "status") return { ok: true, action: { type: "status" }, echo: "status" };

  if (cmd === "auto" || cmd === "arm" || cmd === "disarm") {
    const arg = (parts[1] ?? (cmd === "disarm" ? "off" : "paper")).toLowerCase();
    let mode: Autopilot = "PAPER";
    if (arg === "off" || arg === "stop" || arg === "0") mode = "OFF";
    else if (arg === "shadow" || arg === "watch") mode = "SHADOW";
    else if (arg === "on" || arg === "paper" || arg === "live" || arg === "1") mode = "PAPER";
    else return { ok: false, echo: "usage: auto on|shadow|off" };
    return { ok: true, action: { type: "auto", mode }, echo: `autopilot ${mode}` };
  }

  if (cmd === "instrument" || cmd === "sym" || cmd === "pair") {
    const id = (parts[1] ?? "").toUpperCase() as InstrumentId;
    if (!INSTRUMENTS.some((i) => i.id === id)) {
      return { ok: false, echo: `unknown instrument · ${INSTRUMENTS.map((i) => i.id).join(" ")}` };
    }
    return { ok: true, action: { type: "instrument", id }, echo: `instrument ${id}` };
  }

  if (cmd === "tf" || cmd === "timeframe") {
    const tf = (parts[1] ?? "").toUpperCase() as Timeframe;
    if (!(TIMEFRAMES as readonly string[]).includes(tf)) return { ok: false, echo: `unknown tf · ${TIMEFRAMES.join(" ")}` };
    return { ok: true, action: { type: "tf", tf }, echo: `tf ${tf}` };
  }

  if (cmd === "clob") {
    const slug = parts[1];
    const side = (parts[2] ?? "YES").toUpperCase();
    const usd = Number(parts[3] ?? 100);
    if (!slug) return { ok: false, echo: "usage: clob <slug> YES|NO <usd>" };
    if (side !== "YES" && side !== "NO") return { ok: false, echo: "side must be YES or NO" };
    if (!Number.isFinite(usd) || usd <= 0) return { ok: false, echo: "usd must be > 0" };
    return { ok: true, action: { type: "clob", slug, side, usd }, echo: `clob ${slug} ${side} ${usd}` };
  }

  if (cmd === "copy") {
    const id = parts[1] ?? "fusion-lead";
    return { ok: true, action: { type: "copy", id }, echo: `copy ${id}` };
  }

  if (cmd in CLI_DESKS) {
    const path = CLI_DESKS[cmd as keyof typeof CLI_DESKS];
    return { ok: true, action: { type: "goto", path }, echo: `open ${path}` };
  }

  return { ok: false, echo: `unknown command · help` };
}

export const CLI_HELP = HELP;
