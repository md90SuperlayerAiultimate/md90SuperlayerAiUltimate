import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import {
  AUTO_COOLDOWN_MS,
  ENGINE_VERSION,
  INSTRUMENTS,
  MAX_POSITIONS,
  type Autopilot,
  type InstrumentId,
  type RiskMode,
  type Timeframe,
} from "./constants";
import { parseCommand, type CliParse } from "./cli";
import { pollRealHistory } from "./realMarketData";
import {
  analyze,
  barStartFor,
  generateLiveSeries,
  snapshotChecksum,
  utcSession,
  type Candle,
  type FusionResult,
} from "./engine";
import { runLabPipeline, type LabRun } from "./lab";
import {
  classifyCandidate,
  pickAutoTarget,
  pickProbeTarget,
  scanInstrument,
  type RadarHit,
  type TickPrint,
} from "./live";
import { buildPredictionMarkets, paperClobFill, type ClobFill, type PredictionMarket } from "./markets";
import { deriveOperating, type OperatingState } from "./pipeline";
import {
  dailyLossPct,
  drawdownPct,
  evaluateRisk,
  freshAccount,
  hitStops,
  markPosition,
  openPaper,
  type AccountState,
  type PaperFill,
  type PaperPosition,
  type RiskCheck,
} from "./paper";
import { COPY_TEMPLATES, scanArb } from "./scan";
import type { Locale } from "./i18n";

export type JournalEntry = {
  ts: number;
  event: string;
  detail: string;
  correlationId: string;
};

export type ConsoleLine = { ts: number; kind: "in" | "out" | "err"; text: string };

export type DeskState = {
  locale: Locale;
  instrumentId: InstrumentId;
  timeframe: Timeframe;
  candles: Candle[];
  fusion: FusionResult | null;
  account: AccountState;
  positions: PaperPosition[];
  fills: PaperFill[];
  clobFills: ClobFill[];
  journal: JournalEntry[];
  equityCurve: { t: number; equity: number }[];
  markets: PredictionMarket[];
  replayIndex: number | null;
  lab: LabRun | null;
  operating: OperatingState | null;
  consoleLines: ConsoleLine[];
  hydrated: boolean;
  autopilot: Autopilot;
  radar: RadarHit[];
  lastPrice: number;
  lastTickAt: number;
  tickSeq: number;
  lastAutoAt: number;
  lastAutoBySymbol: Record<string, number>;
  tickTape: TickPrint[];
  barOrigin: number;
  barTicks: number;
  riskChecks: RiskCheck[];
  priceSpark: { t: number; px: number }[];
  labStatus: "idle" | "running" | "ok";
  setLocale: (locale: Locale) => void;
  setInstrument: (id: InstrumentId) => void;
  setTimeframe: (tf: Timeframe) => void;
  setAutopilot: (mode: Autopilot) => void;
  tick: () => void;
  submitPaper: (opts?: { mode?: RiskMode; hit?: RadarHit }) => string;
  submitClob: (slug: string, side: "YES" | "NO", usd: number) => string;
  applyCopy: (id: string) => string;
  runLab: () => void;
  runCommand: (raw: string) => CliParse & { message: string };
  setReplay: (index: number | null) => void;
  resetPaper: () => void;
  ensureLab: () => void;
};

function dayRoll(account: AccountState, now: number): AccountState {
  const key = new Date(now).toISOString().slice(0, 10);
  if (account.dayKey === key) return account;
  return { ...account, dayKey: key, dailyStart: account.equity, dailyPnl: 0, tradesToday: 0 };
}

function log(event: string, detail: string, correlationId: string): JournalEntry {
  return { ts: Date.now(), event, detail, correlationId };
}

function operatingFrom(state: {
  instrumentId: InstrumentId;
  timeframe: Timeframe;
  fusion: FusionResult | null;
  account: AccountState;
  positions: PaperPosition[];
  fills: PaperFill[];
  journal: JournalEntry[];
  autopilot: Autopilot;
}): OperatingState {
  const checks = state.fusion
    ? evaluateRisk({
        fusion: state.fusion,
        account: state.account,
        openCount: state.positions.filter((p) => p.status !== "CLOSED").length,
        session: utcSession(),
        mode: state.autopilot === "PAPER" ? "AUTO" : "STRICT",
      })
    : [];
  return deriveOperating({
    symbol: state.instrumentId,
    timeframe: state.timeframe,
    fusionStatus: state.fusion?.status ?? null,
    fusionScore: state.fusion?.fusionScore ?? 0,
    allGates: state.fusion?.allGates ?? false,
    riskClear: checks.length > 0 && checks.every((c) => c.ok),
    hasOpen: state.positions.some((p) => p.status !== "CLOSED"),
    hasFills: state.fills.length > 0,
    hasJournal: state.journal.length > 0,
  });
}

// Real-candle cache: populated asynchronously by startRealMarketDataFeed() below, read
// synchronously here so the existing tick()/position/fills logic doesn't need to become
// async. Only CRYPTO instruments (BTCUSDT/ETHUSDT/SOLUSDT) ever get an entry — XAUUSD and
// EURUSD have no real source wired into MD90's backend (market.history blocks non-crypto)
// and must keep using generateLiveSeries()'s simulated candles, not silently reuse stale
// or wrong-instrument real data.
const realCandleCache = new Map<InstrumentId, { candles: Candle[]; lastPrice: number; fetchedAt: number }>();
const REAL_CACHE_MAX_AGE_MS = 30_000;

function liveSeries(id: InstrumentId, tf: Timeframe, now: number, barTicks: number): Candle[] {
  const cached = realCandleCache.get(id);
  if (cached && now - cached.fetchedAt <= REAL_CACHE_MAX_AGE_MS) {
    return cached.candles;
  }
  return generateLiveSeries(id, tf, 180, now, barTicks).candles;
}

/**
 * Starts background polling of real Binance data (via realMarketData.ts) for every
 * CRYPTO instrument in INSTRUMENTS, filling realCandleCache so liveSeries() above
 * serves real candles instead of generateLiveSeries()'s synthetic ones. Call this once
 * from the app's root (e.g. on mount) — it returns a stop function for cleanup.
 * If the real fetch fails or goes stale (> REAL_CACHE_MAX_AGE_MS), liveSeries() falls
 * back to the simulated generator automatically rather than showing a frozen price.
 */
export function startRealMarketDataFeed(): () => void {
  const cryptoInstruments = INSTRUMENTS.filter((i) => i.assetClass === "CRYPTO");
  const stops = cryptoInstruments.map((inst) =>
    pollRealHistory(inst.id, "15m", (result) => {
      if (result.status === "ready") {
        realCandleCache.set(inst.id as InstrumentId, {
          candles: result.candles.map((c) => ({ t: c.time, o: c.open, h: c.high, l: c.low, c: c.close, v: c.volume })),
          lastPrice: result.lastPrice,
          fetchedAt: Date.now(),
        });
      }
      // On error/blocked: deliberately do not touch the cache — an existing fresh entry
      // keeps serving until REAL_CACHE_MAX_AGE_MS expires it, rather than snapping back
      // to simulated data on one transient network blip.
    }, 10_000),
  );
  return () => stops.forEach((stop) => stop());
}

function riskSnapshot(
  fusion: FusionResult | null,
  account: AccountState,
  positions: PaperPosition[],
  autopilot: Autopilot,
): RiskCheck[] {
  if (!fusion) return [];
  return evaluateRisk({
    fusion,
    account,
    openCount: positions.filter((p) => p.status !== "CLOSED").length,
    session: utcSession(),
    mode: autopilot === "PAPER" ? "AUTO" : "STRICT",
  });
}

export const useDesk = create<DeskState>()(
  persist(
    (set, get) => ({
      locale: "ID",
      instrumentId: "XAUUSD",
      timeframe: "M15",
      candles: [],
      fusion: null,
      account: freshAccount(),
      positions: [],
      fills: [],
      clobFills: [],
      journal: [],
      equityCurve: [{ t: Date.now(), equity: 10_000 }],
      markets: [],
      replayIndex: null,
      lab: null,
      operating: null,
      consoleLines: [
        {
          ts: Date.now(),
          kind: "out",
          text: "MD90 Superlayer · AUTO PAPER armed · LIVE LOCKED · type help",
        },
      ],
      hydrated: false,
      autopilot: "PAPER",
      radar: [],
      lastPrice: 0,
      lastTickAt: 0,
      tickSeq: 0,
      lastAutoAt: 0,
      lastAutoBySymbol: {},
      tickTape: [],
      barOrigin: 0,
      barTicks: 0,
      riskChecks: [],
      priceSpark: [],
      labStatus: "idle",
      setLocale: (locale) => set({ locale }),
      setInstrument: (id) => {
        const { timeframe } = get();
        const live = generateLiveSeries(id, timeframe);
        const fusion = analyze(live.candles);
        set({
          instrumentId: id,
          candles: live.candles,
          fusion,
          lastPrice: live.lastPrice,
          replayIndex: null,
          markets: buildPredictionMarkets(fusion.entry),
          lab: null,
          labStatus: "idle",
          priceSpark: [],
        });
      },
      setTimeframe: (tf) => {
        const { instrumentId } = get();
        const live = generateLiveSeries(instrumentId, tf);
        const fusion = analyze(live.candles);
        set({ timeframe: tf, candles: live.candles, fusion, lastPrice: live.lastPrice, replayIndex: null, lab: null, labStatus: "idle", priceSpark: [] });
      },
      setAutopilot: (mode) => {
        const cur = get();
        set({
          autopilot: mode,
          journal: [
            log("AUTOPILOT", `mode ${mode} · LIVE remains LOCKED`, snapshotChecksum(ENGINE_VERSION)),
            ...cur.journal,
          ].slice(0, 80),
          consoleLines: [
            { ts: Date.now(), kind: "out" as const, text: `autopilot ${mode}` },
            ...cur.consoleLines,
          ].slice(0, 80),
        });
      },
      tick: () => {
        const state = get();
        const now = Date.now();
        const barStart = barStartFor(state.timeframe, now);
        const barTicks = state.barOrigin === barStart ? state.barTicks + 1 : 1;
        if (state.replayIndex != null) {
          const live = generateLiveSeries(state.instrumentId, state.timeframe, 180, now, barTicks);
          const slice = live.candles.slice(0, Math.max(40, state.replayIndex));
          const fusion = analyze(slice);
          set({
            candles: slice,
            fusion,
            lastPrice: slice.at(-1)?.c ?? 0,
            hydrated: true,
            lastTickAt: now,
            barOrigin: barStart,
            barTicks,
            riskChecks: riskSnapshot(fusion, state.account, state.positions, state.autopilot),
          });
          return;
        }

        const candles = liveSeries(state.instrumentId, state.timeframe, now, barTicks);
        const last = candles.at(-1)!;
        const tickSeq = state.tickSeq + 1;
        const fusion =
          tickSeq >= 2 && (!state.fusion || tickSeq % 8 === 0) ? analyze(candles) : state.fusion;
        const prevPrice = state.lastPrice || last.o;
        let account = dayRoll(state.account, now);
        const fills = [...state.fills];
        const journal = [...state.journal];
        const priceCache = new Map<string, Candle>([[state.instrumentId, last]]);
        const positions = state.positions.map((pos) => {
          if (pos.status === "CLOSED") return pos;
          if (!priceCache.has(pos.symbol)) {
            const px = generateLiveSeries(pos.symbol as InstrumentId, state.timeframe, 80, now, barTicks);
            priceCache.set(pos.symbol, px.candles.at(-1)!);
          }
          const priced = priceCache.get(pos.symbol) ?? last;
          const result = hitStops(pos, priced);
          if (result.fills.length) {
            fills.push(...result.fills);
            account = {
              ...account,
              cash: account.cash + result.closedPnl,
              equity: account.equity + result.closedPnl,
              dailyPnl: account.dailyPnl + result.closedPnl,
              consecutiveLosses:
                result.closedPnl < 0 && result.pos.status === "CLOSED"
                  ? account.consecutiveLosses + 1
                  : result.pos.status === "CLOSED" && result.closedPnl > 0
                    ? 0
                    : account.consecutiveLosses,
            };
            journal.unshift(
              log(
                result.pos.status === "CLOSED" ? "POSITION_CLOSED" : "PARTIAL_TAKE",
                `${pos.symbol} ${result.fills[0]?.note ?? ""}`,
                pos.correlationId,
              ),
            );
          }
          return markPosition(result.pos, priced.c);
        });
        const openPnl = positions.reduce((a, p) => a + (p.status === "CLOSED" ? 0 : p.unrealized), 0);
        const equity = account.cash + openPnl;
        account = {
          ...account,
          equity,
          peakEquity: Math.max(account.peakEquity, equity),
        };
        let radar = state.radar;
        if (tickSeq % 10 === 0 || radar.length === 0) {
          const focusId = INSTRUMENTS[tickSeq % INSTRUMENTS.length]!.id;
          const hit = scanInstrument(focusId, state.timeframe, now, barTicks);
          radar = radar.some((row) => row.id === hit.id)
            ? radar.map((row) => (row.id === hit.id ? hit : row))
            : [...radar, hit].slice(0, INSTRUMENTS.length);
        }

        const print: TickPrint = {
          t: now,
          id: state.instrumentId,
          price: last.c,
          delta: last.c - prevPrice,
        };
        const tickTape = [print, ...state.tickTape].slice(0, 24);

        let lastAutoAt = state.lastAutoAt;
        let lastAutoBySymbol = state.lastAutoBySymbol;
        let consoleLines = state.consoleLines;
        let workingPositions = positions;
        let workingFills = fills;
        let workingAccount = account;
        let workingJournal = journal;

        if (state.autopilot === "SHADOW" && fusion) {
          const detected = classifyCandidate(fusion);
          if (detected.ok && tickSeq % 4 === 0) {
            workingJournal = [
              log(
                "SHADOW_SIGNAL",
                `${state.instrumentId} ${fusion.direction} ${fusion.fusionScore.toFixed(2)} · ${detected.reason} · no fill`,
                snapshotChecksum(`${state.instrumentId}:${barStart}`),
              ),
              ...workingJournal,
            ].slice(0, 80);
          }
        }

        if (state.autopilot === "PAPER" && now - lastAutoAt >= AUTO_COOLDOWN_MS && workingAccount.tradesToday < 8) {
          const openCount = workingPositions.filter((p) => p.status !== "CLOSED").length;
          const openSymbols = new Set(workingPositions.filter((p) => p.status !== "CLOSED").map((p) => p.symbol));
          if (openCount >= MAX_POSITIONS) {
            /* book full — wait for TP/SL */
          } else {
          let target = pickAutoTarget(radar, openSymbols, lastAutoBySymbol, now, AUTO_COOLDOWN_MS * 2);
          if (!target && workingFills.filter((f) => f.note.includes("AUTO")).length === 0 && tickSeq >= 2) {
            target = pickProbeTarget(radar, openSymbols);
          }
          if (target?.fusion) {
            const opened = openPaper({
              symbol: target.id,
              fusion: target.fusion,
              account: workingAccount,
              correlationId: snapshotChecksum(`${target.id}:${target.fusion.direction}:${target.fusion.status}:${barStart}`),
              sizeMult: target.fusion.status !== "ALL-IN" ? 0.5 : 1,
              note: "AUTO paper fill · no network order",
            });
            const alreadyOpen = workingPositions.some((p) => p.symbol === target.id && p.status !== "CLOSED");
            if (!alreadyOpen && !("blocked" in opened)) {
              workingPositions = [opened.position, ...workingPositions];
              workingFills = [opened.fill, ...workingFills];
              workingAccount = {
                ...workingAccount,
                cash: workingAccount.cash - opened.fill.fee,
                tradesToday: workingAccount.tradesToday + 1,
              };
              const openPnl2 = workingPositions.reduce((a, p) => a + (p.status === "CLOSED" ? 0 : p.unrealized), 0);
              workingAccount = {
                ...workingAccount,
                equity: workingAccount.cash + openPnl2,
                peakEquity: Math.max(workingAccount.peakEquity, workingAccount.cash + openPnl2),
              };
              workingJournal = [
                log(
                  "AUTO_PAPER_FILL",
                  `${opened.position.side} ${target.id} qty ${opened.fill.qty.toFixed(4)} @ ${opened.fill.price.toFixed(2)} · ${opened.fill.slippageBps} bps · ${opened.fill.note}`,
                  opened.position.correlationId,
                ),
                ...workingJournal,
              ].slice(0, 80);
              lastAutoAt = now;
              lastAutoBySymbol = { ...lastAutoBySymbol, [target.id]: now };
              consoleLines = [
                {
                  ts: now,
                  kind: "out" as const,
                  text: `AUTO FILL ${target.id} ${target.direction} ${target.score.toFixed(2)} · ${target.reason}`,
                },
                ...consoleLines,
              ].slice(0, 80);
            } else if (tickSeq % 5 === 0) {
              consoleLines = [
                {
                  ts: now,
                  kind: "err" as const,
                  text: `AUTO HOLD ${target.id} · ${"blocked" in opened ? opened.blocked : "BOOK_OPEN"}`,
                },
                ...consoleLines,
              ].slice(0, 80);
            }
          }
          }
        }

        const riskChecks = fusion
          ? riskSnapshot(fusion, workingAccount, workingPositions, state.autopilot)
          : state.riskChecks;
        const priceSpark = [...state.priceSpark, { t: now, px: last.c }].slice(-96);
        const nextCore = {
          candles,
          fusion,
          account: workingAccount,
          positions: workingPositions,
          fills: workingFills.slice(-80),
          journal: workingJournal.slice(0, 80),
          equityCurve: [...state.equityCurve, { t: now, equity: workingAccount.equity }].slice(-180),
          markets: fusion ? buildPredictionMarkets(fusion.entry, now) : state.markets,
          hydrated: true,
          radar,
          lastPrice: last.c,
          lastTickAt: now,
          tickSeq,
          tickTape,
          barOrigin: barStart,
          barTicks,
          riskChecks,
          lastAutoAt,
          lastAutoBySymbol,
          consoleLines,
          priceSpark,
        };

        set({
          ...nextCore,
          operating: fusion
            ? operatingFrom({
                instrumentId: state.instrumentId,
                timeframe: state.timeframe,
                autopilot: state.autopilot,
                ...nextCore,
              })
            : state.operating,
        });
        if (tickSeq >= 2 && tickSeq % 6 === 0 && typeof window !== "undefined") {
          window.setTimeout(() => get().ensureLab(), 40);
        }
      },
      submitPaper: (opts) => {
        const state = get();
        const mode: RiskMode = opts?.mode ?? "STRICT";
        const fusion = opts?.hit?.fusion ?? state.fusion;
        const symbol = opts?.hit?.id ?? state.instrumentId;
        if (!fusion) return "NO_SNAPSHOT";
        const session = utcSession();
        const openCount = state.positions.filter((p) => p.status !== "CLOSED").length;
        const checks = evaluateRisk({
          fusion,
          account: state.account,
          openCount,
          session,
          mode,
        });
        if (checks.some((c) => !c.ok)) {
          const first = checks.find((c) => !c.ok);
          set({
            journal: [
              log("PAPER_BLOCKED", `${first?.code ?? "gate"} · ${first?.detail ?? "gate"}`, snapshotChecksum(ENGINE_VERSION)),
              ...state.journal,
            ].slice(0, 80),
          });
          return first?.code ?? "BLOCKED";
        }
        if (state.positions.some((p) => p.symbol === symbol && p.status !== "CLOSED")) {
          return "BOOK_OPEN";
        }
        const bar = barStartFor(state.timeframe);
        const correlationId = snapshotChecksum(`${symbol}:${fusion.direction}:${fusion.status}:${bar}`);
        if (state.positions.some((p) => p.correlationId === correlationId)) return "IDEMPOTENT";
        const opened = openPaper({
          symbol,
          fusion,
          account: state.account,
          correlationId,
          sizeMult: mode === "AUTO" && fusion.status !== "ALL-IN" ? 0.5 : 1,
          note: mode === "AUTO" ? "AUTO paper fill · no network order" : "Paper broker fill · no network order",
        });
        if ("blocked" in opened) return opened.blocked;
        const cash = state.account.cash - opened.fill.fee;
        const nextPositions = [opened.position, ...state.positions];
        const nextAccount = {
          ...state.account,
          cash,
          tradesToday: state.account.tradesToday + 1,
        };
        set({
          positions: nextPositions,
          fills: [opened.fill, ...state.fills].slice(0, 80),
          account: nextAccount,
          riskChecks: riskSnapshot(fusion, nextAccount, nextPositions, state.autopilot),
          journal: [
            log(
              mode === "AUTO" ? "AUTO_PAPER_FILL" : "PAPER_FILL",
              `${opened.position.side} ${symbol} qty ${opened.fill.qty.toFixed(4)} @ ${opened.fill.price.toFixed(2)} · ${opened.fill.slippageBps} bps · ${opened.fill.note}`,
              correlationId,
            ),
            ...state.journal,
          ].slice(0, 80),
        });
        return "FILLED";
      },
      submitClob: (slug, side, usd) => {
        const state = get();
        const market = state.markets.find((m) => m.slug === slug);
        if (!market) return "NO_MARKET";
        const filled = paperClobFill(market, side, usd);
        if ("blocked" in filled) {
          set({
            journal: [log("CLOB_BLOCKED", filled.blocked, slug), ...state.journal].slice(0, 80),
          });
          return filled.blocked;
        }
        const cash = state.account.cash - filled.usd - filled.fee;
        set({
          clobFills: [filled, ...state.clobFills].slice(0, 40),
          account: { ...state.account, cash, equity: cash, tradesToday: state.account.tradesToday + 1 },
          journal: [
            log(
              "CLOB_FILL",
              `${side} ${slug} ${filled.shares.toFixed(2)} sh @ ${filled.avgPrice.toFixed(3)} · ${filled.note}`,
              filled.id,
            ),
            ...state.journal,
          ].slice(0, 80),
        });
        return "FILLED";
      },
      applyCopy: (id) => {
        const template = COPY_TEMPLATES.find((t) => t.id === id);
        if (!template) return "NO_TEMPLATE";
        if (template.status === "BLOCKED") return "LIVE_LOCKED";
        if (id === "clob-gap") {
          const gaps = scanArb(get().markets).filter((g) => g.side !== "NONE");
          const first = gaps[0];
          if (!first) return "NO_GAP";
          return get().submitClob(first.slug, "YES", 50);
        }
        return get().submitPaper({ mode: "AUTO" });
      },
      runLab: () => {
        const state = get();
        if (state.candles.length < 40) return;
        set({ labStatus: "running" });
        const lab = runLabPipeline({
          candles: state.candles,
          fusion: state.fusion,
          fills: state.fills,
          instrumentId: state.instrumentId,
          timeframe: state.timeframe,
        });
        set({
          lab,
          labStatus: "ok",
          journal: [log("LAB_RUN", lab.digest, lab.runId), ...state.journal].slice(0, 80),
        });
      },
      ensureLab: () => {
        const state = get();
        if (typeof window === "undefined") return;
        if (state.labStatus === "running") return;
        if (state.candles.length < 56) return;
        if (state.lab?.digest.startsWith(`${state.instrumentId}:${state.timeframe}:`)) return;
        set({ labStatus: "running" });
        window.setTimeout(() => {
          const snap = get();
          if (snap.candles.length < 56) {
            set({ labStatus: "idle" });
            return;
          }
          const lab = runLabPipeline({
            candles: snap.candles,
            fusion: snap.fusion,
            fills: snap.fills,
            instrumentId: snap.instrumentId,
            timeframe: snap.timeframe,
            now: Date.now(),
          });
          set({
            lab,
            labStatus: "ok",
            journal: [log("LAB_RUN", lab.digest, lab.runId), ...get().journal].slice(0, 80),
          });
        }, 30);
      },
      runCommand: (raw) => {
        const parsed = parseCommand(raw);
        const push = (kind: ConsoleLine["kind"], text: string) => {
          const cur = get();
          const next: ConsoleLine[] = [
            { ts: Date.now(), kind: "in", text: raw },
            { ts: Date.now(), kind, text },
            ...cur.consoleLines,
          ];
          set({ consoleLines: next.slice(0, 80) });
        };
        if (!parsed.ok) {
          push("err", parsed.echo);
          return { ...parsed, message: parsed.echo };
        }
        const action = parsed.action;
        if (action.type === "help") {
          push("out", parsed.echo);
          return { ...parsed, message: parsed.echo };
        }
        if (action.type === "status") {
          const f = get().fusion;
          const a = get().account;
          const msg = `${get().instrumentId} ${get().timeframe} · ${f?.direction ?? "WATCH"} ${f?.fusionScore.toFixed(2) ?? "—"} ${f?.status ?? "—"} · equity ${a.equity.toFixed(0)} · auto ${get().autopilot} · LIVE LOCKED`;
          push("out", msg);
          return { ...parsed, message: msg };
        }
        if (action.type === "paper") {
          const result = get().submitPaper({ mode: "STRICT" });
          push(result === "FILLED" ? "out" : "err", result);
          return { ...parsed, message: result };
        }
        if (action.type === "auto") {
          get().setAutopilot(action.mode);
          push("out", `autopilot ${action.mode}`);
          return { ...parsed, message: `autopilot ${action.mode}` };
        }
        if (action.type === "reset") {
          get().resetPaper();
          push("out", "paper ledger wiped");
          return { ...parsed, message: "paper ledger wiped" };
        }
        if (action.type === "instrument") {
          get().setInstrument(action.id);
          push("out", `instrument ${action.id}`);
          return { ...parsed, message: action.id };
        }
        if (action.type === "tf") {
          get().setTimeframe(action.tf);
          push("out", `tf ${action.tf}`);
          return { ...parsed, message: action.tf };
        }
        if (action.type === "lab") {
          get().runLab();
          const lab = get().lab;
          const msg = lab ? `${lab.runId} · ${lab.tables.length} tables` : "lab idle";
          push("out", msg);
          return { ...parsed, message: msg };
        }
        if (action.type === "clob") {
          const result = get().submitClob(action.slug, action.side, action.usd);
          push(result === "FILLED" ? "out" : "err", result);
          return { ...parsed, message: result };
        }
        if (action.type === "copy") {
          const result = get().applyCopy(action.id);
          push(result === "FILLED" ? "out" : "err", result);
          return { ...parsed, message: result };
        }
        push("out", parsed.echo);
        return { ...parsed, message: parsed.echo };
      },
      setReplay: (index) => {
        const { instrumentId, timeframe } = get();
        const live = generateLiveSeries(instrumentId, timeframe);
        if (index == null) {
          set({ replayIndex: null, candles: live.candles, fusion: analyze(live.candles), lastPrice: live.lastPrice });
          return;
        }
        const slice = live.candles.slice(0, Math.max(40, index));
        set({ replayIndex: index, candles: slice, fusion: analyze(slice), lastPrice: slice.at(-1)?.c ?? 0 });
      },
      resetPaper: () =>
        set({
          account: freshAccount(),
          positions: [],
          fills: [],
          clobFills: [],
          journal: [log("ACCOUNT_RESET", "Paper ledger wiped locally", "reset")],
          equityCurve: [{ t: Date.now(), equity: 10_000 }],
          lastAutoAt: 0,
          lastAutoBySymbol: {},
          riskChecks: [],
        }),
    }),
    {
      name: "md90-superlayer-desk-v6",
      storage: createJSONStorage(() => {
        if (typeof window === "undefined") {
          return {
            getItem: () => null,
            setItem: () => {},
            removeItem: () => {},
          };
        }
        return localStorage;
      }),
      partialize: (s) => ({
        locale: s.locale,
        instrumentId: s.instrumentId,
        timeframe: s.timeframe,
        account: s.account,
        positions: s.positions,
        fills: s.fills,
        clobFills: s.clobFills,
        journal: s.journal,
        equityCurve: s.equityCurve,
        consoleLines: s.consoleLines.slice(0, 20),
        autopilot: s.autopilot,
      }),
    },
  ),
);

export function selectRisk(state: DeskState): RiskCheck[] {
  return state.riskChecks;
}
