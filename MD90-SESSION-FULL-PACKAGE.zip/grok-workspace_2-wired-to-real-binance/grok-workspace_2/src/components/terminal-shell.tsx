import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  Activity,
  BookOpen,
  BrainCircuit,
  ClipboardCheck,
  Command,
  Gauge,
  Radio,
  ScanSearch,
  ScrollText,
  Shield,
  TerminalSquare,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Toaster } from "sonner";
import { Button } from "@/components/ui/button";
import { copy } from "@/lib/md90/i18n";
import { INSTRUMENTS, TICK_MS, TIMEFRAMES } from "@/lib/md90/constants";
import { getInstrument, utcSession } from "@/lib/md90/engine";
import { CLI_DESKS } from "@/lib/md90/cli";
import { autopilotLabel } from "@/lib/md90/live";
import { useDesk } from "@/lib/md90/store";
import { cn, dash, formatClock, formatUsd } from "@/lib/utils";

const NAV = [
  { to: "/", key: "overview" as const, icon: Gauge, hint: "F1" },
  { to: "/signal-room", key: "signalRoom" as const, icon: Radio, hint: "F2" },
  { to: "/markets", key: "markets" as const, icon: BookOpen, hint: "F3" },
  { to: "/agents", key: "agents" as const, icon: BrainCircuit, hint: "F4" },
  { to: "/risk", key: "risk" as const, icon: Shield, hint: "F5" },
  { to: "/replay", key: "lab" as const, icon: Activity, hint: "F6" },
  { to: "/scan", key: "scan" as const, icon: ScanSearch, hint: "F7" },
  { to: "/console", key: "console" as const, icon: TerminalSquare, hint: "F8" },
  { to: "/audit", key: "audit" as const, icon: ClipboardCheck, hint: "F9" },
  { to: "/journal", key: "journal" as const, icon: ScrollText, hint: "F10" },
];

export function TerminalShell({ children }: { children: React.ReactNode }) {
  const locale = useDesk((s) => s.locale);
  const setLocale = useDesk((s) => s.setLocale);
  const t = copy[locale];
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();
  const instrumentId = useDesk((s) => s.instrumentId);
  const setInstrument = useDesk((s) => s.setInstrument);
  const timeframe = useDesk((s) => s.timeframe);
  const setTimeframe = useDesk((s) => s.setTimeframe);
  const hydrated = useDesk((s) => s.hydrated);
  const account = useDesk((s) => s.account);
  const fusion = useDesk((s) => s.fusion);
  const operating = useDesk((s) => s.operating);
  const runCommand = useDesk((s) => s.runCommand);
  const lastPrice = useDesk((s) => s.lastPrice);
  const autopilot = useDesk((s) => s.autopilot);
  const setAutopilot = useDesk((s) => s.setAutopilot);
  const tickTape = useDesk((s) => s.tickTape);
  const [now, setNow] = useState(Date.now());
  const [palette, setPalette] = useState(false);
  const [query, setQuery] = useState("");

  useEffect(() => {
    const run = () => useDesk.getState().tick();
    run();
    const a = setInterval(run, TICK_MS);
    const b = setInterval(() => setNow(Date.now()), 1000);
    return () => {
      clearInterval(a);
      clearInterval(b);
    };
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setPalette((v) => !v);
      }
      const map: Record<string, string> = {
        F1: "/",
        F2: "/signal-room",
        F3: "/markets",
        F4: "/agents",
        F5: "/risk",
        F6: "/replay",
        F7: "/scan",
        F8: "/console",
        F9: "/audit",
        F10: "/journal",
      };
      if (map[e.key]) {
        e.preventDefault();
        void navigate({ to: map[e.key] });
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [navigate]);

  const session = utcSession(now);
  const digits = getInstrument(instrumentId).digits;
  const delta = tickTape[0]?.delta ?? 0;
  const filtered = useMemo(() => {
    const q = query.toLowerCase();
    if (q.startsWith("goto ") || q.startsWith("paper") || q.startsWith("help") || q.includes(" ")) return [];
    return NAV.filter(
      (n) => t[n.key].toLowerCase().includes(q) || n.hint.toLowerCase().includes(q) || n.to.includes(q),
    );
  }, [query, t]);

  function runPalette(raw: string) {
    const parsed = runCommand(raw);
    if (parsed.ok && parsed.action.type === "goto") {
      void navigate({ to: parsed.action.path });
    } else if (parsed.ok && parsed.action.type === "scan") {
      void navigate({ to: "/scan" });
    } else if (parsed.ok && parsed.action.type === "lab") {
      void navigate({ to: "/replay" });
    }
    setPalette(false);
    setQuery("");
  }

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <Toaster theme="dark" />
      <header className="sticky top-0 z-30 border-b border-border bg-bg/95 backdrop-blur-sm">
        <div className="flex flex-wrap items-center gap-3 px-4 py-3 lg:px-6">
          <Link to="/" className="flex items-baseline gap-2">
            <span className="font-mono text-xs tracking-[0.22em] text-accent">MD90</span>
            <span className="text-lg font-medium tracking-tight">Superlayer</span>
          </Link>
          <span className="hidden text-xs text-muted sm:inline">{t.kicker}</span>
          <div className="ml-auto flex flex-wrap items-center gap-2">
            <span className="flex items-center gap-2 rounded-sm border border-border px-2 py-1 font-mono text-xs tabular-nums">
              <i className={cn("inline-block size-1.5 rounded-full bg-accent", hydrated ? "live-dot" : "")} />
              <span
                key={dash(lastPrice, digits)}
                suppressHydrationWarning
                className={cn("tick-flash", delta >= 0 ? "text-long" : "text-short")}
              >
                {dash(lastPrice, digits)}
              </span>
            </span>
            <span suppressHydrationWarning className="rounded-sm border border-border px-2 py-1 font-mono text-xs tabular-nums text-muted">
              {formatUsd(account.equity, 0)}
            </span>
            <span suppressHydrationWarning className="rounded-sm border border-border px-2 py-1 font-mono text-xs text-muted">
              {formatClock(now).slice(11, 19)}
            </span>
            <span suppressHydrationWarning className="rounded-sm border border-border px-2 py-1 font-mono text-xs text-accent">
              {session}
            </span>
            <Button
              size="sm"
              variant={autopilot === "PAPER" ? "primary" : "ghost"}
              onClick={() => setAutopilot(autopilot === "PAPER" ? "OFF" : "PAPER")}
            >
              {autopilotLabel(autopilot, locale)}
            </Button>
            <span className="rounded-sm border border-short/40 bg-short/10 px-2 py-1 font-mono text-xs text-short">
              {t.liveLocked}
            </span>
            <Button size="sm" variant="ghost" onClick={() => setPalette(true)} className="hidden sm:inline-flex">
              <Command size={14} /> {t.command}
            </Button>
            <Button size="sm" variant="quiet" onClick={() => setLocale(locale === "ID" ? "EN" : "ID")}>
              {locale}
            </Button>
          </div>
        </div>
        <nav className="flex gap-1 overflow-x-auto px-3 pb-2 lg:px-5">
          {NAV.map((item) => {
            const active = pathname === item.to;
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex h-11 min-w-11 shrink-0 items-center gap-2 rounded-md px-3 text-sm",
                  active ? "bg-elevated text-fg" : "text-muted hover:text-fg",
                )}
              >
                <Icon size={16} />
                <span className="whitespace-nowrap">{t[item.key]}</span>
                <span className="hidden font-mono text-xs text-subtle lg:inline">{item.hint}</span>
              </Link>
            );
          })}
        </nav>
      </header>

      <div className="flex flex-wrap items-center gap-2 border-b border-border px-4 py-2 lg:px-6">
        <span className="font-mono text-xs tracking-[0.16em] text-subtle">{t.simulated}</span>
        {INSTRUMENTS.map((inst) => (
          <button
            key={inst.id}
            onClick={() => setInstrument(inst.id)}
            className={cn(
              "h-9 rounded-sm px-3 font-mono text-xs",
              instrumentId === inst.id ? "bg-accent text-accent-fg" : "text-muted hover:text-fg",
            )}
          >
            {inst.label}
          </button>
        ))}
        <span className="mx-1 h-4 w-px bg-border" />
        {TIMEFRAMES.map((tf) => (
          <button
            key={tf}
            onClick={() => setTimeframe(tf)}
            className={cn("h-9 rounded-sm px-2 font-mono text-xs", timeframe === tf ? "text-accent" : "text-muted")}
          >
            {tf}
          </button>
        ))}
        {!hydrated ? <span className="ml-auto font-mono text-xs text-accent">BOOT</span> : null}
      </div>

      <main className="px-4 py-5 pb-16 lg:px-6 lg:py-6">
        {hydrated ? children : (
          <p className="font-mono text-xs tracking-[0.18em] text-accent">BOOT · SIM FEED</p>
        )}
      </main>

      <footer className="sticky bottom-0 border-t border-border bg-bg/95 px-4 py-2 font-mono text-[11px] text-subtle lg:px-6">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
          <span className="text-long">READY</span>
          <span>SIM FEED</span>
          <span>PAPER</span>
          <span suppressHydrationWarning>
            {instrumentId} {dash(lastPrice, getInstrument(instrumentId).digits)}
          </span>
          <span suppressHydrationWarning>
            BID {dash(lastPrice ? lastPrice * 0.99996 : 0, getInstrument(instrumentId).digits)} ASK{" "}
            {dash(lastPrice ? lastPrice * 1.00004 : 0, getInstrument(instrumentId).digits)}
          </span>
          <span>
            {fusion?.direction ?? "WATCH"} {fusion?.status ?? "—"}
          </span>
          <span>{operating?.stage ?? "INGEST"}</span>
          <span>{autopilotLabel(autopilot, locale)}</span>
          <span className="ml-auto text-short">{t.liveLocked}</span>
        </div>
      </footer>

      {palette ? (
        <div className="fixed inset-0 z-50 grid place-items-start bg-overlay pt-24" onClick={() => setPalette(false)}>
          <div
            className="mx-auto w-[min(560px,calc(100%-2rem))] rounded-xl border border-border bg-surface p-3 shadow-panel"
            onClick={(e) => e.stopPropagation()}
          >
            <input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && query.trim()) {
                  const desk = CLI_DESKS[query.trim().toLowerCase() as keyof typeof CLI_DESKS];
                  if (desk && !query.includes(" ")) {
                    void navigate({ to: desk });
                    setPalette(false);
                    setQuery("");
                    return;
                  }
                  runPalette(query);
                }
              }}
              placeholder="auto on · paper · lab · scan · help"
              className="h-12 w-full rounded-md border border-border bg-elevated px-3 font-mono text-sm text-fg outline-none"
            />
            <div className="mt-2 flex flex-col">
              {filtered.map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={() => setPalette(false)}
                  className="flex h-11 items-center justify-between rounded-md px-3 text-sm hover:bg-elevated"
                >
                  <span>{t[item.key]}</span>
                  <span className="font-mono text-xs text-subtle">{item.hint}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
