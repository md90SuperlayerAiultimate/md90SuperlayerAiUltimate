import { OPERATING_STAGES } from "@/lib/md90/constants";
import { cn, dash, pct } from "@/lib/utils";

export function Panel({
  kicker,
  title,
  action,
  className,
  children,
}: {
  kicker?: string;
  title: string;
  action?: React.ReactNode;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <section className={cn("rounded-xl border border-border bg-surface p-3 sm:p-4", className)}>
      <header className="mb-3 flex items-start justify-between gap-3">
        <div>
          {kicker ? <div className="font-mono text-xs tracking-[0.18em] text-accent">{kicker}</div> : null}
          <h2 className="text-base font-medium tracking-tight">{title}</h2>
        </div>
        {action}
      </header>
      {children}
    </section>
  );
}

export function Kpi({
  label,
  value,
  hint,
  tone = "fg",
}: {
  label: string;
  value: string;
  hint?: string;
  tone?: "fg" | "long" | "short" | "warn" | "accent";
}) {
  const color = {
    fg: "text-fg",
    long: "text-long",
    short: "text-short",
    warn: "text-warn",
    accent: "text-accent",
  }[tone];
  return (
    <div className="rounded-lg bg-elevated px-4 py-3">
      <div className="font-mono text-xs tracking-[0.14em] text-subtle">{label}</div>
      <div className={cn("mt-1 font-mono text-xl tabular-nums", color)}>
        <span key={value} className="tick-flash">
          {value}
        </span>
      </div>
      {hint ? <div className="mt-1 text-xs text-muted">{hint}</div> : null}
    </div>
  );
}

export function TickSpark({
  points,
  height = 64,
  rising = true,
}: {
  points: { t: number; px: number }[];
  height?: number;
  rising?: boolean;
}) {
  if (points.length < 2) {
    return <div className="grid h-full place-items-center font-mono text-xs text-subtle">TAPE BOOT</div>;
  }
  const width = 360;
  const min = Math.min(...points.map((p) => p.px));
  const max = Math.max(...points.map((p) => p.px));
  const span = max - min || 1;
  const d = points
    .map((p, i) => {
      const x = (i / (points.length - 1)) * width;
      const y = 4 + ((max - p.px) / span) * (height - 8);
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
    })
    .join(" ");
  const last = points.at(-1)!;
  const lastX = width;
  const lastY = 4 + ((max - last.px) / span) * (height - 8);
  const color = rising ? "var(--color-long)" : "var(--color-short)";
  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="h-full w-full" preserveAspectRatio="none" aria-label="Tick sparkline">
      <path d={d} fill="none" stroke={color} strokeWidth="2.2" />
      <circle cx={lastX} cy={lastY} r="3.4" fill={color} />
    </svg>
  );
}

export function QuoteTape({
  symbol,
  last,
  prior,
  digits,
  spark,
  tickSeq,
  bid,
  ask,
}: {
  symbol: string;
  last: number;
  prior: number;
  digits: number;
  spark: { t: number; px: number }[];
  tickSeq: number;
  bid: number;
  ask: number;
}) {
  const chg = last && prior ? last - prior : 0;
  const chgPct = prior ? (chg / prior) * 100 : 0;
  const up = chg >= 0;
  return (
    <section className="rounded-xl border border-border bg-surface p-4">
      <div className="grid gap-4 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <div className="flex items-center gap-2 font-mono text-xs tracking-[0.2em] text-accent">
            <i className="live-dot inline-block size-1.5 rounded-full bg-accent" />
            LAST · {symbol} · SIM
          </div>
          <div className={cn("mt-1 font-mono text-4xl tabular-nums tracking-tight sm:text-5xl", up ? "text-long" : "text-short")}>
            <span key={dash(last, digits)} className="tick-flash">
              {last ? dash(last, digits) : "—"}
            </span>
          </div>
          <div className={cn("mt-1 font-mono text-sm tabular-nums", up ? "text-long" : "text-short")}>
            {up ? "+" : ""}
            {dash(chg, digits)} ({up ? "+" : ""}
            {chgPct.toFixed(3)}%) vs prior close
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3 self-end font-mono lg:col-span-3">
          <div>
            <div className="text-xs tracking-[0.14em] text-subtle">BID</div>
            <div className="text-xl tabular-nums text-short">{last ? dash(bid, digits) : "—"}</div>
          </div>
          <div>
            <div className="text-xs tracking-[0.14em] text-subtle">ASK</div>
            <div className="text-xl tabular-nums text-long">{last ? dash(ask, digits) : "—"}</div>
          </div>
          <div className="col-span-2 text-xs text-muted">
            tick #{tickSeq} · spread {last ? dash(ask - bid, digits) : "—"}
          </div>
        </div>
        <div className="h-20 lg:col-span-4">
          <TickSpark points={spark} rising={up} height={80} />
        </div>
      </div>
    </section>
  );
}

export function StageRail({
  current,
  events = [],
}: {
  current: string;
  events?: { stage: string; evidence: string; detail: string }[];
}) {
  const byStage = new Map(events.map((event) => [event.stage, event]));
  return (
    <ol className="grid grid-cols-2 gap-2 sm:grid-cols-5">
      {OPERATING_STAGES.map((stage, i) => {
        const event = byStage.get(stage);
        const evidence = event?.evidence ?? "PENDING";
        const tone =
          evidence === "BLOCKED" || evidence === "MISMATCH"
            ? "border-short/50 text-short"
            : evidence === "PENDING"
              ? "border-border text-subtle"
              : "border-long/40 text-long";
        return (
          <li
            key={stage}
            title={event?.detail}
            className={cn(
              "rounded-sm border px-2 py-2 font-mono text-xs tracking-wide",
              tone,
              stage === current && "ring-1 ring-accent",
            )}
          >
            <div>
              {String(i + 1).padStart(2, "0")} {stage.replace("_", " ")}
            </div>
            <div className="mt-1 text-[10px] tracking-normal text-muted">{evidence}</div>
          </li>
        );
      })}
    </ol>
  );
}

export function LabCurve({
  series,
}: {
  series: { t: number; equity: number }[];
}) {
  if (series.length < 2) {
    return <div className="grid h-28 place-items-center text-sm text-muted">No walk-forward equity yet</div>;
  }
  const width = 420;
  const height = 112;
  const pad = 8;
  const vals = series.map((p) => (p.equity - 1) * 100);
  const min = Math.min(0, ...vals);
  const max = Math.max(0, ...vals);
  const span = max - min || 1;
  const y = (v: number) => pad + ((max - v) / span) * (height - pad * 2);
  const x = (i: number) => pad + (i / (series.length - 1)) * (width - pad * 2);
  const d = vals.map((v, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(1)} ${y(v).toFixed(1)}`).join(" ");
  const zero = y(0);
  const last = vals.at(-1)!;
  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="h-28 w-full" aria-label="Walk-forward equity">
      <line x1={pad} x2={width - pad} y1={zero} y2={zero} className="stroke-border" />
      <path d={d} fill="none" stroke={last >= 0 ? "var(--color-long)" : "var(--color-short)"} strokeWidth="2" />
      <text x={width - pad} y={14} textAnchor="end" className="fill-subtle" fontSize="10" fontFamily="var(--font-mono)">
        {pct(last, 2)} net
      </text>
    </svg>
  );
}