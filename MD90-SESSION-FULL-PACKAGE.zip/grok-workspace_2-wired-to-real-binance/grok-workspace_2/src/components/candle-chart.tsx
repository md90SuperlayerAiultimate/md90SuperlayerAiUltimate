import type { Candle, SmcZone } from "@/lib/md90/engine";
import { dash } from "@/lib/utils";

export function CandleChart({
  candles,
  smc,
  last,
  stop,
  takeProfits = [],
  entries = [],
  height = 300,
}: {
  candles: Candle[];
  smc: SmcZone[];
  last?: number;
  stop?: number;
  takeProfits?: number[];
  entries?: { price: number; side: "BUY" | "SELL" }[];
  height?: number;
}) {
  const width = 920;
  const padL = 12;
  const padR = 78;
  const padT = 10;
  const volH = 42;
  const chartH = height - volH - padT;
  const slice = candles.slice(-18);
  if (slice.length < 2) {
    return (
      <div className="grid h-72 place-items-center text-sm text-muted">Waiting for simulated candles</div>
    );
  }
  const lastPx = last ?? slice.at(-1)!.c;
  const closes = slice.slice(-8).map((c) => (c.forming ? lastPx : c.c));
  const drift = Math.max(...closes) - Math.min(...closes);
  const half = Math.max(drift * 0.85, lastPx * 0.00115);
  const max = lastPx + half;
  const min = Math.max(0, lastPx - half);
  const span = max - min || 1;
  const y = (p: number) => padT + ((max - p) / span) * (chartH - 8);
  const gap = (width - padL - padR) / slice.length;
  const startBar = candles.length - slice.length;
  const maxV = Math.max(...slice.map((c) => c.v), 1);
  const digits = lastPx > 100 ? 2 : lastPx > 10 ? 2 : 5;
  const ticks = [max, (max + min) / 2, min];
  const closePath = slice
    .map((c, i) => {
      const x = padL + i * gap + gap / 2;
      return `${i === 0 ? "M" : "L"}${x} ${y(i === slice.length - 1 ? lastPx : c.c)}`;
    })
    .join(" ");
  const lastX = padL + (slice.length - 1) * gap + gap / 2;
  const rising = lastPx >= (slice.at(-2)?.c ?? lastPx);

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="h-full w-full" role="img" aria-label="Simulated OHLC with volume">
      {ticks.map((p) => (
        <g key={p}>
          <line
            x1={padL}
            x2={width - padR}
            y1={y(p)}
            y2={y(p)}
            className="stroke-border"
            strokeWidth="1"
          />
          <text
            x={width - padR + 6}
            y={y(p) + 4}
            className="fill-subtle"
            fontSize="10"
            fontFamily="var(--font-mono)"
          >
            {dash(p, digits)}
          </text>
        </g>
      ))}
      {smc
        .filter((z) => z.bar >= startBar)
        .map((z, i) => {
          const x = padL + (z.bar - startBar) * gap;
          return (
            <rect
              key={`${z.kind}-${i}`}
              x={x - 2}
              y={y(z.top)}
              width={Math.max(8, gap * 1.4)}
              height={Math.max(2, y(z.bottom) - y(z.top))}
              className={z.side === "BULL" ? "fill-long/15" : "fill-short/15"}
            />
          );
        })}
      {stop ? (
        <line x1={padL} x2={width - padR} y1={y(stop)} y2={y(stop)} stroke="var(--color-short)" strokeDasharray="4 4" strokeWidth="1" />
      ) : null}
      {takeProfits.slice(0, 3).map((tp, i) => (
        <line
          key={tp}
          x1={padL}
          x2={width - padR}
          y1={y(tp)}
          y2={y(tp)}
          stroke="var(--color-long)"
          strokeDasharray="3 5"
          strokeWidth="1"
          opacity={1 - i * 0.25}
        />
      ))}
      <path d={closePath} fill="none" stroke="var(--color-accent)" strokeWidth="1.6" opacity="0.55" />
      <line x1={padL} x2={width - padR} y1={y(lastPx)} y2={y(lastPx)} stroke="var(--color-accent)" strokeWidth="1.6" />
      <rect
        x={width - padR + 2}
        y={y(lastPx) - 10}
        width="74"
        height="18"
        fill="var(--color-accent)"
        rx="2"
      />
      <text
        x={width - 4}
        y={y(lastPx) + 3}
        textAnchor="end"
        fill="var(--color-accent-fg)"
        fontSize="11"
        fontFamily="var(--font-mono)"
      >
        {dash(lastPx, digits)}
      </text>
      {slice.map((c, i) => {
        const x = padL + i * gap + gap / 2;
        const forming = Boolean(c.forming) && i === slice.length - 1;
        const close = forming ? lastPx : c.c;
        const up = close >= c.o;
        const color = up ? "var(--color-long)" : "var(--color-short)";
        const bodyY = Math.min(y(c.o), y(close));
        const bodyH = Math.max(2, Math.abs(y(close) - y(c.o)));
        const vh = (c.v / maxV) * (volH - 8);
        const bodyW = forming ? Math.max(6, gap * 0.72) : Math.max(4, gap * 0.58);
        return (
          <g key={c.t} opacity={forming ? 1 : 0.92}>
            <line x1={x} x2={x} y1={y(c.h)} y2={y(c.l)} stroke={color} strokeWidth={forming ? 2.4 : 1.6} />
            <rect
              x={x - bodyW / 2}
              y={bodyY}
              width={bodyW}
              height={bodyH}
              fill={color}
            />
            <rect
              x={x - bodyW * 0.38}
              y={height - 4 - vh}
              width={bodyW * 0.76}
              height={vh}
              fill={color}
              opacity={0.45}
            />
            {forming ? (
              <circle cx={lastX} cy={y(lastPx)} r="4.2" fill="var(--color-accent)" />
            ) : null}
          </g>
        );
      })}
      {entries.map((e, i) => (
        <circle
          key={`${e.price}-${i}`}
          cx={width - padR - 8}
          cy={y(e.price)}
          r="3"
          fill={e.side === "BUY" ? "var(--color-long)" : "var(--color-short)"}
        />
      ))}
      <text x={padL} y={height - 6} className="fill-subtle" fontSize="9" fontFamily="var(--font-mono)">
        {rising ? "TICK UP" : "TICK DN"} · zoom locked to last print · SIM
      </text>
    </svg>
  );
}
