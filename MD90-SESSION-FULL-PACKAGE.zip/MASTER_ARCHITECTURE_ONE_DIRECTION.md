# MD90 — Arsitektur Induk: Satu Arah, Satu Sistem

Status: dokumen kerja hidup. Setiap item di sini sudah DIKERJAKAN (✅), SEDANG (🔶), atau BELUM (⬜) — bukan daftar keinginan, daftar kenyataan.

## 0. Prinsip (kerangka berpikir — berlaku untuk setiap keputusan di bawah)

1. **Satu sistem of record.** `md90-superlayerai-cockpit` (Node + tRPC + MySQL/TiDB) adalah backend tunggal yang nyata, teruji (231+ test lulus), dan dideploy. Semua kapabilitas baru masuk KE SINI — bukan jadi sistem paralel baru.
2. **Bahasa lain = layanan terpisah, bukan kode yang dilebur.** Python/Rust/C++ yang relevan jalan sebagai proses/servis sendiri, dipanggil lewat HTTP/API oleh backend inti. Ini standar industri (microservices), bukan keterbatasan saya.
3. **Setiap penambahan harus lulus 3 gerbang sebelum dianggap selesai:** (a) `tsc --noEmit` 0 error, (b) test baru ditulis dan lulus, (c) tidak merusak test yang sudah ada. Tanpa tiga ini, itu klaim — bukan fakta, persis seperti yang terjadi di dokumen-dokumen fabrikasi yang sudah kita bongkar di sesi ini.
4. **Data asli atau status eksplisit "tidak tersedia" — tidak pernah data sintetis menyamar jadi nyata.** Ini aturan paling penting setelah temuan `grok-workspace_1` (candle palsu berbenih `mulberry32` memakai nama MD90).

## 1. Peta satu arah: dari 8 sumber ke 1 sistem

```
                         ┌─────────────────────────────────────┐
                         │   MD90 BACKEND (sistem of record)    │
                         │   Node + tRPC + MySQL/TiDB           │
                         │   server/routers.ts = satu pintu     │
                         └───────────────┬───────────────────────┘
                                         │
        ┌────────────────┬──────────────┼──────────────┬────────────────┐
        │                │              │              │                │
   DATA MASUK        EKSEKUSI       RISK/AUDIT      UI/FRONTEND      RISET
        │                │              │              │                │
┌───────┴──────┐  ┌──────┴──────┐ ┌─────┴─────┐  ┌─────┴──────┐  ┌──────┴──────┐
│publicHistory  │  │binanceLive  │ │operating  │  │grok-ws_2   │  │qanat-main   │
│.ts (Binance)  │  │Adapter.ts   │ │Orchestr.  │  │(10 desk UI,│  │(pola tabel  │
│✅ real, tested│  │✅ real,test │ │✅ fixed   │  │disambung ke│  │transparan — │
│               │  │             │ │RISK_GATE  │  │data real)  │  │referensi    │
│stooqForex     │  │orders-with- │ │           │  │✅ crypto   │  │desain saja) │
│History.ts     │  │idempotency  │ │dailyLoss  │  │🔶 forex    │  │⬜ belum     │
│(XAUUSD/EURUSD)│  │.ts✅ wired  │ │Pct.ts✅   │  │  (Stooq    │  │  diterapkan │
│✅ real, tested│  │             │ │real calc  │  │  belum     │  │             │
└───────────────┘  └─────────────┘ └───────────┘  │  disambung)│  └─────────────┘
                                                    └────────────┘
        ┌────────────────┬──────────────┬──────────────┐
   POLA DESAIN        LISENSI        TIDAK DIPAKAI
   (bukan kode)        BERMASALAH      (keputusan sadar)
        │                │              │
┌───────┴──────┐  ┌──────┴──────┐ ┌─────┴──────────────┐
│TradingAgents  │  │FinceptTerm. │ │grok-workspace_1     │
│(debat bull/   │  │(AGPL-3.0 —  │ │(data sintetis       │
│bear) ⬜ belum │  │risiko hukum │ │mulberry32 menyamar   │
│diterapkan,    │  │kalau disalin│ │jadi MD90 — JANGAN    │
│butuh LLM API  │  │ke layanan   │ │dipakai sebagai       │
│               │  │jaringan)    │ │dashboard produksi)   │
│Vibe-Trading   │  │⬜ tidak     │ │❌ dibuang dari arah  │
│(ccxt_loader   │  │  disalin    │ │  ini                 │
│pattern) ⬜    │  └─────────────┘ │                      │
│               │                  │market-data-gateway   │
│AI-Trader      │                  │(Rust) — belum pernah │
│(skill         │                  │berhasil compile di   │
│Polymarket)    │                  │sandbox saya           │
│⬜             │                  │🔶 statusnya tidak    │
│               │                  │  diketahui, bukan    │
│OpenTerminal   │                  │  dikonfirmasi rusak  │
│(pola provider │                  │  atau jalan           │
│Stooq) ✅ sudah│                  └──────────────────────┘
│diterapkan ulang│
│dengan benar   │
└───────────────┘
```

## 2. Status per kapabilitas (fakta, bukan klaim)

| Kapabilitas | Sumber pola | Status di MD90 | Bukti |
|---|---|---|---|
| Data live crypto (BTC/ETH/SOL) | native MD90 (`publicHistory.ts`) | ✅ Nyata | `publicHistory.test.ts` 4/4 lulus |
| Data historis XAUUSD/EURUSD | diadaptasi dari pola OpenTerminal, diperbaiki bug suffix-nya | ✅ Nyata | `stooqForexHistory.test.ts` 9/9 lulus |
| Eksekusi order live Binance | native MD90, baru | ✅ Nyata (testnet-default, fail-closed) | `binanceLiveAdapter.test.ts` 9/9 lulus |
| Idempotency order (anti-duplikat) | native MD90, diperbaiki 2 bug nyata | ✅ Nyata | `phase1-idempotency.test.ts` lulus |
| Risk gate (freshness, dailyLoss) | native MD90, 3 bug diperbaiki | ✅ Nyata | `forwardPaperPersistence.test.ts` lulus |
| UI 10-desk (Overview/Signal Room/dst) | `grok-workspace_2` | 🔶 Sebagian — crypto tersambung data real, forex/Polymarket masih simulasi berlabel jujur | `vite build` lulus |
| Backtest deklaratif transparan | pola `qanat-main` | ⬜ Belum diterapkan ke `datasetReplay.ts` | — |
| Sinyal multi-agent (bull/bear debate) | pola `TradingAgents` | ⬜ Belum — butuh keputusan: mau bayar API LLM per analisis? | — |
| Copy-trading / Polymarket | pola `AI-Trader` | ⬜ Belum | — |
| Loader ccxt tambahan | pola `Vibe-Trading` | ⬜ Belum — `binanceLiveAdapter.ts` sudah cover kasus utama | — |
| Terminal desktop C++/Qt6 | `FinceptTerminal` | ❌ Tidak dipakai — AGPL-3.0, risiko hukum | — |
| Market-data-gateway (Rust) | repo lama | 🔶 Status tidak diketahui — belum pernah lulus compile di sandbox saya | `cargo build` gagal karena toolchain |
| Dashboard data sintetis | `grok-workspace_1` | ❌ Dibuang dari arah ini — menyamar sebagai data nyata |  — |

## 3. Urutan eksekusi berikutnya (satu arah, bukan serentak)

1. Sambungkan 3 titik `generateLiveSeries` tersisa di `grok-workspace_2/store.ts` ke `fetchStooqForexHistory` untuk XAUUSD/EURUSD (data sudah ada di backend, tinggal disambung di frontend — sama persis pola yang sudah berhasil untuk crypto).
2. Verifikasi testnet Binance nyata (`scripts/verify-binance-testnet.ts`) — **ini harus Anda jalankan sendiri**, sandbox saya terbukti diblokir ke domain Binance dan Stooq.
3. Baru setelah #1–2 selesai dan terverifikasi: evaluasi apakah pola TradingAgents (debat bull/bear) layak ditambahkan sebagai layer sinyal baru — ini keputusan biaya (API LLM berbayar per run), bukan keputusan teknis semata.

Setiap langkah di atas akan saya kerjakan dengan tiga gerbang di bagian 0 — typecheck, test baru, tidak merusak test lama — dan saya laporkan hasil nyatanya, bukan deklarasi selesai.
