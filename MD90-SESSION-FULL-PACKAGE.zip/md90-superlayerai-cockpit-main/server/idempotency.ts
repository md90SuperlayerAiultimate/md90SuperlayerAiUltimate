/**
 * STEP 3: Idempotency System
 * UUID tracking, state machine untuk mencegah duplikasi request
 */

import { v4 as uuidv4 } from 'uuid';

// State machine untuk idempotency
export enum IdempotencyState {
  PENDING = 'PENDING',
  PROCESSING = 'PROCESSING',
  SUCCESS = 'SUCCESS',
  FAILED = 'FAILED',
  EXPIRED = 'EXPIRED'
}

export interface IdempotencyKey {
  id: string;
  requestId: string;
  state: IdempotencyState;
  createdAt: number;
  expiresAt: number;
  result?: any;
  error?: string;
  retryCount: number;
  maxRetries: number;
}

export interface IdempotencyRequest {
  method: string;
  url: string;
  body?: any;
  headers?: Record<string, string>;
}

/**
 * IdempotencyManager - Mengelola idempotency untuk mencegah duplikasi
 */
export class IdempotencyManager {
  private keyStore: Map<string, IdempotencyKey> = new Map();
  private readonly TTL = 24 * 60 * 60 * 1000; // 24 hours
  private readonly CLEANUP_INTERVAL = 60 * 60 * 1000; // 1 hour
  private cleanupTimer: NodeJS.Timeout | null = null;

  constructor() {
    this.startCleanup();
  }

  /**
   * Generate unique idempotency key
   */
  generateKey(request: IdempotencyRequest): string {
    const keyData = `${request.method}:${request.url}:${JSON.stringify(request.body)}`;
    return Buffer.from(keyData).toString('base64');
  }

  /**
   * Register request dengan idempotency tracking
   */
  registerRequest(
    requestId: string,
    request: IdempotencyRequest,
    maxRetries: number = 5
  ): IdempotencyKey {
    const key = this.generateKey(request);
    const now = Date.now();

    // Check if key sudah exist
    if (this.keyStore.has(key)) {
      const existing = this.keyStore.get(key)!;
      
      // Jika masih processing, return existing
      if (existing.state === IdempotencyState.PROCESSING) {
        return existing;
      }
      
      // Jika success, return cached result
      if (existing.state === IdempotencyState.SUCCESS) {
        return existing;
      }
      
      // Jika failed dan bisa retry
      if (existing.state === IdempotencyState.FAILED && existing.retryCount < maxRetries) {
        existing.state = IdempotencyState.PENDING;
        existing.retryCount++;
        return existing;
      }
    }

    // Create new idempotency key
    const idempotencyKey: IdempotencyKey = {
      id: key,
      requestId,
      state: IdempotencyState.PENDING,
      createdAt: now,
      expiresAt: now + this.TTL,
      retryCount: 0,
      maxRetries
    };

    this.keyStore.set(key, idempotencyKey);
    return idempotencyKey;
  }

  /**
   * Update state dari idempotency key
   */
  updateState(
    key: string,
    state: IdempotencyState,
    result?: any,
    error?: string
  ): IdempotencyKey | null {
    const idempotencyKey = this.keyStore.get(key);
    
    if (!idempotencyKey) return null;

    idempotencyKey.state = state;
    
    if (result !== undefined) {
      idempotencyKey.result = result;
    }
    
    if (error !== undefined) {
      idempotencyKey.error = error;
    }

    this.keyStore.set(key, idempotencyKey);
    return idempotencyKey;
  }

  /**
   * Get idempotency key result
   */
  getResult(key: string): { state: IdempotencyState; result?: any; error?: string } | null {
    const idempotencyKey = this.keyStore.get(key);
    
    if (!idempotencyKey) return null;

    // Check if expired
    if (Date.now() > idempotencyKey.expiresAt) {
      idempotencyKey.state = IdempotencyState.EXPIRED;
      this.keyStore.set(key, idempotencyKey);
    }

    return {
      state: idempotencyKey.state,
      result: idempotencyKey.result,
      error: idempotencyKey.error
    };
  }

  /**
   * Check if request sudah pernah di-process
   */
  isDuplicate(key: string): boolean {
    const idempotencyKey = this.keyStore.get(key);
    
    if (!idempotencyKey) return false;

    const result = this.getResult(key);
    return result?.state === IdempotencyState.SUCCESS || 
           result?.state === IdempotencyState.PROCESSING;
  }

  /**
   * Cleanup expired keys
   */
  private cleanup(): void {
    const now = Date.now();
    const keysToDelete: string[] = [];

    for (const [key, idempotencyKey] of Array.from(this.keyStore.entries())) {
      if (now > idempotencyKey.expiresAt) {
        keysToDelete.push(key);
      }
    }

    keysToDelete.forEach(key => this.keyStore.delete(key));
    
    if (keysToDelete.length > 0) {
      console.log(`[IdempotencyManager] Cleaned up ${keysToDelete.length} expired keys`);
    }
  }

  /**
   * Start cleanup timer
   */
  private startCleanup(): void {
    this.cleanupTimer = setInterval(() => {
      this.cleanup();
    }, this.CLEANUP_INTERVAL);
  }

  /**
   * Stop cleanup timer
   */
  destroy(): void {
    if (this.cleanupTimer) {
      clearInterval(this.cleanupTimer);
      this.cleanupTimer = null;
    }
    this.keyStore.clear();
  }

  /**
   * Get statistics
   */
  getStats(): { total: number; byState: Record<IdempotencyState, number> } {
    const stats: { total: number; byState: Record<IdempotencyState, number> } = {
      total: this.keyStore.size,
      byState: {
        [IdempotencyState.PENDING]: 0,
        [IdempotencyState.PROCESSING]: 0,
        [IdempotencyState.SUCCESS]: 0,
        [IdempotencyState.FAILED]: 0,
        [IdempotencyState.EXPIRED]: 0
      }
    };

    for (const idempotencyKey of Array.from(this.keyStore.values())) {
      stats.byState[idempotencyKey.state]++;
    }

    return stats;
  }
}

// Global singleton instance
export const idempotencyManager = new IdempotencyManager();