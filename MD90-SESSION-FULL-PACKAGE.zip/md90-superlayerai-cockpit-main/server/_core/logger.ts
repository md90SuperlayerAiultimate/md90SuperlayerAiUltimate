export class Logger {
  constructor(private readonly name: string) {}
  private format(level: string, message: string): string {
    return `[${new Date().toISOString()}] [${level}] [${this.name}] ${message}`;
  }
  debug(message: string): void { console.debug(this.format("DEBUG", message)); }
  info(message: string): void { console.log(this.format("INFO", message)); }
  warn(message: string): void { console.warn(this.format("WARN", message)); }
  error(message: string): void { console.error(this.format("ERROR", message)); }
}
