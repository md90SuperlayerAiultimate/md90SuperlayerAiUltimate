export type StooqCandle = { time: number; open: number; high: number; low: number; close: number };
export type StooqHistoryResult =
  | { status: "ready"; symbol: string; candles: StooqCandle[]; checksum: string }
  | { status: "blocked"; symbol: string; reason: string }
  | { status: "error"; symbol: string; reason: string };

const SUPPORTED_SYMBOLS: Record<string, string> = {
  XAUUSD: "xauusd",
  XAGUSD: "xagusd",
  EURUSD: "eurusd",
  GBPUSD: "gbpusd",
  USDJPY: "usdjpy",
};

function stooqQuerySymbol(symbol: string): string | null {
  return SUPPORTED_SYMBOLS[symbol.toUpperCase()] ?? null;
}

async function sha256Hex(input: string): Promise<string> {
  const { createHash } = await import("node:crypto");
  return createHash("sha256").update(input).digest("hex");
}

export function parseStooqCsv(csvText: string): { candles: StooqCandle[]; error: string | null } {
  const lines = csvText.trim().split("\n");
  if (lines.length < 2 || !lines[0].toLowerCase().startsWith("date")) {
    return { candles: [], error: "MALFORMED_CSV_HEADER" };
  }
  const candles: StooqCandle[] = [];
  for (let i = 1; i < lines.length; i++) {
    const parts = lines[i].split(",");
    if (parts.length < 5) return { candles: [], error: `MALFORMED_ROW:${i}` };
    const [dateStr, openStr, highStr, lowStr, closeStr] = parts;
    const time = Date.parse(`${dateStr}T00:00:00Z`);
    const open = Number(openStr);
    const high = Number(highStr);
    const low = Number(lowStr);
    const close = Number(closeStr);
    if (![time, open, high, low, close].every(Number.isFinite)) return { candles: [], error: `NON_NUMERIC_ROW:${i}` };
    if (!(high >= low) || !(high >= open) || !(high >= close) || !(low <= open) || !(low <= close)) {
      return { candles: [], error: `INVALID_OHLC_ROW:${i}` };
    }
    candles.push({ time, open, high, low, close });
  }
  for (let i = 1; i < candles.length; i++) {
    if (candles[i].time <= candles[i - 1].time) return { candles: [], error: `NON_ASCENDING_TIMESTAMPS_AT:${i}` };
  }
  return { candles, error: null };
}

export async function fetchStooqForexHistory(symbol: string, fetchImpl: typeof fetch = fetch): Promise<StooqHistoryResult> {
  const stooqSymbol = stooqQuerySymbol(symbol);
  if (!stooqSymbol) return { status: "blocked", symbol, reason: `UNSUPPORTED_SYMBOL: only ${Object.keys(SUPPORTED_SYMBOLS).join(", ")} are mapped` };
  let response: Response;
  try {
    response = await fetchImpl(`https://stooq.com/q/d/l/?s=${stooqSymbol}&i=d`);
  } catch (error) {
    return { status: "error", symbol, reason: error instanceof Error ? error.message : "NETWORK_ERROR" };
  }
  if (!response.ok) return { status: "error", symbol, reason: `HTTP_${response.status}` };
  const csvText = await response.text();
  const { candles, error } = parseStooqCsv(csvText);
  if (error) return { status: "error", symbol, reason: error };
  if (candles.length === 0) return { status: "error", symbol, reason: "EMPTY_SERIES" };
  const checksum = await sha256Hex(csvText);
  return { status: "ready", symbol, candles, checksum };
}
