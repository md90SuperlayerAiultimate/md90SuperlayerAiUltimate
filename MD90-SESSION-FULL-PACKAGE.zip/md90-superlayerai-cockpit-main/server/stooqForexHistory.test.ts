import { describe, expect, it, vi } from "vitest";
import { fetchStooqForexHistory, parseStooqCsv } from "./stooqForexHistory";

const VALID_CSV = "Date,Open,High,Low,Close,Volume\n2026-01-02,2050.1,2062.4,2048.0,2060.3,0\n2026-01-03,2060.3,2071.0,2058.5,2069.9,0\n";

describe("parseStooqCsv", () => {
  it("parses a well-formed Stooq daily CSV into ascending candles", () => {
    const { candles, error } = parseStooqCsv(VALID_CSV);
    expect(error).toBeNull();
    expect(candles).toHaveLength(2);
  });
  it("rejects a malformed header", () => {
    expect(parseStooqCsv("not,a,real,header\n1,2,3,4\n").error).toBe("MALFORMED_CSV_HEADER");
  });
  it("rejects impossible OHLC", () => {
    const bad = "Date,Open,High,Low,Close,Volume\n2026-01-02,2050,2055,2048,2060,0\n";
    expect(parseStooqCsv(bad).error).toBe("INVALID_OHLC_ROW:1");
  });
  it("rejects non-ascending timestamps", () => {
    const outOfOrder = "Date,Open,High,Low,Close,Volume\n2026-01-03,1,2,0,1,0\n2026-01-02,1,2,0,1,0\n";
    expect(parseStooqCsv(outOfOrder).error).toBe("NON_ASCENDING_TIMESTAMPS_AT:1");
  });
});

describe("fetchStooqForexHistory", () => {
  it("blocks unmapped symbols without calling fetch", async () => {
    const fetchImpl = vi.fn();
    const result = await fetchStooqForexHistory("DOGEUSD", fetchImpl);
    expect(result.status).toBe("blocked");
    expect(fetchImpl).not.toHaveBeenCalled();
  });
  it("maps XAUUSD to bare 'xauusd' — no .us suffix", async () => {
    const fetchImpl = vi.fn().mockResolvedValue({ ok: true, text: async () => VALID_CSV });
    await fetchStooqForexHistory("XAUUSD", fetchImpl);
    expect(fetchImpl.mock.calls[0][0]).toBe("https://stooq.com/q/d/l/?s=xauusd&i=d");
  });
  it("maps EURUSD to bare 'eurusd'", async () => {
    const fetchImpl = vi.fn().mockResolvedValue({ ok: true, text: async () => VALID_CSV });
    await fetchStooqForexHistory("eurusd", fetchImpl);
    expect(fetchImpl.mock.calls[0][0]).toBe("https://stooq.com/q/d/l/?s=eurusd&i=d");
  });
  it("reports ERROR on non-ok HTTP", async () => {
    const fetchImpl = vi.fn().mockResolvedValue({ ok: false, status: 500 });
    const result = await fetchStooqForexHistory("XAUUSD", fetchImpl);
    expect(result.status).toBe("error");
  });
  it("includes checksum on ready result", async () => {
    const fetchImpl = vi.fn().mockResolvedValue({ ok: true, text: async () => VALID_CSV });
    const result = await fetchStooqForexHistory("XAUUSD", fetchImpl);
    if (result.status === "ready") expect(result.checksum).toMatch(/^[0-9a-f]{64}$/);
  });
});
