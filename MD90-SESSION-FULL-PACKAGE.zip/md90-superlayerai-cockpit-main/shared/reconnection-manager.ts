import { Logger } from '../server/_core/logger';

export interface ReconnectionConfig {
  baseDelay: number;
  maxDelay: number;
  maxAttempts: number;
  jitterFactor: number;
}

const DEFAULT_CONFIG: ReconnectionConfig = {
  baseDelay: 1000,
  maxDelay: 32000,
  maxAttempts: Infinity,
  jitterFactor: 0.1,
};

export class ReconnectionManager {
  private attempt = 0;
  private config: ReconnectionConfig;
  private logger: Logger;
  private lastReconnectTime = 0;
  private reconnectCount = 0;
  private timeWindowStart = Date.now();

  constructor(config: Partial<ReconnectionConfig> = {}, logger?: Logger) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.logger = logger || new Logger('ReconnectionManager');
  }

  /**
   * Calculate exponential backoff delay with jitter
   * Formula: min(baseDelay * 2^attempt, maxDelay) * (1 ± jitterFactor)
   */
  private calculateDelay(): number {
    const exponentialDelay = Math.min(
      this.config.baseDelay * Math.pow(2, this.attempt),
      this.config.maxDelay
    );

    const jitter = (Math.random() - 0.5) * 2 * this.config.jitterFactor;
    const delayWithJitter = exponentialDelay * (1 + jitter);

    return Math.max(0, Math.floor(delayWithJitter));
  }

  /**
   * Detect thundering herd: prevent >5 reconnects/minute per IP
   */
  private isThunderingHerd(): boolean {
    const now = Date.now();
    const timeWindow = 60000; // 1 minute

    if (now - this.timeWindowStart > timeWindow) {
      this.timeWindowStart = now;
      this.reconnectCount = 0;
    }

    this.reconnectCount++;
    return this.reconnectCount > 5;
  }

  /**
   * Wait before reconnecting with exponential backoff
   */
  async wait(): Promise<void> {
    if (this.attempt >= this.config.maxAttempts) {
      throw new Error(
        `Max reconnection attempts (${this.config.maxAttempts}) exceeded`
      );
    }

    if (this.isThunderingHerd()) {
      this.logger.warn(
        `Thundering herd detected: >5 reconnects/min. Holding at max delay.`
      );
      await this.sleep(this.config.maxDelay);
      return;
    }

    const delay = this.calculateDelay();
    this.logger.info(
      `Reconnection attempt ${this.attempt + 1}: waiting ${delay}ms`
    );

    this.lastReconnectTime = Date.now();
    await this.sleep(delay);
    this.attempt++;
  }

  /**
   * Reset on successful connection
   */
  reset(): void {
    this.logger.info(`Connection established. Resetting reconnection counter.`);
    this.attempt = 0;
    this.reconnectCount = 0;
  }

  /**
   * Get current attempt number
   */
  getAttempt(): number {
    return this.attempt;
  }

  getAttemptCount(): number {
    return this.attempt;
  }

  getNextDelay(): number | null {
    if (this.attempt >= this.config.maxAttempts) {
      return null;
    }
    const delay = this.isThunderingHerd() ? this.config.maxDelay : this.calculateDelay();
    this.lastReconnectTime = Date.now();
    this.attempt++;
    return delay;
  }

  /**
   * Get last reconnect timestamp
   */
  getLastReconnectTime(): number {
    return this.lastReconnectTime;
  }

  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}
