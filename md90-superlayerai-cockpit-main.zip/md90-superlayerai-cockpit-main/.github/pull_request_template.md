## Ringkasan perubahan

Jelaskan perubahan secara singkat dan file/komponen yang terdampak.

## Evidence wajib

- [ ] `pnpm test` lulus.
- [ ] `pnpm exec tsc --noEmit` lulus.
- [ ] `pnpm build` lulus.
- [ ] Dependency review dan secret scan lulus atau exception dijelaskan.
- [ ] Perubahan tidak memasukkan `.env`, private key, wallet seed, broker credential, atau secret provider.
- [ ] Perubahan tidak mengaktifkan live order, wallet signing, custody, withdrawal, atau external execution.
- [ ] Screenshot/acceptance notes ditambahkan bila UI berubah.

## Data dan audit

Jelaskan provenance, checksum, migration, atau perubahan contract bila relevan. Klaim performa harus menyebut sample size dan tidak boleh berasal dari demo data tanpa label.

## Rollback

Jelaskan checkpoint/commit yang menjadi rollback point dan risiko bila perubahan perlu dibatalkan.
