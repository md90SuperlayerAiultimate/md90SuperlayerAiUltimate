import { calculateDemoStats, generateDemoBatch } from "../server/demoSimulator";
import { getPaperOverview } from "../server/paperEngine";

const startingEquity = 10_000;
const trades = Array.from({ length: 40 }, (_, index) => generateDemoBatch(new Date(Date.UTC(2026, 0, 1, 0, index))).map((trade) => ({ ...trade, batchId: `${trade.batchId}-${index}` }))).flat();
const stats = calculateDemoStats(startingEquity, trades);
let equity = startingEquity;
let peak = startingEquity;
let maxDrawdownPct = 0;
for (const trade of trades) {
  equity += trade.pnl;
  peak = Math.max(peak, equity);
  maxDrawdownPct = Math.max(maxDrawdownPct, peak ? ((peak - equity) / peak) * 100 : 0);
}
const overview = getPaperOverview();
const result = {
  mode: "PAPER",
  provenance: "MD90 deterministic demo simulator; not live market evidence",
  startingEquity,
  ...stats,
  maxDrawdownPct: Number(maxDrawdownPct.toFixed(2)),
  averageFee: Number((trades.reduce((sum, trade) => sum + trade.fee, 0) / trades.length).toFixed(4)),
  paperOverviewTradeCount: overview.metrics.tradeCount,
  paperOverviewCandles: overview.primary.candles.length,
  liveApproval: overview.riskChecks.find((check) => check.label === "Live approval")?.status,
  survivorMode: overview.riskChecks.find((check) => check.label === "Survivor Mode")?.status,
};
console.log(JSON.stringify(result, null, 2));
