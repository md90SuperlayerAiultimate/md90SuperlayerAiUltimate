from __future__ import annotations

import hashlib
import json
import re
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOTS = [Path('/home/ubuntu/md90_refactor_v1'), Path('/home/ubuntu/md90_superlayerai')]
ARCHIVES = [Path('/home/ubuntu/md90_refactor_v1.zip'), Path('/home/ubuntu/upload/md90_FINAL_VERIFIED.zip'), Path('/home/ubuntu/upload/md90_ultimate_fusion_v4_FINAL_ARB.zip')]
OUT = Path('/home/ubuntu/md90_superlayerai/docs/audit')
TEXT_EXTS = {'.py', '.pine', '.pinescript', '.mq4', '.mq5', '.mql4', '.mql5', '.ts', '.tsx', '.js', '.mjs', '.json', '.yaml', '.yml', '.md', '.txt', '.csv', '.sql'}
SKIP_PARTS = {'node_modules', '.git', 'dist', 'build', '.cache'}
PATTERNS = {
    'network': r'\b(?:requests|httpx|aiohttp|websocket|websockets|socket|urllib|fetch\s*\(|axios|curl|http://|https://)\b',
    'credentials': r'(?i)(api[_ -]?key|secret|private[_ -]?key|seed phrase|mnemonic|password|token|bearer)',
    'custody': r'(?i)(sign(?:ing|ature)?|wallet|withdraw|deposit|private key|mnemonic|seed phrase)',
    'order_execution': r'(?i)(create_order|place_order|submit_order|send_order|market_order|limit_order|broker|exchange|ccxt)',
    'automation': r'(?i)(webhook|scheduler|cron|heartbeat|auto[_ -]?tune|self[_ -]?learn|agent|command_listener)',
    'indicators': r'(?i)(rsi|stoch|macd|ema|sma|atr|bollinger|vwap|obv|mfi|engulf|pivot|volume)',
    'risk': r'(?i)(stop[_ -]?loss|take[_ -]?profit|drawdown|risk|slippage|fee|exposure|position[_ -]?size|trailing)',
    'timeframe': r'(?i)(timeframe|interval|15m|1h|4h|1d|multi[_ -]?timeframe|mtfa|htf)',
}

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def classify(path: str, text: str) -> list[str]:
    low = path.lower()
    out = []
    if any(x in low for x in ('data_provider', 'dataset', 'csv', 'ohlcv', 'market')): out.append('data')
    if any(x in low for x in ('indicator', 'signal', 'strategy', 'regime', 'hmm', 'fusion', 'matari', 'alpha')): out.append('signal')
    if any(x in low for x in ('risk', 'policy', 'position', 'broker', 'execution', 'order')): out.append('risk_execution')
    if any(x in low for x in ('dashboard', 'ui', 'client', 'frontend', 'web')): out.append('ui')
    if any(x in low for x in ('memory', 'qdrant', 'graph', 'agent', 'cognitive')): out.append('agent_memory')
    if any(x in low for x in ('test', 'fixture')): out.append('test')
    for key, pattern in PATTERNS.items():
        if re.search(pattern, text): out.append(key)
    return sorted(set(out)) or ['unclassified']

def scan_file(path: Path, origin: str) -> dict:
    raw = path.read_bytes()
    item = {'origin': origin, 'path': str(path), 'filename': path.name, 'extension': path.suffix.lower(), 'sizeBytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    if path.suffix.lower() in TEXT_EXTS:
        text = raw.decode('utf-8', errors='replace')
        lines = text.splitlines()
        item.update({'lineCount': len(lines), 'capabilities': classify(str(path), text), 'riskFlags': {k: len(re.findall(v, text)) for k, v in PATTERNS.items() if re.search(v, text)}, 'emptyOrBinary': False})
    else:
        item.update({'lineCount': None, 'capabilities': ['binary_or_archive'], 'riskFlags': {}, 'emptyOrBinary': True})
    return item

def main() -> None:
    files: list[dict] = []
    seen: set[str] = set()
    for root in ROOTS:
        if not root.exists(): continue
        for path in root.rglob('*'):
            if not path.is_file() or any(part in SKIP_PARTS for part in path.parts): continue
            key = str(path.resolve())
            if key in seen: continue
            seen.add(key)
            files.append(scan_file(path, 'workspace'))
    archives = []
    for path in ARCHIVES:
        if not path.exists(): continue
        entry = {'path': str(path), 'filename': path.name, 'sizeBytes': path.stat().st_size, 'sha256': sha256(path), 'members': []}
        with zipfile.ZipFile(path) as z:
            for info in z.infolist():
                if info.is_dir(): continue
                member_raw = z.read(info)
                member = {'name': info.filename, 'sizeBytes': info.file_size, 'sha256': hashlib.sha256(member_raw).hexdigest(), 'extension': Path(info.filename).suffix.lower()}
                if member['extension'] in TEXT_EXTS:
                    text = member_raw.decode('utf-8', errors='replace')
                    member.update({'lineCount': len(text.splitlines()), 'capabilities': classify(info.filename, text), 'riskFlags': {k: len(re.findall(v, text)) for k, v in PATTERNS.items() if re.search(v, text)}})
                else:
                    member.update({'lineCount': None, 'capabilities': ['binary_or_archive'], 'riskFlags': {}})
                entry['members'].append(member)
        archives.append(entry)
    payload = {'generatedAt': datetime.now(timezone.utc).isoformat(), 'method': 'static_read_only_no_import_no_execution', 'workspaceFiles': files, 'archives': archives}
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / 'OMNI_ARTIFACT_STATIC_LEDGER_2026-08-27.json').write_text(json.dumps(payload, indent=2), encoding='utf-8')
    counts = {}
    for item in files:
        counts[item['extension'] or '[none]'] = counts.get(item['extension'] or '[none]', 0) + 1
    categories = {}
    for item in files:
        for cap in item['capabilities']:
            categories[cap] = categories.get(cap, 0) + 1
    md = ['# Omni-source static artifact ledger — 2026-08-27', '', '> Static read-only audit. No source file was imported, executed, or granted network/custody authority.', '', '## Inventory summary', '', f'- Workspace files scanned: **{len(files)}**', f'- Archives scanned: **{len(archives)}**', f'- Archive members scanned: **{sum(len(a["members"]) for a in archives)}**', '', '| Extension | Files |', '|---|---:|']
    md += [f'| `{k}` | {v} |' for k, v in sorted(counts.items())]
    md += ['', '## Capability and risk signals', '', '| Signal/category | File hits |', '|---|---:|']
    md += [f'| `{k}` | {v} |' for k, v in sorted(categories.items())]
    md += ['', '## Status interpretation', '', '| Status | Meaning |', '|---|---|', '| `STATIC_PARSED` | Bytes/text read, checksum and structural signals recorded. |', '| `RUNTIME_MAPPED` | Capability has an explicit canonical module, route, test, and safety contract. |', '| `PENDING_EVIDENCE` | Requires source/provider/license/fixture or operator evidence not present in the file itself. |', '| `DISABLED` | Network order, custody, signing, withdrawal, or promotion authority is intentionally unavailable. |', '', 'The complete per-file ledger, including line counts, SHA-256, capabilities, and risk flag counts, is stored in the adjacent JSON file.']
    (OUT / 'OMNI_ARTIFACT_STATIC_LEDGER_2026-08-27.md').write_text('\n'.join(md) + '\n', encoding='utf-8')
    print(json.dumps({'workspaceFiles': len(files), 'archives': len(archives), 'archiveMembers': sum(len(a['members']) for a in archives), 'extensionCounts': counts, 'ledger': str(OUT / 'OMNI_ARTIFACT_STATIC_LEDGER_2026-08-27.json')}, indent=2))

if __name__ == '__main__':
    main()
