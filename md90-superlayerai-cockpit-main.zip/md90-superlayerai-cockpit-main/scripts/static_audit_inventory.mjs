import { createHash } from "node:crypto";
import { readdirSync, readFileSync, statSync, writeFileSync } from "node:fs";
import { join, relative } from "node:path";

const root = "/home/ubuntu/upload";
const out = "/home/ubuntu/md90_superlayerai/docs/audit/OMNI_SOURCE_LINE_FLAGS_2026-08-26.md";
const rules = [
  ["NETWORK", /fetch\(|axios|requests\.|httpx|websocket|web3|ccxt|urllib|socket\./i],
  ["CREDENTIAL", /api[_-]?key|api[_-]?secret|private[_-]?key|secret|token|password|mnemonic|seed phrase|wallet/i],
  ["ORDER_CUSTODY", /place[_-]?order|create[_-]?order|cancel[_-]?all|positionopen|positionclose|ctrade|sign_transaction|withdraw|deposit|transfer|wallet/i],
  ["MUTABLE_STATE", /write_text|write_bytes|open\([^\n]*["']w|json\.dump|pickle\.dump|save\(|commit\(|push\(|apply[_-]?to[_-]?config/i],
  ["PROCESS", /subprocess|os\.system|popen\(|run\(|exec\(|spawn\(|shell=True/i],
  ["NOTIFY", /telegram|send_message|webhook|smtp|notification/i],
];
const files = readdirSync(root).filter((name) => statSync(join(root, name)).isFile()).sort();
const rows = [];
for (const name of files) {
  const path = join(root, name);
  const bytes = readFileSync(path);
  const hash = createHash("sha256").update(bytes).digest("hex");
  const text = bytes.toString("utf8");
  const lines = text.split(/\r?\n/);
  for (const [index, line] of lines.entries()) {
    const tags = rules.filter(([, pattern]) => pattern.test(line)).map(([tag]) => tag);
    if (tags.length) rows.push({ name, hash, line: index + 1, tags: tags.join(","), text: line.trim().replaceAll("|", "\\|").slice(0, 220) });
  }
}
const uniqueFiles = [...new Set(rows.map((row) => row.name))];
const output = ["# Omni Source Line Flags — Static Inventory", "", `Generated from ${files.length} top-level upload files; ${uniqueFiles.length} files contain at least one flagged line.`, "", "> This is lexical triage, not execution tracing. A flagged token requires human/formula review; no source was imported or executed.", "", "| File | SHA-256 | Line | Tags | Static line excerpt |", "|---|---|---:|---|---|"];
for (const row of rows) output.push(`| \`${row.name}\` | \`${row.hash}\` | ${row.line} | ${row.tags} | ${row.text} |`);
writeFileSync(out, `${output.join("\n")}\n`);
console.log(`wrote ${out}: ${files.length} files, ${rows.length} flagged lines`);
