import { runCanonicalReplayBacktest } from "../server/paperReplayBacktest";
console.log(JSON.stringify(runCanonicalReplayBacktest(), null, 2));
