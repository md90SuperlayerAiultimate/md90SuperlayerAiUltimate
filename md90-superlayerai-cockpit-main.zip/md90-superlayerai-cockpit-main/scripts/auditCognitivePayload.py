from __future__ import annotations
import hashlib, json, re, sys
from pathlib import Path

path = Path(sys.argv[1] if len(sys.argv) > 1 else "/home/ubuntu/upload/pasted_content.txt")
raw = path.read_bytes()
text = raw.decode("utf-8", errors="replace")
lines = text.splitlines()

def line_hits(pattern: str):
    rx = re.compile(pattern, re.I)
    return [i + 1 for i, line in enumerate(lines) if rx.search(line)]

def unique_urls():
    return sorted(set(re.findall(r"https?://[^\s)`]+", text)))

sections = []
for i, line in enumerate(lines, 1):
    if re.search(r"^(BAGIAN|[A-Z]\.|[0-9]+\.[0-9]+|FASE|PHASE|ROADMAP|ACTION PLAN|TARGET|KESIMPULAN|CONCLUSION)", line.strip(), re.I):
        sections.append({"line": i, "title": line.strip()})

code_fences = len(re.findall(r"^```", text, re.M)) // 2
order_lines = line_hits(r"create_(?:market|limit|stop)_order|market order|limit order|place_order|submit|order routing|TWAP|VWAP|live execution|execution agent")
custody_lines = line_hits(r"private.?key|seed|wallet|signing|withdraw|deposit|custody|transfer")
network_lines = line_hits(r"https?://|wss?://|websocket|redis|socket\.io|MCP|API")
claim_lines = line_hits(r"real.?time|near.?zero latency|< ?500ms|institutional|ready.?to.?use|production.?ready|9/10|10/10|60.?65%|Sharpe|monthly return|win rate")
mock_lines = line_hits(r"mock|random score|placeholder|UI tanpa data|belum terintegrasi|belum dites|tidak ada implementasi|asumsikan|pseudocode")

result = {
    "path": str(path),
    "sha256": hashlib.sha256(raw).hexdigest(),
    "bytes": len(raw),
    "lines": len(lines),
    "codeFenceBlocks": code_fences,
    "sections": sections,
    "urls": unique_urls(),
    "counts": {"orderExecutionMarkers": len(order_lines), "custodyMarkers": len(custody_lines), "networkMarkers": len(network_lines), "claimMarkers": len(claim_lines), "mockOrGapMarkers": len(mock_lines)},
    "lineEvidence": {"orderExecution": order_lines, "custody": custody_lines, "network": network_lines, "claims": claim_lines, "mockOrGaps": mock_lines},
    "decisions": {
        "sourceClass": "DESIGN_BLUEPRINT_WITH_PSEUDOCODE",
        "safeIntegration": ["OHLCV normalization contract", "indicator formulas as evidence-only", "MTF alignment contract", "risk gate and sample-size policy", "audit/event schema"],
        "pendingEvidence": ["real-time provider feeds", "CryptoIZ private MCP access", "FRED/Alpha Vantage credentials", "return_series production backfill", "independent 210-trade ledger", "MetaEditor compile and broker-fill verification"],
        "disabled": ["live exchange orders", "wallet custody/signing", "withdrawal/deposit", "automated TWAP/SOR", "LLM probability as execution authority", "random/mock score in production"],
    },
}
print(json.dumps(result, ensure_ascii=False, indent=2))
