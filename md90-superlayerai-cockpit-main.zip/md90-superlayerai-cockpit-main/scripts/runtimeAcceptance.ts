import { runPersistedStrategyAdapterComparison } from "../server/strategyAdapterReplay";
import { buildAuditBundle, auditBundleCsv, auditBundleJson } from "../server/auditBundle";
import { writeFile } from "node:fs/promises";

const outputDir = "/home/ubuntu/md90_superlayerai/docs/audit";
const ingestionIds = [1, 2];

const comparison = await runPersistedStrategyAdapterComparison(1, {
  ingestionIds,
  trainBars: 240,
  testBars: 96,
  startingEquity: 100_000,
  feeBps: 10,
  slippageBps: 5,
});

const audit = await buildAuditBundle(1, {
  filter: { correlationId: undefined, from: undefined, to: undefined },
});

if (audit.status !== "READY") {
  throw new Error(`Audit bundle unavailable: ${audit.status}`);
}

await writeFile(`${outputDir}/md90-audit-bundle-${audit.bundle.signature.slice(0, 12)}.json`, auditBundleJson(audit.bundle));
await writeFile(`${outputDir}/md90-audit-bundle-${audit.bundle.signature.slice(0, 12)}.csv`, auditBundleCsv(audit.bundle));
await writeFile(`${outputDir}/runtime_acceptance_2026-08-26.json`, JSON.stringify({
  generatedAt: new Date().toISOString(),
  manifestIds: ingestionIds,
  comparison,
  audit: {
    signature: audit.bundle.signature,
    filter: audit.bundle.filter,
    authority: audit.bundle.authority,
    orderRoute: audit.bundle.orderRoute,
    jsonBytes: Buffer.byteLength(auditBundleJson(audit.bundle)),
    csvBytes: Buffer.byteLength(auditBundleCsv(audit.bundle)),
  },
}, null, 2));

console.log(JSON.stringify({
  comparison: {
    status: comparison.status,
    authority: comparison.authority,
    orderRoute: comparison.orderRoute,
    results: comparison.results.map((result) => ({
      ingestionId: result.ingestionId,
      status: result.status,
      symbol: "symbol" in result ? result.symbol : undefined,
      barCount: "manifest" in result && result.manifest ? result.manifest.barCount : undefined,
      coverageClass: "coverageClass" in result ? result.coverageClass : undefined,
      evidenceState: "evidenceState" in result ? result.evidenceState : undefined,
      adapters: "attribution" in result ? result.attribution : undefined,
      reason: "reason" in result ? result.reason : undefined,
    })),
  },
  audit: {
    signature: audit.bundle.signature,
    authority: audit.bundle.authority,
    orderRoute: audit.bundle.orderRoute,
    jsonBytes: Buffer.byteLength(auditBundleJson(audit.bundle)),
    csvBytes: Buffer.byteLength(auditBundleCsv(audit.bundle)),
  },
}, null, 2));
process.exit(0);
