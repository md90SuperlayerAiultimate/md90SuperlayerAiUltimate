from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

BASE = Path('/home/ubuntu/md90_superlayerai')
LEDGER = BASE / 'docs/audit/OMNI_ARTIFACT_STATIC_LEDGER_2026-08-27.json'
OUT = BASE / 'docs/audit/OMNI_SOURCE_MATRIX_2026-08-27.md'


def status(item: dict) -> tuple[str, str, str]:
    path = item['path'].lower()
    caps = set(item.get('capabilities', []))
    flags = item.get('riskFlags', {})
    if item.get('emptyOrBinary') or item.get('lineCount') is None:
        return 'STATIC_PARSED', 'Artifact metadata/checksum only', 'PENDING_EVIDENCE'
    if 'network' in caps or 'custody' in caps or 'order_execution' in caps:
        if any(token in path for token in ('server/', 'shared/', 'client/src/')) and any(token in path for token in ('boundary', 'policy', 'adapter', 'contract', 'audit', 'risk', 'router', 'persistence')):
            return 'RUNTIME_MAPPED', 'Canonical protected contract / adapter / audit surface', 'DISABLED_OR_PAPER_ONLY'
        return 'STATIC_PARSED', 'Reference capability; isolated review required', 'DISABLED'
    if 'test' in caps:
        return 'RUNTIME_MAPPED', 'Regression evidence', 'TEST_ONLY'
    if path.startswith(str(BASE).lower()):
        return 'RUNTIME_MAPPED', 'md90 canonical application surface', 'PAPER_SHADOW_ONLY'
    return 'STATIC_PARSED', 'External/reference workspace artifact', 'PENDING_EVIDENCE'


def main() -> None:
    data = json.loads(LEDGER.read_text(encoding='utf-8'))
    rows = []
    counts = Counter()
    category_counts = Counter()
    for item in data['workspaceFiles']:
        st, target, authority = status(item)
        counts[st] += 1
        for cap in item.get('capabilities', []):
            category_counts[(cap, st)] += 1
        rows.append((st, authority, item['filename'], item['path'], item['sha256'][:16], ', '.join(item.get('capabilities', [])), target))
    rows.sort(key=lambda row: (row[0], row[2].lower()))
    md = [
        '# Omni-source integration matrix — 2026-08-27',
        '',
        '> Generated from the static SHA-256 ledger. This matrix is a routing and evidence decision aid; it does not execute uploaded code and does not grant live or custody authority.',
        '',
        '## Closure summary',
        '',
        f"Scanned workspace files: **{len(rows)}**. Archive members: **{data['archives'][0]['filename'] if data['archives'] else 'none'} / {sum(len(a['members']) for a in data['archives']) if data['archives'] else 0} members**.",
        '',
        '| Status | Files |', '|---|---:|',
    ]
    md += [f'| `{k}` | {v} |' for k, v in sorted(counts.items())]
    md += ['', '## Decision rules', '', '| Condition | Canonical action |', '|---|---|', '| Pure logic/indicator/risk with route + tests | Map to shared canonical module or isolated PAPER adapter. |', '| Network/order/custody/automation signal in external artifact | Keep static/reference; require contract, permission, privacy, and failure tests; authority remains DISABLED. |', '| Binary/archive or metadata-only item | Record checksum/member metadata; do not infer source behavior. |', '| Test/fixture | Treat as regression evidence only; never as market-performance evidence. |', '| Missing expected vector/provider/license/operator payload | `PENDING_EVIDENCE`; no synthetic replacement. |', '', '## Capability status cross-tab', '', '| Capability | Static parsed | Runtime mapped |', '|---|---:|---:|']
    caps = sorted({cap for cap, _ in category_counts})
    for cap in caps:
        md.append(f'| `{cap}` | {category_counts[(cap, "STATIC_PARSED")]} | {category_counts[(cap, "RUNTIME_MAPPED")]} |')
    md += ['', '## Per-file routing matrix', '', '| Status | Authority | File | Path | SHA-256 | Signals | Canonical target/decision |', '|---|---|---|---|---|---|---|']
    for st, authority, filename, path, digest, signals, target in rows:
        safe_path = path.replace('|', '\\|')
        md.append(f'| `{st}` | `{authority}` | `{filename}` | `{safe_path}` | `{digest}` | {signals or "—"} | {target} |')
    md += ['', '## Honest boundary', '', 'The matrix records what can be statically established from bytes and source text. It does not certify strategy profitability, licensing sufficiency, provider truth, or live readiness. Those require independent evidence, legal review, reproducible replay, and explicit approval gates.']
    OUT.write_text('\n'.join(md) + '\n', encoding='utf-8')
    print(json.dumps({'rows': len(rows), 'statusCounts': counts, 'output': str(OUT)}, default=dict, indent=2))


if __name__ == '__main__':
    main()
