from pathlib import Path
import re, json, hashlib

path = Path('/home/ubuntu/upload/pasted_content.txt')
text = path.read_text(errors='replace')
lines = text.splitlines()

# Exclude language keywords, types, and common built-ins from unresolved function candidates.
keywords = set('if else for while switch case return void int double bool string datetime struct enum input group true false NULL OnInit OnDeinit OnTick OnTimer'.split())
definitions = {}
for n, line in enumerate(lines, 1):
    m = re.search(r'^\s*(?:bool|void|int|double|string|datetime|ENUM_[A-Z_]+)\s+([A-Za-z_]\w*)\s*\(', line)
    if m:
        definitions.setdefault(m.group(1), []).append(n)

calls = {}
for n, line in enumerate(lines, 1):
    for m in re.finditer(r'\b([A-Za-z_]\w*)\s*\(', line):
        name = m.group(1)
        if name not in keywords:
            calls.setdefault(name, []).append(n)

unresolved = {name: rows for name, rows in calls.items() if name not in definitions and name not in {
    'Print','Alert','EnumToString','ArraySize','ArraySetAsSeries','IndicatorRelease','ObjectsDeleteAll',
    'iTime','iRSI','iStochastic','iMA','iMACD','iATR','CopyBuffer','NormalizeDouble','MathAbs','MathMax','MathMin',
    'AccountInfoDouble','EventSetTimer','EventKillTimer','PositionGetInteger','PositionGetDouble','PositionGetString',
    'PositionsTotal','PositionSelectByTicket','PositionGetTicket','HistorySelect','HistoryDealsTotal','HistoryDealGetTicket',
    'HistoryDealGetInteger','HistoryDealGetDouble','StringFormat','TimeToString','TimeCurrent','TimeDay','TimeHour',
    'TimeMinute','TimeToStruct','StructToTime','StringSubstr','StringLen','StringFind','StringToUpper','StringTrimLeft',
    'StringTrimRight','MathSqrt','MathPow','MathLog','MathExp','MathTan','MathArctan','MathMax','MathMin','SymbolInfoDouble',
    'SymbolInfoInteger','SymbolInfoTick','CopyRates','CopyTicks','ArrayResize','ArrayFree','ArrayInitialize','ArraySort',
    'ObjectCreate','ObjectSetInteger','ObjectSetDouble','ObjectSetString','ObjectDelete','ObjectFind','ChartRedraw',
    'Comment','SendNotification','SendMail','NormalizeDouble','GetLastError','ResetLastError'
}}

patterns = {
    'order_calls': r'\btrade\.(Buy|Sell|PositionClose|PositionModify)\s*\(',
    'position_management': r'\b(ManagePositions|ProcessSignal|PositionsTotal|PositionSelect)\b',
    'timer_events': r'\b(EventSetTimer|OnTimer|EventKillTimer)\b',
    'indicator_handles': r'\b(handle[A-Za-z_]*)\b',
    'daily_pnl': r'\b(dailyProfit|dailyLoss|HistoryDeal|DEAL_PROFIT)\b',
    'time_stop': r'\b(Time_Stop|TimeStop|Inp_Time_Stop_Bars|barsHeld)\b',
    'partial_or_scale': r'partial|scale.?out|PositionClosePartial',
    'placeholder': r'\.\.\.|TODO|FIXME|placeholder|stub|simplif',
}
out = {
    'file': str(path),
    'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
    'lineCount': len(lines),
    'definedFunctions': definitions,
    'unresolvedCandidateCalls': unresolved,
    'patternMatches': {},
}
for key, pattern in patterns.items():
    hits = [n for n, line in enumerate(lines, 1) if re.search(pattern, line, re.I)]
    out['patternMatches'][key] = {'count': len(hits), 'lines': hits[:80]}
print(json.dumps(out, indent=2))
