import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";

const inputs = [
  ["EURUSD", "/home/ubuntu/official-data/eurusd_2026-06-01_2026-07-15.csv.csv"],
  ["XAUUSD", "/home/ubuntu/official-data/xauusd_2026-06-01_2026-07-15.csv.csv"],
];
const manifest = [];
for (const [symbol, path] of inputs) {
  const bytes = readFileSync(path);
  const hash = createHash("sha256").update(bytes).digest("hex");
  const lines = bytes.toString("utf8").trim().split(/\r?\n/);
  const header = lines.shift();
  const rows = lines.map((line) => {
    const [timestamp, open, high, low, close, volume] = line.split(",").map((v) => Number(v.trim()));
    return { timestamp, open, high, low, close, volume };
  });
  const valid = rows.every((row) => Number.isFinite(row.timestamp) && [row.open, row.high, row.low, row.close, row.volume].every(Number.isFinite) && row.high >= Math.max(row.open, row.close, row.low) && row.low <= Math.min(row.open, row.close, row.high));
  const diffs = rows.slice(1).map((row, index) => row.timestamp - rows[index].timestamp);
  const intervalMs = 15 * 60 * 1000;
  const exactIntervals = diffs.filter((diff) => diff === intervalMs).length;
  const start = new Date(rows[0].timestamp).toISOString();
  const end = new Date(rows.at(-1).timestamp).toISOString();
  manifest.push({ symbol, path, header, barCount: rows.length, start, end, spanDays: (rows.at(-1).timestamp - rows[0].timestamp) / 86_400_000, validOhlcv: valid, exact15mRatio: diffs.length ? exactIntervals / diffs.length : 0, sha256: hash });
}
const output = ["# Official Dukascopy OHLCV Validation Manifest", "", "> Source: Dukascopy historical data feed via dukascopy-node 1.50.0. This report contains real downloaded files; no synthetic or crypto fallback was used.", "", "| Symbol | Bars | UTC start | UTC end | Span days | OHLCV valid | Exact 15m ratio | SHA-256 |", "|---|---:|---|---|---:|---|---:|---|"];
for (const item of manifest) output.push(`| ${item.symbol} | ${item.barCount} | ${item.start} | ${item.end} | ${item.spanDays.toFixed(2)} | ${item.validOhlcv ? "YES" : "NO"} | ${(item.exact15mRatio * 100).toFixed(2)}% | \`${item.sha256}\` |`);
writeFileSync("/home/ubuntu/md90_superlayerai/docs/audit/OFFICIAL_DUKASCOPY_LONG_MANIFEST_2026-08-26.md", `${output.join("\n")}\n`);
console.log(JSON.stringify(manifest, null, 2));
