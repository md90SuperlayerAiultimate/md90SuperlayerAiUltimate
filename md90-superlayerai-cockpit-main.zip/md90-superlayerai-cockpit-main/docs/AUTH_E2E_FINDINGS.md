# Authenticated E2E Findings

## Overview production/preview

Authenticated session is active as `marseto80@gmail.com`. Overview exposes PAPER/SHADOW/LIVE state, live locked, canonical 15m base/4h HTF lineage, candlestick chart, order tape, risk gate, demo ledger, shadow/news panels, and 808 demo transactions at the latest observation. The evidence is read-only except for the explicit PAPER batch action.

## Protected audit

`/authenticated-audit` on preview shows `SESSION AUTHENTICATED`, `PAPER READ / WRITE`, `SHADOW REFRESHED`, `NEWS REFRESHED`, base timeframe `15m`, `News items 3`, and `Order route DISABLED`. It explicitly rejects API keys, seed phrases, private keys, signing, deposits, withdrawals, and network orders.

## Important distinction

The latest production route remains protected and the authenticated session is valid. The protected verifier is the canonical evidence for user-scope paper/shadow/news procedure results; the next checks cover Management, Research Desk, and Signal Room surface access and their visible safety states.

## Main dashboard surfaces

Overview authenticated displays paper/shadow/live mode, 15m base and 4h HTF lineage, candlestick chart, order tape, risk gate, demo ledger, strategy contract, shadow/news panels, and live-disabled language. Management authenticated displays persistent demo ledger, 816 trades, 65.56% measured win rate, equity 100040.57, drawdown 0.01%, scheduler ACTIVE, read-only credential staging, and order route DISABLED. No credential was entered during verification.

## Research Desk

Authenticated Research Desk is accessible and shows PAPER/SHADOW ONLY with LIVE ROUTE DISABLED, canonical paper ledger, demo win rate, shadow observations, news freshness alert, scanner registry, provider-session-required external sources, synced 15m/4h TradingView research lineage, LQ Magnet freshness, pending DOM/Gamma/COT sources, risk state, and no network orders.

## Signal Room

Authenticated Signal Room is accessible and shows BTC/USDT LONG with composite 84 and confidence 76%, synced 15m/4h timeframe, Matari + Fusion contract parameters, PAPER ENABLED, SHADOW OBSERVE_ONLY, LIVE DISABLED, immutable paper fill, Survivor Mode 0.50% risk and 3.00% exposure cap, paper-only approval lock, and an explicit LIVE BLOCKED event.

## Direct surface scope closure

`AuthenticatedScopeBadge` is now wired into Overview, Management, Research Desk, and Signal Room. It reads `auth.me` and, only when authenticated, executes the canonical paper overview, shadow observations, and intelligence news queries. Its visible state is AUTHENTICATED with paper READ / WRITE, shadow REFRESHED, and news REFRESHED, or CHECKING/ERROR/DEMO SESSION when evidence is incomplete. This makes user-scope and refresh evidence visible on each main surface rather than only on the protected verifier.

Management now also has an ID/EN language control with translated identity-facing header, hero copy, and paper batch action. A route-level contract test covers badge wiring and language controls for all four institutional surfaces; AuthenticatedAudit retains the dedicated bilingual safety/persistence copy test.

## Bilingual coverage

Signal Room language toggle changed from `ID` to `EN` in the authenticated session. The primary headings and safety copy rendered in English, including “Evidence before conviction”, “Risk gate”, “Paper-only policy”, and “No network order path is enabled”. The canonical timeframe and live-lock states remained unchanged across the toggle. Overview and Management expose the same language toggle control; Research Desk also exposes the ID/EN control. This confirms the critical authenticated Signal Room bilingual path; route-level bilingual coverage is now documented by the shared contract test and Management language control addition.
