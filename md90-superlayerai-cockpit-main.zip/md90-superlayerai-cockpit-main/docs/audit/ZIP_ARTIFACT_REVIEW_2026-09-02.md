# ZIP Artifact Review — 2026-09-02

## Scope and method

The uploaded archive `md90_superlayerai_fixed.zip` was inspected read-only. The archive SHA-256 and file inventory were recorded outside the application workspace. No Python, Pine, MQL5, shell script, executable, or dependency artifact from the archive was executed.

## Findings

| Evidence class | Result | Decision |
|---|---|---|
| Pine source (`.pine`, `.pinescript`) | No files found. Textual signatures only occur in audit documentation and historical notes. | `EVIDENCE_REQUIRED` |
| MQL4/MQL5 source (`.mq4`, `.mq5`, `.ex4`, `.ex5`) | No files found. The archive contains readiness reports describing earlier snapshots, not source bytes. | `EVIDENCE_REQUIRED` |
| Python strategy/runtime source | Python files are audit utilities and project scripts inside the archive; they are not accepted as certified expected-vector artifacts without an explicit source checksum, line range, and numeric fixture contract. | `REVIEW` |
| FX/XAU candle dataset | No CSV/TSV/Parquet/NDJSON candle dataset was found. The two tabular files are audit/export bundles, not OHLCV series. | `EVIDENCE_REQUIRED` |
| Dukascopy manifest | Documentation records EURUSD/XAUUSD checksums and coverage, but the corresponding data bytes are absent from the uploaded archive and current workspace. | `EVIDENCE_REQUIRED` |

## Parity verdict

No new real source artifact was available to bind into `audit_parity_vectors`. Therefore the application must not emit `MATCH` or `MISMATCH` from this ZIP. The correct current state is `EVIDENCE_REQUIRED` until the operator uploads the original Pine/MQL5/Python file or a signed numeric fixture with SHA-256, source line range, formula version, symbol, timeframe, and expected vector.

## Implemented intake uplift

The manual FX/XAU intake now accepts all nine canonical intervals: `1m`, `3m`, `5m`, `15m`, `30m`, `1h`, `4h`, `1d`, and `1M`. Monthly candles require explicit close timestamps because calendar months do not have a fixed millisecond duration. A protected batch contract accepts exactly one payload per canonical interval and persists each validated series through the existing user-scoped storage/checksum/idempotency path. All external data remains `SHADOW_EXTERNAL` with `orderRoute=DISABLED`.

## Operator action required

Upload the actual source/data bytes, not only a report or filename. For nine-timeframe replay, provide one validated OHLCV payload for each canonical interval per instrument, with source provenance and checksum. For parity, provide the original artifact or official expected-vector fixture; otherwise the system remains fail-closed by design.

## References

[1]: https://www.dukascopy.com/swiss/english/marketwatch/historical/ "Dukascopy Historical Data Export"
[2]: https://www.dukascopy.com/swiss/english/fx-market-tools/historical-data/ "Dukascopy Historical Data Tool"
