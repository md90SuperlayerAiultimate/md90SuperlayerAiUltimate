# Omni Source Runtime Trace Matrix

> Setiap baris membedakan **source finding** dari **runtime implementation**. “Mapped” bukan berarti source dieksekusi atau di-copy; ia berarti ada kontrak md90 yang secara eksplisit mengadopsi subset aman atau memblokir action tersebut.

| Finding group | Runtime module | tRPC / persistence | Operator surface | Regression proof | Status |
|---|---|---|---|---|---|
| DataProvider pure indicators | `shared/artifactParity.ts` | `server/paperEngine.ts` emits `artifactParity` in canonical PAPER snapshot. | Risk Lab `Canonical indicator audit`. | `artifactParity.test.ts`; Workbench contract. | **IMPLEMENTED / READ_ONLY** |
| Fusion weights / five gates | `artifactParity.ts` weighted buy/sell diagnostic. | Snapshot only; not an input that mutates `paper.decide`. | Risk Lab FUSION shows diagnostic weighted score. | `artifactParity.test.ts`. | **IMPLEMENTED WITH SAFETY DIVERGENCE** |
| Regime/session/circuit evidence | `protectivePolicy.ts`, `artifactTradeProposal.ts`. | `paperEngine.ts` produces advisory protection/proposal. | Risk Lab protective and proposal rows. | Protective/proposal unit tests. | **IMPLEMENTED / ADVISORY_ONLY** |
| MQL time-stop candidate | `paperPositionClock.ts`, `paperPersistence.ts`. | `paper.timeStop` protected query reads durable user position. | Risk Lab time-stop row; close remains separate operator command. | Clock/persistence/authenticated router tests. | **IMPLEMENTED / ADVISORY_ONLY** |
| FX/XAU export | `manualDataset.ts`, `datasetCoverage.ts`, `datasetPersistence.ts`. | `datasets.ingestManual`; raw payload to object storage, manifest to DB. | Market Map upload/coverage panel. | Normalizer/coverage/persistence/router tests. | **IMPLEMENTED / SHADOW_EXTERNAL** |
| Bayesian/statistical learning | `learningEvidence.ts`. | `paper.learning` reads only user-scoped journal rows. | Audit Log learning/OOS card. | Learning and authenticated-router tests. | **IMPLEMENTED / PROPOSAL_ONLY** |
| Polymarket/executor/CTrade order paths | `artifactBoundary.ts`. | No external order procedure exists; `paper.close` is PAPER replay only. | Risk Lab outbound locks. | Boundary test and Workbench no-order contract. | **BLOCKED** |
| Webhook/Telegram/Qdrant/graph ingress/egress | `artifactBoundary.ts`. | No webhook command/connector mutation route. | Risk Lab outbound locks; Audit Log lineage. | Boundary test. | **BLOCKED** |
| Auto tuner/config/GitHub promotion | `artifactBoundary.ts`, `learningEvidence.ts`. | No tuning/promotion/mutable release mutation. | Audit Log explicitly says promotion disabled. | Learning/boundary/Workbench tests. | **BLOCKED** |
| HMM online model | No active model import. | No fit/predict/promote route. | Regime is labelled deterministic evidence only. | Evidence/policy tests. | **PENDING_EVIDENCE** |
| Atomic audit registry | `shared/auditMatrix.ts` | `audit.matrix` protected query returns typed findings and filters. | `/audit-matrix` with status/classification/artifact/checksum/search filters. | `shared/auditMatrix.test.ts`; route/build validation. | **IMPLEMENTED / READ_ONLY** |
| Numeric indicator parity vector | `shared/numericParity.ts` | `audit.parityVector` protected query accepts provenance/checksum and source expected values. | Audit/research workflow can inspect per-indicator delta; no promotion. | `shared/numericParity.test.ts`; `server/auditParityRouter.test.ts`. | **IMPLEMENTED / OOS_PENDING** |
| Dataset coverage review state | `shared/datasetCoverage.ts`, `server/datasetPersistence.ts` | Migration 0012 persists `coverageClass` and `evidenceState`; raw candles remain object-storage only. | Market Map manifest coverage and limitation state. | `datasetCoverage.test.ts`, persistence/router suite. | **IMPLEMENTED / EVIDENCE_BOUND** |

## Boundary verification

The active `paperEngine.ts` constructs the auditable snapshot chain: `analyzeArtifactParity` → `evaluateProtectivePolicy` → `proposePaperTrade` → `artifactOutboundBoundaries`. `routers.ts` exposes protected `paper.timeStop`, `paper.learning`, `audit.matrix`, and `audit.parityVector`; `datasetPersistence.ts` stores only dataset manifest metadata plus durable coverage/review state. The UI binds this state through Workbench and `/audit-matrix`, and regression tests cover safety and user scope.

This trace matrix therefore closes the **mapping** pass for the currently inventoried finding groups. A previous recovery to checkpoint `445ad798` temporarily removed uncheckpointed Audit Matrix files; they have now been reconstructed, typechecked, and covered by the tests listed above. The recovery was not treated as proof of feature continuity until this validation passed. It does not claim that every source formula has numeric parity; formula-level candidates remain controlled by explicit test vectors and evidence gates.
