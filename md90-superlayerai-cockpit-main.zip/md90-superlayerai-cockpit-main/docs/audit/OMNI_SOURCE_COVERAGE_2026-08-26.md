# Omni Source Coverage Ledger — 26 August 2026

## Purpose

Laporan ini menjelaskan perbedaan antara **jumlah file yang pernah dikirim**, **jumlah entry yang tercatat dalam register**, dan **jumlah artefak yang dapat disebut runtime-validated**. Ketiganya bukan metrik yang sama. Satu ZIP dapat memuat banyak file, satu file dapat memiliki banyak line findings, dan satu repo GitHub dapat hanya memiliki metadata tanpa source yang dieksekusi.

## Baseline yang dapat dihitung ulang

| Scope | Count | Status | Interpretation |
|---|---:|---|---|
| Active runtime tree (`client`, `server`, `shared`, `drizzle`) | 262 files | Parsed by project tree | File aplikasi aktif; bukan semua source upload historis. |
| Vitest files | 60 files | Executed | Test files yang masuk suite aktif. |
| Project audit/docs files | 30 files | Parsed | Laporan, register, manifests, dan validation notes. |
| Artifact checksum register rows | 52 rows | Checksum-registered | Entry checksum yang tercatat pada checksum text register; bukan jumlah semua file ZIP. |
| GitHub repository register rows | 102 rows | Metadata/reference | 78 metadata rows tersedia; 24 unresolved pada register sebelumnya. Metadata bukan runtime integration. |
| Atomic audit findings | 18 findings | Static/runtime mapped | Temuan capability/side-effect, bukan file count. |
| Line-flag table rows | 995 table lines | Static lexical flags | Flag lexical; bukan verdict function-level dan bukan bukti eksekusi. |
| Open implementation items at start of this pass | 8 items | Work in progress | Scope baru: coverage, manifest selection, vectors, adapter report, handoff, tests, acceptance. |

## Classification contract

| Classification | Meaning |
|---|---|
| `PARSED` | File/entry dapat dibaca dan bentuknya dikenali. |
| `CHECKSUM_REGISTERED` | File memiliki SHA-256 yang tercatat; checksum tidak membuktikan keamanan atau runtime correctness. |
| `VALIDATED` | Struktur/data melewati validator dan bukti test yang sesuai. |
| `RUNTIME_MAPPED` | Temuan memiliki binding ke module aktif, route, UI, dan/atau test. |
| `REFERENCE_ONLY` | Source dipakai sebagai referensi desain/logic, tidak diimport atau dieksekusi. |
| `PENDING_EVIDENCE` | Diperlukan artifact vector, provider response, license/source, atau replay operator sebelum verdict lebih tinggi. |
| `BLOCKED` | Capability sengaja dikunci karena live order, custody, signing, outbound command, atau mutable promotion. |

## Honest explanation of the 67 figure

Angka **67** tidak boleh dipresentasikan sebagai “67 dari seluruh kiriman telah selesai” tanpa denominator yang jelas. Pada baseline ini, angka 67 dapat merujuk ke subset entry yang sebelumnya berhasil dipetakan atau diverifikasi dalam satu batch; ia bukan count universal untuk seluruh file, ZIP, repo, dan line-level finding. Denominator yang dapat diverifikasi dari workspace sekarang berbeda: 52 checksum rows, 102 GitHub register rows, 18 atomic findings, dan 995 line-flag table lines. Jika pengguna memiliki arsip atau upload yang tidak berada di workspace project, file tersebut tidak boleh diberi status parsed/validated hanya berdasarkan pernyataan historis.

## Coverage policy

Sebuah artefak baru hanya naik ke `RUNTIME_MAPPED` apabila memiliki filename/archive context, SHA-256, line/surface range, classification, runtime decision, direct proof, dan bila diadaptasi—test serta UI binding. File yang hanya memiliki nama, ringkasan, atau klaim “sudah diverifikasi” tetap `PENDING_EVIDENCE` sampai payload tersedia dan dapat dihitung ulang.

## This pass

Perbaikan berikut menghapus ambiguitas operasional: operator dapat memilih manifest persisted EURUSD/XAUUSD, menjalankan comparison adapter dengan dataset yang sama, memuat expected vector Pine/MQL5 yang artifact-bound, membaca verdict parity per indikator, dan mengekspor audit bundle JSON/CSV dengan filter serta signature. Semua output tetap `PAPER_ONLY` / `DISABLED`; tidak ada live route atau synthetic evidence.

## Acceptance update — 26 August 2026

The manifest picker now exposes persisted EURUSD/XAUUSD rows with bar count, coverage class, status, and checksum prefix, and sends only the operator-selected IDs to the protected adapter comparison route. The artifact parser now refuses unrelated numbers from calls such as `rsi(14)` or `plot(macdHistogram, 12, 26, 9)` unless a vector literal assignment/value is present. Signed JSON/CSV handoff now displays filename, filter summary, SHA-256 signature, credential-redaction status, and `DISABLED` order route after download.

Validation completed: 60 Vitest files and 158 tests passed; TypeScript and production build passed; dev runtime remained healthy; desktop and mobile Overview/Replay visual captures passed. Actual `MATCH` or `MISMATCH` remains dependent on a real uploaded Pine/MQL5/Python artifact and its checksum-bound expected literals; no values were fabricated.

## No-browser acceptance boundary

Pada pass ini acceptance interaktif deployment tidak dijalankan karena operator meminta workflow tanpa browser. Sebagai pengganti yang dapat diulang, server-side protected contract memverifikasi user scope dan authority untuk adapter comparison, parser test memverifikasi assignment-only extraction, dan local validation memverifikasi build serta visual surface. Pemilihan manifest nyata, upload file artefak nyata, dan pengunduhan blob signed dari sesi operator tetap merupakan langkah runtime yang belum dapat dipalsukan oleh test statis.

## Runtime evidence acceptance — 26 August 2026

Manifest persisted operator yang benar-benar tersedia dan dipakai adalah EURUSD `ingestionId=1` (3,072 bar, LONG, READY, checksum prefix `ddb52201c4fd816fbad837d4`) dan XAUUSD `ingestionId=2` (2,912 bar, LONG, READY, checksum prefix `b52edf45bf2fee68690abb35`). Adapter comparison memakai train 240 bar, test 96 bar, fee 10 bps, dan slippage 5 bps. Hasil tidak dianggap sebagai janji performa: EURUSD FUSION V9-IMP memiliki 7 sample, 22 blocked windows, hit rate 14.29%, PnL -97.72, expectancy -13.96; Matari memiliki 15 sample, 14 blocked windows, hit rate 20%, PnL -164.21, expectancy -10.95. XAUUSD FUSION V9-IMP memiliki 4 sample, 23 blocked windows, hit rate 75%, PnL 89.33, expectancy 22.33; Matari memiliki 17 sample, 10 blocked windows, hit rate 41.18%, PnL -83.13, expectancy -4.89. Semua hasil berstatus PAPER_ONLY dengan order route DISABLED.

Signed audit handoff berhasil dibuat dalam JSON dan CSV dengan signature SHA-256 `e176dc27e17aca760f93eee7899ec0152d8480096ec372c7449e172dfcf3b95a`; authority `PAPER_SHADOW_ONLY`, order route `DISABLED`, ukuran JSON 100,803 byte dan CSV 108,133 byte. Expected vector MATCH/MISMATCH belum diklaim karena artefak Pine/MQL5 asli belum tersedia pada runtime acceptance ini.

## Omni-source archive reconciliation — 27 August 2026

Audit statis diperluas ke tiga archive fisik: `md90_refactor_v1.zip`, `md90_FINAL_VERIFIED.zip`, dan `md90_ultimate_fusion_v4_FINAL_ARB.zip`. Ketiganya berisi total **322 member**; inventory workspace menghasilkan **552 file** dan **93 file Python** (termasuk payload workspace/expanded content), dengan 92 bytecode `.pyc` yang diperlakukan sebagai binary/reference, bukan source evidence. Ketiga archive tidak memiliki member berakhiran `.pine`, `.pinescript`, `.mq4`, `.mq5`, `.mql4`, `.mql5`, `.ex4`, atau `.ex5`.

Dengan demikian, istilah “EA/Pine yang dikirim” belum memiliki payload format Pine/MQL/EX yang dapat diparsing pada staging saat audit ini. Materi yang tersedia dapat diaudit sebagai Python source/reference dan diadaptasi hanya melalui isolated PAPER contract. Expected vector literal untuk parity Pine/MQL5 tidak boleh dinaikkan menjadi MATCH/MISMATCH sampai file asli atau fixture resmi tersedia. Hasil ini bukan penolakan terhadap materi yang pernah dikirim; ini adalah batas payload yang dapat dibuktikan secara fisik pada workspace saat ini.

## Python capability integration — 27 August 2026

Modul Python yang ditemukan telah dipetakan melalui static scanner berdasarkan indikator, risk, timeframe, network, custody, order-execution, automation, agent/memory, dan test signals. Integrasi runtime tidak dilakukan dengan `import` atau menjalankan archive. Sebagai gantinya, registry canonical kini memiliki `python-omni-reference-paper`, yaitu adapter `PYTHON` berstatus `REFERENCE_ONLY`, `PAPER_ONLY`, signal selalu `NEUTRAL`, dan blocked reason `PYTHON_SOURCE_REVIEW_ONLY`. Adapter ini membuat coverage Python terlihat di Strategy Lab tanpa memberi source upload kemampuan network, signing, custody, order, webhook, atau promotion.

Capability Python yang berisi pure risk/indicator/replay logic dapat diangkat lebih lanjut hanya setelah fungsi spesifik, fixture input/output, license/provenance, dan deterministic tests dipasangkan. Modul yang mengandung network, broker/exchange order, webhook, wallet/custody, agent memory, auto-tune, atau scheduler tetap reference/disabled sampai kontrak isolation dan evidence independen tersedia.

## Re-upload correction — 27 August 2026

`pasted_content.txt` kini bukan lagi payload Pine 127 baris. File yang tersedia saat audit terakhir adalah UTF-8 MQL5 `FUSION_PRO_ADVANCED_V1`, **1,497 lines / 47,366 bytes**, SHA-256 `f15dc7188f647a62fe1790673de977c66875ba0e898bd854b31f9e2e0af97c2c`. Static scan menemukan tiga order-capable call sites, tujuh position/execution references, timer satu detik, dan 56 input declarations; tidak ditemukan pola network atau credential. Payload diklasifikasikan `MQL5 / PENDING_VECTOR / PAPER_ONLY`, bukan Pine, dan tidak dieksekusi.

Attachment path yang sama dapat berubah ketika user re-upload; karena itu checksum terbaru menjadi identitas artifact yang benar. Hash lama tidak boleh dipakai untuk parity. Enam attachment kini memiliki provenance terpisah berdasarkan SHA-256 aktual; sinyal XAU/USD tetap `PAPER_ABORT / NO_ORDER`.

## FUSION_PRO_ADVANCED rerun — 27 August 2026

Rerun runner persisted memakai ingestion EURUSD `1` dan XAUUSD `2`, train 240 bar, test 96 bar, fee 10 bps, dan slippage 5 bps. Adapter baru `fusion-pro-advanced-paper` memakai checksum `f15dc7188f647a62fe1790673de977c66875ba0e898bd854b31f9e2e0af97c2c`, status `REFERENCE_ONLY`, authority `PAPER_ONLY`, dan order route `DISABLED`. Karena contract-nya menggunakan canonical FUSION evaluation dengan exit policy yang diekstrak dari payload MQL5, hasilnya tidak boleh dibaca sebagai hasil compile atau performa EA asli.

Pada EURUSD, adapter menghasilkan 7 sample, 22 blocked windows, hit rate 14.29%, realized PnL -97.72, expectancy -13.96, dengan blocker utama volume, RSI, stochastic, dan HTF. Pada XAUUSD, adapter menghasilkan 4 sample, 23 blocked windows, hit rate 75%, realized PnL 89.33, expectancy 22.33, dengan blocker utama volume, RSI, stochastic, EMA direction, dan HTF. Angka ini adalah replay PAPER dengan sampel kecil, bukan klaim win rate atau live readiness.

Signed bundle tetap memakai signature `e176dc27e17aca760f93eee7899ec0152d8480096ec372c7449e172dfcf3b95a`, JSON SHA-256 `7fcb329703477cc737fe2318e32c701480b5cf640e41e6c956855b6d3bcb2d82`, CSV SHA-256 `7cc24653b6a3be895feeae81feb55a97b368182c2786aaaa69b53a3c942adcf6`, dan runtime acceptance SHA-256 `88bb53efbbd0ff8b71612afd352429e8c81cc76d480265201abc112dd41b1d35`. No live order, broker call, wallet signing, or custody side effect occurred.
