# md90_superlayerAi — Canonical All-in-One Map

**Status dokumen:** canonical integration record, 27 August 2026. Dokumen ini menyatukan artefak yang tersedia ke satu vocabulary dan tidak menggantikan, menghapus, atau mengeksekusi source eksternal.

## Alur canonical

| Stage | Canonical surface | Evidence boundary | Output |
|---|---|---|---|
| Ingest | `server/datasetPersistence.ts`, dataset routes, persisted manifests | User-scoped manifest, checksum, timestamp, OHLC validation | Validated candle series |
| Normalize / coverage | `shared/dataCoverageAudit.ts`, `server/datasetReplay.ts` | Cadence, gaps, order, invalid OHLC, sample sufficiency | Coverage gate |
| Strategy / adapters | `shared/strategyAdapters.ts`, `shared/strategyAdapterReplay.ts`, shadow registries | PAPER/SHADOW and source provenance; external source is not executed | Signal candidate |
| Confluence / MTFA | `shared/operatingCockpit.ts`, timeframe context, Signal Room | Evidence and parity gates; missing vectors remain pending | Confluence state |
| Risk | `shared/institutionalRiskAnalytics.ts`, risk routes, Risk Lab | Volatility, correlation, risk parity, VaR/stress, fail-closed policy | Risk decision |
| PAPER execution | `server/paperBroker.ts`, `shared/forwardPaperSession.ts` | Fee, slippage, latency, partial fill, time stop; no network order | Simulated fill |
| Ledger | `server/paperPersistence.ts`, `server/forwardPaperPersistence.ts`, Drizzle schema | Session/order/fill/position/equity/journal lineage and idempotency | Persistent history |
| Attribution | `shared/forwardComparison.ts`, comparison route and journal | OOS boundary, sample size, PnL, win rate, expectancy, drawdown | Backtest-vs-forward report |
| Audit / handoff | Audit Matrix, authenticated audit, signed JSON/CSV | Correlation ID, checksum, signature, redaction, authority receipt | Evidence bundle |
| Primary UI | `client/src/pages/Home.tsx` and Signal Room | All-In-One cockpit; unavailable values display pending state | Operator surface |

## Preserved source inventory

The local project retains the existing code and documentation inventory. The available uploaded ZIP sources are `md90_FINAL_VERIFIED.zip` (143 members), `md90_ultimate_fusion_v4_FINAL_ARB.zip` (143 members), and `md90_refactor_v1.zip` (152 members). They are treated as reference artifacts only; no external source is imported into the runtime or executed. The active project baseline contains 65 test files, 50 documentation files, 80 server files, 50 shared files, and 103 client source files at the time of this record.

## Active routes

The All-in-One cockpit remains at `/`. The dedicated Signal Room remains at `/signal-room`; Research Desk, Management, Authenticated Audit, Audit Matrix, Workbench, Market Map, Risk Lab, Replay, Audit Log, and the 404 route remain registered in `client/src/App.tsx`. The root route intentionally remains the unified Overview cockpit because the product focus is All-in-One, not a detached signal-only application.

## UI integrity correction

Static fallback watchlist rows, layer scores, chart price labels, entry/SL/TP labels, R:R projection, and AI note claims were removed from the Overview where they could be mistaken for current evidence. When the canonical snapshot is absent, the interface now exposes `PENDING`, `NO VERIFIED SIGNAL`, or `No verified signal in the current canonical snapshot.` This preserves the full architecture while preventing demo values from masquerading as live or persisted results.

## Non-negotiable boundary

The canonical system is a research and PAPER/SHADOW operating cockpit. Live broker order submission, wallet signing, custody, withdrawal, and external execution remain disabled. Private CryptoIZ/Dynamic Execution feeds and source-vector parity remain evidence-gated until an operator supplies verifiable provider or artifact evidence. A passing test suite validates software behavior; it does not prove profitability, a 93% win rate, institutional readiness, or live trading performance.

## Verification record

The final local validation for this consolidation passed: 65 Vitest files and 177 tests, TypeScript compilation, production build, and visual captures of the main cockpit, Overview, and Audit Matrix. The inventory diff showed no deleted tracked files and all required core surfaces remained present.

## Final consolidation addendum

The root route remains the All-in-One Overview after rollback reconciliation. Signal Room remains a linked detail surface. Both surfaces now avoid hardcoded composite score, confidence, R:R, layer score, price-axis, entry/SL/TP, and AI-note outputs when canonical evidence is unavailable. The signal table explicitly reports when no verified signal exists. The Vitest configuration now allows 15 seconds for integration tests and hooks, addressing database contention observed during the full suite; standard `pnpm test` completed with 65 files and 177 tests passing. No source artifact, ZIP member, route, or tracked application file was deleted during this consolidation.

## Runtime execution-path addendum

The protected operating workflow now has an explicit handoff after source validation: persisted manifest → parity evaluation → protective risk gate → forward-paper session → OOS comparison → canonical session/ledger persistence → operating workflow events. The forward engine is not invoked on missing/mismatched parity or failed risk policy. All resulting execution authority remains `PAPER_ONLY` and `orderRoute` remains `DISABLED`. This is a runtime integration improvement, not evidence of live profitability.

The `/overview` alias was restored after visual validation found a real navigation 404. Root, Overview, Signal Room, Research Desk, and Risk Lab now resolve to valid surfaces.
