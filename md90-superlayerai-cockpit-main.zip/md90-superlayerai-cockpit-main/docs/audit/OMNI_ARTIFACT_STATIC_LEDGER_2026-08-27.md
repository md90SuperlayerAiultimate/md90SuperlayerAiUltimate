# Omni-source static artifact ledger — 2026-08-27

> Static read-only audit. No source file was imported, executed, or granted network/custody authority.

## Inventory summary

- Workspace files scanned: **552**
- Archives scanned: **3**
- Archive members scanned: **322**

| Extension | Files |
|---|---:|
| `.css` | 1 |
| `.csv` | 1 |
| `.example` | 1 |
| `.html` | 1 |
| `.js` | 1 |
| `.json` | 33 |
| `.log` | 4 |
| `.md` | 53 |
| `.mjs` | 2 |
| `.patch` | 1 |
| `.py` | 93 |
| `.pyc` | 92 |
| `.sh` | 4 |
| `.sql` | 16 |
| `.tag` | 1 |
| `.ts` | 151 |
| `.tsv` | 1 |
| `.tsx` | 78 |
| `.txt` | 5 |
| `.yaml` | 1 |
| `.yml` | 1 |
| `[none]` | 11 |

## Capability and risk signals

| Signal/category | File hits |
|---|---:|
| `agent_memory` | 11 |
| `automation` | 102 |
| `binary_or_archive` | 117 |
| `credentials` | 92 |
| `custody` | 178 |
| `data` | 44 |
| `indicators` | 238 |
| `network` | 63 |
| `order_execution` | 75 |
| `risk` | 175 |
| `risk_execution` | 23 |
| `signal` | 15 |
| `test` | 69 |
| `timeframe` | 137 |
| `ui` | 111 |
| `unclassified` | 31 |

## Status interpretation

| Status | Meaning |
|---|---|
| `STATIC_PARSED` | Bytes/text read, checksum and structural signals recorded. |
| `RUNTIME_MAPPED` | Capability has an explicit canonical module, route, test, and safety contract. |
| `PENDING_EVIDENCE` | Requires source/provider/license/fixture or operator evidence not present in the file itself. |
| `DISABLED` | Network order, custody, signing, withdrawal, or promotion authority is intentionally unavailable. |

The complete per-file ledger, including line counts, SHA-256, capabilities, and risk flag counts, is stored in the adjacent JSON file.
