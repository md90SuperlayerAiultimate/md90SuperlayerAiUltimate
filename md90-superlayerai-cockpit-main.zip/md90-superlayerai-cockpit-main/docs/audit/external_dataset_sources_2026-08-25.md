# External dataset sources — verified 25 August 2026

## Reset full-version verification

Pada 25 Agustus 2026, jalur public market data Binance kembali diverifikasi. Halaman koleksi data menampilkan kategori `futures`, `option`, dan `spot`, sehingga cocok sebagai kandidat artefak historical crypto yang harus di-download/manifest sebelum digunakan sebagai canonical replay. [1]

Halaman Historical Data Export Dukascopy menyatakan bahwa historical price data tersedia untuk berbagai instrumen, termasuk Forex, Commodities, dan Indices; layar instrumen menampilkan EUR/USD, USD/JPY, GBP/USD, serta XAU/USD. Jalur ini adalah kandidat untuk coverage FX/XAU, tetapi tidak dipromosikan menjadi runtime replay sebelum file, license/terms, checksum, normalisasi, dan scenario test tersedia. [2]

Pemeriksaan ulang pada halaman API/Tools Dukascopy mengonfirmasi navigasi Historical Data Export dan live chart EUR/USD/XAU/USD, tetapi dokumentasi API yang dapat diekstrak tidak menampilkan endpoint raw bar tanpa credential yang stabil. Karena itu, pipeline berikutnya akan menerima **file CSV/JSON yang telah diunduh dan diverifikasi** sebagai ingestion manual user-scoped; ia tidak akan menebak URL, melewati terms, atau membuat quote FX/XAU sintetis. [2] [3]

## References

[1] [Binance Data Collection](https://data.binance.vision/)

[2] [Dukascopy Historical Data Export](https://www.dukascopy.com/swiss/english/marketwatch/historical/)

[3] [Dukascopy Forex Data & Tools](https://www.dukascopy.com/swiss/english/fx-market-tools/historical-data/)

## Binance Data Collection

URL: https://data.binance.vision/

The public collection page exposes `data/spot/`, `data/futures/`, and `data/option/` prefixes. It links to the Binance public-data GitHub repository. This is suitable as a candidate source for timestamped crypto market data, but the project still needs an ingestion manifest, selected symbol/timeframe files, checksums, missing-bar policy, and a reproducible normalization step before a symbol is promoted from pending to evidence-backed replay.

## Dukascopy Historical Data Export

URL: https://www.dukascopy.com/swiss/english/marketwatch/historical/

The official page describes Historical Data Export for a variety of financial instruments, including Forex, Commodities, and Indices. The page also exposes links for FX market hours, trading breaks calendar, average spreads, and COT charts. For md90, this is a candidate source for EUR/USD and XAU/USD evidence, not an already integrated provider. Before promotion, the project must record exact download endpoint/file, timestamp/coverage, timezone/session calendar, checksum, licensing/terms, and data-quality statistics.

## Safety interpretation

These sources are data candidates only. No API key, network order, wallet signing, deposit, withdrawal, or custody path is implied by source discovery. The dataset evidence manifest remains `PENDING_EXTERNAL_DATA` until the actual files and their provenance are attached and validated.
