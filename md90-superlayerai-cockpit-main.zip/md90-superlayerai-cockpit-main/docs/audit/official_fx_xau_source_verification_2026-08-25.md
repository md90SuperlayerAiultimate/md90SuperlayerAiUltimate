# Official FX/XAU Historical Source Verification

**Tanggal:** 25 Agustus 2026 (UTC+8)  
**Tujuan:** menilai apakah EUR/USD dan XAU/USD dapat dipasok sebagai historical evidence tanpa kredensial trading.

## Hasil terverifikasi

| Bukti | Hasil |
|---|---|
| [Dukascopy Historical Data Export](https://www.dukascopy.com/swiss/english/fx-market-tools/historical-data/) | Halaman publik dapat dibuka tanpa login dan mencantumkan **EUR/USD** serta **XAU/USD** pada daftar instrument export. |
| Dialog export EUR/USD | UI publik menyediakan pilihan offer side (**Bid/Ask**), period, date, timezone (**UTC**), dan tombol **Download** tanpa meminta akun trading. |
| Sample download aktual | File publik `EUR-USD_1Minute_BID_2026-08-25_23_59-23_59_Etc_UTC.csv` berhasil diunduh dari `widgets.dukascopy.com`. Header nyata adalah `Etc/UTC,Open,High,Low,Close,Volume`; sample berisi ISO-8601 UTC dan volume numerik. |
| XAU selection dan sample | XAU/USD (Gold vs US Dollar) berhasil dipilih dan file `XAU-USD_1Minute_BID_2026-08-25_23_59-23_59_Etc_UTC.csv` berhasil diunduh dari export publik yang sama. Header aktual identik: `Etc/UTC,Open,High,Low,Close,Volume`, dengan ISO-8601 UTC dan volume numerik. |
| [Dukascopy Historical Data Service](https://www.dukascopy.com/wiki/en/development/strategy-api/historical-data/historical-data-service/) | Dokumentasi Strategy API membuktikan availability historical candle/tick untuk EUR/USD dan periode 1m/5m/15m/1h/4h/daily, tetapi contohnya berada di runtime JForex/Strategy API, bukan REST endpoint browser yang distabilkan untuk integrasi SaaS. |

## Keputusan integrasi

| Area | Status | Alasan |
|---|---|---|
| Export manual EURUSD/XAUUSD | **SUPPORTED** | Operator dapat memperoleh file dari surface resmi lalu melewati normalizer/manifest md90. |
| `datasets.ingestManual` | **IMPLEMENTED** | CSV/JSON manual divalidasi pada OHLC, timestamp, duplicate, volume, checksum, source/provenance; header `Etc/UTC` resmi Dukascopy dan close time dari interval sekarang ditangani; route tetap `DISABLED`. |
| Server-side auto-fetch Dukascopy | **NOT APPROVED** | Tidak ada endpoint REST/CSV yang stabil, berdokumentasi, dan telah diuji end-to-end di sini. Membongkar request UI atau memakai URL tidak terdokumentasi akan rapuh dan berpotensi melanggar ketentuan sumber. |
| XAUUSD format payload | **VERIFIED** | Sample publik XAU/USD memiliki kontrak CSV UTC/OHLCV yang sama dengan EUR/USD dan diterima oleh mapping `Etc/UTC` normalizer. |

> Kesimpulan: **sumber resmi, export publik, dan format CSV EUR/USD telah terverifikasi; auto-ingestion endpoint belum tersertifikasi.** Oleh sebab itu, md90 mempertahankan jalur manual SHADOW_EXTERNAL sampai ada API yang terdokumentasi, stabil, dan sesuai syarat penggunaan. Tidak ada fallback crypto atau broker execution.

## Extension coverage

Halaman export publik menjelaskan cakupan historical untuk Forex, Commodities, dan Indices; hasil pencarian resmi juga menyebut CSV tersedia pada rentang timeframe tick hingga monthly. Namun control periode pada surface browser tetap script-driven dan tidak menyediakan kontrak endpoint server yang stabil untuk auto-ingestion. Oleh sebab itu, md90 memperluas upload manual hingga **6 MB** dan menambahkan manifest `SHORT`, `MEDIUM`, atau `LONG` berdasarkan jumlah bar serta durasi file.

> Label `LONG` hanya menandakan kesiapan **review evidence**. Ia tidak menjadikan file sebagai canonical PAPER replay, tidak meniadakan provenance/checksum, dan tidak memberi authority eksekusi.

## Local public-export sample manifest

| Instrument | Interval | Bar data | UTC coverage | SHA-256 | Coverage verdict |
|---|---:|---:|---|---|---|
| EUR/USD BID | 1m | 547 candles (548 CSV rows incl. header) | 2026-08-25 00:00 → 09:07 | `4a487e9df3017c225c51f2de4c1a44a6a55595e6c7a39f48564d57ddae729fc9` | `MEDIUM` / `EVIDENCE_REQUIRED` |
| XAU/USD BID | 1m | 552 candles (553 CSV rows incl. header) | 2026-08-25 00:00 → 09:12 | `51b1b1d5ebf11c79cd29c8587037672fdce2fe9c23cc50b2eeb40d2b993a507f` | `MEDIUM` / `EVIDENCE_REQUIRED` |

Kedua file tersebut adalah export publik yang ditinjau secara statis; raw file tidak dipindahkan ke database atau dijadikan data demo. Keduanya membuktikan jalur normalisasi/provenance format aktual, tetapi **belum** memenuhi ambang `LONG` md90 (minimal 2.000 bar atau 30 hari coverage) untuk review dataset jangka panjang.
