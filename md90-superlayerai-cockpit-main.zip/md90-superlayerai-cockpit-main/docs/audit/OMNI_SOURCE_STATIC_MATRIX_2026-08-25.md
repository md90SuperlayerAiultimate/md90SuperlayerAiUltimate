# Omni Source Static Matrix — Upload Inventory

**Method:** metadata, checksum register, filename inventory, and lexical static scan only. No uploaded code, shell runner, MQL5 EA, ZIP payload, or video was executed. A lexical match means a surface requires review; it is not proof that a call ran.

| Static group | Files covered | Static finding | Runtime classification |
|---|---|---|---|
| Broker-order EAs | `MD90_ULTIMATE_FUSION_EA_v2*.mq5*.txt` (11 variants) | `CTrade`, `PositionOpen`, close/modify/partial-close, martingale, notification, pyramiding. | **BLOCKED**; see MQL reconciliation. |
| Direct order clients | `executor.py`, `polymarket_client.py`, `execution.py` | Order posting/cancellation, authenticated client, private-key/credential surfaces. | **BLOCKED**; no client, signing, account, or order route. |
| Command/external ingress | `webhook_server.py`, `command_listener.py`, `ws_engine.py`, `telegram_alerts.py` | HTTP/WebSocket/Telegram ingress or outbound notifications, mutable command bridge. | **BLOCKED**; no webhook/connector/alert authority. |
| Provider/network data | `data_provider.py`, `scanner.py`, `six_cycle.py`, `md90_ultra_market_v4.py`, `config.py` | CCXT/HTTP/WebSocket/provider config surfaces. | **REFERENCE_ONLY / ADAPTABLE SUBSET**; only canonical-candle pure math may be ported with provenance. |
| Mutable learning/release | `auto_tuner.py`, `tuner.py`, `self_learner.py`, `github_sync.py`, `main.py`, `local_agent.py`, `cognitive_pipeline.py` | Parameter search, config/model persistence, callbacks, GitHub/release or orchestration side effects. | **BLOCKED** for promotion/release; journal/OOS evidence only. |
| Vector/graph/memory | `qdrant_memory.py`, `graph.py`, `mirofish_graph.py`, `agent.py` | External memory/graph/agent state, API credential surfaces. | **BLOCKED** pending dedicated storage, access, and outbound contract. |
| Deterministic market logic | `fusion.py`, `constants.py`, `detectors.py`, `signal_engine.py`, `strategy_engine.py`, `swing_detector.py`, `regime_engine.py`, `regime_strategies.py`, `session_manager.py`, `risk_calculator.py`, `risk_manager.py`, `circuit_breaker.py`, `statistics_engine.py`, `bayesian_updater.py`, `kelly_sizer.py`, `state_manager.py`, `journal.py`, `types.py` | Candidate indicator, regime, scoring, policy, journal, and data-shape logic. | **ADAPTABLE SELECTIVELY**. Each formula requires line reconciliation, canonical inputs, tests, and no auto-promotion. |
| Research/static payload | `README.md`, `requirements.txt`, `github.com_*.md`, `pasted_content*.txt`, `MD90_ALLIN_FIXED.pine.txt`, `pre_market.py`, `test_full_pipeline.py` | Documentation, snippets, Pine strategy/order API references, research/test concepts. | **REFERENCE_ONLY** unless a pure formula is separately reconciled. |
| Runners | `run.sh`, `run_dashboard.sh`, `run_dry.sh`, `run_tests.sh` | Starts scripts/processes; can chain external behavior. | **BLOCKED**; never executed. |
| Archives/media/other | `md90_FINAL_VERIFIED.zip`, `md90_ultimate_fusion_v4_FINAL_ARB.zip`, `ssstwitter*.mp4`, `tone.xml`, `__init__.py` | Archive/media/placeholder surfaces. | **REFERENCE_ONLY**; archives were read-only audited separately, media does not enter runtime. |

## Global lexical surfaces

| Surface | Files flagged by static scan | Interpretation |
|---|---|---|
| Network | `config.py`, `data_provider.py`, `md90_ultra_market_v4.py`, `scanner.py`, `six_cycle.py`, `telegram_alerts.py`, `webhook_server.py`, `ws_engine.py`, plus snippet/dependency text | External I/O requires a dedicated adapter/provenance contract; no artifact client is imported. |
| Credential | `agent.py`, `config.py`, `github_sync.py`, `local_agent.py`, `mirofish_graph.py`, `polymarket_client.py`, `telegram_alerts.py`, `webhook_server.py` | All credential/private-key/token surfaces remain unavailable to md90 runtime. |
| Order/custody | 11 MQL variants, `execution.py`, `executor.py`, `polymarket_client.py` | Hard-blocked by explicit outbound boundary; source `DRY_RUN` does not weaken the lock. |
| Mutable release | `auto_tuner.py`, `github_sync.py`, `main.py`, `self_learner.py`, `tuner.py`, `ws_engine.py`, runners/snippets | No auto tuning/promotion/GitHub sync/background release path. |

> The matrix completes static triage coverage of the current upload inventory. It does **not** assert formula-level parity for every source line: formula reconciliation proceeds one candidate at a time, with tests and evidence gates. This distinction prevents both missed side effects and unsupported integration claims.
