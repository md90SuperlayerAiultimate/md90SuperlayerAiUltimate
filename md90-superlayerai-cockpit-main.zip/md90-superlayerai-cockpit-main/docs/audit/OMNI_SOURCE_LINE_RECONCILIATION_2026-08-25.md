# Omni Source Line Reconciliation — DataProvider

**Artifact:** `/home/ubuntu/upload/data_provider.py`  
**SHA-256:** `beee3a9aac71fe41697a308d4df88710c2734d09cb969953c89831c1353bedd7`  
**Audit mode:** static-only; artifact tidak dieksekusi atau diimport oleh runtime md90.

> Fokus dokumen ini adalah membedakan “formula yang tampak tersedia” dari formula yang benar-benar digunakan pada runtime. Kesamaan nama indikator tidak dianggap sebagai equivalence sampai window, fallback, output, dan proof test dibandingkan.

| Source line / surface | Static behavior | Runtime md90 comparison | Decision |
|---|---|---|---|
| 10–14 (`asyncio`, `ccxt.async_support`, `MarketData`) | Bergantung pada library eksternal dan model di luar runtime project. | md90 tidak mengimpor artifact ini; public crypto history memakai adapter Binance read-only, manual FX/XAU memakai manifest object-storage. | **REFERENCE_ONLY**. |
| 21–28 (`_ema`) | EMA seeded dengan SMA `period` pertama. | `artifactParity.ts:33–39` memakai seed dan recursion yang sama secara semantik. | **IMPLEMENTED SUBSET**; tetap perlu vector parity fixture bila source formula akan dijadikan benchmark numerik. |
| 31–44 (`_rsi`) | Memakai perubahan pada **window awal** `closes[1..period]`, bukan trailing window; token `__add__` di line 37 tidak memutasi state. | `artifactParity.ts:47–58` sengaja memakai trailing 14 perubahan canonical sebagai standardisasi evidence terbaru. | **ADAPTED WITH DIVERGENCE**. Bukan klaim bit-for-bit parity; source fallback tidak dijadikan authority. |
| 47–54 (`_atr`) | True range dan rata-rata trailing period. | `artifactParity.ts:41–45` memakai true range/trailing average yang sesuai konsep. | **IMPLEMENTED SUBSET**. |
| 57–67 (`_stochastic`) | K dari rolling range dan D dari mean K terakhir. | `artifactParity.ts:60–71` menghitung K/D dari candle trailing yang lebih kecil. | **ADAPTED WITH DIVERGENCE**; perlu vector test untuk parity exact bila menjadi gate kuat. |
| 70–82 (`_macd`) | EMA fast/slow, signal, histogram. | Tidak ada MACD evidence eksplisit pada 17-layer runtime saat audit ini. | **ADAPTABLE GAP**. |
| 85–112 (`_adx`) | DI/true range dengan smoothing lokal. | `artifactParity.ts:73–89` memakai proxy DI/ADX trailing tanpa full smoothing source. | **ADAPTED WITH DIVERGENCE**; hanya regime evidence, bukan execution. |
| 115–122 (`_obv`) | Accumulated signed volume. | Runtime belum menyimpan OBV evidence. | **ADAPTABLE GAP**. |
| 125–138 (`_mfi`) | Typical-price money-flow ratio. | Runtime belum menyimpan MFI evidence. | **ADAPTABLE GAP**. |
| 141–147 (`_vwap`) | Cumulative typical-price × volume / volume. | Layer VWAP runtime masih fail-visible/neutral ketika certified source belum tersedia. | **ADAPTABLE GAP**; hanya boleh dihitung apabila canonical volume tersedia. |
| 150–162 (`_bollinger`) | Bands/width dari rolling close. | Runtime belum punya Bollinger evidence layer eksplisit. | **ADAPTABLE GAP**. |
| 165–175 (volume ratio/buy pressure) | Ratio volume terakhir terhadap average dan prosentase candle bullish. | Runtime memiliki proxy body/volume, bukan formula penuh. | **ADAPTABLE GAP**. |
| 182–192 (`DataProvider.__init__/close`) | Membentuk CCXT exchange; menerima API key/secret optional. | Tidak ada client CCXT atau credential route md90. | **BLOCKED RUNTIME**. |
| 194–261 (`fetch`) | Mengambil OHLCV network multi-TF / daily dan menelan error. | md90 memerlukan checksum/freshness/provenance dan tidak memakai network client artifact. | **BLOCKED RUNTIME**. |
| 263–280 (`MarketData` return) | Mengemas hasil ke external model dan memberi `session_active=True`. | md90 memakai typed Paper/SHADOW evidence, tidak mempercayai session default dari source. | **REFERENCE_ONLY**. |

## Decision

Gap yang aman untuk ditutup adalah **indikator murni berbasis candle canonical yang sudah memiliki volume**: MACD, OBV, MFI, VWAP, Bollinger, volume ratio, dan buy pressure. Integrasi wajib mempertahankan kondisi berikut: bila OHLCV tidak lengkap, indikator menjadi `NOT_EVALUATED`/neutral dan tidak dapat meloloskan gate; tidak ada network fetch, credential, broker action, atau perubahan config otomatis.

---

# Omni Source Line Reconciliation — Polymarket Execution

| Artifact | SHA-256 | Source line / surface | Static behavior | Runtime decision |
|---|---|---|---|---|
| `executor.py` | `4a5d20e3d174b140a6b7932da5f8016162485edd66596a884724bd2d5ea41970` | 11 (`DRY_RUN`) | Environment switch controls whether path proceeds. | **BLOCKED**; environment flag tidak menjadi security boundary md90. |
| `executor.py` | same | 18–25 (`_get_client`) | Lazy imports external `PolyClient`. | **BLOCKED**; no runtime import/connector. |
| `executor.py` | same | 27–36 (`execute` dry path) | Menghasilkan status `DRY_EXECUTED`, tetapi sizing tetap 15% equity. | **REFERENCE_ONLY**; demo/PAPER md90 memakai Survivor Mode 0.5–1%, bukan formula ini. |
| `executor.py` | same | 42–64 (`BUY_BOTH` / buy branch) | Mengirim `place_limit_order` untuk satu atau dua token. | **BLOCKED**; `ORDER_SUBMIT` boundary `DISABLED`. |
| `executor.py` | same | 66–70 | Melaporkan `EXECUTED`/`PARTIAL` berdasarkan result external. | **BLOCKED**; status ini tidak boleh menjadi fill/journal md90. |
| `polymarket_client.py` | `cc6c1d4f7645097e9a22ded014a2c98673ddc7e065f6ed11a80cbe01e408a258` | 23–32 (`__init__`) | Membaca host/chain/private key/funder/signature type dari environment. | **BLOCKED**; tidak ada secret intake/private key/wallet state. |
| `polymarket_client.py` | same | 34–53 (`_get_creds`) | Membangun `ClobClient`, menderivasi API credentials dari private key. | **BLOCKED**; credential derivation/signing tidak tersedia. |
| `polymarket_client.py` | same | 55–72 (`get_client`) | Membentuk authenticated client dengan credentials/signature/funder. | **BLOCKED**; tidak ada connector route. |
| `polymarket_client.py` | same | 74–88 (`get_balance`, `get_positions`) | Authenticated account data read path. | **BLOCKED**; current scope tidak menyimpan atau memproses wallet/account provider state. |
| `polymarket_client.py` | same | 90–107 (`place_limit_order`) | `create_and_post_order` dengan order args dan GTC. | **BLOCKED**; no direct/indirect order post route. |
| `polymarket_client.py` | same | 109–115 (`cancel_all_orders`) | Membatalkan seluruh order external. | **BLOCKED**; PAPER command retry bahkan menolak close replay agar side effect tidak digandakan. |
| `polymarket_client.py` | same | 117–125 (`test_connection`) | Memakai authenticated balance call sebagai health check. | **BLOCKED**; health runtime md90 tidak menggunakan account credential. |

> Kesimpulan batch ini: `DRY_RUN` bukan substitusi untuk boundary keamanan; ia masih membawa client, credential, sizing, dan jalur post order. md90 mempertahankan hard lock di `artifactBoundary`, sementara seluruh fill/journal berasal dari FSM PAPER internal yang user-scoped.

---

# Omni Source Line Reconciliation — Fusion Score and Constants

**Artifacts:** `fusion.py` (`da16cf6c61f26b527fa35cb1e98c8b47146de12cf0dcf1ac685c91774eed32f3`) and `constants.py` (static source package; filename identity is not relied on without hash in a deployment decision).

| Source line / surface | Static behavior | md90 runtime comparison | Decision |
|---|---|---|---|
| `constants.py:6–39` | Defines 17 layer identifiers and weights totaling 1.01. | `artifactParity` uses the same 17-layer vocabulary, but current score is vote-based rather than source-weighted. | **ADAPTABLE GAP**: add a weight-normalized evidence score only; no authority change. |
| `fusion.py:36–64` | Computes directional weighted score from layer strength. | Current fusion direction/count is deterministic but not weighted. | **ADAPTABLE GAP** with unit vector test. |
| `fusion.py:73–121` | Evaluates five gates; G2 and G4 include strength override conditions. | md90 preserves 5 gates but declines missing/certification-dependent layers rather than passing on implicit source strength. | **ADAPTED WITH SAFETY DIVERGENCE**. Missing MTF/time-stop remains HOLD. |
| `fusion.py:128–145` | Maps passing score/confidence to `ALL-IN`. | No `ALL-IN` status exists in md90. | **BLOCKED**; outcome vocabulary remains `PAPER_CANDIDATE` / `REVIEW` / `BLOCKED`. |
| `fusion.py:151–192` | Bonus/penalty confidence then changes lot and SL multiplier. | md90 may expose confidence as evidence, but cannot import dynamic lot multiplier/SL reduction. | **ADAPTABLE SUBSET**: score/reason only; no sizing mutation. |
| `fusion.py:199–215` | Produces ATR SL/TP levels with source multipliers. | md90 `strategyConfig` applies approved PAPER config (2.5 ATR SL / 2R) and Survivor Mode. | **REFERENCE_ONLY** for source multipliers; no source value overrides canonical policy. |
| `constants.py:41–52` | Threshold 0.55/75, 1.5 ATR SL, TP ladder, partial closure percentages. | Existing PAPER trade proposal has advisory partial exit/time-stop and canonical parameters. | **REFERENCE_ONLY + ADAPTED CONTRACT**; source numbers not authority. |
| `constants.py:67–71` | Default 1% risk, 10% drawdown, 5% daily loss, three positions. | md90 clamps daily loss at 3%, exposure at 3%, risk 0.5–1%. | **BLOCKED OVERRIDE**; Survivor Mode is stricter. |

## Safe extraction decision

The normalized weighted confluence diagnostic is now implemented in `shared/artifactParity.ts`. It exposes normalized buy/sell/maximum weighted evidence in the Risk Lab but does not alter `paper.decide`, risk percentage, ATR level policy, position count, order route, or any execution authority. The vector contract asserts the score remains within 0–1 and equal to `max(weightedBuyScore, weightedSellScore)`.

---

# Omni Source Line Reconciliation — HMM Regime Engine

**Artifact:** `regime_engine.py`  
**SHA-256:** `2336eb076598d0ad1a79ced5f0150a782c2220beb235241d5f3dfff8cac3c8de`

| Source line / surface | Static behavior | Runtime decision |
|---|---|---|
| 16–32 (state model/names) | Five regime labels, probability, persistence, transition risk, confidence fields. | **REFERENCE VOCABULARY**. md90 can map labels to evidence but not trust a source probability without a fit/replay artifact. |
| 44–63 (`_init_model`) | Optionally initializes `hmmlearn.GaussianHMM` with runtime dependency. | **BLOCKED RUNTIME**. No deployed arbitrary model initialization/import. |
| 65–88 (`prepare_features`) | Derives returns, log volume, realized volatility, normalized ADX. | **ADAPTABLE** only from canonical OHLCV with explicit availability; no source data client. |
| 90–105 (`fit`) | Fits mutable HMM online from input bars. | **PENDING_EVIDENCE**. Requires train/test split, model/version hash, label mapping stability, and OOS evidence; not auto-fit. |
| 107–147 (`predict` / `_hmm_predict`) | Predicts state, mutates state history, calculates transition risk/confidence. | **PENDING_EVIDENCE**. No mutable model state or confidence promotion in current runtime. |
| 149–185 (`_rule_based`) | Deterministic EMA/ADX/ATR classification fallback, but returns fixed probability/persistence/confidence values. | **ADAPTED SUBSET**. Current parity/protective policy uses trend/volatility labels; fixed 0.75/0.60/72 confidence is rejected as synthetic certainty. |

> The currently surfaced regime is a deterministic candle-evidence label, not an HMM prediction. A future HMM proposal requires a dataset manifest, serialized model checksum, walk-forward/OOS test, stable state-to-label mapping, and a manual review gate; it cannot update a strategy, risk limit, or execution route.

---

# Omni Source Line Reconciliation — MQL5 Ultimate Fusion EA Variants

Static scan covered the uploaded `MD90_ULTIMATE_FUSION_EA_v2*` variants. Variant filenames are not treated as identity; the register tracks checksum when a source is used for a decision. All variants contain broker-bound `CTrade` paths and are **reference-only**.

| Source surface observed across variants | Static behavior | Runtime decision |
|---|---|---|
| Inputs `UseHedgeMode`, `UseMartingale`, `TP*_LotsPercent`, notifications | Configures broker hedging, loss recovery, partial closure, and device notifications. | **BLOCKED**. No broker hedge/martingale/notification capability. |
| Global `CTrade`, `CPositionInfo`, `COrderInfo` | Imports active terminal trade/position/order state. | **BLOCKED**. No MQL5/terminal adapter imported. |
| `PositionOpen(...)` entry and pyramiding | Opens initial and additional broker positions. | **BLOCKED** as `ORDER_SUBMIT`; no sizing/position escalation is adopted. |
| `PositionClose(...)` time/reversal/close-all flows | Directly closes terminal positions. | **BLOCKED**. md90 time-stop query is advisory-only; only an operator-triggered internal PAPER close can write a replay exit. |
| `PositionClosePartial(...)` TP ladder | Partial broker close and mutable remaining lot state. | **ADVISORY CONTRACT ONLY**. PAPER proposal may show partial exit state but cannot close or reduce a broker position. |
| `PositionModify(...)`, trailing, break-even, SAR | Mutates broker stop-loss and take-profit. | **BLOCKED**. Existing ATR/trailing parameters are research/PAPER evidence only. |
| Martingale doubling (`MathPow(2, level)`) | Increases lot after loss and statefully advances recovery level. | **BLOCKED**. Contradicts Survivor Mode caps and no escalation rule. |
| `SendNotification(...)` | Sends push notification from trading terminal. | **BLOCKED** by outbound boundary. |
| Time-stop / session / ATR / MTF formulas | Contains candidate deterministic references. | **ADAPTABLE SUBSET** only after per-formula vector parity and canonical data availability. Existing bar-clock, session protection, MTF requirement, and ATR proposal are separately evidence-bound. |

> A source setting labelled “disabled by default” is not accepted as a security control. The runtime excludes the broker library and represents all external action categories as explicit `DISABLED` locks.

---

# Omni Source Line Reconciliation — Webhook Command Server

**Artifact:** `webhook_server.py`  
**SHA-256:** `3eda66d9d42eee33881087845d599604df4599b5cf83fd187bef6a7e7a0e3dd1`

| Source line / surface | Static behavior | Runtime decision |
|---|---|---|
| 1–16 | Declares n8n/VPS endpoints for live signals, manual commands, research, and resolved markets; documented host/port external exposure. | **BLOCKED**. md90 does not deploy this listener or an arbitrary command ingress. |
| 23 (`WEBHOOK_SECRET`) | Uses a source-code fallback secret (`md90secret`). | **BLOCKED**; no default secret or webhook auth path accepted. |
| 34–58 (state/command file) | Reads bot state and appends commands to JSON file. | **BLOCKED**; user-scoped DB/object storage replaces file command bridge for protected PAPER capability. |
| 71–98 (`/`, `/status`, `/signal`) | Exposes state/status through HTTP after header secret check. | **BLOCKED**; no external bot state API. |
| 100–128 (`/research`) | Accepts external research and writes JSON for bot consumption. | **BLOCKED**. Research ingestion requires dedicated provenance/checksum contract; no webhook bypass. |
| 130–151 (`/command`) | Queues `FLATTEN`, `PAUSE`, `RESUME`, `SET_PARAM`, `STATUS`, `STOP` for bot execution. | **BLOCKED**. tRPC PAPER commands are typed, user-scoped, audited, and only whitelisted; no external `SET_PARAM`/flatten bridge. |
| 153–179 (`/market_resolved`) | Writes resolution event to file and explicitly triggers Bayesian/SelfLearner workflow. | **BLOCKED**. Learning evidence is journal/OOS proposal-only; no event-triggered self-learning mutation. |
| 181–205 (`/ml_stats`) | Reads mutable learner state and publishes thresholds/win rate. | **BLOCKED**. md90 calculates evidence from user-scoped journal and avoids unverifiable learner statistics. |
| 207–229 (aiohttp fallback) | Starts alternate unauthenticated fallback status server if FastAPI unavailable. | **BLOCKED**. No fallback listener may bypass auth/boundary. |

> The server's static `_auth` function does not make the system safe for md90 scope: an external command action, mutable file state, permissive fallback, and downstream bot side effects remain present. The correct runtime outcome is a total `WEBHOOK_COMMAND` lock, not a reimplementation.

---

# Omni Source Line Reconciliation — Auto Tuner

**Artifact:** `auto_tuner.py`  
**SHA-256:** `d6bf22dd31f02f8e9ee2874cb74f1cf7eb5776c3bb3cef04f3ed92dad5ad8e70`

| Source line / surface | Static behavior | Runtime decision |
|---|---|---|
| 1–15 | States self-tuning goal and candidate parameters including Kelly/all-in/Polymarket threshold. | **REFERENCE_ONLY**; no performance claim or source parameter promotion. |
| 36–45 (`PARAM_SPACE`) | Defines search space containing `kelly_fraction`, `composite_allin`, and risk/reward thresholds. | **BLOCKED CONFIG DOMAIN**. md90 does not accept Kelly or all-in promotion. |
| 52–101 (`_objective`) | Filters replay records and optimizes `profit_factor × win_rate`; minimum sample is only 10. | **ADAPTABLE CONCEPT ONLY**. md90 learning evidence has explicit sample/OOS gate; no objective result changes config. |
| 103–149 (`run`) | Imports Optuna, optimizes, invokes callback on new best, and assigns mutable best state. | **BLOCKED**. No background optimizer/callback route. |
| 154–172 (`apply_to_config`) | Merges learned values into a running configuration. | **BLOCKED** by `AUTO_TUNE_PROMOTION` and `MODEL_RELEASE` locks. |
| 174–188 (file save/load) | Persists best parameters to local JSON and reloads them. | **BLOCKED**. Runtime journal evidence is user-scoped and does not persist proposed strategy config. |

> The safe md90 analog is `learningEvidence`: it can report closed-sample/OOS/posterior review evidence, but it cannot run a tuner, write a config, call a callback, change a threshold, or release a model.
