# Omni Source Atomic Audit Register

**Tanggal:** 25 Agustus 2026 (UTC+8)  
**Mode audit:** static-only. Tidak ada Python, Pine, MQL5, shell runner, webhook, bot, atau connector dari upload yang dieksekusi.  
**Tujuan:** memecah audit dari label besar menjadi unit temuan yang dapat dilacak: *artifact checksum → file → line/surface → capability → side effect → keputusan runtime → bukti test/UI*.

> Register ini bukan klaim bahwa satu juta langkah telah selesai. Ia adalah struktur kerja yang mencegah “satu juta checklist” palsu: setiap entry baru harus memiliki artifact hash, bukti static analysis, keputusan, dan—jika diadaptasi—test serta surface runtime.

## 1. Skema unit audit

| Field | Definisi operasional |
|---|---|
| `findingId` | ID stabil `OS-YYYYMMDD-BATCH-###`; satu capability atau side effect spesifik. |
| `artifact` / `sha256` | Filename saat audit dan checksum penuh. Filename tidak dianggap identity karena upload dapat menimpa nama yang sama. |
| `surface` | Function, import, line range, atau runtime module yang relevan. |
| `classification` | `IMPLEMENTED`, `ADAPTABLE`, `REFERENCE_ONLY`, `BLOCKED`, atau `PENDING_EVIDENCE`. |
| `decision` | Tindakan yang diizinkan pada md90: adaptasi pure TypeScript, observability, atau hard lock. |
| `proof` | Unit/integration test, UI binding, migration, manifest, atau reason code yang membuktikan keputusan. |

## 2. Baseline source map

| Batch | Cakupan | Status audit | Catatan provenance |
|---|---|---|---|
| Runtime aktif | `client/`, `server/`, `shared/`, `drizzle/`, `docs/` | Active comparison baseline | Hanya code yang berada di tree project dan lulus test dapat disebut runtime. |
| Source upload Python | Engine, scanner, regime, risk, memory, webhook, executor, tuner, journal | Static triage active | Tidak diimport atau dieksekusi oleh deployed md90. |
| Pine/MQL5 | Pine strategy dan EA variants | Static triage active | EA/MQL5 termasuk broker execution reference-only. |
| ZIP/source archives | `md90_FINAL_VERIFIED.zip`, `md90_ultimate_fusion_v4_FINAL_ARB.zip`, refactor archive | Archive/provenance | Dibaca sebagai evidence, bukan dependency runtime. |
| GitHub metadata | CCXT, NautilusTrader, Freqtrade, TradingAgents, dan kandidat lain | Metadata/reference | License, branch, dan source health selalu diverifikasi sebelum dipertimbangkan. |

## 3. Atomic high-risk decision ledger

| findingId | Artifact / SHA-256 | Static finding | Classification | Runtime decision / proof |
|---|---|---|---|---|
| OS-20260825-EXEC-001 | `executor.py` / `4a5d20e3d174b140a6b7932da5f8016162485edd66596a884724bd2d5ea41970` | Memanggil `place_limit_order`; membentuk result order. | **BLOCKED** | Tidak diimport. `artifactBoundary` memblokir `ORDER_SUBMIT`; PAPER close menggunakan route internal `PAPER_REPLAY_ONLY` saja. |
| OS-20260825-EXEC-002 | `execution.py` / `4e04f7e2611b42d4a8b1dd272eeb0d2ec8839dc8876200dd66e8683d054ce82d` | Memanggil order limit klien eksternal. | **BLOCKED** | Tidak ada adapter executor/outbound. Regression boundary menyatakan authority `DISABLED`. |
| OS-20260825-EXEC-003 | `polymarket_client.py` / `cc6c1d4f7645097e9a22ded014a2c98673ddc7e065f6ed11a80cbe01e408a258` | Private-key credential dan lifecycle client order. | **BLOCKED** | Tidak ada private key, wallet, signing, deposit, withdrawal, atau Polymarket route pada md90. |
| OS-20260825-EXEC-004 | `MD90_ULTIMATE_FUSION_EA_v2.mq5.txt` / `0f3145deeb394bce95fa0c701ab803b5d458c2daf8ed2b546f62b83fe5564e33` | `CTrade`, `PositionOpen`, modification/scale position. | **REFERENCE_ONLY** | Formula dapat ditelaah; order EA tidak diport. `artifactTradeProposal` hanya menghasilkan advisory PAPER proposal. |
| OS-20260825-EXEC-005 | `webhook_server.py` / `3eda66d9d42eee33881087845d599604df4599b5cf83fd187bef6a7e7a0e3dd1` | Command ingress melalui webhook. | **BLOCKED** | Tidak ada webhook command listener deployed; `WEBHOOK_COMMAND` hard-locked. |
| OS-20260825-EXEC-006 | `command_listener.py` / `0e1924c2799e66ee9a4271c3c140b8eabdadc52270153a6668c4c8786b85b6b3` | Mengonsumsi command external dari state webhook. | **BLOCKED** | Tidak ada command bridge; protected tRPC hanya menerima mutation scoped yang di-whitelist. |
| OS-20260825-EXEC-007 | `github_sync.py` / `4b6effe54909d429258e698e244f6b830e51db4f8129805eeb3ac93635a47bee` | Mutable repository sync/push possibility. | **BLOCKED** | `GITHUB_PUSH` / model release disabled; checkpoint platform adalah jalur release yang audited. |
| OS-20260825-EXEC-008 | `telegram_alerts.py` / `fa1cf1e21defdae9fc8b8f80ef288e92dd3175b9c91f53ce19befdc95daf657d` | Outbound notification surface. | **BLOCKED** | `TELEGRAM_NOTIFY` lock; tidak ada secret atau HTTP alert path. |
| OS-20260825-EXEC-009 | `qdrant_memory.py` / `a55dc41775ecce1cb7f817ce7dbbb85aec989942b7a2d04e47848b00ba1df8ab` | External/vector memory persistence. | **BLOCKED** | `QDRANT_WRITE` lock; learning evidence menggunakan journal user-scoped tanpa remote memory. |
| OS-20260825-EXEC-010 | `auto_tuner.py` / `d6bf22dd31f02f8e9ee2874cb74f1cf7eb5776c3bb3cef04f3ed92dad5ad8e70` dan `self_learner.py` / `0ae3242f2a4f59384484eb1bec007a371dd8c2435c433c454c5543b9527d7162` | Tuning/state mutation dapat mengubah parameter. | **BLOCKED** | `AUTO_TUNE_PROMOTION` dan `MODEL_RELEASE` disabled; Bayesian output hanya proposal review dengan OOS/sample gate. |

## 4. Atomic pure-logic adaptation ledger

| findingId | Artifact / SHA-256 | Logic statis yang ditinjau | Classification | Implementasi/proof md90 |
|---|---|---|---|---|
| OS-20260825-LOGIC-001 | `data_provider.py` / `beee3a9aac71fe41697a308d4df88710c2734d09cb969953c89831c1353bedd7` | EMA, RSI, ATR, stochastic, MACD, ADX/DI, OBV/MFI/VWAP/volume calculations. | **IMPLEMENTED PURE SUBSET / NETWORK BLOCKED** | Seluruh indikator murni yang disetujui tersedia di `artifactParity`; missing OHLCV menjadi `NOT_EVALUATED`. CCXT client, credential, network fetch, dan source fallback tidak diport. Vector proof ada pada `numericParity.test.ts`. |
| OS-20260825-LOGIC-002 | `fusion.py` / `da16cf6c61f26b527fa35cb1e98c8b47146de12cf0dcf1ac685c91774eed32f3` | Fusion score dan gate confluence. | **IMPLEMENTED WITH SAFETY DIVERGENCE** | 17-layer/5-gate parity sekarang juga memberi diagnostic weighted score dari bobot source yang dinormalisasi; outcome tetap `PAPER_CANDIDATE`, `REVIEW`, atau `BLOCKED`, tanpa `ALL-IN`. |
| OS-20260825-LOGIC-003 | `regime_engine.py` / `2336eb076598d0ad1a79ced5f0150a782c2220beb235241d5f3dfff8cac3c8de` | Trend/range/volatile regime context. | **IMPLEMENTED** | `artifactParity` dan `protectivePolicy` menghasilkan reason code dan state advisory. |
| OS-20260825-LOGIC-004 | `session_manager.py` / `23add8d0048adc99120eebfc777c55cd521482252d30d2d925f2215ee3b3f621` | Session classification/filter. | **IMPLEMENTED** | Session gate dipakai sebagai evidence/protection, bukan scheduler/executor. |
| OS-20260825-LOGIC-005 | `risk_calculator.py` / `f0522744f55a653d99b2fcf93e0b529939d5475d8856e1890bda4d11e3f91f0c` | ATR-based risk calculations. | **IMPLEMENTED** | `artifactTradeProposal` memakai canonical strategy config dan Survivor Mode clamp, proposal-only. |
| OS-20260825-LOGIC-006 | `statistics_engine.py` / `e9b27fd80a64c11c8b66be7cb2bb3183686ebc305d0f7d6722f2b54e046342b5` dan `journal.py` / `5ac0234dc0814dc06eb4b70f86fcb6f55676aac288c7070eacb2c849883f5e1d` | Statistics/journal outcomes. | **IMPLEMENTED** | `learningEvidence` membaca journal user-scoped, enforce sample/OOS gate, promotion disabled. |
| OS-20260825-LOGIC-007 | `MD90_ALLIN_FIXED.pine.txt` / `602e6b8affc9bbfdbbaed529f43317adf74a8e753e42e2699ed7b88b42a68b37` | Indicator/context calculations plus `strategy()` actions. | **REFERENCE_ONLY + IMPLEMENTED SUBSET** | Perhitungan/context dipetakan ke parity; order Pine dan placeholder layer tidak diklaim aktif. |
| OS-20260825-LOGIC-008 | `strategy_engine.py` / `190ab42e768b5867a0942cd2896da52b8955c030c4854c83103a713b113deb3f`, `scanner.py` / `e6b5cbf987926a00f90d6ed4fa3fdc6cb148f1f8b5948fde471edacda8c087f5` | Selection/ranking opportunity. | **ADAPTABLE** | Belum dipakai sebagai source authority; kandidasi hanya dari canonical evidence. |

## 5. Runtime reconciliation targets

| Target runtime | Required static evidence | Current status |
|---|---|---|
| `shared/artifactParity.ts` | Pure candle math, reason codes, no default pass on missing data. | IMPLEMENTED / tested. |
| `shared/protectivePolicy.ts` | Session/regime/circuit-breaker clamps under Survivor Mode. | IMPLEMENTED / advisory-only. |
| `shared/artifactTradeProposal.ts` | MTF/ATR/partial/time-stop proposal, no broker route. | IMPLEMENTED / disabled authority. |
| `shared/artifactBoundary.ts` | Webhook/Telegram/Qdrant/graph/GitHub/tuner/executor/wallet/order locks. | IMPLEMENTED / tested. |
| `shared/learningEvidence.ts` | User journal, posterior/sample/OOS review gate, no promotion. | IMPLEMENTED / tested. |
| `server/paperPersistence.ts` | Durable position clock and close lifecycle with idempotent PAPER route. | IMPLEMENTED / migration 0011. |

## 6. Next atomic batches

1. **OS-PY-IO:** per-file line findings for Python imports, network clients, filesystem writes, subprocess, and environment reads.
2. **OS-MQL-PINE:** split formula, placeholder, broker order, sizing, stop, and notification symbols by EA/Pine variant checksum.
3. **OS-RUNTIME:** link every acceptable finding to actual TypeScript source, test name, tRPC route, UI location, and failure reason.
4. **OS-EVIDENCE:** classify source/data gaps according to checksum, freshness, coverage, license, and provider terms before any runtime adaptation.

## 7. Static IO triage matrix

Static scan menandai kandidat berdasarkan token import/call dan **bukan** verdict akhir. Contohnya, kata `signal`, `seed`, atau `sign` dapat muncul sebagai perhitungan lokal; baris terkait harus dibaca sebelum diklasifikasikan `ORDER_OR_CUSTODY`. Triage berikut menentukan urutan audit line-level.

| Triage group | Files detected | Next audit action |
|---|---|---|
| Network + credential + external action | `md90_ultra_market_v4.py`, `webhook_server.py`, `telegram_alerts.py`, `polymarket_client.py`, `execution.py`, `executor.py` | Baca import, client construction, environment read, request/order call, error/retry, dan output state per function; default `BLOCKED`. |
| Mutable state / tuning / sync | `auto_tuner.py`, `tuner.py`, `self_learner.py`, `bayesian_updater.py`, `github_sync.py`, `state_manager.py`, `statistics_engine.py`, `journal.py` | Pisahkan formula statistik dari config/file/repo mutation; formula dapat `ADAPTABLE` hanya setelah vector dan test tersedia. |
| Agent / graph / pipeline | `agent.py`, `local_agent.py`, `cognitive_pipeline.py`, `graph.py`, `mirofish_graph.py`, `six_cycle.py`, `ws_engine.py` | Audit connector, tool dispatch, network, state write, dan order delegation; default no-outbound boundary. |
| Candidate deterministic market logic | `data_provider.py`, `fusion.py`, `regime_engine.py`, `regime_strategies.py`, `risk_calculator.py`, `session_manager.py`, `swing_detector.py`, `detectors.py`, `pre_market.py` | Read function-level math and required inputs; map only to canonical candle/reason-code contracts. |
| Shell / runner | `run.sh`, `run_dashboard.sh`, `run_dry.sh`, `run_tests.sh`, `main.py` | Audit command invocation and process start surface; never execute. |

## 8. Runtime proof reconciliation

| Finding class | Active runtime binding | Direct proof |
|---|---|---|
| Candle/indicator/parity adaptation | `server/paperEngine.ts` → `analyzeArtifactParity(replayCandles)` | `shared/artifactParity.test.ts` passes and output is attached to `PaperOverview`. |
| Protective regime/session/risk | `server/paperEngine.ts` → `evaluateProtectivePolicy(...)` | `shared/protectivePolicy.test.ts`; outcome is advisory (`PAPER_CANDIDATE`/`REVIEW`/`BLOCKED`). |
| MTF/ATR/partial/time-stop proposal | `server/paperEngine.ts` → `proposePaperTrade(...)` | `shared/artifactTradeProposal.test.ts` asserts `executionAuthority: DISABLED`. |
| Outbound artifact controls | `server/paperEngine.ts` → `artifactOutboundBoundaries([...])` | `shared/artifactBoundary.test.ts`; order, wallet, webhook, Telegram, Qdrant, graph, GitHub, tuner, and release locks are explicit. |
| Durable time-stop | `server/paperPersistence.ts` → `evaluatePaperTimeStop(...)`; `paper.timeStop` tRPC | `shared/paperPositionClock.test.ts` and `server/authenticatedRouter.test.ts` assert user scope, no replay fallback, `ADVISORY_ONLY`, and `DISABLED`. |
| Dataset source coverage | `server/datasetPersistence.ts` → `assessDatasetCoverage(...)` | `shared/datasetCoverage.test.ts`; `LONG` only becomes `REVIEW_READY`, never executable. |
| Bayesian/journal learning | `server/routers.ts` → `evaluateLearningEvidence(await getPaperJournal(...))` | `shared/learningEvidence.test.ts`; proposal-only and user-scoped. |
