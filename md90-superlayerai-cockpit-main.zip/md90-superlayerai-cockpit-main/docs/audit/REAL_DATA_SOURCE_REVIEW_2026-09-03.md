# Real Data Source Review — 2026-09-03

## Ringkasan

Pemeriksaan sumber resmi menemukan dua jalur yang relevan, tetapi belum ada bytes dataset yang aman untuk langsung dimasukkan ke project tanpa operator memilih rentang tanggal dan menyelesaikan alur unduh.

## Sumber resmi

| Sumber | Cakupan yang dinyatakan | Keterbatasan ingest saat ini | Status |
|---|---|---|---|
| [Dukascopy Historical Data Export](https://www.dukascopy.com/swiss/english/marketwatch/historical/) | Instrumen Forex, komoditas, dan indeks; halaman menyatakan CSV dari tick hingga monthly serta beberapa timeframe. | Halaman export bersifat interaktif/dinamis; belum ada file bytes yang diunduh, tanggal/rentang belum dipilih, dan checksum belum tersedia. | Candidate, evidence-required |
| [TraderMade Free Forex Data](https://tradermade.com/download-forex-data) | Secara eksplisit mencantumkan EURUSD dan XAUUSD; pilihan minute/hourly/daily serta 1m/5m/15m/30m. | Free plan menyatakan minute maksimum 2 hari, hourly maksimum 2 bulan, daily maksimum 5 tahun; belum ada bytes/checksum dan tidak mencakup semua sembilan interval secara native. | Candidate, evidence-required |

## Keputusan ingest

Tidak ada dataset yang di-seed atau dibuat sintetis. Untuk menghasilkan manifest sembilan timeframe, operator harus memberikan file candle nyata atau menyelesaikan unduh dari sumber dengan rentang tanggal yang disepakati. Interval canonical project adalah M1, M3, M5, M15, M30, H1, H4, D1, dan 1M. Jika sumber hanya menyediakan sebagian interval, resampling harus dilakukan secara eksplisit, disimpan sebagai derived dataset dengan formula, parent checksum, timezone, dan coverage; tidak boleh disamarkan sebagai source-native.

## Parity artifact

ZIP operator yang diaudit sebelumnya tidak berisi Pine/MQL5/Python source atau expected vector literal yang dapat diverifikasi. MATCH/MISMATCH tidak boleh dihasilkan sampai artifact asli, SHA-256, line range, formula version, expected vector, dan manifest checksum tersedia.

## References

[1]: https://www.dukascopy.com/swiss/english/marketwatch/historical/ "Dukascopy Historical Data Export"
[2]: https://tradermade.com/download-forex-data "TraderMade Free Forex Data"
