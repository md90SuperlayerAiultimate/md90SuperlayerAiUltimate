# New strategy artifact audit — 2026-08-27

## Scope and safety

Enam attachment baru diaudit sebagai teks statis. Tidak ada file yang di-import, dikompilasi, dijalankan, dihubungkan ke broker, atau dipakai untuk membuat order. Semua keputusan di bawah berada pada jalur `PAPER/SHADOW`; instruksi sinyal XAU/USD berstatus **ABORT** dan tidak menjadi command.

## File inventory

| File | Type | Lines | Bytes | SHA-256 | Content decision |
|---|---|---:|---:|---|---|
| `pasted_content.txt` | UTF-8 MQL5 text | 1,497 | 47,366 | `f15dc7188f647a62fe1790673de977c66875ba0e898bd854b31f9e2e0af97c2c` | FUSION_PRO_ADVANCED_V1; order-capable source, static audit only. |
| `pasted_content_2.txt` | ASCII/C-like mixed text | 469 | 18,622 | `8dc7ca756d44fd072568a73d0d0a987463058ce9c73d9549d64666e09b7abef2` | Pine + MQL5 concatenation; two source contracts must be separated before validation. |
| `pasted_content_3.txt` | ASCII text | 184 | 8,999 | `f74710b638f8f4429a04fd50face3ab83ec65d5b4b32125cedc13cb38fc4b2aa` | Pine Supreme Battle; MTF and risk placeholders require correction. |
| `pasted_content_4.txt` | ASCII text | 112 | 6,507 | `c6c2f8ea8f94a229f415b55e0fe18b3077558997a6f1f84d1db2dd1e7257d0d6` | Pine Mega-Konfluensi; tuple, time, and syntax hazards. |
| `pasted_content_5.txt` | UTF-8 text | 181 | 6,873 | `2d15f3dd1abf55f56f592a45b7992e79072d4c612e0e8f8170871af9ec4c08b8` | Pine strategy Matari-Fusion V9; direct strategy order calls and non-reproducible gates. |
| `pasted_content_6.txt` | UTF-8 text | 247 | 12,007 | `a269d5af016041ada0ba63316f1c50a2d89a42cd08e1d053345c61a2b537d724` | Pine HedgeFusion; read-only indicator with MTF and state/line-budget hazards. |

## Per-artifact findings

### `pasted_content.txt` — FUSION_PRO_ADVANCED_V1 MQL5

This re-upload is a 1,497-line MQL5 payload containing `CTrade`, `CPositionInfo`, `CAccountInfo`, indicator handles, `OnTick`, `OnTimer`, `ProcessSignal`, and `ManagePositions`. Static scanning found order-capable calls at lines 971, 1017, and 1090, plus a one-second timer at lines 195–224 and 278. It is therefore not a passive indicator: it is an order-capable EA source and remains `LIVE_DISABLED` in md90.

The source declares a large combined Matari/FUSION parameter surface, including fixed lot, ATR SL, TP multiplier, time stop, trailing stop, HTF EMA, RSI/Stochastic/SMA/MACD, slippage, magic number, and execution settings. Those values may be extracted as a parameter reference, but they do not prove behavior. The supplied text has no network or credential pattern, yet direct terminal order semantics are sufficient to require isolation. Compile correctness, broker fill behavior, partial fills, daily loss accounting, and every helper implementation must be validated independently; no MQL5 source is imported or executed by the application.

Integration decision: bind the new checksum to the source-vector catalog, expose it as `MQL5 / PENDING_VECTOR / PAPER_ONLY`, and map only deterministic risk/indicator concepts into the isolated adapter. Direct `CTrade` calls, timers, terminal state, and broker-side position management remain excluded.

### `pasted_content_2.txt` — mixed Pine and MQL5 payload

The first 127 lines repeat the FUSION V6 Pine contract. From line 128 onward, MQL5 source is concatenated into the same attachment. The mixed file is not a valid single-language artifact and must be split before either compiler or parser verdict is meaningful.

The MQL5 segment contains direct `CTrade` and `trade.SetExpertMagic()` usage, grid controls, position management, and `ProcessSignal()` order flow. It also contains ellipsis placeholders, incomplete helper bodies, and a comment claiming ten-layer confirmation while the implementation is incomplete in the supplied excerpt. This is an **order-capable reference**, not a validated executable EA. Integration decision: split-and-hash sub-artifacts; retain MQL5 portion as `SHADOW_REFERENCE / LIVE_DISABLED` and never execute it.

### `pasted_content_3.txt` — MD90 Supreme Battle System

The script is an `indicator()`, so it does not place orders. It uses `request.security()` across D1/H4/H1 and computes trend, momentum, volume, volatility regime, and weighted fusion. However, `momentum_macd = request.security(..., ta.macd(...))` attempts to assign a multi-value MACD result to one variable, while later local MACD correctly destructures a tuple. This requires explicit tuple handling before compile validation.

The fusion signal is a weighted combination of nonnegative binary signals. Consequently `fusion_signal < -0.7` for the sell branch is unreachable, so the advertised symmetric BUY/SELL behavior is not implemented. `account_size = 10000` is explicitly a placeholder at line 131; position sizing therefore cannot be treated as broker or account evidence. Integration decision: MTF/regime parameter concepts may map to a read-only adapter; sell parity and sizing remain `MISMATCH/PENDING` until fixed and fixture-tested.

### `pasted_content_4.txt` — MD90 Mega-Konfluensi

The design separates deterministic timing, HTF scorecard, and low-timeframe trigger. It uses a `bar_index % ml_cycle_period` cycle rather than timestamp/session data, so the MTR phase is dataset-index dependent and not portable across different history windows. The London/NY overlap filter also requires explicit timezone/session validation.

`request.security()` calls for SuperTrend and MACD return tuples but are assigned or indexed in ways that require Pine compiler verification; `f_htf_st_val[0]` is not a safe substitute for tuple destructuring. The semicolon-compressed `if L1_MA == 1; ...` statements are a syntax hazard. The artifact has no order calls, but its phase gate can be represented as a diagnostic only after deterministic time and tuple fixes. Integration decision: `SHADOW_REFERENCE`, no order authority.

### `pasted_content_5.txt` — MATARI-FUSION V9 Institutional Authority Build

This is a Pine `strategy()` and includes direct `strategy.entry()` and `strategy.exit()` calls. It therefore has order-capable semantics in the source and must remain `LIVE_DISABLED` in md90. `ta.adx(14)` is a compile-risk in Pine v5 where explicit DMI/ADX tuple handling is normally required. The `SYS_LIFETIME` and `SYS_DRIFT` logic depends on `timenow` and changes permission based on elapsed wall-clock time, which makes historical replay non-reproducible and can create different decisions for identical candles.

The daily PnL block adds the most recent closed-trade profit on every bar after `strategy.closedtrades > 0`, which can double-count the same trade unless a last-processed trade index is stored. The permission engine correctly expresses several blocks conceptually—regime, loss, session, weekend, cooldown, and open trades—but the lifetime/license-like gate is not a market-evidence feature and must be excluded from canonical signal parity. Integration decision: extract risk/session concepts into a deterministic PAPER policy; exclude lifetime/drift and all direct order calls.

### `pasted_content_6.txt` — MD90 HedgeFusion v1

This is a read-only Pine indicator with explicit H1/M15/M5/M1 bridges and `lookahead_off`, which is a useful no-lookahead intent. It combines EMA direction, structure, liquidity sweep, order-flow proxy, volume, ADX, and ATR levels. However, `structDir()` defines `up` as `lastH > lastL` and `down` as `lastL < lastH`; these conditions overlap whenever both pivots exist, so the function can report up and down simultaneously through the final ternary ordering. This is a structural parity defect.

`showLine()` creates new lines on every bar while active, making line-budget exhaustion likely on long histories. The grid is anchored to current close/ATR rather than frozen signal-bar ATR, so displayed exits can drift after entry. The indicator emits alert conditions but no strategy orders. Integration decision: MTF feature and order-flow proxy can be mapped read-only after structure and object-lifecycle fixes; no order authority.

## XAU/USD signal audit

The supplied signal states `BUY`, entry zone 4980–4990, SL 4950, TP1 5000, score 0.53, confidence 53%, and `MODE: ABORT`. Its own conclusion says **BATAL EKSEKUSI** because RR is insufficient and several layers are neutral. The metadata says `Data Quality: Medium – Visual interpolation digunakan`, which means the price/layer values are not a clean OHLCV evidence series. The signal timestamp is `2026-02-19T02:55:00Z`, while the current audit date is 2026-08-27; it is stale for any current decision.

The stated TP1 RR is internally consistent with a 30-point stop distance and 20-point target distance only as approximately 1:0.67, not 1:0.5; the supplied grid contains multiple target conventions and must be normalized before replay. The 8/17 layer consensus and 73% buyer sentiment are unproven because no source vector, candle manifest, or sentiment provider checksum accompanies the text. Decision: persist as `PAPER_ABORT / VISUAL_INTERPOLATION / STALE / NO_ORDER` only.

## Integration decision matrix

| Artifact | Safe extraction | Canonical status | Blocker |
|---|---|---|---|
| FUSION V6 Pine | Inputs, ATR/RSI/SuperTrend intent, risk ratios | `REFERENCE_ONLY` | Indicator/strategy mismatch, undefined ADX inputs, five-point hardcoded proxy. |
| Mixed Pine/MQL5 | Separate language sections and parameter inventory | `SHADOW_REFERENCE` | Mixed payload, incomplete code, direct order-capable MQL5. |
| Supreme Battle | MTF timeframe intent, regime labels, weighted signal concept | `REFERENCE_ONLY` | Tuple handling, unreachable SELL branch, placeholder account size. |
| Mega-Konfluensi | Phase/gate vocabulary and HTF trigger intent | `SHADOW_REFERENCE` | Time-index dependency, tuple/syntax hazards, no deterministic fixture. |
| Matari-Fusion V9 | Regime/session/risk gate vocabulary | `PAPER_POLICY_CANDIDATE` | Direct strategy orders, `timenow` drift, daily PnL double-count hazard. |
| HedgeFusion | MTF feature pack and read-only alert vocabulary | `PAPER_FEATURE_CANDIDATE` | Structure bug, dynamic line accumulation, no frozen exit evidence. |
| XAU/USD pasted signal | Abort decision and risk discrepancy evidence | `PAPER_ABORT` | Visual interpolation, stale timestamp, no source manifest/vector, no order authority. |

## Required evidence gates

Before any artifact can produce parity `MATCH` or a performance claim, the project requires a separated source file, SHA-256, line range, formula version, symbol/timeframe, expected vector or official fixture, and deterministic replay against a checksum-bound OHLCV manifest. Direct strategy/order calls, broker clients, wallet operations, webhooks, and license-like runtime gates remain excluded from canonical execution.

## Static readiness scan addendum — latest MQL5 payload

A file-based scanner found 25 named functions defined in the supplied MQL5 text, including `OnInit`, `OnDeinit`, `OnTick`, `OnTimer`, `ProcessSignal`, `ExecuteBuy`, `ExecuteSell`, `ManagePositions`, `CheckTimeStop`, `ApplyTrailingStop`, and `OnTradeTransaction`. It found five order-capable call sites: buy at line 971, sell at 1017, position close at 1090, and position modifications at 1146/1163. These are source capabilities only; they are not imported into md90.

The scan also found three timer event references at lines 195, 224, and 278; 52 indicator-handle references; six daily-profit/history references; three time-stop references; and no partial/scale-out keyword, placeholder token, network call, or credential-shaped pattern. The absence of a keyword is not proof of absence of the behavior, so broker-side fill and accounting behavior remain unverified. The scanner intentionally reports candidate calls conservatively and may classify human-readable comments as unresolved; that list is a review aid, not a compiler verdict.

The latest payload is therefore integrated only as a checksum-bound static reference plus an isolated adapter contract. The adapter's deterministic PAPER metrics are canonical replay metrics with extracted parameters, not a claim that the supplied EA compiles or behaves identically in MetaTrader.
