# Official Dukascopy OHLCV Validation Manifest

> Source: Dukascopy historical data feed via dukascopy-node 1.50.0. This report contains real downloaded files; no synthetic or crypto fallback was used.

| Symbol | Bars | UTC start | UTC end | Span days | OHLCV valid | Exact 15m ratio | SHA-256 |
|---|---:|---|---|---:|---|---:|---|
| EURUSD | 3072 | 2026-06-01T00:00:00.000Z | 2026-07-14T23:45:00.000Z | 43.99 | YES | 99.80% | `a5a458ba606e3cb7162982fe184e1e64d2a00f3a4d3e3f99c4bd602cd1e1a1f6` |
| XAUUSD | 2912 | 2026-06-01T00:00:00.000Z | 2026-07-14T23:45:00.000Z | 43.99 | YES | 98.90% | `faa1d247d4d1ba0595b35430db8accb42303377886bac65f354e5a7293987da3` |
