# OMNI Ultra-Detail Reconciliation — md90_superlayerAi

**Tanggal:** 26 August 2026  
**Mode:** Static audit + runtime contract review  
**Authority:** PAPER / SHADOW only  
**Live order, wallet signing, custody, withdrawal, external execution, webhook command, and model promotion:** DISABLED

## 1. Executive finding

Audit ulang menemukan bahwa workspace saat ini menyimpan **85 top-level upload files** yang dipindai secara statis, dengan **53 file berisi 993 flagged lines**. Scanner memeriksa checksum SHA-256, line number, dan lexical surfaces berisiko tanpa mengimpor atau mengeksekusi source pihak ketiga. Kode aktif md90 mencakup **163 file TypeScript/TSX non-UI-boilerplate**. Bukti resmi Dukascopy berada di luar source runtime lokal pada dua file EURUSD/XAUUSD 15m dengan manifest LONG; status data tersebut harus tetap datang dari ingestion manifest persisted, bukan dari angka UI.

> Kesimpulan utama: md90 memiliki fondasi All-in-One yang terhubung pada level canonical contracts, tetapi tidak semua artefak eksternal dapat dijadikan runtime dependency. Artefak network/order/custody tetap reference-only; pure deterministic logic dapat diadaptasi setelah input, checksum, licensing, dan test tersedia.

## 2. Inventory and provenance matrix

| Input class | Evidence found | Audit treatment | Runtime decision |
|---|---|---|---|
| Pine/Python/MQL5/MQH source | Present in static upload inventory; line flags include order, notify, network, tuning, and pure-logic surfaces | SHA-256 + line-level lexical triage; no execution | Pure formulas may be adapted; external execution remains blocked |
| ZIP/source archives | Registry records three archives including `md90_FINAL_VERIFIED.zip`, `md90_ultimate_fusion_v4_FINAL_ARB.zip`, and refactor archive | Archive provenance and capability mapping | Not imported as runtime dependency |
| GitHub references | Registry records 102 URL entries: 78 metadata and 24 unresolved in prior audit | Metadata/reference only; licensing and branch health must be checked per repository | No blind clone, no mutable sync, no GitHub push/release path |
| Official FX/XAU data | Dukascopy EURUSD/XAUUSD 15m exports, 43.99 days, 3,072/2,912 bars, checksums in official manifest | OHLCV validation, continuity, UTC range, checksum, persisted user scope | SHADOW_EXTERNAL/PAPER replay only |
| Instagram/reels | Profile/reel pages hit login wall; content cannot be independently verified from current session | Reference pending; no extraction of claims or strategy authority | No logic or metrics imported |
| Active md90 runtime | 163 TS/TSX files, protected tRPC, Drizzle/TiDB, S3 object storage, typed shared contracts | Typecheck, tests, route/runtime trace, visual capture | Canonical runtime source |

## 3. Line-level risk taxonomy

| Surface | Examples found by scanner | Canonical handling |
|---|---|---|
| ORDER_CUSTODY | MQL5 `CTrade`, `PositionOpen`, `PositionClose`, partial close | Map to trade proposal/fill contract only; outbound route disabled |
| NETWORK | CCXT docs/client references, webhook, provider calls | Treat as reference; no external command or broker authority in md90 |
| NOTIFY | MQL5 notifications, Telegram references | No outbound notification path without separately approved connector and safety review |
| MUTABLE_RELEASE/TUNING | Auto-tuner, self-learner, GitHub sync | Proposal/evidence only; no automatic parameter/model promotion |
| PURE_LOGIC | Data provider, fusion, regime, risk, session, detector functions | Candidate adapters to canonical candle/indicator/risk contracts, subject to parity vectors |
| RUNNER/SHELL | `run.sh`, dashboard runners, test scripts | Static review only; never executed from upload inventory |

The presence of a flagged line is **not proof of a vulnerability or strategy quality**. It means the line requires semantic review. The generated line report is a reproducible triage index, not a replacement for source compilation or a claim that all source behavior has been certified.

## 4. Runtime capability mapping

| Capability | Current md90 implementation | Evidence state |
|---|---|---|
| Dataset ingestion | User-scoped S3/object manifest, OHLCV normalization, checksum and coverage assessor | READY for persisted Dukascopy LONG datasets |
| Numeric parity | Canonical indicators, source-vector registry, artifact checksum/line/formula gate, MATCH/MISMATCH/EVIDENCE_REQUIRED contract | Parser ready; literal expected vectors still required from source artifacts |
| MTFA/confluence | Canonical paper engine and operating orchestrator stages | PAPER/SHADOW evidence |
| Risk | Session/regime/circuit-breaker policies and PAPER risk gate | Advisory/fail-closed |
| Replay | Persisted candle cohort replay with train/test, fee, slippage, drawdown, expectancy and OOS metrics | Measured accounting evidence |
| Cross-instrument attribution | Durable EURUSD/XAUUSD aggregation with instrument/timeframe/regime/risk-block/OOS dimensions | PAPER_DATASET_REPLAY |
| Journal/audit | Workflow event ledger, correlation/causation lineage, user-scoped audit bundle | Ready with export filters/signature |
| External adapters | Shadow/reference boundaries and no-fallback gates | Pending evidence or disabled |
| Live trading/custody | No order bridge, signing, key storage, custody, withdrawal, or broker execution | Permanently disabled for this scope |

## 5. Acceptance gates for 10/10 claim

A 10/10 label is not valid until every gate below has a reproducible artifact or test. The current state is **advanced operating cockpit, not certified live trading system**.

| Gate | Required proof | Current status |
|---|---|---|
| Provenance | Source artifact checksum, line range, formula version, licensing decision | Implemented for submitted vector; source literal values pending |
| Numeric parity | Same dataset checksum plus source expected vector and per-indicator verdict | EVIDENCE_REQUIRED until literal vectors are supplied |
| Multi-instrument replay | Persisted EURUSD/XAUUSD manifests and separate OOS results | Authenticated and measured |
| Comparative attribution | Grouped by instrument, regime, timeframe, risk block, OOS window, checksum | Implemented and durable |
| Audit handoff | JSON/CSV, deterministic signature, filters, redaction | Implemented and protected |
| Strategy adapter certification | Isolated strategy ID, deterministic replay, parameter bounds, no-live test | Not yet implemented for external EA patterns |
| External provider certification | Contract, freshness, failure behavior, independent verification | Pending per provider |
| Live readiness | Broker/exchange authority, key management, custody and order safety | Disabled by design |

## 6. Required next evidence

The only valid path to a `MATCH` verdict is to provide source artifacts or fixtures that contain literal expected indicator values. A repository description, reel view count, popularity, or advertised win rate cannot replace that vector evidence. Once supplied, the artifact loader will compute SHA-256, record line range, bind formula version, persist the vector, and evaluate each indicator against the persisted dataset with explicit tolerance.

External EA skills should be treated as **candidate strategy adapters**, not rejected and not trusted automatically. Their entry/exit/filter/regime/sizing/time-stop ideas can be isolated under a strategy ID, replayed against identical cohorts, and compared to canonical md90 using the same costs, OOS split, and failure-mode taxonomy.

## 7. References

[1]: `docs/audit/OMNI_SOURCE_LINE_FLAGS_2026-08-26.md` — reproducible static line flag inventory.  
[2]: `docs/audit/OMNI_SOURCE_ATOMIC_REGISTER_2026-08-25.md` — source/repository capability registry.  
[3]: `docs/audit/OFFICIAL_DUKASCOPY_LONG_MANIFEST_2026-08-26.md` — official EURUSD/XAUUSD dataset manifest.  
[4]: `docs/audit/validation_2026-08-25_retry_parity.md` — runtime, authenticated, visual, and evidence log.  
[5]: `https://www.instagram.com/cryptoteknikal_id` — profile access was login-gated during reconnaissance.
