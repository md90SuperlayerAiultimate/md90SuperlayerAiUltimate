# ZIP Review — 2026-08-30

## Kesimpulan

`md90_superlayerai_fixed.zip` telah diperiksa secara read-only di direktori karantina. Tidak ada file yang dieksekusi. Arsip berisi project tree lengkap dan `package-lock.json`, tetapi tidak membawa workflow `.github`, target hosting, atau credential deploy yang dapat dipakai secara sah.

Perbandingan terhadap HEAD aktif menunjukkan bahwa sebagian besar perubahan arsip sudah lebih lama daripada source aktif. Forced `manualChunks` pada arsip sengaja tidak diambil karena telah terbukti dapat membentuk circular dependency React pada deployment publik. OAuth/storage hardening, boot fallback, canonical orchestration, dan dokumentasi yang lebih baru pada HEAD aktif juga tidak boleh tertimpa oleh arsip.

Satu perubahan substantif yang lolos review diambil dari arsip: `server/forwardPaperPersistence.ts` sekarang menghitung `dataFreshnessSeconds` dari timestamp equity point terakhir. Sebelumnya persistence risk row menulis nilai `0` secara hardcoded. Perubahan ini menjaga risk ledger agar mencerminkan umur evidence forward-paper yang benar, atau `MAX_SAFE_INTEGER` jika timestamp tidak valid sehingga fail-closed.

## Keputusan per area

| Area | Keputusan | Alasan |
|---|---|---|
| `server/forwardPaperPersistence.ts` | USE | Perbaikan risk freshness berbasis persisted equity timestamp; kecil, terisolasi, dan kompatibel |
| `server/operatingOrchestrator.ts` | REJECT duplicate | HEAD sudah memiliki manifest-based freshness dan audit comments yang lebih lengkap |
| `vite.config.ts` | REJECT | Arsip memulihkan forced vendor chunks yang menjadi penyebab public `createContext` boot failure |
| `client/index.html` | REJECT older version | HEAD memiliki visible boot fallback dan deployment diagnostics |
| `client/src/main.tsx` / `useAuth.ts` | REJECT older version | HEAD memiliki public-safe auth boundary dan storage guard yang lebih baru |
| `package-lock.json` | REJECT | Project menggunakan pnpm lockfile; menambah lockfile kedua dapat menciptakan drift |
| credential/config | REJECT | Tidak ada secret yang boleh diambil dari arsip atau dimasukkan ke Git |

## Dampak kualitas

Perubahan yang diambil meningkatkan **data integrity risk reporting**, bukan win rate. Saat paper session dipersist, risk state tidak lagi menyatakan freshness zero secara palsu. Ini memperkuat auditability dan fail-closed behavior pada data stale. Arsip tidak menambah provider feed, expected indicator vector, atau bukti profitability independen.
