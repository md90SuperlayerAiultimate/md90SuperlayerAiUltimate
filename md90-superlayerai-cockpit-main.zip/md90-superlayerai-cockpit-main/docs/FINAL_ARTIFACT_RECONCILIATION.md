# Final Artifact Reconciliation

## Scope

Dua arsip yang diperiksa secara read-only adalah `md90_FINAL_VERIFIED.zip` dan `md90_ultimate_fusion_v4_FINAL_ARB.zip`. Keduanya masing-masing berisi 143 entry dengan daftar nama yang sama, tetapi 22 file berbeda secara konten. Project aktif md90 memiliki 109 file dalam area client/server/shared/drizzle/docs yang diaudit.

| Artefak | SHA-256 | Hasil |
| --- | --- | --- |
| md90_FINAL_VERIFIED.zip | `831e06d41f3bd4a9ad4cedb36b5b2f0e2eff9bf35460b254b54635b9ffc9e2a0` | Referensi arsitektur, tidak disalin mentah |
| md90_ultimate_fusion_v4_FINAL_ARB.zip | `3e885b942705b3c488b96df882ebc1efdbf2af8c6447e72732513b51d1d98320` | Referensi arsitektur, tidak disalin mentah |

## Keputusan integrasi

Kedua arsip memiliki komponen bernilai seperti modular backtest, risk manager, journal, strategy engine, research agent, dan configuration model. Namun audit menemukan jalur yang menyebut `POLY_PRIVATE_KEY`, `POLY_API_KEY`, `execute_order`, `_execute_binance`, `_execute_polymarket`, serta status `ALL-IN`. Ada pula pipeline yang dapat mengubah keputusan menjadi `executed=true`. Karena md90 saat ini sengaja fail-closed, komponen tersebut **tidak boleh dicopy ke runtime aktif**. Yang dapat diadopsi adalah ide dan kontrak yang dinormalisasi ulang ke PAPER/SHADOW, dengan no-signing, no-deposit, no-withdrawal, dan no-network-order boundary.

Kedua arsip juga menggunakan test yang menanamkan random seed dan mengizinkan status `ALL-IN`, sehingga test tersebut tidak dapat dianggap sebagai bukti performa live. Backtest hanya dapat diadopsi setelah ditambahkan biaya, spread, slippage, out-of-sample split, walk-forward, drawdown, expectancy, dan provenance dataset.

## Gap final version saat ini

| Area | Status md90 | Tindakan |
| --- | --- | --- |
| Paper broker, ledger, journal, equity | Terintegrasi | Pertahankan sebagai canonical runtime |
| Candlestick OHLC dan TradingView | Sedang di-hardening | Validasi visual dan fallback replay |
| Strategy parameters Matari/FUSION | Canonical config ditambahkan | Selanjutnya hubungkan ke evaluator, bukan UI saja |
| LQ, liquidity, DOM, gamma, COT | Research contracts + pending states | Tidak mengubah sinyal sebelum provider verified |
| Backtest engine arsip | Referensi saja | Reimplementasi terkontrol pada paper engine |
| Live broker / wallet signing | Terkunci | Tidak digabung |
| 93% win-rate | Belum terbukti | Validation target saja, sample-size aware |

## Kesimpulan

Final version yang aman adalah **md90 canonical core + selected research contracts + deterministic paper measurement**, bukan union mentah dari dua ZIP. Materi lama memperkaya daftar modul, tetapi jalur eksekusinya membawa risiko yang bertentangan dengan Safe Core.

## Measurement evidence

Canonical replay backtest kini mengambil 24 bar langsung dari `server/paperEngine.ts:getCanonicalReplayPrices`. Dengan 11 trade deterministik, fee 10 bps, slippage 5 bps, dan quantity 0.01, hasilnya adalah 7 win, 4 loss, win rate 63.64%, realized PnL 11.3080, expectancy 1.0280, dan max drawdown 0.01%. Status target 93% adalah `TRACKING`, bukan `MEETS_TARGET`, dan `liveRoute` tetap `DISABLED`.

Runner `scripts/paper-validation.ts` tetap diperlakukan sebagai demo batch simulation terpisah: ia menghasilkan 320 trade lintas instrumen dari `generateDemoBatch()` untuk menguji observability dan ledger behavior, bukan bukti historis market performance. Perbedaan ini sekarang diuji oleh `server/paperReplayBacktest.test.ts` dan tidak boleh digabung sebagai satu angka win rate.
