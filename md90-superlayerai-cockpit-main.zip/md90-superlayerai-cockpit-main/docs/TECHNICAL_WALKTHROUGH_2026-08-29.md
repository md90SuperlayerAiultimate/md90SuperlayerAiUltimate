# md90_superlayerAi — Technical Walkthrough

**Tanggal:** 29 Agustus 2026  
**Status:** Implemented for PAPER/SHADOW; live execution and custody are disabled.  
**Scope:** Signal engine, All-in-One operating cockpit, parity/evidence gates, risk policy, forward-paper execution, persistence, attribution, audit, UI, and validation.

## 1. Cara membaca sistem

md90_superlayerAi bukan satu bot yang langsung mengirim order ke broker. Sistem aktifnya adalah **research-and-paper execution cockpit**: data masuk melalui kontrak canonical, diproses menjadi signal/confluence, diperiksa oleh evidence dan risk gate, kemudian—hanya jika gate lulus—direplay melalui paper broker. Setiap tahap menghasilkan event yang dapat dilacak melalui `correlationId`, checksum, provenance, timestamp, dan user scope.

> Prinsip operasional: **observe → qualify → normalize → parity → confluence → risk gate → paper decision → simulated fill → position/equity → journal → audit**. Jalur live, signing wallet, custody, withdrawal, dan external order submission berada di luar authority runtime dan tetap disabled.

### 1.1 Inventory yang diverifikasi

| Area | Lokasi utama | Fungsi | Status bukti |
|---|---|---|---|
| Router contract | `server/routers.ts` | tRPC query/mutation dan access boundary | Aktif; 67 file test / 183 test lulus |
| Operating orchestration | `server/operatingOrchestrator.ts` | Manifest-to-paper workflow dan event graph | Aktif; protected workflow |
| Forward engine | `shared/forwardPaperSession.ts` | Sequential replay dengan biaya dan fill model | Aktif; PAPER_ONLY |
| Persistence adapter | `server/forwardPaperPersistence.ts` | Session, event, order, fill, position, equity, journal | Aktif bila database tersedia |
| Dataset ingestion | `server/datasetPersistence.ts`, `server/manualDataset.ts` | Manifest dan normalized persisted candles | Aktif; user-scoped |
| Numeric parity | `shared/numericParity.ts`, `server/parityPersistence.ts` | Perbandingan vector indikator dengan expected source | Aktif; evidence-gated |
| Strategy adapters | `shared/strategyAdapters.ts`, `server/strategyAdapterReplay.ts` | Matari/Fusion dan external adapter comparison | PAPER/SHADOW; external feed pending |
| Risk policy | `server/paperEngine.ts`, `shared/protectivePolicy.ts` | Freshness, exposure, loss, drawdown, Survivor Mode | Aktif; fail-closed |
| UI cockpit | `client/src/pages/Home.tsx` | Overview / operating cockpit | Aktif; public snapshot + protected writes |
| UI signal surface | `client/src/pages/SignalRoom.tsx` | Chart, signal, layers, tape, strategy, risk, journal | Aktif; missing evidence = PENDING |
| UI command surfaces | `client/src/pages/WorkbenchSurface.tsx`, `Management.tsx`, `ResearchDesk.tsx` | Replay, risk, management, provenance | Aktif dengan protected actions |
| Audit | `server/auditBundle.ts`, `shared/auditMatrix.ts`, `client/src/pages/AuditMatrix.tsx` | Evidence register dan signed JSON/CSV bundle | Aktif; order route disabled |
| Regression | `server/**/*.test.ts`, `shared/**/*.test.ts`, `client/src/**/*.test.ts` | Safety, data, access, UI contracts | Aktif; 183 test terbaru lulus |

Repository yang diinventaris berisi **236 file TypeScript/TSX**, **31 server test file**, dan **52 file docs** pada saat walkthrough ini dibuat. Angka tersebut adalah inventory lokal, bukan klaim jumlah seluruh artefak eksternal yang pernah dibagikan.

## 2. Route dan authority boundary

### 2.1 Public read surface

`cockpit.snapshot` di `server/routers.ts` menggunakan `publicProcedure`. Route ini boleh membaca context snapshot, demo overview, static paper engine state, shadow observations, news labels, broker read-only state, safety boundary, dan dataset evidence. Jika user tidak authenticated, response secara eksplisit mengembalikan `identity.authenticated: false`, `persistenceState: AUTH_REQUIRED`, dan tidak mengambil user-scoped ingestion.

Snapshot tidak boleh dianggap sebagai bukti bahwa akun user sudah memiliki ledger persistence. Snapshot juga tidak mengubah database. Write path berada pada protected procedures.

### 2.2 Protected command surface

Workflow yang memerlukan manifest user, parity source artifact, forward paper persistence, attribution, adapter comparison, dan audit bundle memakai `protectedProcedure`. Contoh route aktif:

| Route | Input penting | Hasil |
|---|---|---|
| `operating.run` | `ingestionId`, timeframe, expected vector, artifact checksum/line range, idempotency key | Satu canonical operating run |
| `operating.runBatch` | maksimal lima ingestion IDs dan idempotency key | Batch per-ingestion dengan correlation graph terpisah |
| `operating.attribution` | ingestion IDs dan train/test/cost config | Cross-instrument report |
| `operating.adapterComparison` | ingestion IDs dan replay cost config | Perbandingan strategy adapter |
| `audit.bundle` | JSON/CSV, correlation ID, date range | Bundle signed dengan signature hash |
| `audit.matrix` | status, classification, artifact, checksum, search | Filtered audit findings; read-only |
| `audit.parityVectorFromManifest` | ingestion ID, expected vector, tolerance | MATCH/MISMATCH/PENDING parity |

Tidak ada route yang menerima API key broker untuk order live. Credential contract dan broker adapter hanya mendukung read-only market-data scope, dan `executionBoundary("LIVE")` menghasilkan route `DISABLED`.

## 3. Ordered signal-to-paper path

### Tahap 0 — Context selection

`TimeframeContext` menyimpan instrument, base timeframe, dan higher timeframe. `Home.tsx`, `SignalRoom.tsx`, `ResearchDesk.tsx`, dan `WorkbenchSurface.tsx` memakai context yang sama sehingga symbol dan timeframe tidak berubah diam-diam antar surface. `cockpit.snapshot` menormalisasi HTF dan mengembalikan `timeframe.base`, `timeframe.htf`, serta TradingView symbol dalam response.

Pada layer UI, `MarketContextControls` menampilkan instrument, base TF, HTF/MTFA, dan synced state. TradingView hanya read-only: tidak ada credential capture, order route, atau wallet signing.

### Tahap 1 — Source qualification dan manifest

Operator mengunggah atau memilih dataset melalui protected evidence control. Dataset dinormalisasi oleh `normalizeManualHistoricalDataset`, kemudian disimpan sebagai ingestion/manifest dengan symbol, interval, source, bar count, checksum, coverage class, evidence state, dan user ID. Bar harus berisi OHLC valid dan timestamp yang bisa diterjemahkan menjadi UTC date.

`runOperatingWorkflow` mencari manifest dengan `input.userId` dan `input.ingestionId`. Jika tidak ditemukan, sistem membuat state dengan authority `DISABLED`, evidence `BLOCKED`, alasan `MANIFEST_MISSING`, dan tidak melanjutkan ke parity atau execution.

### Tahap 2 — Normalize persisted series

`loadPersistedDatasetForParity` membaca series yang sudah disimpan, bukan data yang diberikan langsung dari browser. Engine memerlukan symbol, interval, checksum, dan candles. Jika status bukan `READY` atau shape series invalid, workflow diblokir dengan `MANIFEST_STALE` atau alasan pemuatan yang relevan.

Dengan cara ini browser tidak dapat menyuntikkan candle mentah ke protected run tanpa melewati manifest persistence dan user scope.

### Tahap 3 — Numeric parity

Parity mempunyai dua input yang harus dibedakan:

1. **Observed vector**, dihitung dari persisted candles oleh engine.
2. **Expected vector**, harus datang dari artefak source-of-truth seperti Pine, MQL5, Python, atau fixture resmi yang diikat ke `artifactName`, `sourceArtifactChecksum`, `sourceLineRange`, dan `formulaVersion`.

Jika expected vector ada tetapi source artifact binding tidak lengkap, `sourceEvidence` menjadi `ARTIFACT_CHECKSUM_REQUIRED` dan parity tidak dianggap ready. Jika expected vector belum dikirim, engine mengevaluasi dengan expected kosong untuk menghasilkan evidence state yang tidak cukup; keputusan berikutnya tetap blocked.

Snippet inti pada `server/operatingOrchestrator.ts`:

```ts
const hasExpectedVector = Boolean(
  input.expected && Object.keys(input.expected).length > 0
);
const sourceEvidence = hasExpectedVector && input.artifactName
  && input.sourceArtifactChecksum && input.sourceLineRange
  && input.formulaVersion
  ? validateSourceVectorEvidence({
      artifactName: input.artifactName,
      artifactChecksum: input.sourceArtifactChecksum,
      lineRange: input.sourceLineRange,
      formulaVersion: input.formulaVersion,
      symbol: persistedSeries.symbol,
      interval: persistedSeries.interval,
      vector: input.expected ?? {},
    })
  : { ok: false, reason: "ARTIFACT_CHECKSUM_REQUIRED" };
const parityReady = hasExpectedVector && sourceEvidence.ok;
```

`evaluateNumericParity` membandingkan observed dan expected memakai tolerance. Verdict MATCH hanya boleh memengaruhi jalur forward jika source evidence terikat dan overall parity MATCH. MISMATCH menjadi finding yang dapat diaudit, bukan alasan untuk mengubah observed value agar cocok.

### Tahap 4 — Confluence dan MTFA

Event `MTFA_CONFLUENCE_EVALUATED` merekam base/HTF pair dan `parityOverall`. Pada implementasi canonical workflow, confluence tidak boleh meng-upgrade parity yang blocked. Jika parity PENDING atau MISMATCH, state tetap menuju audit blocked. Ini menjaga supaya label “bullish consensus” tidak berubah menjadi order candidate tanpa evidence source.

Strategy parameters yang ditampilkan di Signal Room berasal dari shared strategy configuration. Konfigurasi yang telah dipasang mencakup Matari Candle Enhanced + Alpha dan FUSION V9-IMP: RSI, Stochastic, SMA, MACD, HTF confirmation, ATR SL, TP RR, time stop, trailing, dan volume factor. Parameter tersebut adalah policy/configuration evidence; bukan bukti bahwa semua indikator telah parity MATCH terhadap Pine/MQL5 sebelum expected vector source diunggah.

### Tahap 5 — Risk gate

Risk dihitung setelah data freshness diturunkan dari candle terakhir pada manifest yang sedang dijalankan. Implementasi menggunakan `closedAt`, fallback `timestamp`, kemudian `openedAt`. Ini penting: risk freshness tidak lagi membaca legacy snapshot yang tidak terkait dengan manifest aktif.

`evaluatePaperRisk` memeriksa daily loss, gross exposure, drawdown, data freshness, dan policy Survivor Mode. Pada pre-trade operating run, exposure/drawdown/daily loss dimulai dari zero karena belum ada position baru; hal itu tidak boleh dibaca sebagai bukti portofolio selalu sehat.

Jika risk tidak approved, event `PROTECTIVE_POLICY_EVALUATED` menjadi `BLOCKED`, alasan menyertakan `RISK_POLICY_HOLD`, lalu audit event dibuat dengan route `PAPER_SHADOW_ONLY` dan `orderRoute: DISABLED`.

### Tahap 6 — Paper decision dan forward session

Hanya jika parity ready/MATCH dan risk approved, state dapat menghasilkan event `PAPER_DECISION_RECORDED`, `PAPER_FILL_STAGED`, `PAPER_POSITION_PROJECTED`, `PAPER_JOURNAL_PROJECTED`, dan `OPERATING_RUN_AUDITED`. Ini adalah staging dalam paper graph, bukan order broker.

Kemudian `runForwardPaperSession` memutar seluruh persisted candle secara sequential. Engine membaca candle satu per satu sehingga future candle tidak tersedia pada saat signal dibuat.

Kontrak hasil selalu menyatakan:

```ts
{
  mode: "FORWARD_PAPER",
  status: "COMPLETED" | "BLOCKED",
  executionAuthority: "PAPER_ONLY",
  orderRoute: "DISABLED",
  dataQuality: "VALIDATED_OHLC" | "BLOCKED"
}
```

### Tahap 7 — Signal rule dan order intent

Implementasi forward engine saat ini menggunakan aturan deterministik `CLOSE_VS_LOOKBACK`: close candle dibandingkan close candle pada `lookbackBars`. Jika close lebih tinggi, direction LONG; jika lebih rendah, SHORT. Rule ini adalah baseline replay yang dapat diuji, bukan klaim bahwa seluruh strategi 17-layer atau indikator eksternal telah direplikasi.

Quantity dihitung dari equity dikalikan risk fraction dibagi close. Risk fraction dijepit antara 0,5% dan 1%. Quantity nol atau negatif menghasilkan `INVALID_QUANTITY` dan tidak dikirim ke paper broker.

Order intent menggunakan `clientOrderId` deterministic dari symbol, index, dan direction. Ini menjadi kunci idempotency dan audit correlation.

### Tahap 8 — Paper fill model

`PaperBroker.submit` menerima side, quantity, bid, ask, feeBps, dan slippageBps. Forward engine membuat bid/ask dari spreadBps dan memakai ask untuk LONG atau bid untuk SHORT. Fill event menyimpan requested quantity, filled quantity, average price, status, fee, slippage, dan authority `PAPER_ONLY`.

Model ini bukan koneksi exchange. Spread, fee, slippage, dan partial fill adalah accounting assumptions untuk replay; nilai harus dibaca dari config pada report, bukan diperlakukan sebagai kondisi pasar live.

Duplicate order ditangani melalui deterministic client order IDs dan persistence upsert. Jika fill ditolak, event `RECONCILIATION` dibuat dengan state `BLOCKED`, alasan error dipertahankan, dan engine melanjutkan observation tanpa menyamarkan kegagalan sebagai fill.

### Tahap 9 — Position clock dan exit

Saat ada position, setiap candle berikutnya menghasilkan `POSITION_MARK` dengan unrealized PnL, price, dan bars held. Jika `barsHeld >= maxHoldingBars`, engine menutup secara time stop dan membuat journal event `TIME_STOP_REVIEW`. Jika position masih terbuka di akhir dataset, engine membuat `SESSION_CLOSE_REVIEW` pada last valid candle.

Status result menjadi `BLOCKED` jika ada invalid OHLC dan tidak ada simulated fill; jika masih ada fill, result dapat `COMPLETED` tetapi `dataQuality` tetap `BLOCKED` dan `blockedReasons` mempertahankan invalid indices. Ini memungkinkan audit membedakan partial usable replay dari clean dataset.

### Tahap 10 — Equity, comparison, attribution, dan journal

Setiap equity point menyimpan index, equity, drawdownPct, dan timestamp source candle. Perbaikan fixed archive yang dipakai mempertahankan source candle timestamps, bukan menggantinya dengan `Date.now()` untuk tampilan curve.

`compareForwardToBacktest` membandingkan trades, win rate, realized PnL, expectancy, max drawdown, symbol, interval, dan manifest checksum antara OOS backtest dan forward replay. Perbandingan ini bukan bukti profitability; fungsinya mendeteksi divergence antara dua engine/cadence/cost treatment.

Cross-instrument attribution memakai ingestion IDs yang dipilih dan memecah result menurut instrument/cohort. Jika data atau parity tidak tersedia, report mempertahankan PENDING/blocked state.

## 4. Persistence dan idempotency

`persistForwardPaperSession` meng-upsert paper session berdasarkan user dan nama symbol. Event workflow menggunakan event ID dari `correlationId`, event type, index, dan client order ID. Signal memakai correlation plus index. Order memakai deterministic client order ID. Duplicate rerun meng-update record yang sama atau tidak menambah fill kedua.

Ledger persistence mencakup:

| Entity | Disimpan | Idempotency / linkage |
|---|---|---|
| `paperSessions` | equity, peak, PnL, drawdown, trade count | user + session identity |
| `paperWorkflowEvents` | observation, signal, intent, fill, journal, comparison, equity event | eventId + idempotencyKey |
| `paperSignals` | bias, score/confidence baseline, observedAt, provenance | signalId |
| `paperOrders` | venue, instrument, direction, quantity, limit price, status | clientOrderId |
| `paperFills` | quantity, average price, fee, slippage, filledAt | orderId; existing fill checked |
| `paperPositions` | direction, quantity, average entry, mark, bars held | session + instrument + direction |
| `paperEquityPoints` | timestamp, equity, realized/unrealized PnL, drawdown | point event check before insert |
| `paperJournal` | time stop, session close, reconciliation, comparison | linked by session/provenance |
| `paperRiskStates` | daily loss, exposure, drawdown, freshness, liveApproval | session + evaluatedAt |

Database availability is a separate runtime gate. If `getDb()` returns no connection, engine can calculate in memory but persistence response is `database-unavailable`; UI must not represent this as durable ledger proof.

## 5. UI composition

### Overview / Operating Cockpit

`Home.tsx` menggabungkan global context, operating stage strip, delivery/evidence/safety cards, primary command deck, mode selector, data lineage, candle chart, tape, risk, news, dan artifact system map. Filter artifact bekerja case-insensitively pada name, role, status, dan note, tanpa memodifikasi source inventory.

Primary signal tidak lagi menampilkan score/confidence/R:R buatan ketika data tidak ada. `EMPTY_SIGNAL`, missing paper snapshot, dan missing dataset menggunakan label PENDING/evidence required. Hal ini sengaja membuat UI terasa lebih konservatif daripada marketing dashboard.

### Signal Room

Signal Room menerapkan pola reel yang observable dan aman: dense workspace, prominent instrument header, OHLC candlestick replay, headline metrics, risk panel, journal timeline, strategy contract, order tape, source/provenance panel, and locked live pill. Candles berasal dari `projectCandles(data?.primary?.candles)`; bila data tidak ada chart tetap kosong/menunggu, bukan mengisi synthetic bars.

Layer list memisahkan Structure, Momentum, Liquidity, Macro/news, Regime, dan Risk. Missing layer evidence ditampilkan `PENDING`, bukan angka acak. External Cryptoiz/Dynamic Execution feed tetap SHADOW/external sampai provider freshness, permission, dan accuracy gate benar-benar lulus.

### Research / Management / Audit

Research Desk menyatukan strategy registry, evidence checkpoints, news/shadow state, dan research contracts untuk liquidity, DOM/order flow, gamma, COT, dan LQ. Management menampilkan demo paper ledger, heartbeat state, scheduler state, health, credential contract, dan no-order boundary. Audit Matrix memfilter finding berdasarkan status/classification/artifact/checksum/search. Audit bundle mengembalikan JSON/CSV dan signature hash untuk handoff eksternal, tetapi route order tetap disabled.

## 6. Feature classification aktual

| Capability | Classification | Evidence / limitation |
|---|---|---|
| Canonical paper snapshot | RUNNING | Public `cockpit.snapshot`; static/canonical paper state |
| Persisted user manifests | RUNNING when authenticated | Requires operator upload and DB persistence |
| Numeric parity | PARTIALLY WIRED / EVIDENCE-GATED | Engine exists; expected source vector must be uploaded and checksum-bound |
| MTFA/timeframe sync | RUNNING | Shared context + normalized timeframe + read-only TradingView state |
| Matari/Fusion configuration | RUNNING as policy/config | Parameter display and gates exist; parity against original EA requires source vectors |
| Forward paper replay | RUNNING after parity/risk gate | Sequential candle replay with fee/spread/slippage/time stop |
| Paper ledger | RUNNING when DB available | Session/order/fill/position/equity/journal persistence and idempotency |
| OOS comparison | RUNNING | Deterministic backtest-vs-forward comparison with manifest checksum |
| Cross-instrument attribution | RUNNING when protected input exists | Requires selected ingestion IDs and sufficient dataset |
| Cryptoiz adapter | SHADOW / EXTERNAL | Private/provider feed is not independently verified in runtime |
| Dynamic Execution adapter | SHADOW / EXTERNAL | Presentation contract exists; not an execution authority |
| News intelligence | SHADOW / PENDING REVIEW | Source/freshness labels; no unsupported Bloomberg/EIA/Reuters claim |
| TradingView | READ-ONLY | Symbol/timeframe context, no order bridge |
| Demo account | PAPER SIMULATION | No live capital, no customer performance claim |
| 24/7 scheduler | PARTIALLY WIRED / PENDING DEPLOYMENT | Heartbeat contract and scheduler UID surface exist; continuous production certification not proven |
| Audit Matrix | RUNNING | Static authoritative register + filters |
| Signed audit bundle | RUNNING when protected records exist | JSON/CSV response includes signature and correlation filter |
| Live broker order | LIVE-BLOCKED | `executionBoundary("LIVE")` = `DISABLED` |
| Wallet signing/custody/withdrawal | LIVE-BLOCKED | No seed/private key intake, no custody route |
| 93% win rate | NOT A FACT | Target/validation threshold only; no performance claim |

## 7. Error, gap, dan reason implementation

### Resolved in this session

The published deployment exposed a concrete production-only boot failure. Public HTML and assets returned HTTP 200, but the browser root remained empty. Dynamic import reproduced `TypeError: Cannot read properties of undefined (reading 'createContext')` from `vendor-core`, caused by a circular split between `vendor-core` and `vendor-react` produced by manual `manualChunks` rules. The fix removed forced vendor chunk grouping and allowed Rollup to build a single dependency graph without that React cycle.

A second hardening fix moved `useAuth` localStorage persistence out of `useMemo` into guarded `useEffect`, because hardened/private browser contexts may throw on storage access. An inline boot fallback now renders a visible PAPER/SHADOW-only status when module boot rejects. Regression coverage locks the absence of manual vendor grouping, storage guard, public root render, and fallback copy.

The source-level fix is validated by build and tests. A public recheck immediately after checkpoint still showed stale vendor hashes and blank root, indicating that the public domain did not yet consume the newly published no-manualChunks artifact at the moment of observation. The latest truthful status is therefore **source repaired, local build verified, public deployment sync observed as unresolved** until a fresh public bundle hash is seen.

### Open evidence gaps

Expected vectors from original Pine/MQL5/Python artifacts are not automatically invented. They must be extracted from a real uploaded artifact, associated with line range and checksum, then compared to observed vectors. Without this, parity remains `EVIDENCE_REQUIRED`/PENDING.

Independent EURUSD/XAUUSD persisted data may exist in the database, but a runtime paper session is not proof of profitable trading. A valid evidence handoff must include dataset source, coverage, checksum, exact timeframe, fill assumptions, trade count, PnL, expectancy, drawdown, and comparison status. A 93% target is not a result.

Provider claims for Cryptoiz/Dynamic Execution, Bloomberg-like news feeds, and external social/video claims remain classified as external or unverified until a real provider connector and independent evidence test exist. A reel showing a dashboard or a marketing statement does not prove backend logic, live fills, or returns.

## 8. Latest validation record

| Check | Result |
|---|---|
| Vitest | **67 files / 183 tests passed** |
| TypeScript | **Passed** |
| Production build | **Passed** |
| Local root visual | **Passed; cockpit renders** |
| Local Signal Room visual | **Passed; candlestick/replay surface renders** |
| Public deployment visual | **Not accepted; stale/blank symptom observed after publish** |
| Live order path | **Disabled** |
| Wallet/custody/withdrawal | **Disabled** |
| Public profitability claim | **Not certified** |

## 9. Practical next evidence action

To turn the remaining PENDING states into evidence, the operator must use the protected Evidence Command Center to select a persisted EURUSD or XAUUSD manifest, upload the original Pine/MQL5/Python vector artifact or official fixture, fill expected vector values, and run the comparison. The UI should then show artifact checksum, line range, formula version, observed vector, expected vector, tolerance, and verdict. If MATCH, the operator may run PAPER forward replay; if MISMATCH, the system must preserve the discrepancy and block the gated path.

The safe next output is not a live deployment promise. It is an externally handoffable audit bundle with correlation ID, manifest checksum, event graph, risk gate, fills, equity points, journal, comparison metrics, and signature hash.

## 10. Boundary statement

md90_superlayerAi is currently a **PAPER/SHADOW research terminal with an All-in-One operating graph**. It is not certified for live trading, not connected to custody, and does not claim a verified 93% win rate. The architecture can be expanded with independently verified providers and operator-uploaded source vectors, but the evidence state must change before the UI or documentation changes from PENDING to MATCH.
