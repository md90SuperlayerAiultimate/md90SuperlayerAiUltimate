# GitHub CI dan Auto-Deploy Boundary

## Yang aktif

Repository GitHub privat baru `md90SuperlayerAiultimate/md90-superlayerai-cockpit` menjadi target source-control. Repository lama `md90SuperlayerAiultimate/md90_superlayer_ai` tidak ditimpa karena berisi histori bot berbeda dan file yang tidak cocok dengan cockpit. Workflow `.github/workflows/ci.yml` berjalan pada pull request ke `main`, push ke `main`, dan manual dispatch. Workflow menjalankan `pnpm install --frozen-lockfile`, `pnpm test`, `pnpm exec tsc --noEmit`, `pnpm build`, lalu memeriksa bahwa source tidak mengaktifkan `orderRoute: ENABLED` atau `liveApproval: approved`.

Dengan demikian setiap perubahan yang masuk ke `main` memperoleh quality gate yang sama dengan validasi lokal. Concurrency membatalkan run lama pada ref yang sama agar hasil CI tidak saling menimpa.

## Auto-deploy

Hosting Manus tetap menjadi deployment production utama dan tidak memiliki GitHub deploy hook yang tersedia di repository ini. Karena itu workflow GitHub tidak berpura-pura melakukan deploy ke Manus melalui credential yang tidak ada. Push ke GitHub memberi versioned source, CI gate, dan audit trail; checkpoint WebDev tetap menjadi mekanisme publish Manus.

Jika nanti dipilih hosting eksternal, workflow deploy baru boleh ditambahkan setelah provider, environment, target project, dan secret resmi disediakan. Secret harus ditempatkan di GitHub Actions Secrets atau environment protection, tidak di YAML, source, ZIP, issue, atau log. Deploy production harus dipisahkan dari pull request dan hanya berjalan setelah CI sukses pada `main`.

## Batas keamanan

Tidak ada API key broker, wallet seed, private key, custody credential, database password, OAuth secret, atau Manus system secret yang dimasukkan ke repository. Jalur live trading tetap disabled. Workflow hanya menguji build dan guardrail source.

## Runbook push

```bash
git remote add github-cockpit https://github.com/md90SuperlayerAiultimate/md90-superlayerai-cockpit.git
git push -u github-cockpit main
```

Pada environment ini target GitHub lama telah diverifikasi sebagai repository privat milik `md90SuperlayerAiultimate`, tetapi tidak dipakai sebagai target push karena histori dan isinya tidak sesuai. Target cockpit baru dibuat privat agar tidak ada penghapusan data atau force-push terhadap repository lama. Sebelum push final, diff harus ditinjau, secret scan harus bersih, test/typecheck/build harus lulus, dan hanya file source/docs/workflow yang dimasukkan.
