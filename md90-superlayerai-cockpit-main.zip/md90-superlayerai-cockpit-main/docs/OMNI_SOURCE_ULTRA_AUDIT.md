# Omni-Source Ultra-Detail Audit

**Proyek:** md90_superlayerAi  
**Tanggal audit:** 24 Agustus 2026  
**Mode runtime:** PAPER aktif, SHADOW observasi, LIVE dan custody terkunci  
**Tujuan:** menentukan apa yang benar-benar dapat digabungkan dari seluruh artefak tanpa mengubah klaim pemasaran, kode berisiko, atau hasil simulasi menjadi bukti live.

## Kesimpulan eksekutif

Audit ini menemukan bahwa bahan yang tersedia memang kaya secara konsep, tetapi belum merupakan satu sistem yang dapat disatukan dengan cara copy-paste. Dua arsip final memiliki 143 entry dengan nama file yang sama, namun 22 file berbeda secara konten. Keduanya memuat komponen bernilai seperti risk manager, strategy engine, research agent, journal, dan backtest; sekaligus memuat pola yang tidak kompatibel dengan Safe Core md90, termasuk private/API key configuration, private-key signing, withdrawal/deposit, exchange order executors, dan status `ALL-IN`.

Daftar yang dikirim sebagai “100+ repo” berisi **100 URL GitHub**, tetapi audit filesystem menemukan hanya **dua Git repository lokal** (`md90_superlayerai` dan `.nvm`) serta enam snapshot Markdown yang mewakili empat repo unik setelah duplikasi. Artinya, 100 URL tidak sama dengan 100 repo yang telah di-clone, diuji, atau dapat dipertanggungjawabkan lisensinya. Temuan ini adalah salah satu penyebab utama mengapa union arsitektur tidak realistis dan mengapa skor presentasi sebelumnya tidak mencerminkan integrasi substantif.

> **Putusan utama:** final version yang sah bukan union mentah seluruh sumber. Bentuk yang dapat dipertanggungjawabkan adalah **md90 Safe Core + kontrak riset yang dipilih + paper broker deterministik + canonical replay backtest + observability lineage**.

## 1. Provenance artefak

| Input | Bukti yang tersedia | Status provenance | Keputusan |
| --- | --- | --- | --- |
| `md90_FINAL_VERIFIED.zip` | 143 entry; SHA-256 `831e06d41f3bd4a9ad4cedb36b5b2f0e2eff9bf35460b254b54635b9ffc9e2a0` | Arsip supplied, bukan repository history | Audit read-only; tidak disalin mentah |
| `md90_ultimate_fusion_v4_FINAL_ARB.zip` | 143 entry; SHA-256 `3e885b942705b3c488b96df882ebc1efdbf2af8c6447e72732513b51d1d98320` | Arsip supplied, bukan repository history | Audit read-only; tidak disalin mentah |
| GitHub register attachment | 100 URL bernomor, terutama Polymarket, AI trading, broker, backtest, agent, dan research projects | URL register; bukan bukti clone/build/test | Gunakan sebagai candidate register saja |
| Uploaded repo snapshots | TradingAgents, CCXT, Freqtrade, Nautilus Trader; beberapa snapshot duplikat | Snapshot Markdown; tidak cukup untuk lisensi/commit/security penuh | Referensi pola, bukan runtime dependency |
| Kode aktif md90 | Git repository aktif dengan shared/server/client/drizzle/tests | Provenance paling dapat diaudit di workspace | Canonical runtime |

Inventaris mentah disimpan di `md90_artifact_audit/omni_inventory_2026-08-24.txt`, metrik provenance di `md90_artifact_audit/repo_provenance_counts_2026-08-24.txt`, dan temuan statis di `md90_artifact_audit/omni_static_findings_2026-08-24.txt`.

## 2. Rekonsiliasi dua ZIP

Kedua ZIP memiliki struktur nama yang sama, tetapi konten berbeda pada 22 file. Perbedaan itu penting karena satu varian dapat memiliki file `__init__` kosong sementara varian lain memiliki implementasi, dan beberapa file inti seperti executor, client, strategy engine, risk manager, serta statistics engine tetap memuat jalur yang sama. Kesamaan nama file tidak boleh dianggap sebagai kesamaan perilaku.

| Area | Temuan statis | Risiko integrasi |
| --- | --- | --- |
| Execution | `execute_order`, `_execute_binance`, `_execute_polymarket`, executor/client venue | Dapat menyeberang dari signal ke network order |
| Credentials | `POLY_PRIVATE_KEY`, `POLY_API_KEY`, exchange config, secret patterns | Credential leakage dan unauthorized custody |
| DeFi/wallet | wallet, signing, transfer, deposit/withdrawal patterns | Bertentangan dengan no-signing/no-custody md90 |
| Strategy | FUSION/alpha/kelly/sizer dan status `ALL-IN` | Risk posture tidak compatible dengan Survivor Mode |
| Backtest | replay/statistics modules, random seed, outcome generation | Tidak otomatis bebas look-ahead, leakage, atau overfit |
| Research | research agent, journal, cognitive pipeline | Bernilai sebagai observability/pattern; provider authority belum terbukti |
| Runtime | script/run configs, requirements, Railway-style deployment hints | Tidak kompatibel langsung dengan managed React/Express/Tenancy md90 |

### Keputusan file-level

Komponen yang hanya memuat data model, journal, feature calculation, atau risk mathematics dapat di-**ADAPT** setelah ditulis ulang ke TypeScript canonical contracts dan diberi provenance. Komponen yang memiliki network order, signing, private credentials, withdrawal, deposit, atau transfer di-**REJECT** untuk runtime md90. Tidak ada exception untuk label “paper”, “dry run”, atau “all-in”; authority ditentukan oleh call path, bukan nama file.

## 3. Matrix keputusan integrasi

| Komponen sumber | Keputusan | Bentuk integrasi md90 | Acceptance evidence |
| --- | --- | --- | --- |
| Risk manager, sizing, drawdown | ADAPT | Survivor Mode, ATR-aware sizing, exposure/daily-loss/drawdown gates | `server/botContracts.test.ts`, `server/paperEngine.test.ts` |
| Backtest/statistics engine | ADAPT | `runCanonicalReplayBacktest()` dengan fee, slippage, expectancy, drawdown, sample size | `server/paperReplayBacktest.test.ts`, CLI runner |
| Journal/research/cognitive pipeline | ADAPT | Research Desk, evidence lineage, decision journal | Paper overview + research contracts |
| Alpha/Fusion parameters | USE/ADAPT | `shared/strategyConfig.ts`, strategy panel, timeframe contract | Strategy config tests and UI screenshot |
| Candlestick/OHLC | USE/ADAPT | Canonical replay OHLC and SVG renderer | `server/paperEngine.test.ts`, `client/src/lib/candles.test.ts` |
| TradingView | ADAPT | Read-only widget surface, canonical symbol/timeframe mapping | `TradingViewSurface.test.ts`, no order authority assertion |
| Liquidity/DOM/heatmap/gamma/COT/LQ | ADAPT as research | Fail-closed research contracts and freshness classification | `shared/researchContracts.test.ts` |
| Meteora DLMM/Meridian | ADAPT as research | LP/DeFi failure-mode notes only | No wallet/signing route; custody tests |
| Cryptoiz/Dynamic Execution | ADAPT as SHADOW | Provider state, freshness, permission scope, no-order route | Shadow adapter tests; provider remains pending |
| Binance/CCXT exchange credentials | REJECT runtime | Public market-data adapter only | Credential and broker boundary tests |
| Polymarket/CLOB/arbitrage executors | REJECT | No runtime integration | Live/custody boundary tests |
| Private key/seed/signing/transfer | REJECT | No input, no storage, no route | Explicit custody rejection tests |
| UI/layout patterns | ADAPT selectively | Signal Atelier shell, evidence-first workstation, tape/risk rail | Desktop/mobile screenshots and layout contracts |

## 4. Runtime architecture after reconciliation

```text
source snapshot / public feed
        ↓ provenance + freshness + permission scope
canonical research contract
        ↓ fail-closed verification
feature / signal explanation
        ↓ Survivor Mode + exposure + loss + drawdown + latency gates
paper broker / shadow observation
        ↓ immutable ledger, fill, equity, journal, audit trail
Overview / Signal Room / Research Desk / Management Plane

LIVE ORDER, WALLET SIGNING, DEPOSIT, WITHDRAWAL = DISABLED
```

The architecture is now integrated at the boundary level, not merely at the label level. The paper query accepts a canonical base timeframe, the replay engine resamples OHLC, the TradingView widget maps the same interval, and Home/Signal Room consume a shared timeframe context. The external sources remain explicitly external or pending until a real provider contract and timestamped evidence are available.

## 5. Timeframe and chart integrity

The canonical state contains `base`, `htf`, `symbol`, `source`, `timezone`, and `updatedAt`. The default is **15m base / 4h HTF / BINANCE:BTCUSDT / UTC / PAPER_REPLAY**. TradingView maps `15m → 15`, `1h → 60`, `4h → 240`, and `1d → D`. A mismatch state is rendered as `MISMATCH`; the policy text is that paper signal processing pauses rather than silently mixing timeframes.

`paper.overview` accepts an optional timeframe. `paperEngine` resamples the canonical replay prices for 1h, 4h, and 1d requests and returns `overview.timeframe` plus OHLC candles with the matching interval. This is materially different from changing a dropdown label while leaving a 15-minute dataset unchanged.

## 6. Performance evidence and win-rate integrity

The demo batch and canonical replay are separate populations and must remain separate in every dashboard and report.

| Measurement | Dataset | Result/status | Interpretation |
| --- | --- | --- | --- |
| Demo batch | `generateDemoBatch()` across simulated instruments | Observability/ledger exercise; latest production row reported 520 trades and 65.19% win rate | Not historical market evidence |
| Canonical replay backtest | 24 canonical replay bars, deterministic 11 trades | 7 wins, 4 losses, 63.64% win rate, realized PnL 11.3080, expectancy 1.0280, max drawdown 0.01%, fee 10 bps, slippage 5 bps | Reproducible paper evidence on a tiny replay sample |
| Target | Validation policy | 93% = `TRACKING`, never forced | Target is not proof and must not modify outcomes |

The correct conclusion is that a 93% real-trade win rate has **not** been verified. A small deterministic replay can validate accounting, cost application, idempotency, and policy behavior; it cannot establish a production edge. A meaningful claim would require an independently sourced, timestamped, sufficiently long dataset, explicit train/test or walk-forward separation, fees/slippage, missing-data rules, and reproducible run manifests.

## 7. Why the previous result looked like 3/10

| Cause | Observable effect | Corrective action |
| --- | --- | --- |
| Architecture was treated as a union of names | UI displayed modules that were not executable together | Canonical contracts and explicit status matrix |
| 100 repo URLs were treated as 100 audited clones | Provenance and license confidence was overstated | Separate register, snapshot, clone, and verified dependency states |
| Cryptoiz/DEX content was treated as integrated | Private feed accuracy and scope were not verified | Shadow-only provider state, freshness, and pending review |
| TradingView was treated as signal backend | Widget existed but did not drive replay/paper timeframe | Shared timeframe context and paper query input |
| Replay data was limited | Win rate and chart could look impressive without market coverage | Canonical replay backtest with costs and honest sample quality |
| Target win rate influenced presentation pressure | Risk of overclaiming or hiding poor outcomes | Target remains a validation gate only |
| UI was dashboard-first | Panels looked standard and evenly weighted | Workstation hierarchy, candlestick, risk rail, order tape, lineage |
| OAuth E2E was not completed | User-scope persistence was not independently proven | Protected audit route exists; real session remains required |

## 8. Final implementation scope

The safe integrated version includes the canonical paper schema, deterministic paper broker, persistent ledger/equity/journal paths, shadow adapter state, Binance public market-data boundary, Matari/FUSION strategy contract, Survivor Mode, canonical replay backtest, OHLC candlesticks, shared timeframe synchronization, TradingView read-only mapping, Signal Room, Research Desk, Management Plane, bilingual copy foundation, and explicit live/custody locks.

The following are intentionally **not** claimed as complete: private Cryptoiz/Dynamic Execution provider accuracy, real exchange execution, wallet custody, 93% win rate, production alpha, or authenticated user-scope E2E. These are not cosmetic omissions; they require external evidence or a user-authenticated session and cannot be manufactured from supplied archives.

## 9. Evidence index

| Evidence | Location |
| --- | --- |
| Previous artifact reconciliation | `docs/FINAL_ARTIFACT_RECONCILIATION.md` |
| Previous integration matrix | `docs/FINAL_ARTIFACT_AUDIT_MATRIX.md` |
| Readiness and gate status | `docs/FINAL_READINESS_REPORT.md` |
| ZIP checksums and structural audit | `/home/ubuntu/md90_artifact_audit/` |
| Canonical replay runner | `scripts/paper-replay-backtest.ts` |
| Replay implementation/test | `server/paperReplayBacktest.ts`, `server/paperReplayBacktest.test.ts` |
| Timeframe contract/tests | `shared/timeframe.ts`, `client/src/lib/timeframe.test.ts` |
| TradingView boundary/tests | `client/src/components/TradingViewSurface.tsx`, `TradingViewSurface.test.ts` |
| Live/custody boundary/tests | `server/botContracts.ts`, `server/botContracts.test.ts` |

## Final verdict

Secara teknis, md90 sudah mencapai **integrasi boundary-aware PAPER/SHADOW**, bukan integrasi penuh seluruh dunia trading. Itu adalah perbedaan yang penting. Menggabungkan semua artefak secara literal justru akan menurunkan kualitas dan keselamatan karena memasukkan executor, credential paths, dan asumsi venue yang tidak kompatibel. Peningkatan ke kualitas institusional berikutnya harus datang dari data provider yang terverifikasi, dataset historis yang independen, evaluasi walk-forward, dan authenticated persistence E2E—bukan dari menambahkan lebih banyak label atau menyalin lebih banyak repo.

## 10. GitHub register verification

Audit metadata read-only terhadap register yang disuplai mengonfirmasi 100 entry bernomor. Namun, 24 entry tidak berhasil di-resolve oleh GitHub CLI pada waktu audit, dan dari 76 entry yang berhasil di-resolve, field SPDX tidak terdeteksi untuk seluruhnya. Nilai `UNKNOWN` tidak otomatis berarti repository tidak memiliki lisensi; artinya lisensi tidak dapat dikonfirmasi sebagai SPDX melalui metadata yang diambil. Karena itu, tidak satu pun URL tersebut boleh diperlakukan sebagai dependency runtime hanya berdasarkan popularitas atau stars.

Beberapa kandidat populer memang aktif dan memiliki banyak stars, tetapi stars dan `pushedAt` tidak membuktikan kecocokan arsitektur, keamanan execution path, atau lisensi yang kompatibel. Metadata mentah tersimpan di `md90_artifact_audit/github_register_metadata_2026-08-24.tsv`, ringkasannya di `github_metadata_summary_2026-08-24.txt`, dan daftar URL yang diproses di `github_register_repos.txt`. Keputusan per repo yang lebih granular membutuhkan checkout atau source snapshot yang benar-benar tersedia; kondisi itu tidak boleh dipalsukan dari daftar URL.

| Coverage audit | Angka | Makna |
| --- | ---: | --- |
| URL GitHub terdaftar | 100 | Candidate register |
| Repository lokal yang ditemukan | 2 | Bukan 100 clone trading repo |
| Snapshot Markdown GitHub | 6 file / 4 repo unik | Metadata/source snapshot terbatas |
| ZIP final | 2 × 143 entry | Arsip supplied, bukan repo history |
| ZIP content differences | 22 file | Same filename tidak berarti same behavior |
| GitHub metadata errors | 24 | Tidak dapat diverifikasi pada audit ini |
| Successful metadata with SPDX UNKNOWN | 76 | Lisensi belum terkonfirmasi secara machine-readable |

## 11. Ultra-detail decision rule

Sebuah komponen hanya dapat masuk status **USE** jika source, lisensi, dependency, test, dan execution boundary dapat diperiksa. Status **ADAPT** digunakan untuk ide atau algoritme yang ditulis ulang ke kontrak md90, dengan dataset dan provenance baru. Status **FORK** memerlukan source lengkap, lisensi yang mengizinkan fork, dan review dependency; tidak ada komponen ZIP yang memenuhi syarat itu secara otomatis. Status **IDEAS** berlaku untuk konsep yang belum memiliki feed/data contract atau belum dapat direproduksi. Status **REJECT** berlaku untuk private key, signing, transfer, withdrawal, live order, credential authority, atau execution path yang tidak bisa dipagari dengan fail-closed policy.

Dengan aturan ini, artefak memang sudah diambil “untuk kesempurnaan”, tetapi yang diambil adalah **struktur, konsep, kontrak, dan pola observability** yang dapat dibuktikan—bukan jalur berisiko atau klaim performa. Ini adalah cara paling dekat menuju kualitas institusional tanpa mengorbankan auditability.


## 12. Ultra-detail reconciliation update — 25 August 2026

### 12.1 New attachment provenance

The supplied `pasted_content.txt` is a Windows batch recipe containing 100 `git clone` commands. It is not a clone manifest, build log, lockfile, checksum set, license report, or test report. The final `echo ALL 100 REPOSITORIES CLONED!` is therefore treated as an unverified claim. The current filesystem contains the active md90 repository, the previous artifact audit directory, and three ZIP archives, not 100 tested Git working trees.

| Artifact | Count | Current decision |
|---|---:|---|
| `md90_FINAL_VERIFIED.zip` | 143 entries | Read-only audit; no raw runtime import |
| `md90_ultimate_fusion_v4_FINAL_ARB.zip` | 143 entries | Read-only audit; no raw runtime import |
| `md90_refactor_v1.zip` | 152 entries | Read-only audit; reference only |
| Attachment clone commands | 100 URLs | Candidate register; not proof of clone or test |
| Active project tests | 32 test files / 77 tests | Canonical runtime evidence |

### 12.2 Capability and execution-path reconciliation

The archives contain valuable patterns for risk calculation, regime detection, signal fusion, journal, memory, latency, backtest, and recovery. They also expose executor/client modules, credential configuration, private-key and wallet terminology, Polymarket and exchange routes, and deploy scripts that are not compatible with the md90 Safe Core. The governing rule remains call-path based: a function or module is rejected when it can reach a network order, signing, transfer, deposit, withdrawal, or credential authority, even if its filename says `paper`, `dry_run`, or `all-in`.

The current safe adaptations are now concrete rather than presentational: `shared/workflow.ts` produces provenance-bearing stage events and a stable correlation ID; `shared/paperExecution.ts` enforces PAPER state transitions through reconciliation; `server/routers.ts` returns the same workflow and execution state through `cockpit.snapshot`; `paper.decide` is protected and replay-gated; and non-replay instruments return explicit pending/shadow-only state rather than borrowing BTC candles.

### 12.3 Route-level full-version closure

The operator workbench now exposes direct routes for `/market-map`, `/risk-lab`, `/replay`, and `/audit-log`. All four use the same global instrument/base/HTF context and `cockpit.snapshot` contract. Market Map exposes source/freshness/shadow observations; Risk Lab exposes Survivor Mode sizing and protected paper decision; Replay exposes walk-forward out-of-sample evidence; Audit Log exposes workflow events and the paper execution state machine. Unsupported authority is rendered as an explicit lock, not a fake action.

### 12.4 Remaining non-negotiable limits

The following remain pending by evidence, not by UI effort: private Cryptoiz/Dynamic Execution accuracy, authoritative DOM/gamma/COT feeds, independent long historical datasets for every supported instrument, live provider certification, production 24/7 worker registration, and any live/custody action. The 93% target remains a tracking gate. A score of 10/10 cannot be certified from a 24-bar replay, a demo batch, an unverified clone script, or a list of repository URLs.

### 12.5 Evidence index update

| Evidence | Location |
|---|---|
| Attachment recipe audit | `docs/OPEN_SOURCE_GAP_CLOSURE.md` |
| Capability decisions | `docs/CAPABILITY_CONTRACT_MATRIX.md` |
| Full-version gap audit | `docs/ALL_IN_ONE_GAP_AUDIT.md` |
| Unified workflow contract | `shared/workflow.ts`, `server/workflow.test.ts` |
| Paper execution FSM | `shared/paperExecution.ts`, `server/paperExecution.test.ts` |
| Walk-forward adaptation | `server/walkForwardReplay.ts`, `server/walkForwardReplay.test.ts` |
| Lower-surface Workbench | `client/src/pages/WorkbenchSurface.tsx`, `client/src/pages/WorkbenchSurface.test.ts` |
| Latest static audit | `/tmp/omni-static-audit-final.txt` |

**Verdict update:** the project has a stronger, reproducible PAPER/SHADOW vertical slice and real lower-surface routes. It is not yet a complete multi-provider institutional trading platform. The remaining work requires evidence and data that cannot be invented from the supplied artifacts.
