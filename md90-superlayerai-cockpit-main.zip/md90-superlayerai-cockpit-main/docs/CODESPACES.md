# GitHub Codespaces

Repository ini dapat dibuka melalui [GitHub Codespaces](https://codespaces.new/md90SuperlayerAiultimate/md90-superlayerai-cockpit). Pengguna harus login ke GitHub dan memiliki entitlement Codespaces; tautan tersebut tidak dapat membuka private repository bila sesi browser belum terautentikasi.

Konfigurasi `.devcontainer/devcontainer.json` menyiapkan Node 22, pnpm 10.34.4, frozen lockfile install, dan port 3000. Setelah container selesai dibuat, jalankan `pnpm dev` untuk memulai cockpit. Port 3000 dapat dibuka melalui forwarded port Codespaces.

Codespaces adalah lingkungan development. Jangan memasukkan API key, API secret, private key, wallet seed, broker credential, database URL, atau token provider ke Codespaces, terminal, issue, atau commit. Gunakan secret store resmi hanya jika integrasi read-only benar-benar diperlukan dan telah diaudit.

Environment default di container menyatakan `PAPER_SHADOW` dan `DISABLED`. Jalur live order, wallet signing, custody, withdrawal, dan external execution tetap dilarang. Publish production md90_superlayerAi tetap menggunakan checkpoint WebDev, bukan Codespaces.
