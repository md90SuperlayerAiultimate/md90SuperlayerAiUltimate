# Repository Governance 10/10 — 2026-08-30

## Tujuan

Dokumen ini merangkum seluruh saran hardening repository agar kualitas proses engineering dapat naik secara terukur. Skor 10/10 di sini berarti governance, reproducibility, security gate, audit trail, dan deployment boundary dapat dibuktikan; skor ini tidak berarti sistem trading telah menghasilkan profit atau aman untuk live trading.

## Status kontrol

| Kontrol | Status | Bukti atau batasan |
|---|---|---|
| CI pada push/pull request ke `main` | ACTIVE | `.github/workflows/ci.yml`; test, typecheck, build, dan live-boundary guard |
| Dependency audit pada pull request | ACTIVE FALLBACK | `.github/workflows/dependency-review.yml`; `pnpm audit --audit-level=high` lulus dengan 0 high/critical pada lockfile saat ini. Official GitHub Dependency Review mengembalikan unsupported pada private GitHub Free. |
| Secret scan pada push/pull request | ACTIVE | `.github/workflows/secret-scan.yml`; Gitleaks memeriksa working tree dan history |
| Branch protection `main` | BLOCKED BY PLAN | GitHub API mengembalikan 403: private repository membutuhkan GitHub Pro atau repository public |
| Required CI check sebelum merge | BLOCKED BY PLAN | Tidak dapat dipaksa via branch protection pada plan saat ini; CI tetap berjalan sebagai gate informatif |
| Force-push/deletion lock | BLOCKED BY PLAN | Bagian dari branch protection/rulesets yang tidak tersedia pada plan saat ini |
| External auto-deploy | NOT CONFIGURED | Tidak ada provider deploy hook resmi yang diberikan; Manus tetap publish melalui WebDev checkpoint |
| Secret storage | ACTIVE BY POLICY | Tidak ada `.env`, private key, broker credential, atau Manus secret di repository |
| PAPER/SHADOW boundary | ACTIVE | Workflow guard dan source contract mempertahankan live/custody disabled |
| Reproducible local validation | ACTIVE | 67 Vitest files / 183 tests, TypeScript, production build, `pnpm audit --audit-level=high` lulus; audit total masih mencatat 35 low/moderate |

## Arsitektur deployment yang benar

GitHub menjadi source-control dan quality gate. Setiap push ke `main` memicu CI dan secret scan. Pull request memicu CI, dependency audit lokal, dan secret scan. Official GitHub Dependency Review tidak tersedia pada plan private saat ini, sehingga fallback `pnpm audit --audit-level=high` dipakai dan menghasilkan 0 high/critical; 35 low/moderate tetap tercatat untuk backlog. Manus tetap menjadi hosting production project ini dan publish dilakukan melalui checkpoint WebDev. Tidak ada workflow deploy eksternal yang dibuat secara spekulatif karena deploy hook, target project, dan credential provider belum tersedia.

Jika branch protection wajib diterapkan tanpa upgrade GitHub, pilihan yang benar adalah membuat repository public dengan evaluasi ulang risiko informasi atau mengaktifkan GitHub Pro. Saya tidak mengubah repository menjadi public dan tidak force-push repository lama yang berisi histori berbeda.

## Roadmap setelah hardening

Setelah governance dasar tersedia, peningkatan kualitas berikutnya harus mengarah ke evidence trading: expected vectors Pine/MQL5/Python dengan checksum, batch forward-paper EURUSD/XAUUSD, reconciliation exception queue, independent OOS dataset, signed JSON/CSV audit bundle, dan provider freshness tests. Semua tetap PAPER/SHADOW sampai bukti dan approval gate terpenuhi.
