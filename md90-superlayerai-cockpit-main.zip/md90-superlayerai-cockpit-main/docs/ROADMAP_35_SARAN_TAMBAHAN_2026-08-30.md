# 35 Saran Tambahan Menuju md90_superlayerAi 10/10

Dokumen ini menambahkan 35 saran di luar roadmap governance sebelumnya. **10/10 berarti kontrol, evidence, dan operasional dapat diaudit; bukan jaminan keuntungan atau izin live trading.** Status `ACTIVE` sudah diterapkan, `PARTIAL` baru sebagian, `EVIDENCE REQUIRED` menunggu artefak/operator/data nyata, dan `BLOCKED` memerlukan entitlement atau provider resmi.

| No. | Domain | Saran ultra-detail | Status | Kriteria selesai |
|---:|---|---|---|---|
| 1 | Evidence | Tambahkan intake file Pine, Python, MQL5, MQH, TXT, dan JSON melalui UI operator. | ACTIVE | File dibaca lokal, tidak dieksekusi, dan unresolved indicators ditampilkan. |
| 2 | Evidence | Hitung SHA-256 penuh dari artefak source sebelum parity. | ACTIVE | Checksum 64 hex wajib dan tersimpan bersama request. |
| 3 | Evidence | Simpan line range dan formula version untuk setiap expected vector. | ACTIVE | Form parity menolak metadata kosong. |
| 4 | Evidence | Tolak expected vector kosong atau non-numerik. | ACTIVE | Status tetap `EVIDENCE_REQUIRED`, bukan default zero. |
| 5 | Evidence | Tampilkan delta per indikator dan verdict MATCH/MISMATCH. | ACTIVE | Result panel dan history menampilkan row-level verdict. |
| 6 | Evidence | Ikat parity ke checksum manifest dan user scope. | ACTIVE | Server memeriksa ingestion ID, checksum, dan authenticated scope. |
| 7 | Evidence | Tambahkan manifest picker khusus EURUSD/XAUUSD. | ACTIVE | Operator memilih hanya manifest persisted yang terdaftar. |
| 8 | Evidence | Validasi coverage, cadence, OHLC relationship, dan timestamp ascending. | ACTIVE | Dataset invalid diblokir sebelum replay. |
| 9 | Evidence | Tambahkan provenance source timestamp dan received timestamp. | ACTIVE | Freshness dapat dihitung ulang dari metadata sumber. |
| 10 | Evidence | Pisahkan bukti runtime dari klaim marketing/provider. | ACTIVE | Audit matrix memberi status verified, pending, unsupported, atau stale. |
| 11 | MTF | Tampilkan base timeframe, HTF, dan context timeframe secara bersamaan. | ACTIVE | Panel MTFA empat kartu hadir pada TradingView research surface. |
| 12 | MTF | Map interval canonical ke interval TradingView (`15`, `60`, `240`, `D`). | ACTIVE | Mapping diuji unit test dan URL widget read-only. |
| 13 | MTF | Tandai BASE, HTF, dan CONTEXT dengan hierarchy visual berbeda. | ACTIVE | Kartu selected memiliki accent dan status SYNCED. |
| 14 | MTF | Perubahan symbol/base/HTF harus memperbarui global context. | ACTIVE | TimeframeContext menjadi single source of truth. |
| 15 | MTF | Tampilkan status CONNECTING, CONNECTED, dan UNAVAILABLE. | ACTIVE | iframe load/error transition diuji. |
| 16 | MTF | Kunci TradingView sebagai research-only tanpa order capability. | ACTIVE | URL tidak membawa credential/order parameter; footer menyatakan DISABLED. |
| 17 | MTF | Gunakan UTC konsisten pada chart, provenance, dan audit. | ACTIVE | UI dan server menampilkan UTC. |
| 18 | MTF | Tambahkan freshness badge per timeframe ketika dataset canonical tersedia. | PARTIAL | Memerlukan wiring dataset multi-timeframe operator nyata. |
| 19 | MTF | Tambahkan cross-timeframe conflict reason ke risk gate. | EVIDENCE REQUIRED | Memerlukan sample candle multi-timeframe dan policy threshold tervalidasi. |
| 20 | MTF | Simpan correlation ID untuk setiap perubahan context dan replay. | PARTIAL | Workflow correlation aktif; context-change journal perlu evidence operator. |
| 21 | Risk | Hitung daily loss dari equity awal hari UTC, bukan hardcode. | EVIDENCE REQUIRED | Perlu ledger multi-hari dan test boundary reset harian. |
| 22 | Risk | Terapkan kill switch paper jika stale data, spread ekstrem, atau partial-fill anomaly. | PARTIAL | Beberapa gate aktif; scenario test gabungan masih diperlukan. |
| 23 | Risk | Pisahkan gross exposure, net exposure, dan concentration per instrument. | PARTIAL | Gross exposure ada; net/concentration perlu ledger cohort nyata. |
| 24 | Risk | Tambahkan scenario stress gap, spread widening, dan missing candle. | ACTIVE / EVIDENCE REQUIRED | Contracts tersedia; harus dijalankan pada dataset asli. |
| 25 | Risk | Tampilkan alasan setiap risk block pada journal dan UI. | ACTIVE | Block reasons dipersist bersama correlation ID. |
| 26 | Execution | Pertahankan paper fill model fee, spread, slippage, latency, partial fill. | ACTIVE | Unit/integration tests lulus dan order route tetap disabled. |
| 27 | Execution | Uji duplicate command, restart recovery, dan idempotency lintas session. | ACTIVE / EVIDENCE REQUIRED | Contract test aktif; recovery production memerlukan run authenticated. |
| 28 | Execution | Pisahkan intent, accepted fill, rejected order, position, dan close event. | ACTIVE | Ledger schema dan workflow event menyimpan tahap terpisah. |
| 29 | Execution | Larang wallet signing, withdrawal, custody, dan external order submission. | ACTIVE | Safety guard dan source scan tetap wajib hijau. |
| 30 | Data | Tambahkan benchmark dataset independen selain replay internal. | EVIDENCE REQUIRED | Upload sumber nyata dengan checksum dan lisensi. |
| 31 | Data | Simpan dataset besar di object storage, metadata/query di database. | ACTIVE | S3/storage helper dan metadata schema menjadi boundary. |
| 32 | Data | Tambahkan retry/backoff/timeout untuk shadow read-only adapters. | PARTIAL | Contract adapter ada; provider-specific soak test masih pending. |
| 33 | Testing | Tambahkan visual acceptance desktop/mobile pada root, Signal Room, Risk Lab, dan MTF surface. | PARTIAL | Local captures pernah lulus; perlu acceptance ulang setelah MTF uplift. |
| 34 | Testing | Jalankan CI matrix Node/pnpm serta dependency/security scan berkala. | PARTIAL | Main CI dan security scan aktif; matrix multi-runtime belum ditambahkan. |
| 35 | Operations | Tambahkan backup/restore drill, alerting, heartbeat, reconciliation queue, dan incident runbook. | PARTIAL / EVIDENCE REQUIRED | Sebagian contracts ada; drill operasional 24/7 belum disertifikasi. |

## Prioritas implementasi

Prioritas P0 adalah nomor 1–10, 21–22, dan 29 karena menentukan apakah evidence dan risk boundary dapat dipercaya. Prioritas P1 adalah nomor 11–20, 26–28, dan 33 karena meningkatkan observability dan konsistensi MTF. Prioritas P2 adalah nomor 30–35 karena membutuhkan dataset independen, provider, atau drill operasional yang tidak boleh dibuat dengan data contoh.

## Batas tindakan yang tidak diotomatisasi

Upgrade GitHub Pro, perubahan repository menjadi public, pembelian provider, penambahan deploy hook, pengiriman credential, dan pembukaan live order tidak dijalankan tanpa entitlement, target, secret store, serta persetujuan pemilik. Manus tetap menjadi jalur publish melalui checkpoint WebDev; GitHub menjadi source-control dan quality gate.

## Definisi selesai

Saran hanya berstatus selesai jika ada source implementation, test, runtime evidence, dan audit trail yang sesuai. Screenshot, klaim pemasaran, angka target 93%, atau status CI hijau saja tidak cukup untuk menyatakan sistem siap live.
