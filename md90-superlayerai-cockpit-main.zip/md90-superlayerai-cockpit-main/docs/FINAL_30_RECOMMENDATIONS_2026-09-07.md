# 30 Rekomendasi Final md90_superlayerAi

**Tanggal:** 2026-09-07  
**Status:** Final engineering backlog dengan evidence boundary eksplisit  
**Mode:** PAPER/SHADOW only; live order, custody, wallet signing, withdrawal, dan broker execution tetap disabled.

Dokumen ini memisahkan pekerjaan yang sudah tersedia dari pekerjaan yang membutuhkan input operator atau capability hosting. Tidak ada rekomendasi yang boleh dibaca sebagai sertifikasi profit, win rate, atau kesiapan live trading.

## Peta status dan 30 rekomendasi

| No. | Prioritas | Rekomendasi | Status | Kriteria selesai |
|---:|---|---|---|---|
| 1 | P0 | Unggah manifest candle EURUSD dan XAUUSD dengan sembilan interval canonical: M1, M3, M5, M15, M30, H1, H4, D1, 1M. | Operator-required | Semua file memiliki checksum, coverage, timezone, OHLCV valid, dan provenance.
| 2 | P0 | Simpan parent checksum dan formula resampling untuk interval derived seperti M3, M30, H4, dan 1M jika sumber tidak menyediakan interval native. | Implement next | Derived tidak pernah disamarkan sebagai source-native.
| 3 | P0 | Unggah source Pine/MQL5/Python asli atau fixture expected vector resmi. | Operator-required | File asli, SHA-256, line range, formula version, dan expected vector tersedia.
| 4 | P0 | Jalankan parity terhadap manifest terpilih dan hasilkan MATCH/MISMATCH hanya ketika expected vector lengkap dan provenance valid. | Implemented contract | Verdict per indikator, tolerance, delta, dan alasan tercatat.
| 5 | P0 | Tambahkan cohort-level parity agar sembilan timeframe dapat dinilai sebagai satu evidence set. | Implement next | Cohort ID, coverage, konflik lintas-TF, dan verdict agregat tersedia.
| 6 | P0 | Tambahkan audit OHLCV: high/low containment, positive volume, monotonic timestamp, cadence, gap, dan duplicate candle. | Implemented partly | Dataset invalid berhenti sebelum persistence/replay.
| 7 | P0 | Tambahkan timezone/session policy yang eksplisit untuk FX dan XAUUSD. | Implement next | UTC storage, broker session, weekend gap, dan DST policy terdokumentasi.
| 8 | P0 | Tambahkan freshness policy berbeda untuk replay historis, forward paper, dan shadow feed. | Implemented partly | Gate menggunakan policy sesuai use case, bukan satu threshold global.
| 9 | P0 | Pastikan idempotency memakai user, symbol, interval, source, checksum, dan cohort identity. | Implemented partly | Upload ulang tidak menggandakan dataset atau event.
| 10 | P0 | Tambahkan reconciliation queue untuk partial-fill, duplicate command, stale manifest, dan incomplete cohort. | Implemented partly | Semua exception memiliki correlation ID, owner, state, dan resolution note.
| 11 | P1 | Tambahkan cross-timeframe conflict matrix untuk trend, timestamp, cadence, dan freshness. | Implemented partly | Conflict reason code terlihat di UI dan audit bundle.
| 12 | P1 | Tambahkan forward-paper replay per instrument dengan fee, spread, slippage, drawdown, expectancy, dan sample size. | Implemented partly | Replay menyimpan input manifest checksum dan output accounting.
| 13 | P1 | Pisahkan OOS train/test dari in-sample dan tampilkan leakage guard. | Implemented partly | Window overlap dan future-data leakage ditolak.
| 14 | P1 | Tambahkan benchmark independen untuk EURUSD dan XAUUSD. | Operator-required | Benchmark memiliki source berbeda atau documented source limitation.
| 15 | P1 | Tambahkan regime attribution: trend, range, high-volatility, news-lock, dan stale-data block. | Implement next | Attribution dapat difilter per regime dan risk-block reason.
| 16 | P1 | Tambahkan risk budget per instrument dan portfolio-level exposure cap. | Implemented partly | Aggregate exposure tetap fail-closed di paper workflow.
| 17 | P1 | Tambahkan fee/slippage scenario grid dan sensitivity report. | Implement next | Hasil menunjukkan rentang konservatif, bukan satu angka promosi.
| 18 | P1 | Tambahkan kill-switch paper workflow dan operator acknowledgement untuk exception kritis. | Implemented partly | Tidak ada transition tanpa gate atau acknowledgement.
| 19 | P1 | Tambahkan signed JSON/CSV audit bundle dengan event graph, checksum, metrics, risk gate, journal, dan correlation ID. | Implemented partly | Signature hash dapat diverifikasi oleh auditor eksternal.
| 20 | P1 | Tambahkan retention/backup policy untuk manifest, source artifact, parity, journal, dan replay output. | Implement next | Restore drill dan retention evidence tercatat.
| 21 | P1 | Sinkronkan branch main GitHub dengan commit `67e59c4c` tanpa force-push. | Completed | Remote main diverifikasi pada SHA `67e59c4c`.
| 22 | P1 | Aktifkan branch protection setelah repository public atau GitHub Pro tersedia. | Blocked by plan | Required CI, review, conversation resolution, dan force-push lock aktif.
| 23 | P1 | Perbaiki Dependabot noise dan audit low/moderate advisories secara triage. | Open | Semua advisory memiliki owner, severity rationale, dan remediation/acceptance note.
| 24 | P1 | Pastikan Gitleaks/secret scan dan dependency audit berjalan pada setiap PR. | Implemented partly | Workflow hijau pada commit terbaru dan output tersimpan.
| 25 | P1 | Tetapkan provider deployment resmi, secret store, rollback target, dan health-check endpoint sebelum deploy hook. | Operator-required | Deploy hook tidak aktif sebelum empat komponen tervalidasi.
| 26 | P1 | Untuk proses 24/7, gunakan hosting always-on terkelola hanya setelah biaya dan batas resource disetujui. | Approval-required | Reserved instance 1 vCPU/512 MB dipilih atau alternatif disetujui.
| 27 | P1 | Tambahkan heartbeat idempotent, watchdog, restart policy, dan alert untuk dataset ingestion/replay. | Implemented partly | Duplicate run dan silent failure terdeteksi.
| 28 | P2 | Tambahkan performance/observability dashboard: latency, ingest rate, error rate, queue age, DB health, dan storage health. | Implement next | Metrics memiliki timestamp, source, dan retention.
| 29 | P2 | Tambahkan authenticated acceptance test untuk upload manifest, persisted cohort, parity verdict, audit export, dan rollback. | Implemented partly | Test menggunakan session operator dan tidak mengaktifkan live route.
| 30 | P2 | Buat release gate final: evidence complete, tests green, audit clean, rollback tested, dan operator sign-off. | Implemented contract | Release tidak dapat dipromosikan hanya karena UI terlihat siap.

## Status dataset nyata

Dukascopy menyatakan Historical Data Export menyediakan data Forex, komoditas, dan instrumen lain dalam CSV dengan rentang tick hingga monthly, tetapi halaman export bersifat interaktif dan bytes dataset, tanggal, serta checksum belum tersedia di workspace.[1] TraderMade secara eksplisit mencantumkan EURUSD dan XAUUSD serta interval minute/hourly/daily; free plan yang tertulis membatasi minute hingga dua hari, hourly hingga dua bulan, dan daily hingga lima tahun.[2] Karena itu sistem tidak mengarang sembilan dataset dan tetap menunggu file operator atau proses export yang menghasilkan checksum.

## Readiness hosting 24/7

Mode Autoscale saat ini memadai untuk web cockpit dan request-scoped workflow. Proses always-on memerlukan Reserved Hosting: satu proses persistent 24/7, 1 vCPU, dan 512 MB RAM. Batas atas compute yang terdokumentasi adalah sekitar **$37,50/bulan sebelum kredit $10/bulan**, ditambah egress dan volume berbasis penggunaan.[3] Reserved Hosting tidak sama dengan mengaktifkan live trading; order route, credential exchange, wallet signing, custody, dan withdrawal tetap harus disabled.

| Opsi | Cocok untuk | Trade-off | Keputusan sekarang |
|---|---|---|---|
| Autoscale | Cockpit, authenticated API, batch operator, cron/heartbeat ringan | Cold start dan request timeout | Tetap default |
| Reserved Hosting | Worker 24/7, polling sub-menit, WebSocket/SSE, watchdog | 1 vCPU/512 MB; biaya usage-based hingga sekitar $37,50/bulan sebelum kredit | Menunggu persetujuan operator |
| Cloud computer | Docker, fixed IP, root access, custom runtime, resource di atas batas WebDev | Operasional dan biaya terpisah | Tidak diperlukan untuk workload saat ini |

## GitHub dan deployment

Remote GitHub telah dipulihkan melalui autentikasi resmi dan `main` berhasil disinkronkan ke `67e59c4c`. Branch protection masih belum aktif karena repository private belum memenuhi capability enforcement yang diperlukan. Deploy hook tidak boleh dibuat sebelum provider, secret store, rollback, dan health-check ditentukan.

## References

[1]: https://www.dukascopy.com/swiss/english/marketwatch/historical/ "Dukascopy Historical Data Export"
[2]: https://tradermade.com/download-forex-data "TraderMade Free Forex Data"
[3]: https://www.dukascopy.com/swiss/english/marketwatch/historical/ "Dukascopy historical data and export information"
