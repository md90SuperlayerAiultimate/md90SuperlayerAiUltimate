
## Kandidat 1 — NautilusTrader

**URL:** https://github.com/nautechsystems/nautilus_trader  
**Metadata yang diverifikasi:** repository aktif, default branch `develop`, lisensi LGPL-3.0, Rust-native dengan Python control plane, arsitektur event-driven deterministik, multi-asset/multi-venue, dan test Rust/Python.  
**Relevansi:** sangat kuat untuk pola event bus, order/fill lifecycle, reconciliation, multi-venue data model, dan deterministic simulation.  
**Boundary:** repository juga mencakup adapter venue/live-execution; tidak boleh diimpor sebagai runtime executor md90. Hanya pola domain/state machine yang dapat ditulis ulang ke TypeScript Safe Core.  
**Keputusan awal:** ADAPT, bukan dependency runtime; wajib review LGPL compatibility, dependency surface, dan pemisahan execution authority.

## Kandidat 2 — Backtrader

**URL:** https://github.com/mementum/backtrader  
**Metadata yang diverifikasi:** repository aktif tetapi commit terbaru yang terlihat bertanggal 19 April 2023, lisensi GPL-3.0, Python backtesting library, dan direktori `tests`, `samples`, serta feed Yahoo dalam README.  
**Relevansi:** berguna sebagai referensi konsep data feed, strategy loop, indicator, analyzer, dan chart/backtest separation.  
**Boundary:** GPL-3.0 dan usia maintenance membuatnya tidak cocok sebagai dependency runtime langsung di aplikasi React/Express md90; tidak memberi bukti walk-forward modern atau multi-venue contract yang diperlukan.  
**Keputusan:** IDEAS/ADAPT only; jangan menyalin kode atau memasukkan GPL runtime tanpa legal review. Prioritas integrasi rendah dibanding Nautilus pattern dan native md90 contracts.

## Kandidat 3 — Freqtrade

**URL:** https://github.com/freqtrade/freqtrade  
**Metadata yang diverifikasi:** repository sangat aktif, branch `develop`, lisensi GPL-3.0, Python crypto trading bot dengan backtesting, plotting, money management, strategy optimization, web UI/Telegram control, multi-exchange support, persistence berbasis SQLite, dan direktori tests.  
**Relevansi:** pola strategy lifecycle, backtest/plot, money management, persistence, dan test organization dapat menjadi referensi untuk paper observability dan replay UX.  
**Boundary:** ini adalah bot yang mencakup exchange control dan live trading capability; GPL-3.0 serta jalur order/credential menjadikannya tidak cocok sebagai runtime dependency md90.  
**Keputusan:** ADAPT as patterns only; tidak menyalin executor/exchange client, tidak memakai GPL code sebagai dependency, dan mempertahankan `paper.decide` sebagai satu-satunya decision route.

## Kandidat 4 — VectorBT

**URL:** https://github.com/polakowo/vectorbt  
**Metadata GitHub:** repository aktif, sekitar 8.8k stars pada pemeriksaan, commit terbaru 2 Agustus 2026, dan metadata GitHub menampilkan lisensi `Other`—bukan lisensi SPDX permisif yang dapat langsung diasumsikan.  
**Relevansi:** vectorized backtesting dan eksplorasi banyak strategi berpotensi membantu desain replay/walk-forward dan comparison view.  
**Keputusan:** IDEAS only sampai lisensi lengkap dan dependency terms diverifikasi; tidak dipasang sebagai dependency runtime.

## Kandidat 5 — TypeScript event-sourcing

**URL:** https://github.com/Brenopms/ts-event-sourcing  
**Metadata GitHub:** repository aktif, MIT, tetapi kecil dengan sekitar 8 stars pada pemeriksaan.  
**Relevansi:** typed event store/projection pattern berpotensi menjadi referensi untuk correlation ID, aggregate transition, dan audit projections.  
**Keputusan:** ADAPT pattern only; md90 sudah memiliki `shared/workflow.ts` dan `shared/paperExecution.ts`, sehingga tidak perlu menambah dependency kecil yang belum battle-tested.

## Shortlist conclusion

Kandidat yang paling bernilai bukan otomatis yang harus dipasang. NautilusTrader memberi pola event-driven dan reconciliation paling kaya; Freqtrade memberi pola strategy/backtest/persistence tetapi GPL dan memiliki live path; Backtrader memberi konsep backtest tetapi lebih tua dan GPL; VectorBT memberi ide vectorized research tetapi lisensinya belum cukup jelas dari metadata; TypeScript event-sourcing memberi pola typed namun belum cukup matang. Safe Core md90 tetap menjadi runtime; hasil audit dipakai untuk menutup kontrak, bukan copy-paste repository.

## Integrasi yang benar-benar diterapkan

Berdasarkan pola NautilusTrader untuk deterministic event-driven processing serta ide VectorBT/Freqtrade tentang replay analysis, md90 menambahkan `server/walkForwardReplay.ts`. Implementasi ini memakai `getCanonicalReplayPrices()` yang sama dengan paper backtest, membagi train/test windows, menghitung out-of-sample trades, wins, PnL, dan win rate, lalu mengembalikan `liveRoute: DISABLED`. Hasilnya sekarang masuk ke `cockpit.snapshot` dan tampil sebagai OOS WALK-FORWARD di Overview. Ini adalah adaptasi kontrak TypeScript md90, bukan penyalinan kode repository.

## Batas evidence

Walk-forward dengan canonical replay 24 bar hanya membuktikan determinisme dan accounting pada sample kecil. Ia belum membuktikan edge pasar, 93% win rate, atau kesiapan live. Untuk menaikkan kualitas evidence, md90 masih membutuhkan dataset historis independen yang cukup panjang, manifest run, train/test separation yang lebih besar, dan provider data yang terverifikasi.

## References

[1]: https://github.com/nautechsystems/nautilus_trader "NautilusTrader — deterministic event-driven trading engine"
[2]: https://github.com/freqtrade/freqtrade "Freqtrade — open-source crypto trading bot"
[3]: https://github.com/mementum/backtrader "Backtrader — Python backtesting library"
[4]: https://github.com/polakowo/vectorbt "VectorBT — vectorized backtesting engine"
[5]: https://github.com/Brenopms/ts-event-sourcing "TypeScript event-sourcing library"

## Attachment audit — `pasted_content.txt`

Attachment ini adalah Windows batch script yang mendeklarasikan 100 perintah `git clone` menuju folder lokal `C:\Users\Asus\Desktop\md90-Superlayer\md90_v4`. Script tersebut mengelompokkan sumber ke TradingView MCP, Nango, agent skills, Polymarket, AI trading agents, arbitrage, copy trading, market making, analytics, weather/sports markets, backtesting, risk/Kelly, Telegram, dashboard/CLI, agent frameworks, dan library trading umum.

Script merupakan **intent/recipe**, bukan evidence execution: tidak terdapat log clone, commit SHA, license manifest, dependency lock, test output, checksum, atau hasil security scan. Karena itu, klaim “ALL 100 REPOSITORIES CLONED” pada baris akhir tidak diperlakukan sebagai fakta provenance. Audit filesystem sebelumnya menemukan hanya dua Git repository lokal dan register URL, bukan 100 clone teruji.

| Attachment class | Decision | Reason |
|---|---|---|
| Official/public docs, read-only market-data clients, backtest concepts | ADAPT/REFERENCE | Dapat ditulis ulang ke contract md90 setelah license/source/test review |
| Agent frameworks and MCP connectors | IDEAS/ADAPT | Tidak menjadi trading authority; requires tool allowlist, timeout, provenance, and no credential escalation |
| Polymarket/DEX/arbitrage/copy-trading executors | REJECT runtime | Network order, credential, signing, custody, or live execution path |
| Script itself | AUDIT ONLY | Recipe tanpa clone logs atau reproducible provenance |

The script adds no new verified runtime capability. Its useful contribution is a more complete candidate register; its main risk is provenance overclaim and indiscriminate cloning of execution-capable repositories.
