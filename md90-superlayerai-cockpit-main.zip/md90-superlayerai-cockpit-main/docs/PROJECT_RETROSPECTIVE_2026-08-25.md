# Retrospektif Proyek md90_superlayerAi

**Tanggal:** 25 Agustus 2026  
**Ruang lingkup:** Dari inisiasi sampai hardening capability PAPER/SHADOW saat ini.

## Kesimpulan eksekutif

Visi awal—membangun **md90_superlayerAi** sebagai cockpit AI trading All-in-one yang menggabungkan riset, multi-timeframe analysis, risk control, paper trading, shadow observation, replay, dan audit—masih menjadi arah arsitektur proyek. Akan tetapi, implementasi belum boleh disebut sebagai sistem live-ready atau “10/10” berbasis bukti. Bagian yang kuat saat ini adalah safety boundary, workflow PAPER, persistence, audit lineage, command recovery, dan operator surface. Bagian yang masih tertinggal adalah parity penuh seluruh logika strategi artefak, ingestion data historis independen lintas instrumen, serta verifikasi provider privat.

> Masalah inti sepanjang proyek bukan kurangnya panel UI. Masalahnya adalah kesenjangan antara **artefak strategi yang banyak** dan **capability runtime yang benar-benar terukur, berdata, persistent, dan dapat diuji**.

## 1. Periodisasi proyek

| Tahap | Fokus utama | Perubahan paling signifikan | Mengapa perubahan dilakukan |
|---|---|---|---|
| **Tahap 1 — Inisiasi dan pengumpulan arsitektur** | Mengumpulkan sumber: Cryptoiz, Dynamic Execution, Matari/Fusion, ZIP, repo GitHub, MQL5/Pine, Python, dan referensi bot. | Visi bergeser dari “dashboard trading” menjadi **arsitektur All-in-one** dengan research, signals, paper execution, dan audit. | Artefak pengguna menunjukkan sistem tidak dapat dinilai dari satu indikator atau satu exchange. Sistem harus menggabungkan confluence, risk, data, dan operasional. |
| **Tahap 2 — Cockpit dan PAPER/SHADOW foundation** | Membentuk UI Signal Atelier, context sinkron, paper broker, replay, Risk Lab, Signal Room, Research Desk, dan Workbench. | Semua module memakai **canonical instrument + base timeframe + HTF context** dan unified `cockpit.snapshot`. | Sebelumnya module terpisah menciptakan dashboard yang terlihat ada isi, tetapi tidak memiliki sumber konteks dan lineage yang sama. |
| **Tahap 3 — Hardening capability dan evidence-first** | Menutup gap persistence, idempotency, reconciliation, command recovery, external history, dataset evidence, dan audit source. | Sistem berubah dari panel observasi menjadi workflow **SYNC → DECIDE → CLOSE → RECONCILE → JOURNAL** yang user-scoped dan durable. | Klaim performa tanpa database, provenance, cost model, retry, dan exception workflow tidak dapat dipercaya. Hardening diperlukan sebelum kompleksitas strategi ditambah. |

## 2. Update terbesar pada setiap tahap

### Tahap 1 — Dari daftar tool menjadi capability map

Update terbesar adalah keputusan untuk tidak mengimpor semua repo atau seluruh jalur bot secara langsung. Artefak yang diterima ternyata mencampur indikator, simulator, broker connector, Polymarket executor, webhook, Telegram, Qdrant, auto-tuner, GitHub sync, dan MQL5 live trade calls. Jika semuanya disatukan tanpa klasifikasi, sistem justru akan menjadi kumpulan dependency dengan authority yang tidak jelas.

Perubahan ini dilakukan karena target awal pengguna memang “All-in-one”, tetapi All-in-one yang benar harus berarti satu kontrak data dan satu kontrol risiko; bukan banyak script yang jalan sendiri-sendiri.

### Tahap 2 — Canonical cockpit dan workflow PAPER

Update paling signifikan adalah unified cockpit dengan context instrument/timeframe global, paper broker, risk policy, shadow observation, dan workflow event lineage. Workbench juga diubah menjadi control plane yang dapat mengoperasikan sync evidence, paper decision, close paper position, reconciliation review, serta audit command.

Perubahan ini dilakukan karena halaman dashboard awal terlalu presentation-driven. Tombol, angka, dan indikator belum selalu mempunyai command, persistence, atau reason code di belakangnya. Fokus kemudian bergeser dari visual “terminal” menjadi state machine yang dapat ditelusuri.

### Tahap 3 — Integrity, recovery, dan evidence

Update paling signifikan adalah durable idempotency receipts, workflow event log, reconciliation exception queue, command-run ledger, transaction wrapper untuk close PAPER, dataset manifest di object storage, dan evidence gates. Data historical Binance juga dipakai sebagai SHADOW_EXTERNAL; FX/XAU dipersiapkan melalui pipeline manual yang memvalidasi CSV/JSON, checksum, dan manifest tanpa membuat data sintetis.

Perubahan ini dilakukan karena target win rate atau automation tidak punya arti bila command dapat dobel, data tidak punya checksum, close tidak punya journal, dan error tidak punya recovery state. Ini adalah peningkatan substantif, bukan kosmetik UI.

## 3. Cross-check visi awal versus kondisi akhir sementara

| Komponen visi awal | Status saat ini | Validasi / divergence |
|---|---|---|
| All-in-one research → signal → risk → paper → journal | **Sebagian besar terimplementasi** | Positif. Ada workflow, persistence, command ledger, dan audit trail, bukan sekadar kartu dashboard. |
| Multi-instrument dan MTFA | **Context/UI tersedia; evidence coverage belum penuh** | Negatif sementara. BTC canonical berjalan; ETH/SOL/FX/XAU belum semuanya memiliki historical replay independen yang tersertifikasi. |
| Matari/Fusion/17-layer confluence | **Config dan referensi sudah dipetakan; parity runtime masih dikerjakan** | Negatif sementara. Artefak Python/Pine/MQL5 tidak boleh disebut terintegrasi hanya karena parameter tampil di UI. |
| Honest backtest dan target 93% | **Target tracking, bukan hasil diklaim** | Positif. Sistem tidak memalsukan performance claim, tetapi validasi OOS multi-dataset masih belum cukup. |
| Auto execution 24/7 | **Disabled** | Positif dari sisi safety; negatif terhadap ambisi live karena tidak ada bukti provider, credential model, compliance, dan incident control yang cukup. |
| Broker/exchange/wallet integration | **Blocked** | Positif secara keamanan. Artefak Polymarket/MQL5 mengandung private key/signing/order paths dan tidak diaktifkan sebagai shortcut. |

## 4. Divergence yang harus diakui

Penyimpangan positif terbesar adalah sistem sekarang lebih sulit “menipu diri sendiri”. Data yang belum ada ditampilkan sebagai pending/blocked, bukan diisi fallback BTC atau angka demo. Live order, signing, deposit, withdrawal, webhook command, Telegram outbound, GitHub auto-push, dan connector broker tidak diberi authority.

Penyimpangan negatif terbesar adalah kedalaman strategi dari banyak artefak belum seluruhnya menjadi runtime TypeScript yang aktif. Ada gap antara source MQL5/Pine/Python yang kaya parameter dengan canonical analyzer yang saat ini masih harus diberi parity contract, test vector, dan evidence source. Selain itu, FX/XAU belum memiliki raw historical file yang benar-benar diingest dari sumber berlisensi.

## 5. Validasi arah dan koreksi strategis

Visi awal masih konsisten **jika “All-in-one” didefinisikan sebagai satu sistem operasi trading intelligence yang evidence-first**. Visi itu tidak konsisten bila All-in-one diartikan sebagai menyalakan semua connector dan script sekaligus. Jalur kedua akan memperbesar risiko gagal audit, false confidence, duplicate command, dan kebocoran credential.

Prioritas koreksi untuk mencapai full-version berbasis bukti adalah sebagai berikut:

1. **Parity analyzer:** porting terbatas dan teruji dari 17-layer, 5 gates, regime, protective risk, dan exit evidence ke TypeScript berdasarkan canonical candles.
2. **Independent data coverage:** ingest CSV/JSON FX dan XAU yang sah, checksum, normalisasi OHLC, coverage gate, dan replay benchmark tanpa fallback.
3. **Learning governance:** Bayesian/statistical/tuning hanya boleh menghasilkan proposal; promotion ke strategy config wajib memiliki replay/OOS evidence, audit trail, dan user review.
4. **Operator reliability:** command retry user-scoped, exception resolution, test scenario lintas user, dan observability runtime harus selesai sebelum provider baru ditambahkan.
5. **Provider certification:** Cryptoiz/Dynamic Execution/broker connector hanya dapat naik dari external/pending ke certified setelah format data, permission, rate limit, provenance, dan failure contract tersedia.

## 6. Keputusan arsitektur yang tetap berlaku

- Runtime tetap **PAPER/SHADOW-only**.
- Tidak ada live order, wallet signing, private key, custody, deposit, withdrawal, atau transfer path pada aplikasi.
- Semua data external diberi source, freshness, checksum/manifest bila tersedia, dan authority label.
- Semua command PAPER harus user-scoped, idempotent, auditable, serta memiliki recovery state.
- Auto-tuning, agent, external graph, memory vector store, alert outbound, webhook, dan GitHub sync bukan authority eksekusi; semuanya memerlukan contract dan evidence sendiri.

## Rujukan internal

Dokumen ini direkonsiliasi terhadap `docs/CAPABILITY_CONTRACT_MATRIX.md`, `docs/OMNI_SOURCE_ULTRA_AUDIT.md`, `docs/OMNI_SOURCE_RECONCILIATION_2026-08-25.md`, `docs/ARTIFACT_IMPROVEMENT_AUDIT.md`, `docs/CAPABILITY_RESET_MAP.md`, `todo.md`, serta source runtime aktif.
