# Audit Peningkatan Artefak md90_superlayerAi

**Tanggal audit:** 25 Agustus 2026  
**Ruang lingkup:** kode aktif, schema Drizzle, router tRPC, persistence, paper engine, shadow adapters, UI utama, dokumen audit, tiga ZIP, recipe `pasted_content.txt`, dan bukti test/build/visual yang tersedia.

## Kesimpulan eksekutif

Artefak saat ini sudah memiliki **vertical slice PAPER/SHADOW yang dapat didemokan**: context instrumen/timeframe, snapshot terpadu, shadow/news presentation, risk gate, replay, paper decision, journal, demo ledger, dan live/custody fail-closed. Namun, artefak belum setara dengan terminal institusional produksi karena beberapa bagian masih bersifat **in-memory, statis, belum direkonsiliasi, atau belum memiliki bukti provider independen**.

Peningkatan terbesar bukan menambah lebih banyak panel atau mengkloning repo. Prioritasnya adalah memperbaiki **kebenaran state, durability, provenance, determinisme multi-instance, kualitas dataset, dan observability operasional**. Win rate 93% tetap harus diperlakukan sebagai target validasi, bukan hasil.

> Penilaian jujur: fondasi workflow sudah lebih kuat daripada prototype dashboard, tetapi klaim full-version belum dapat dinaikkan ke level production-grade sebelum persistence, replay evidence, provider certification, dan operational controls diperkuat.

## 1. Temuan paling penting pada kode aktif

| Prioritas | Temuan | Dampak | Peningkatan yang disarankan |
|---|---|---|---|
| P0 | `cockpit.snapshot` adalah query public yang melakukan write ketika sesi authenticated | Query read dapat menimbulkan side effect, duplikasi, dan latency tidak terprediksi | Pisahkan `cockpit.snapshot` menjadi read-only; gunakan mutation/command eksplisit untuk persist snapshot dan refresh ingestion |
| P0 | `persistedOverviewKeys` dan `sessionCache` hanya berada di memory proses | Duplicate protection hilang ketika autoscale restart atau memiliki lebih dari satu instance | Gunakan unique key/database constraint dan transaction/idempotency key durable; cache hanya optimasi |
| P0 | Shadow observations di-insert pada setiap snapshot tanpa unique constraint | History dapat membengkak dengan baris duplikat dan statistik freshness menjadi bias | Tambahkan `source + instrument + observedAt` atau `observationId` sebagai key; gunakan upsert yang benar |
| P0 | News duplicate update mengubah `publishedAt` menjadi `new Date()` | Umur berita menjadi palsu setelah refresh; freshness tidak lagi merepresentasikan sumber | Jangan ubah `publishedAt` saat upsert; simpan `receivedAt`, `lastSeenAt`, dan `sourceUpdatedAt` secara terpisah |
| P0 | `paper.decide` menerima `riskPct`, tetapi hanya menyimpan overview dan mengembalikan correlation string | Decision belum sepenuhnya menjalankan state machine, risk calculation, atau reconciliation command | Jalankan command domain: validate context → evaluate gates → create decision → create order intent → simulated fill → journal; simpan setiap transition dengan idempotency |
| P0 | `paperPositions` dan `paperRiskStates` di-insert berulang tanpa lifecycle close/reconcile yang jelas | Posisi dan risk history dapat menggandakan state yang sama atau meninggalkan posisi stale | Tambahkan position identity, opened/closed state, mark-to-market events, reconciliation status, dan transaction boundaries |
| P1 | Fill persistence tidak memiliki fill idempotency key dan tidak membedakan partial fill | Replay ulang dapat menghasilkan fill ganda; partial-fill policy belum terbukti di history | Tambahkan `clientFillId`, execution event sequence, fill status, remaining quantity, dan reconciliation exception |
| P1 | `dailyLossPct` dipersist sebagai `0` dalam paper risk state | Risk audit tidak merepresentasikan daily loss aktual | Hitung dari session ledger berbasis UTC trading day dan simpan input/threshold yang digunakan |
| P1 | Demo account global dan `demo.runBatch` public | Semua operator dapat memicu state global; demo terpisah dari user paper scope | Jadikan control protected/admin-scoped, simpan run manifest, dan tampilkan siapa/apa yang memicu batch |
| P1 | `broker.publicTicker` masih hardcoded BTCUSDT | Multi-instrument context belum mengalir ke semua broker read-only surface | Terima symbol ter-normalisasi, validasi allowlist, dan simpan provider timestamp/received timestamp |
| P1 | Router memiliki TODO template dan beberapa response memakai `any` di UI | Kontrak dapat melorot tanpa terdeteksi dan maintainability rendah | Pecah router per domain, ekspor Zod output schema, hilangkan `any` dari paper/shadow/news payload |
| P2 | Foreign key, index, retention, dan query pagination belum terlihat sebagai kontrak utama | History besar akan lambat dan integritas relasional sulit dijaga | Tambahkan FK/index untuk session, order, fill, signal, observation, news; paginasi audit dan kebijakan retention |

## 2. Gap data dan evidence

| Area | Kondisi sekarang | Yang harus ditingkatkan sebelum klaim lebih tinggi |
|---|---|---|
| Replay/backtest | Deterministik dan dapat diuji, tetapi sample canonical kecil dan masih BTC-centric | Dataset historis independen multi-instrumen, manifest checksum, timezone/session calendar, train/validation/test separation, out-of-sample report yang lebih panjang |
| Cryptoiz/Dynamic Execution | Presentation shadow dengan quality/freshness/permission scope | Adapter provider resmi, timestamped payload, schema contract, auth scope verification, latency/error logs, dan accuracy evaluation terhadap benchmark |
| DOM/gamma/COT | Typed contracts dan PENDING_REVIEW | Sumber authoritative, data dictionary, update cadence, missing-data behavior, dan proof bahwa feature tidak masuk scoring saat stale |
| News | Items dan freshness classification tersedia | Source ingestion log, deduplication, received-vs-published timestamps, correction history, confidence calibration, dan stale queue yang dapat di-resolve |
| Demo ledger | Statistik persisten dan dapat dipantau | Run manifest, deterministic seed/version, strategy/config hash, cost model version, dan pemisahan eksplisit demo simulation vs canonical replay |
| Win rate | Sample-aware display dan target 93% | Confidence interval, sample size minimum, expectancy, drawdown, turnover, fee/slippage sensitivity, walk-forward stability, dan benchmark comparison |
| ZIP/repo attachments | Sudah diaudit sebagai reference; tidak semuanya dapat diperlakukan sebagai runtime | License manifest, commit SHA, SBOM, security scan, reproducibility note, dan keputusan dependency per artefak |

## 3. Gap arsitektur All-in-one

Saat ini `cockpit.snapshot` menyatukan banyak read models, tetapi belum menjadi **event-sourced operating model**. Workflow event dan journal sudah terlihat, namun command, aggregate state, transition idempotency, dan reconciliation exception belum menjadi satu sumber kebenaran.

Peningkatan arsitektur yang paling bernilai adalah membangun empat lapisan berikut.

| Lapisan | Kontrak yang disarankan | Acceptance criteria |
|---|---|---|
| Event log | `market_observed`, `research_updated`, `risk_evaluated`, `paper_order_created`, `paper_fill_recorded`, `position_marked`, `journal_written`, `reconciliation_failed` | Setiap event memiliki event id unik, correlation id, causation id, actor scope, timestamp UTC, schema version, dan provenance |
| Aggregates | Paper session, order, fill, position, risk state, research source | Replay event yang sama menghasilkan state yang sama; duplicate event tidak menggandakan state |
| Read models | Cockpit snapshot, Audit Log, Research Desk, Management | Read model dapat dibangun ulang dari event/history dan memiliki `asOf` timestamp |
| Operations | ingestion run, heartbeat run, provider health, exception queue | Operator melihat last success, last failure, latency, stale age, retry count, dan remediation action |

## 4. Gap UI/UX yang dapat meningkatkan kualitas terminal

UI sudah memiliki Signal Atelier aesthetic, context sync, Workbench, provenance drawer, dan observability card. Peningkatan berikut akan membuatnya terasa lebih seperti control plane daripada kumpulan panel.

| Area | Peningkatan |
|---|---|
| Audit Log | Tambahkan filter correlation ID, instrument, stage, time range, status, dan source; setiap event membuka raw evidence, transformed value, dan reason code |
| Replay | Tampilkan dataset manifest, coverage period, train/test boundary pada timeline, cost model, run ID, config hash, dan tombol compare antar-run |
| Risk Lab | Tampilkan input → formula → output; bedakan `PASS`, `LOCKED`, `STALE`, `BLOCKED`, dan `NOT_EVALUATED`; simpan risk decision sebagai artefak yang dapat dibuka kembali |
| Research Desk | Jadikan setiap source row memiliki source contract, freshness age, permission scope, last ingestion attempt, dan reason bila tidak dipakai |
| Management | Tambahkan system health timeline, scheduler run history, ingestion queue, persistence failures, dan action ownership; jangan hanya menampilkan status label |
| Multi-timeframe | Tampilkan candle timestamp alignment, HTF candle close status, timezone, source lag, dan mismatch reason; jangan hanya menampilkan `SYNCED` |
| Bilingual | Pindahkan status/error/reason codes ke dictionary terpusat; saat ini sebagian copy masih bercampur bahasa dan hardcoded di page |
| Accessibility | Tambahkan semantic table headers, focus restoration setelah drawer, live region untuk run state, dan keyboard shortcut yang terdokumentasi |

## 5. Gap operasional 24/7

Heartbeat paper-only sudah memiliki pola callback dan idempotensi dasar, tetapi kesiapan 24/7 belum terbukti hanya dengan adanya callback. Sistem perlu mengukur runtime behavior secara eksplisit.

| Kontrol | Implementasi yang dibutuhkan |
|---|---|
| Liveness | Heartbeat lease, last successful run, timeout, retry/backoff, dan stale threshold |
| Readiness | Database connectivity, provider connectivity, schema version, queue depth, dan clock skew |
| Reconciliation | Expected-vs-recorded orders/fills/positions, exception state, retry, manual review, dan immutable resolution note |
| Alerting | Severity, deduplication, escalation, acknowledgement, notification destination, dan quiet hours |
| Recovery | Restart-safe idempotency, rebuild read models, dead-letter events, backup/restore drill, dan retention policy |
| Safety | Kill switch paper engine, independent live-route deny test, credential scope test, dan audit trail untuk setiap blocked action |

## 6. Hal yang harus tetap tidak diaktifkan

Dokumen dan ZIP yang memiliki network order, exchange execution, wallet signing, private key/seed, deposit, withdrawal, DEX transaction, copy-trading, atau live automation tidak boleh dimasukkan sebagai runtime tanpa perubahan scope dan approval keamanan yang terpisah. Dalam arsitektur sekarang, keputusan untuk mempertahankan `LIVE DISABLED` dan custody `DISABLED` adalah benar.

Yang dapat dipakai dari sumber-sumber tersebut hanyalah pattern yang dapat ditulis ulang secara aman: event lineage, deterministic replay, strategy configuration, risk policy, adapter interface, observability, dan operator workflow. Repository yang lisensinya tidak jelas, GPL tanpa legal review, atau mengandung jalur live tidak boleh disalin sebagai dependency runtime.

## 7. Urutan implementasi yang disarankan

**Fase 1 — Data integrity dan idempotency.** Pisahkan query dari command, tambahkan unique keys dan transaction boundaries, perbaiki timestamp news, dan buat migration/index yang terukur. Keberhasilan diukur dengan replay command dua kali yang menghasilkan satu state.

**Fase 2 — Paper execution dan reconciliation.** Jadikan `paper.decide` benar-benar menjalankan state machine, simpan order/fill/position lifecycle, hitung daily loss dari ledger, dan buat exception queue. Keberhasilan diukur dengan scenario entry, partial fill, close, duplicate command, stale data, dan failed persistence.

**Fase 3 — Evidence-grade replay.** Tambahkan dataset manifest, multi-instrument history, cost sensitivity, walk-forward compare, confidence interval, dan run registry. Keberhasilan diukur dengan reproducible run ID dan tidak ada angka yang berubah tanpa perubahan dataset/config.

**Fase 4 — Provider certification.** Sambungkan hanya provider yang memiliki contract, permission scope, freshness, error handling, dan benchmark test. Semua provider lain tetap PENDING_REVIEW.

**Fase 5 — Operations dan UX control plane.** Tambahkan filters, evidence drawer, health timeline, run history, remediation, bilingual reason codes, dan accessibility verification. Keberhasilan diukur dengan operator dapat menelusuri satu signal dari source hingga journal tanpa membuka kode.

## Referensi internal yang diaudit

- `docs/CAPABILITY_CONTRACT_MATRIX.md`
- `docs/ALL_IN_ONE_GAP_AUDIT.md`
- `docs/OMNI_SOURCE_ULTRA_AUDIT.md`
- `docs/FINAL_ALL_IN_ONE_AUDIT.md`
- `docs/FINAL_READINESS_REPORT.md`
- `docs/OPEN_SOURCE_GAP_CLOSURE.md`
- `server/routers.ts`
- `server/paperPersistence.ts`
- `server/paperEngine.ts`
- `server/walkForwardReplay.ts`
- `server/shadowAdapters.ts`
- `drizzle/schema.ts`
- `client/src/pages/WorkbenchSurface.tsx`
- `client/src/pages/ResearchDesk.tsx`

**Catatan final:** laporan ini menilai peningkatan yang tersedia dari artefak yang dibagikan; ia tidak mengubah status provider-private, dataset historis independen, heartbeat production, atau live/custody menjadi PASS tanpa bukti baru.
