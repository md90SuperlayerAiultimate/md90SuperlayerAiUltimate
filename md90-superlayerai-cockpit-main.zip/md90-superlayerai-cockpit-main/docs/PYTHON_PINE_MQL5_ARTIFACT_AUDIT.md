# Python, Pine, dan MQL5 Artifact Decision Ledger

**Tanggal audit:** 25 Agustus 2026 (UTC+8)  
**Metode:** inspeksi statis saja. Tidak ada file Python, Pine, MQL5, atau shell runner yang dieksekusi.  
**Snapshot provenance:** daftar SHA-256 root-level tersimpan pada [`docs/audit/artifact_checksums_2026-08-25.txt`](audit/artifact_checksums_2026-08-25.txt). Nama file di folder upload dapat dipakai ulang/ditimpa; checksum, bukan nama, adalah penanda artefak yang dapat diaudit.

> **Aturan runtime md90:** keputusan hanya dapat berakhir sebagai **PAPER_CANDIDATE**, **REVIEW**, atau **BLOCKED**. Tidak ada artefak yang diberi jalur order live, wallet signing, private key, deposit, withdrawal, transfer, atau broker authority.

## Status keputusan

| Kelompok artefak | Contoh snapshot/checksum | Permukaan statis yang ditemukan | Keputusan | Batas implementasi md90 |
|---|---|---|---|---|
| Indikator OHLC murni | `data_provider.py` `beee3a9a…`, `detectors.py` `3e425f8e…`, `swing_detector.py` `41aa828b…` | EMA, RSI, ATR, stochastic, MACD, ADX/DI, level/range, pola candle | **ADAPT** | Hanya fungsi deterministik yang dihitung dari candle canonical atau dataset SHADOW_EXTERNAL tervalidasi. Tidak mengimpor Python runtime. |
| Fusion dan signal gates | `fusion.py` `da16cf6c…`, `signal_engine.py` `38f1fe2a…`, `strategy_engine.py` `190ab42e…` | Skor confluence, filter momentum, kandidat arah | **ADAPT** | Output bukan `ALL-IN`; harus reason-coded, mempunyai data availability, dan tidak dapat melewati Survivor Mode. |
| Regime dan sesi | `regime_engine.py` `2336eb07…`, `regime_strategies.py` `a3daa9aa…`, `session_manager.py` `23add8d0…` | Klasifikasi trend/range/volatile dan sesi | **ADAPT** | Evidence/read-only. Confidence rendah atau data kurang menghasilkan hold/review, bukan default pass. |
| Risk guard protektif | `risk_calculator.py` `f0522744…`, `risk_manager.py` `cadddb9d…`, `circuit_breaker.py` `d960f116…` | Daily-loss, drawdown, consecutive loss, session lock | **ADAPT** | Dibatasi kebijakan md90 Survivor Mode: 0,5–1% risk PAPER dan exposure cap saat ini. Tidak menyalin risiko 3–5%, Kelly, win multiplier, martingale, atau auto-resume. |
| Statistik dan Bayesian | `statistics_engine.py` `e9b27fd8…`, `bayesian_updater.py` `02ed5787…`, `journal.py` `5ac0234d…` | Posterior, trade statistics, journal concept | **ADAPT — evidence proposal** | Hanya proposal dengan sample size, out-of-sample gate, source audit, dan tanpa auto-promote parameter/model. |
| Pine 17 layer / 5 gate | `MD90_ALLIN_FIXED.pine.txt` `602e6b8a…` | `strategy()` order semantics, 17 layer, 5 gate, inline placeholder untuk order block/time stop | **ADAPT — calculation only** | `shared/artifactParity.ts` menghitung 17 layer dalam **READ_ONLY** mode. Layer tanpa source certified netral; placeholder tidak dianggap implemented. |
| MQL5 EA variants | Dibaca pada batch sebelumnya; tidak tampak sebagai file root-level snapshot saat ini | `CTrade`, open/modify/close position, ATR exits, partial exit, optional martingale/notifications | **REJECT runtime** | MQL5 tidak dieksekusi atau diimpor. Konsep MTF/ATR/cooldown hanya boleh direimplementasi dan dites dalam TypeScript PAPER. Hash ulang wajib jika artefak diunggah kembali. |
| Polymarket/executor | `executor.py` `4a5d20e3…`, `polymarket_client.py` `cc6c1d4f…`, `kelly_sizer.py` `aff7552e…` | `place_limit_order`, credential derivation, private key, sizing terhadap equity | **REJECT** | Tidak ada client, secret, wallet, CLOB order, Kelly sizing, atau cancellation path di runtime md90. |
| Scanner market eksternal | `scanner.py` `e6b5cbf9…` | `aiohttp` ke Gamma/CLOB, market opportunity scoring | **REFERENCE / PENDING** | Ide scoring dapat dievaluasi hanya bila provider dan legal basis disetujui. Tidak ada endpoint Polymarket yang diaktifkan. |
| Webhook/command/notification | `webhook_server.py` `3eda66d9…`, `command_listener.py` `0e1924c2…`, `telegram_alerts.py` `fa1cf1e2…` | inbound command dan outbound HTTP messaging | **REJECT runtime** | Tidak ada listener, remote command, webhook execution, atau Telegram outbound route. |
| Agent/memory/graph/network | `agent.py` `07e13a5e…`, `local_agent.py` `13d2334a…`, `cognitive_pipeline.py` `46ddf6c5…`, `qdrant_memory.py` `a55dc417…`, `ws_engine.py` `dba5cfc0…`, `mirofish_graph.py` `8f1de29e…` | connector/network/vector/agent orchestration | **PENDING EVIDENCE / BLOCKED** | Tidak dihubungkan sampai ada contract privacy, retention, authorization, provider scope, failure policy, dan test isolation yang eksplisit. |
| Learning/tuning/release mutation | `auto_tuner.py` `d6bf22dd…`, `tuner.py` `708abd7d…`, `self_learner.py` `0ae3242f…`, `github_sync.py` `4b6effe5…`, `execution.py` `4e04f7e2…` | mutable tuning, repository sync, opaque execution | **REJECT runtime** | Tidak ada auto-tuning promotion, GitHub push, self-modification, model release, atau remote execution. |
| Dashboard/app/shell runners | `app.py` `d0cc3a15…`, `run.sh` `1dd13aab…`, `run_dashboard.sh` `d8ce44e7…`, `run_dry.sh` `2a8c0766…`, `run_tests.sh` `41722448…` | Streamlit display, local files, command launch | **REFERENCE** | Tidak dijalankan. UX/ledger insight hanya dipindahkan ke React/tRPC jika memenuhi PAPER/SHADOW contract. |

## Adaptasi yang sudah terbukti masuk runtime

| Capability | Implementasi md90 | Bukti pengaman |
|---|---|---|
| 17-layer parity | `shared/artifactParity.ts` menilai SNR, EMA, RSI, stochastic, volume availability, macro, ATR, OTE, sweep, engulfing, dan layer unavailable secara eksplisit | `authority: READ_ONLY`; `executionAuthority: DISABLED`; 5 gate tidak default-pass saat MTF/volume/time stop tidak tersedia. |
| Integrasi operator | `server/paperEngine.ts` mengekspos `artifactParity` dalam canonical PAPER snapshot; `RiskLabView` menampilkan status, regime, fusion, gate, limitation, dan authority | Tidak mengubah `paper.decide` menjadi auto execution atau menambah order route. |
| Protective policy | `shared/protectivePolicy.ts` memetakan session, confidence regime, daily loss, drawdown, consecutive loss, dan daily-trade cap ke `PAPER_CANDIDATE` / `REVIEW` / `BLOCKED` | `authority: ADVISORY_ONLY`; circuit-breaker tidak mengirim close/order dan semua nilai tetap dibatasi Survivor Mode. |
| MTF / ATR / exit parity | `shared/artifactTradeProposal.ts` mengekstrak proposal MTF, ATR stop/target, partial-exit, dan time-stop dari config canonical | HTF independen dan durable position age wajib ada; tanpa keduanya state `REVIEW` atau `NOT_EVALUATED`, bukan substitute same-TF atau close otomatis. |
| Bayesian / learning | `shared/learningEvidence.ts` menghitung posterior Beta dari close outcome berlabel yang berasal dari journal user-scoped | `authority: PROPOSAL_ONLY`, sample/OOS floor 30, `promotionRoute: DISABLED`; tidak ada auto-tuner, parameter promotion, model push, atau release. |
| Outbound artifact boundary | `shared/artifactBoundary.ts` menolak order/cancel, wallet/private key, custody, webhook, Telegram, Qdrant, graph, GitHub push, auto-tune, dan model release | Semua keputusan `{ allowed: false, route: DISABLED }` dan lock count muncul di Risk Lab. |
| Evidence import FX/XAU | `server/manualDataset.ts`, `datasets.ingestManual`, dan Market Map file input menerima CSV/JSON manual untuk EURUSD/XAUUSD | Validator menolak timestamp/OHLC/volume/duplikasi yang salah; raw file menuju object storage manifest; order route `DISABLED`. |
| Recovery command | `paper.retry` memeriksa user scope, terminal state, dan payload schema | Whitelist hanya `SYNC`, `DECIDE`, `RECONCILIATION`; `CLOSE` dan `DATASET_INGEST` harus dibuat sebagai command baru, sehingga retry tidak menggandakan close atau re-fetch eksternal. |

## Keterbatasan yang tidak boleh disamarkan

1. **Parity bukan validasi performa.** Data canonical replay saat ini belum menyediakan volume dan HTF independen penuh; karena itu volume/MTF/time-stop menjadi neutral atau hold. Tidak ada klaim 93% win rate.
2. **Pine adalah referensi, bukan bukti implementasi penuh.** Placeholder yang ditulis pada source—khususnya order block dan time-stop—tetap placeholder dalam md90 sampai memiliki dataset dan kontrak durable yang sah.
3. **MQL5/Polymarket tidak boleh mendapat jalur kompatibilitas “sementara”.** Menerjemahkan API order, CTrade, private key, atau shell launcher ke TypeScript tetap merupakan execution path dan ditolak.
4. **Lisensi/provenance masih tidak lengkap.** Tidak ada metadata repository atau license notice yang dapat diverifikasi untuk sebagian besar upload root-level ini. Keputusan ADAPT berarti reimplementasi konsep yang terbatas, bukan copy, fork, atau penggunaan kode sumber sebagai dependency.

## Acceptance berikutnya

| Gate | Bukti minimum untuk menjadi lebih dari `EVIDENCE_REQUIRED` |
|---|---|
| Layer volume/VWAP | Dataset OHLCV berlisensi/berprovenance, checksum, coverage, freshness, dan test normalizer. |
| Layer MTF/Ultra | Dua stream candle independen dengan timeframe yang diketahui; tidak boleh substitute same-timeframe. |
| Time stop | Posisi PAPER durable dengan entry timestamp, bar clock canonical, dan transaction/idempotency test. |
| Bayesian/learning | Sample-size floor, split in-sample/OOS, audit input-output, dan proposal manual—tanpa promotion otomatis. |
| Provider/connector | Kontrak terpisah untuk scope, legal source, retention, auth, rate limit, outage, dan no-order/custody proof. |
