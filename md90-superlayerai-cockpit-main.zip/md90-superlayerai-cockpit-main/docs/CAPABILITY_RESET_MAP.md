# Capability Reset Map — md90_superlayerAi

**Tanggal pembaruan:** 27 Agustus 2026  
**Status sistem:** PAPER/SHADOW operator system; seluruh authority live, custody, signing, deposit, transfer, dan withdrawal tetap **disabled**.

Capability hanya dianggap implemented apabila memiliki contract, procedure, persistence/data source, operator surface, dan regression evidence. Blueprint, attachment, atau klaim provider tidak otomatis menjadi runtime feature.

| Capability | Runtime sekarang | Bukti executable | Surface operator | Status jujur |
|---|---|---|---|---|
| Matari/Fusion confluence, HTF, RSI/MACD/ATR, Survivor Mode | Canonical paper strategy/risk contracts | `paper.decide`, risk policies, tests | Signal Room, Risk Lab | `PAPER` |
| Source → confluence → risk → fill → journal | Correlated workflow and user-scoped journal | workflow events, idempotency, journal queries | Audit Log, cockpit | `PAPER` |
| Forward historical session | Sequential persisted-candle engine with PaperBroker | `paper.forwardRun`, manifest checksum gate, forward tests | Overview forward-paper panel | `PAPER / EVIDENCE-GATED` |
| Forward ledger | Session, order, fill, position, risk, journal, equity, comparison markers | `forwardPaperPersistence.ts` and existing schema | Cockpit, Audit Log | `PAPER / DB-CONDITIONAL` |
| Backtest versus forward attribution | OOS replay and cohort delta report | `shared/forwardComparison.ts`, comparison journal | Forward Paper panel | `EVIDENCE REPORT` |
| Duplicate/partial/invalid fill recovery | PaperBroker idempotency and reconciliation contract | broker tests, exception queue, persistence markers | Audit Log | `PAPER` |
| CryptoIZ/Dynamic Execution | Observation/provenance contracts only | shadow adapter, freshness/permission/order-route labels | Research Desk, Market Map | `SHADOW / PROVIDER-PENDING` |
| Public crypto historical observation | Read-only public candle adapter | structural validation, checksum, freshness, no-order return | Market Map | `SHADOW_EXTERNAL` |
| Persisted external dataset | Authenticated object-storage manifest, user-scoped checksum and coverage | `datasets.imports`, `loadPersistedDatasetForParity`, storage pointer | Evidence Command Center, Forward Paper | `PAPER INPUT / EVIDENCE-GATED` |
| FX/XAU historical forward input | Persisted Dukascopy manifests are supported when present and checksum-valid | protected manifest loader and forward route | Forward Paper panel | `PAPER / MANIFEST-DEPENDENT` |
| Command recovery and auditability | Durable command-run ledger with terminal states | `paper_command_runs`, correlation, retry routes | Audit Log | `PAPER` |
| DOM, gamma, COT, private provider feed | Contracts/evidence gates only | provider timestamp, permission, and source certification pending | Research Desk, Audit Log | `PENDING_EVIDENCE` |
| LP, Meteora, wallet, DeFi custody automation | Explicit safety boundary | credential validation and custody tests | Management, Risk Lab | `DISABLED` |
| Binance/broker live order execution | No client, server, or provider order route | safety contracts and negative tests | All operator surfaces | `DISABLED` |
| Auto-tuning/model promotion/external webhook | No promotion or external execution authority | policy boundary and negative tests | Audit surfaces | `DISABLED` |

## Executable operator scenario

An authenticated operator can select a user-scoped persisted manifest, run the forward PAPER session, and receive sequential observation, signal, order-intent, simulated-fill, position-mark, journal, reconciliation, equity, and OOS comparison output. The process verifies storage shape and SHA-256 checksum before processing. Persistence writes to the existing paper ledger with correlation and idempotency markers. No step sends an order to a broker or network.

The prior SYNC → DECIDE → CLOSE → RECONCILIATION command path remains available and is separate from forward manifest execution. Demo batch simulation remains a separate observability product and must not be mixed with historical replay or forward-paper metrics.

> **Performance policy:** the 93% win rate remains a validation target only. It is not a result, guarantee, or marketing claim.

## Acceptance gate for the next capability tier

A strategy or data source must not be promoted to integrated authority until it has a raw file/API contract, source timestamp, checksum/version, license or permission record, replay coverage, expected-vector/parity evidence where applicable, and regression scenarios. Public FX/XAU manifests may be used for PAPER evidence when their checksum and user scope validate, but this does not certify provider accuracy, live liquidity, or live execution.

## References

[1] [Binance Data Collection — public data access](https://data.binance.vision/)
[2] `docs/audit/INTERNAL_AUDITOR_FORENSIC_RESPONSE_2026-08-27.md`
[3] `docs/audit/FULL_VERSION_FINAL_STATUS_2026-08-27.md`
[4] `docs/FINAL_READINESS_REPORT.md`
