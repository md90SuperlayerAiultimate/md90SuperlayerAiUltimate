# Capability Contract Matrix — md90_superlayerAi

Dokumen ini mengubah register URL, ZIP, attachment, dan source audit menjadi kontrak kemampuan yang dapat diverifikasi. Status `integrated` berarti dipakai oleh runtime canonical. Status `adapted` berarti pola ditulis ulang ke Safe Core. Status `shadow` berarti hanya observasi dengan provenance/freshness. Status `rejected` berarti tidak boleh menjadi runtime dependency. Status `pending` berarti membutuhkan source/provider evidence tambahan.

| Capability | Source classes audited | Runtime contract | Status | Acceptance evidence |
|---|---|---|---|---|
| Market context | Binance public, OANDA/FX metadata, TradingView mapping | instrument registry + canonical base/HTF/symbol/source | integrated / shadow | `shared/instruments.ts`, `shared/timeframe.ts`, broker tests |
| OHLC replay | supplied strategy/backtest patterns and md90 replay | deterministic 24-bar replay, OHLC resampling, fee/slippage | integrated paper-only | `server/paperEngine.test.ts`, replay test |
| Signal confluence | Matari, FUSION, alpha/feature patterns | strategy contract + evidence score, no order authority | adapted paper-only | strategy config and Signal Room contracts |
| Risk and sizing | risk manager, ATR, drawdown, Kelly/sizer patterns | Survivor Mode 0.5–1%, exposure cap 3%, freshness/volatility/news gates | adapted integrated | `server/botContracts.test.ts`, paper tests |
| Research and provenance | TradingAgents, cognitive/research/journal patterns | source, freshness, permission scope, evidence checkpoints | adapted integrated | Research Desk, shadow adapter tests |
| Liquidity/DOM/gamma/COT/LQ | research and market-structure candidates | typed observation contracts; stale/missing data blocks decision | adapted shadow/pending | research contract tests and provider states |
| Cryptoiz/Dynamic Execution | supplied web/source references | observation metadata only; no execution authority | shadow / pending provider | external findings, shadow tests |
| Meteora/Meridian/DeFi | supplied tutorial and agent patterns | failure-mode research only; no wallet/custody route | adapted research / rejected execution | custody boundary tests |
| Broker execution | CCXT/Freqtrade/Nautilus-style patterns | in-process paper broker with idempotent fills | adapted paper-only | paper broker and execution state tests |
| Exchange/network orders | ZIP executors, API/private key paths, CLOB paths | no runtime order, signing, transfer, deposit, withdrawal | rejected | live/custody regression |
| Demo operations | generated batch and heartbeat patterns | isolated demo ledger, scheduler metadata, metrics | integrated demo-only | demo persistence/schedule tests |
| Operator workflow | institutional UI/workstation patterns | snapshot → workflow events → paper decision → reconciliation | integrated PAPER/SHADOW | cockpit, workflow, paper execution tests |
| AI/LLM explanation | agent/LLM patterns | explanation only; cannot bypass policy gate | experimental | module status and boundary tests |

## Decision rule

Tidak ada source yang masuk runtime hanya karena URL, stars, nama file, atau klaim pemasaran. `USE`/`ADAPT` membutuhkan contract dan test; `FORK` membutuhkan source lengkap dan lisensi yang dapat diperiksa; private execution, signing, custody, dan live order paths selalu `REJECT`. Target win rate 93% tetap validation gate, bukan output yang boleh dipaksakan.
