import { nanoid } from "nanoid";
import { PaperBroker } from "./paperBroker";
import { strategyConfig, type StrategyConfig } from "@shared/strategyConfig";
import { survivorModeGate } from "./botContracts";
import { normalizeTimeframe, type BaseTimeframe } from "@shared/timeframe";
import { analyzeArtifactParity, type ArtifactParity } from "@shared/artifactParity";
import { evaluateProtectivePolicy, type ProtectivePolicy } from "@shared/protectivePolicy";
import { proposePaperTrade, type PaperTradeProposal } from "@shared/artifactTradeProposal";
import { artifactOutboundBoundaries, type ArtifactBoundaryDecision } from "@shared/artifactBoundary";

export type PaperSignal = {
  symbol: string;
  market: string;
  bias: "LONG" | "SHORT" | "WATCH";
  score: number;
  confidence: number;
  change: string;
  updated: string;
  source: string;
  accent: "teal" | "amber" | "vermillion";
};

export type PaperCandle = { timestamp: string; open: number; high: number; low: number; close: number };

export function resampleReplayPrices(prices: number[], timeframe: BaseTimeframe = "15m") {
  const step = timeframe === "15m" ? 1 : timeframe === "1h" ? 4 : timeframe === "4h" ? 16 : 96;
  if (step === 1) return prices.slice(-12);
  const source = prices.slice(-(step * 12));
  const buckets: number[] = [];
  for (let index = 0; index < source.length; index += step) {
    const bucket = source.slice(index, index + step);
    if (bucket.length) buckets.push(bucket[bucket.length - 1]);
  }
  return buckets.slice(-12);
}

export function buildReplayCandles(prices: number[], nowMs = Date.now(), timeframe: BaseTimeframe = "15m"): PaperCandle[] {
  const resampled = resampleReplayPrices(prices, timeframe);
  const intervalMinutes = timeframe === "15m" ? 15 : timeframe === "1h" ? 60 : timeframe === "4h" ? 240 : 1440;
  return resampled.map((close, index, recent) => {
    const previous = recent[index - 1] ?? close - 45;
    const open = previous;
    const high = Math.max(open, close) + 38 + (index % 3) * 7;
    const low = Math.min(open, close) - 32 - (index % 2) * 6;
    return { timestamp: new Date(nowMs - (recent.length - 1 - index) * intervalMinutes * 60 * 1000).toISOString(), open: Number(open.toFixed(2)), high: Number(high.toFixed(2)), low: Number(low.toFixed(2)), close: Number(close.toFixed(2)) };
  });
}

export type PaperOverview = {
  mode: "PAPER";
  timeframe: BaseTimeframe;
  generatedAt: string;
  provenance: string;
  metrics: {
    systemPulse: number;
    grossExposurePct: number;
    peakDrawdownPct: number;
    dataFreshnessSeconds: number;
    equity: number;
    realizedPnl: number;
    unrealizedPnl: number;
    fees: number;
    slippageBps: number;
    tradeCount: number;
  };
  primary: {
    symbol: string;
    market: string;
    last: number;
    bid: number;
    ask: number;
    entry: number;
    stop: number;
    takeProfit: number;
    score: number;
    confidence: number;
    riskPct: number;
    source: string;
    points: number[];
    candles: PaperCandle[];
  };
  signals: PaperSignal[];
  positions: Array<{ instrument: string; direction: string; quantity: number; entry: number; mark: number; unrealizedPnl: number }>;
  riskChecks: Array<{ label: string; status: "PASS" | "LOCKED"; detail: string }>;
  equityCurve: Array<{ timestamp: string; equity: number; drawdownPct: number }>;
  trades: Array<{ id: string; instrument: string; side: "BUY" | "SELL"; quantity: number; price: number; fee: number; slippageBps: number; status: "filled" | "partial"; timestamp: string }>;
  journal: Array<{ timestamp: string; event: string; detail: string; provenance: string }>;
  modules: Array<{ name: string; role: string; status: "integrated" | "paper-only" | "experimental" | "external" | "live-blocked"; note: string }>;
  artifactParity: ArtifactParity;
  artifactProtection: ProtectivePolicy;
  artifactTradeProposal: PaperTradeProposal;
  artifactBoundaryLocks: ArtifactBoundaryDecision[];
  strategy: StrategyConfig;
};

const replayPrices = [70220, 70310, 70180, 70490, 70620, 70510, 70840, 70980, 71120, 71040, 71320, 71480, 71390, 71640, 71810, 71740, 71980, 72140, 72080, 72290, 72410, 72350, 72540, 72620];

export function getCanonicalReplayPrices() {
  return [...replayPrices];
}
const startingEquity = 10_000;
const feeBps = 10;
const slippageBps = 5;

function pct(value: number) {
  return Number(value.toFixed(2));
}

export type PaperRiskInput = { dailyLossPct: number; grossExposurePct: number; drawdownPct: number; dataFreshnessSeconds: number; riskPct?: number; highImpactNews?: boolean; volatilityShock?: boolean; gammaRequired?: boolean; institutionalFlowRequired?: boolean };

export function evaluatePaperRisk(input: PaperRiskInput) {
  const survivor = survivorModeGate({ riskPct: input.riskPct ?? 0.5, totalExposurePct: input.grossExposurePct, dailyLossPct: input.dailyLossPct, highImpactNews: input.highImpactNews ?? false, volatilityShock: input.volatilityShock ?? false, gammaVerified: !(input.gammaRequired ?? false), institutionalFlowVerified: !(input.institutionalFlowRequired ?? false) });
  const dailyLossPass = input.dailyLossPct <= 2;
  const exposurePass = input.grossExposurePct <= 25;
  const drawdownPass = input.drawdownPct <= 10;
  const freshnessPass = input.dataFreshnessSeconds <= 90;
  return { dailyLossPass, exposurePass, drawdownPass, freshnessPass, survivor, approved: dailyLossPass && exposurePass && drawdownPass && freshnessPass && survivor.allowed };
}

export function getPaperOverview(requestedTimeframe: string = "15m"): PaperOverview {
  const timeframe = normalizeTimeframe(requestedTimeframe) as BaseTimeframe;
  const entry = replayPrices[8];
  const last = replayPrices[replayPrices.length - 1];
  const bid = last - 2.5;
  const ask = last + 2.5;
  const stop = entry * 0.991;
  const takeProfit = entry * 1.021;
  const riskQuantity = (startingEquity * 0.005) / Math.abs(entry - stop);
  const survivorExposureCap = startingEquity * 0.03;
  const quantity = Math.min(riskQuantity, survivorExposureCap / last);
  const broker = new PaperBroker();
  const fill = broker.submit({ clientOrderId: "paper-fill-001", instrument: "BTC/USDT", side: "BUY", quantity, bid, ask, feeBps, slippageBps });
  const filledQuantity = fill.filledQuantity;
  const grossExposure = filledQuantity * last;
  const grossExposurePct = grossExposure / startingEquity * 100;
  const realizedPnl = 0;
  const unrealizedPnl = filledQuantity * (last - entry);
  const fees = fill.fee;
  const equity = startingEquity + unrealizedPnl - fees;
  const peak = Math.max(...replayPrices.map((price) => startingEquity + filledQuantity * (price - entry) - fees));
  const peakDrawdownPct = Math.max(0, (peak - equity) / peak * 100);
  const priceChange = (last / replayPrices[0] - 1) * 100;
  const score = 60 + Math.min(24, Math.round((last - replayPrices[0]) / 100));
  const confidence = 60 + Math.min(16, Math.round((last - replayPrices[0]) / 150));
  const now = new Date().toISOString();
  const risk = evaluatePaperRisk({ dailyLossPct: 0, grossExposurePct, drawdownPct: peakDrawdownPct, dataFreshnessSeconds: 3, riskPct: 0.5, gammaRequired: false, institutionalFlowRequired: false });
  const replayCandles = buildReplayCandles(replayPrices, Date.now(), timeframe);
  const artifactParity = analyzeArtifactParity(replayCandles);
  const artifactProtection = evaluateProtectivePolicy({ parity: artifactParity, dailyLossPct: 0, drawdownPct: peakDrawdownPct, consecutiveLosses: 0, tradesToday: 1 });
  const artifactTradeProposal = proposePaperTrade({ parity: artifactParity, protection: artifactProtection, baseTimeframe: timeframe, htfTimeframe: "4h", independentHtf: false });
  const artifactBoundaryLocks = artifactOutboundBoundaries(["ORDER_SUBMIT", "WALLET_SIGN", "WEBHOOK_COMMAND", "TELEGRAM_NOTIFY", "QDRANT_WRITE", "EXTERNAL_GRAPH", "GITHUB_PUSH", "AUTO_TUNE_PROMOTION", "MODEL_RELEASE"]);
  const equityCurve = replayPrices.slice(-10).map((price, index) => {
    const pointEquity = startingEquity + filledQuantity * (price - entry) - fees;
    return { timestamp: new Date(Date.now() - (9 - index) * 15 * 60 * 1000).toISOString(), equity: Number(pointEquity.toFixed(2)), drawdownPct: pct(Math.max(0, (peak - pointEquity) / peak * 100)) };
  });
  return {
    mode: "PAPER",
    timeframe,
    generatedAt: now,
    provenance: "Deterministic replay · bid/ask spread 5.0 bps · fee 10 bps · slippage 5 bps",
    metrics: {
      systemPulse: Math.round((score + confidence) / 2),
      grossExposurePct: pct(grossExposurePct),
      peakDrawdownPct: -pct(peakDrawdownPct),
      dataFreshnessSeconds: 3,
      equity: Number(equity.toFixed(2)),
      realizedPnl,
      unrealizedPnl: Number(unrealizedPnl.toFixed(2)),
      fees: Number(fees.toFixed(2)),
      slippageBps,
      tradeCount: 1,
    },
    primary: {
      symbol: "BTC",
      market: "BTC/USDT",
      last: Number(last.toFixed(2)),
      bid: Number(bid.toFixed(2)),
      ask: Number(ask.toFixed(2)),
      entry: Number(entry.toFixed(2)),
      stop: Number(stop.toFixed(2)),
      takeProfit: Number(takeProfit.toFixed(2)),
      score,
      confidence,
      riskPct: 0.5,
      source: "17-layer fusion / replay",
      points: replayPrices.slice(-12),
      candles: replayCandles,
    },
    signals: [
      { symbol: "BTC", market: "BTC/USDT", bias: "LONG", score, confidence, change: `${priceChange >= 0 ? "+" : ""}${priceChange.toFixed(2)}%`, updated: "3 sec ago", source: "17-layer fusion", accent: "teal" },
      { symbol: "ETH", market: "ETH/USDT", bias: "WATCH", score: 61, confidence: 58, change: "+0.84%", updated: "18 sec ago", source: "Regime split", accent: "amber" },
      { symbol: "SOL", market: "SOL/USDT", bias: "SHORT", score: 47, confidence: 52, change: "-1.28%", updated: "28 sec ago", source: "Momentum fade", accent: "vermillion" },
      { symbol: "ARB", market: "ARB/USDT", bias: "WATCH", score: 54, confidence: 49, change: "+0.12%", updated: "41 sec ago", source: "Thin liquidity", accent: "amber" },
    ],
    positions: [{ instrument: "BTC/USDT", direction: "LONG", quantity: fill.filledQuantity, entry: Number(entry.toFixed(2)), mark: Number(last.toFixed(2)), unrealizedPnl: Number(unrealizedPnl.toFixed(2)) }],
    riskChecks: [
      { label: "Daily loss limit", status: risk.dailyLossPass ? "PASS" : "LOCKED", detail: "0.00% / 2.00%" },
      { label: "Gross exposure", status: risk.exposurePass ? "PASS" : "LOCKED", detail: `${pct(grossExposurePct)}% / 25.00% · Survivor cap 3.00% · sizing capped before fill` },
      { label: "Drawdown limit", status: risk.drawdownPass ? "PASS" : "LOCKED", detail: `${pct(peakDrawdownPct)}% / 10.00%` },
      { label: "Data freshness", status: risk.freshnessPass ? "PASS" : "LOCKED", detail: "3 sec / 90 sec" },
      { label: "Survivor Mode", status: risk.survivor.allowed ? "PASS" : "LOCKED", detail: risk.survivor.allowed ? "0.50% risk · 3.00% exposure cap · pre-fill enforced" : risk.survivor.reasons.join(" · ") },
      { label: "Live approval", status: "LOCKED", detail: "Paper-only policy" },
    ],
    equityCurve,
    trades: [{ id: fill.clientOrderId, instrument: "BTC/USDT", side: "BUY", quantity: fill.filledQuantity, price: fill.averagePrice, fee: fill.fee, slippageBps: fill.slippageBps, status: fill.status, timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString() }],
    journal: [
      { timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(), event: "ORDER_FILLED", detail: "Paper BUY accepted at bid/ask-aware simulated price", provenance: "Replay · fee 10 bps · slippage 5 bps" },
      { timestamp: new Date(Date.now() - 14 * 60 * 1000).toISOString(), event: "RISK_PASS", detail: `Exposure ${pct(grossExposurePct)}% below 25% cap`, provenance: "Policy v1.0" },
      { timestamp: new Date(Date.now() - 13 * 60 * 1000).toISOString(), event: "LIVE_BLOCKED", detail: "No network order path is enabled", provenance: "Paper-only guard" },
    ],
    artifactParity,
    artifactProtection,
    artifactTradeProposal,
    artifactBoundaryLocks,
    strategy: strategyConfig,
    modules: [
      { name: "Canonical data contract", role: "Venue-neutral snapshots", status: "integrated", note: "UTC timestamp, quality, provenance" },
      { name: "17-layer fusion", role: "Signal evidence", status: "paper-only", note: "Decision output is gated" },
      { name: "Cryptoiz / DEX intelligence", role: "External source", status: "external", note: "Requires adapter and source validation" },
      { name: "Dynamic Execution", role: "External signal source", status: "external", note: "Not an execution authority" },
      { name: "Paper broker", role: "Fill simulation", status: "integrated", note: "Bid/ask, fee, slippage, idempotency" },
      { name: "Risk policy", role: "Pre-trade gate", status: "integrated", note: "Exposure, loss, drawdown, freshness" },
      { name: "AI / LLM layer", role: "Explanation and research", status: "experimental", note: "Cannot bypass policy gate" },
      { name: "Binance / Solana / Polymarket live", role: "Execution adapters", status: "live-blocked", note: "No live credentials or order path" },
    ],
  };
}

export function newPaperSessionId() {
  return `paper-${nanoid(10)}`;
}
