import { and, desc, eq } from "drizzle-orm";
import { paperReplayRuns } from "../drizzle/schema";
import { getDb } from "./db";
import { loadPersistedDatasetForParity } from "./datasetPersistence";
import { runDatasetReplay, type DatasetReplayParams } from "./datasetReplay";

export async function runAndPersistDatasetReplay(userId: number, ingestionId: number, params: DatasetReplayParams) {
  const loaded = await loadPersistedDatasetForParity(userId, ingestionId);
  if (loaded.status !== "READY") return { status: loaded.status, reason: loaded.reason } as const;
  const replay = runDatasetReplay(loaded.series.candles!, params);
  const correlationId = `replay:${ingestionId}:${loaded.series.checksum}:${replay.trainBars}:${replay.testBars}`;
  const db = await getDb();
  if (!db) return { status: "UNAVAILABLE" as const, reason: "database-unavailable" as const, replay, correlationId };
  const inserted = await db.insert(paperReplayRuns).values({
    userId,
    ingestionId,
    correlationId,
    trainBars: replay.trainBars,
    testBars: replay.testBars,
    strategyVersion: replay.strategyVersion,
    sourceChecksum: loaded.series.checksum!,
    status: "READY",
    metricsJson: JSON.stringify(replay),
    orderRoute: replay.orderRoute,
  }).$returningId();
  return { status: "persisted" as const, runId: inserted[0]?.id ?? 0, correlationId, replay, source: { symbol: loaded.series.symbol, interval: loaded.series.interval, checksum: loaded.series.checksum, barCount: loaded.series.candles?.length ?? 0 } };
}

export async function getDatasetReplayRuns(userId: number, ingestionId?: number) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select().from(paperReplayRuns).where(ingestionId ? and(eq(paperReplayRuns.userId, userId), eq(paperReplayRuns.ingestionId, ingestionId)) : eq(paperReplayRuns.userId, userId)).orderBy(desc(paperReplayRuns.createdAt)).limit(20);
  return rows.map((row) => ({ ...row, replay: parseJson(row.metricsJson) }));
}

function parseJson(value: string) {
  try { return JSON.parse(value) as Record<string, unknown>; } catch { return {}; }
}
