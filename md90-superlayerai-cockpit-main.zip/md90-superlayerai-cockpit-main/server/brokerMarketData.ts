export type BrokerHealth = "HEALTHY" | "STALE" | "DEGRADED" | "BLOCKED";

export type PublicTicker = {
  venue: "BINANCE_PUBLIC";
  symbol: string;
  bid: number;
  ask: number;
  spreadBps: number;
  sourceTimestamp: number;
  receivedAt: number;
  health: BrokerHealth;
  orderRoute: "DISABLED";
};

const BINANCE_PUBLIC_BASE = "https://data-api.binance.vision";
const MAX_AGE_MS = 15_000;

function normalizeSymbol(symbol: string) {
  const normalized = symbol.trim().toUpperCase();
  if (!/^[A-Z0-9]{5,20}$/.test(normalized)) throw new Error("Invalid market symbol");
  return normalized;
}

export function normalizePublicTicker(
  payload: { symbol: string; bidPrice: string; askPrice: string },
  receivedAt = Date.now(),
  sourceTimestamp = receivedAt,
): PublicTicker {
  const symbol = normalizeSymbol(payload.symbol);
  const bid = Number(payload.bidPrice);
  const ask = Number(payload.askPrice);
  if (!Number.isFinite(bid) || !Number.isFinite(ask) || bid <= 0 || ask <= 0 || ask < bid) throw new Error("Invalid broker ticker");
  const spreadBps = ((ask - bid) / ((ask + bid) / 2)) * 10_000;
  const age = Math.max(0, receivedAt - sourceTimestamp);
  const health: BrokerHealth = age > MAX_AGE_MS ? "STALE" : "HEALTHY";
  return { venue: "BINANCE_PUBLIC", symbol, bid, ask, spreadBps, sourceTimestamp, receivedAt, health, orderRoute: "DISABLED" };
}

function sourceTimeFromHeaders(response: Response, fallback: number) {
  const value = response.headers?.get("date");
  if (!value) return fallback;
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

export async function fetchBinancePublicTicker(symbol: string, fetchImpl: typeof fetch = fetch, now = Date.now(), timeoutMs = 5_000): Promise<PublicTicker> {
  const normalized = normalizeSymbol(symbol);
  let lastError: unknown;
  for (let attempt = 1; attempt <= 2; attempt += 1) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetchImpl(`${BINANCE_PUBLIC_BASE}/api/v3/ticker/bookTicker?symbol=${encodeURIComponent(normalized)}`, { signal: controller.signal });
      if (!response.ok) throw new Error(`Broker HTTP ${response.status}`);
      const payload = await response.json() as { symbol?: string; bidPrice?: string; askPrice?: string };
      if (!payload.symbol || !payload.bidPrice || !payload.askPrice) throw new Error("Incomplete broker ticker");
      const ticker = normalizePublicTicker({ symbol: payload.symbol, bidPrice: payload.bidPrice, askPrice: payload.askPrice }, now, sourceTimeFromHeaders(response, now));
      return ticker;
    } catch (error) {
      lastError = error;
      if (attempt === 2) break;
    } finally {
      clearTimeout(timeout);
    }
  }
  const message = lastError instanceof Error ? lastError.message : "Broker request failed";
  throw new Error(`BINANCE_PUBLIC_BLOCKED: ${message}`);
}
