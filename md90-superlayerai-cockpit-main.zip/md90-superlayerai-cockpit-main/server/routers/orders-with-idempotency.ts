import { z } from 'zod';
import { publicProcedure, router } from '../trpc';
import { IdempotencyManager, OrderIntent } from '../../shared/idempotency';
import { Logger } from '../_core/logger';

const logger = new Logger('OrdersRouter');
const idempotencyManager = new IdempotencyManager(logger);

// Run cleanup every hour
setInterval(() => idempotencyManager.cleanup(), 60 * 60 * 1000);

const submitOrderSchema = z.object({
  symbol: z.string(),
  side: z.enum(['BUY', 'SELL']),
  quantity: z.number().positive(),
  price: z.number().positive(),
  type: z.enum(['MARKET', 'LIMIT']),
  clientOrderId: z.string().uuid().optional(),
});

export const ordersRouter = router({
  /**
   * Submit order with idempotency guarantee
   * If network fails, retry with same clientOrderId = no duplicate
   */
  submitOrder: publicProcedure
    .input(submitOrderSchema)
    .mutation(async ({ input }) => {
      const intent: OrderIntent = {
        symbol: input.symbol,
        side: input.side,
        quantity: input.quantity,
        price: input.price,
        type: input.type,
      };

      // Generate or use provided clientOrderId
      let clientOrderId = input.clientOrderId;
      if (!clientOrderId) {
        const key = idempotencyManager.generateKey(intent);
        clientOrderId = key.clientOrderId;
        idempotencyManager.registerOrder(key, intent);
      } else {
        // Check if this is a retry
        if (!idempotencyManager.canRetry(clientOrderId)) {
          const existingOrder = idempotencyManager.getOrder(clientOrderId);
          if (existingOrder) {
            logger.info(
              `Returning cached result for order ${clientOrderId}: ${existingOrder.status}`
            );
            return {
              clientOrderId: existingOrder.clientOrderId,
              exchangeOrderId: existingOrder.exchangeOrderId,
              status: existingOrder.status,
              cached: true,
            };
          }
        }

        if (idempotencyManager.isDuplicate(clientOrderId, intent)) {
          logger.warn(`Duplicate order detected: ${clientOrderId}`);
          return {
            clientOrderId,
            error: 'DUPLICATE_ORDER',
            message: 'This order has already been submitted',
          };
        }

        idempotencyManager.recordRetry(clientOrderId);
      }

      try {
        // Submit to exchange
        const exchangeResponse = await submitToExchange(intent, clientOrderId);

        if (exchangeResponse.success) {
          idempotencyManager.updateOrderState(
            clientOrderId,
            exchangeResponse.orderId,
            'PENDING'
          );

          logger.info(
            `Order submitted successfully: ${clientOrderId} -> ${exchangeResponse.orderId}`
          );

          return {
            clientOrderId,
            exchangeOrderId: exchangeResponse.orderId,
            status: 'PENDING',
            success: true,
          };
        } else {
          throw new Error(exchangeResponse.error);
        }
      } catch (error) {
        logger.error(
          `Order submission failed for ${clientOrderId}: ${error}. Will retry with same ID.`
        );

        return {
          clientOrderId,
          error: 'SUBMISSION_FAILED',
          message: String(error),
          retryable: true,
        };
      }
    }),

  /**
   * Query order status
   * Used to check if order was filled before retry
   */
  queryOrderStatus: publicProcedure
    .input(z.object({ clientOrderId: z.string().uuid() }))
    .query(async ({ input }) => {
      const orderState = idempotencyManager.getOrder(input.clientOrderId);

      if (!orderState) {
        return {
          found: false,
          message: 'Order not found in local state',
        };
      }

      return {
        found: true,
        clientOrderId: orderState.clientOrderId,
        exchangeOrderId: orderState.exchangeOrderId,
        status: orderState.status,
        attempts: orderState.attempts,
        timestamp: orderState.timestamp,
      };
    }),

  /**
   * Reconcile orders after restart
   * Query exchange for all open orders and sync state
   */
  reconcileOrders: publicProcedure.mutation(async () => {
    logger.info('Starting order reconciliation...');

    try {
      const exchangeOrders = await queryExchangeOpenOrders();

      for (const exchangeOrder of exchangeOrders) {
        const localOrder = idempotencyManager.getOrder(
          exchangeOrder.clientOrderId
        );

        if (!localOrder) {
          logger.warn(
            `Exchange has order ${exchangeOrder.clientOrderId} not in local state`
          );
          continue;
        }

        if (localOrder.status !== exchangeOrder.status) {
          logger.info(
            `Syncing order ${exchangeOrder.clientOrderId}: ${localOrder.status} -> ${exchangeOrder.status}`
          );
          idempotencyManager.updateOrderState(
            exchangeOrder.clientOrderId,
            exchangeOrder.exchangeOrderId,
            exchangeOrder.status as any
          );
        }
      }

      logger.info('Order reconciliation complete');
      return { success: true, ordersReconciled: exchangeOrders.length };
    } catch (error) {
      logger.error(`Reconciliation failed: ${error}`);
      return { success: false, error: String(error) };
    }
  }),
});

/**
 * Mock exchange submission
 * In production, this would call Binance/Kraken/etc API
 */
async function submitToExchange(
  intent: OrderIntent,
  clientOrderId: string
): Promise<{ success: boolean; orderId?: string; error?: string }> {
  // Simulate network latency
  await new Promise((resolve) => setTimeout(resolve, Math.random() * 1000));

  // Mock: 95% success rate
  if (Math.random() > 0.05) {
    return {
      success: true,
      orderId: `EX-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    };
  }

  return {
    success: false,
    error: 'Exchange API error',
  };
}

/**
 * Mock query exchange open orders
 */
async function queryExchangeOpenOrders(): Promise<
  Array<{
    clientOrderId: string;
    exchangeOrderId: string;
    status: string;
  }>
> {
  // In production, call exchange API
  return [];
}
