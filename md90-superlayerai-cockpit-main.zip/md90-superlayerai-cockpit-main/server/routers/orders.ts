/**
 * STEP 5: Order Submission Router
 * Safe retry dengan idempotency keys
 */

import { Router, Request, Response, NextFunction } from 'express';
import { idempotencyManager, IdempotencyRequest, IdempotencyState } from '../idempotency';
import { v4 as uuidv4 } from 'uuid';

export interface OrderRequest {
  symbol: string;
  quantity: number;
  price?: number;
  side: 'BUY' | 'SELL';
  orderType: 'MARKET' | 'LIMIT' | 'STOP';
  timeInForce?: 'GTC' | 'IOC' | 'FOK';
}

export interface OrderResponse {
  orderId: string;
  symbol: string;
  quantity: number;
  price?: number;
  side: string;
  orderType: string;
  status: string;
  timestamp: number;
  executedQuantity?: number;
  executedPrice?: number;
}

export interface RetryContext {
  attempt: number;
  maxAttempts: number;
  nextRetryIn: number;
  lastError?: string;
}

const router = Router();

// Middleware untuk parse idempotency key dari header
const extractIdempotencyKey = (req: Request, res: Response, next: NextFunction) => {
  const idempotencyKey = req.headers['idempotency-key'] as string || uuidv4();
  (req as any).idempotencyKey = idempotencyKey;
  res.setHeader('idempotency-key', idempotencyKey);
  next();
};

router.use(extractIdempotencyKey);

/**
 * POST /orders - Submit order dengan idempotency
 */
router.post('/orders', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const idempotencyKey = (req as any).idempotencyKey;
    const order: OrderRequest = req.body;

    // Validate order
    if (!validateOrder(order)) {
      return res.status(400).json({
        error: 'Invalid order request',
        details: 'Missing required fields'
      });
    }

    // Create idempotency request
    const idempotencyRequest: IdempotencyRequest = {
      method: 'POST',
      url: '/orders',
      body: order,
      headers: {
        'idempotency-key': idempotencyKey
      }
    };

    // Register dan check idempotency
    const idempotencyData = idempotencyManager.registerRequest(
      uuidv4(),
      idempotencyRequest,
      5
    );

    // Jika sudah ada result yang success, return cached result
    const existingResult = idempotencyManager.getResult(idempotencyKey);
    if (existingResult?.state === IdempotencyState.SUCCESS) {
      return res.status(200).json({
        result: existingResult.result,
        cached: true,
        idempotencyKey
      });
    }

    // Jika sedang processing, return status
    if (existingResult?.state === IdempotencyState.PROCESSING) {
      return res.status(202).json({
        message: 'Order is being processed',
        idempotencyKey,
        status: IdempotencyState.PROCESSING
      });
    }

    // Update state to PROCESSING
    idempotencyManager.updateState(
      idempotencyKey,
      IdempotencyState.PROCESSING
    );

    // Submit order dengan retry logic
    const orderResponse = await submitOrderWithRetry(order, idempotencyKey, 5);

    // Update state to SUCCESS
    idempotencyManager.updateState(
      idempotencyKey,
      IdempotencyState.SUCCESS,
      orderResponse
    );

    res.status(201).json({
      result: orderResponse,
      idempotencyKey,
      status: 'created'
    });
  } catch (error) {
    const idempotencyKey = (req as any).idempotencyKey;
    const errorMessage = error instanceof Error ? error.message : String(error);

    // Update state to FAILED
    idempotencyManager.updateState(
      idempotencyKey,
      IdempotencyState.FAILED,
      undefined,
      errorMessage
    );

    next(error);
  }
});

/**
 * GET /orders/:orderId - Get order status
 */
router.get('/orders/:orderId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { orderId } = req.params;
    const idempotencyKey = (req as any).idempotencyKey;

    // Get order dari database/cache
    const order = await getOrderFromDatabase(orderId);

    if (!order) {
      return res.status(404).json({
        error: 'Order not found',
        orderId
      });
    }

    res.json({
      result: order,
      idempotencyKey
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /orders - List orders dengan idempotency
 */
router.get('/orders', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const idempotencyKey = (req as any).idempotencyKey;
    const { symbol, status, limit = 100, offset = 0 } = req.query;

    // Get orders dari database
    const orders = await listOrdersFromDatabase({
      symbol: symbol as string,
      status: status as string,
      limit: parseInt(limit as string, 10),
      offset: parseInt(offset as string, 10)
    });

    res.json({
      result: orders,
      idempotencyKey,
      pagination: {
        limit: parseInt(limit as string, 10),
        offset: parseInt(offset as string, 10)
      }
    });
  } catch (error) {
    next(error);
  }
});

/**
 * PATCH /orders/:orderId/cancel - Cancel order dengan idempotency
 */
router.patch('/orders/:orderId/cancel', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { orderId } = req.params;
    const idempotencyKey = (req as any).idempotencyKey;

    // Create idempotency request
    const idempotencyRequest: IdempotencyRequest = {
      method: 'PATCH',
      url: `/orders/${orderId}/cancel`,
      headers: {
        'idempotency-key': idempotencyKey
      }
    };

    // Register idempotency
    idempotencyManager.registerRequest(uuidv4(), idempotencyRequest, 5);

    // Check existing result
    const existingResult = idempotencyManager.getResult(idempotencyKey);
    if (existingResult?.state === IdempotencyState.SUCCESS) {
      return res.json({
        result: existingResult.result,
        cached: true,
        idempotencyKey
      });
    }

    // Update state to PROCESSING
    idempotencyManager.updateState(
      idempotencyKey,
      IdempotencyState.PROCESSING
    );

    // Cancel order
    const cancelledOrder = await cancelOrderInDatabase(orderId);

    // Update state to SUCCESS
    idempotencyManager.updateState(
      idempotencyKey,
      IdempotencyState.SUCCESS,
      cancelledOrder
    );

    res.json({
      result: cancelledOrder,
      idempotencyKey,
      status: 'cancelled'
    });
  } catch (error) {
    const idempotencyKey = (req as any).idempotencyKey;
    const errorMessage = error instanceof Error ? error.message : String(error);

    idempotencyManager.updateState(
      idempotencyKey,
      IdempotencyState.FAILED,
      undefined,
      errorMessage
    );

    next(error);
  }
});

/**
 * Helper: Submit order dengan retry logic
 */
async function submitOrderWithRetry(
  order: OrderRequest,
  idempotencyKey: string,
  maxAttempts: number = 5
): Promise<OrderResponse> {
  let lastError: Error | null = null;
  let attempt = 1;

  while (attempt <= maxAttempts) {
    try {
      console.log(`[OrderRouter] Submitting order (attempt ${attempt}/${maxAttempts})`);

      // Call ke order execution service
      const response = await executeOrder(order);

      console.log(`[OrderRouter] Order submitted successfully:`, response.orderId);
      return response;
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      
      // Check if error is retryable
      if (!isRetryableError(error)) {
        throw error;
      }

      attempt++;

      if (attempt <= maxAttempts) {
        // Calculate exponential backoff
        const delayMs = Math.min(1000 * Math.pow(2, attempt - 1), 30000);
        console.log(`[OrderRouter] Retry in ${delayMs}ms`);
        await new Promise(resolve => setTimeout(resolve, delayMs));
      }
    }
  }

  throw new Error(`Order submission failed after ${maxAttempts} attempts: ${lastError?.message}`);
}

/**
 * Helper: Check if error is retryable
 */
function isRetryableError(error: any): boolean {
  if (error instanceof Error) {
    const message = error.message.toLowerCase();
    
    // Network errors yang bisa di-retry
    if (message.includes('econnrefused') || 
        message.includes('econnreset') || 
        message.includes('timeout') ||
        message.includes('temporarily unavailable')) {
      return true;
    }
  }

  return false;
}

/**
 * Helper: Validate order
 */
function validateOrder(order: OrderRequest): boolean {
  if (!order.symbol || !order.quantity || !order.side || !order.orderType) {
    return false;
  }

  if (!['BUY', 'SELL'].includes(order.side)) {
    return false;
  }

  if (!['MARKET', 'LIMIT', 'STOP'].includes(order.orderType)) {
    return false;
  }

  if (order.orderType === 'LIMIT' && !order.price) {
    return false;
  }

  return true;
}

/**
 * Helper: Execute order (placeholder untuk actual service call)
 */
async function executeOrder(order: OrderRequest): Promise<OrderResponse> {
  return {
    orderId: uuidv4(),
    symbol: order.symbol,
    quantity: order.quantity,
    price: order.price,
    side: order.side,
    orderType: order.orderType,
    status: 'PENDING',
    timestamp: Date.now()
  };
}

/**
 * Helper: Get order dari database
 */
async function getOrderFromDatabase(orderId: string): Promise<OrderResponse | null> {
  // Placeholder untuk actual database call
  return null;
}

/**
 * Helper: List orders dari database
 */
async function listOrdersFromDatabase(query: {
  symbol?: string;
  status?: string;
  limit: number;
  offset: number;
}): Promise<OrderResponse[]> {
  // Placeholder untuk actual database call
  return [];
}

/**
 * Helper: Cancel order dari database
 */
async function cancelOrderInDatabase(orderId: string): Promise<OrderResponse | null> {
  // Placeholder untuk actual database call
  return null;
}

export default router;
