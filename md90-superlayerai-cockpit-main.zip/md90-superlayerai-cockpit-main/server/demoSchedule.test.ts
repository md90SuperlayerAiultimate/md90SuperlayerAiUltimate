import { describe, expect, it } from "vitest";
import { buildDemoHeartbeatJob, DEMO_CRON } from "./demoSchedule";

describe("demo heartbeat schedule", () => {
  it("uses a valid UTC five-minute cron and the protected callback path", () => {
    const job = buildDemoHeartbeatJob();
    expect(DEMO_CRON.split(" ")).toHaveLength(6);
    expect(job).toMatchObject({ name: "md90-demo-paper-24-7", cron: DEMO_CRON, path: "/api/scheduled/demo-paper" });
    expect(job.description).toContain("PAPER-only");
  });
});
