export type ShadowObservation = {
  source: "BINANCE" | "FX" | "CRYPTOIZ" | "DYNAMIC_EXECUTION";
  instrument: string;
  bid: number;
  ask: number;
  mid: number;
  spreadBps: number;
  observedAt: string;
  freshnessSeconds: number;
  quality: "VERIFIED_REPLAY" | "SHADOW_SAMPLE" | "EXTERNAL_PENDING";
  provenance: string;
  permissionScope: "PUBLIC_MARKET_DATA" | "PROVIDER_SESSION_REQUIRED";
  orderRoute: "DISABLED";
};

export type NewsItem = {
  id: string;
  headline: string;
  source: string;
  instrument: string;
  publishedAt: string;
  relevance: number;
  sentiment: "POSITIVE" | "NEUTRAL" | "NEGATIVE";
  status: "PENDING_REVIEW";
};

const now = Date.now();

export function getShadowObservations(): ShadowObservation[] {
  return [
    { source: "BINANCE", instrument: "BTC/USDT", bid: 72407.5, ask: 72412.5, mid: 72410, spreadBps: 0.69, observedAt: new Date(now - 3_000).toISOString(), freshnessSeconds: 3, quality: "EXTERNAL_PENDING", provenance: "STATIC CONTRACT · NOT MARKET EVIDENCE · no order route", permissionScope: "PUBLIC_MARKET_DATA", orderRoute: "DISABLED" },
    { source: "FX", instrument: "EUR/USD", bid: 1.08421, ask: 1.08429, mid: 1.08425, spreadBps: 0.74, observedAt: new Date(now - 7_000).toISOString(), freshnessSeconds: 7, quality: "EXTERNAL_PENDING", provenance: "STATIC CONTRACT · NOT MARKET EVIDENCE · FX venue pending", permissionScope: "PROVIDER_SESSION_REQUIRED", orderRoute: "DISABLED" },
    { source: "FX", instrument: "USD/JPY", bid: 154.82, ask: 154.85, mid: 154.835, spreadBps: 0.19, observedAt: new Date(now - 11_000).toISOString(), freshnessSeconds: 11, quality: "EXTERNAL_PENDING", provenance: "STATIC CONTRACT · NOT MARKET EVIDENCE · FX venue pending", permissionScope: "PROVIDER_SESSION_REQUIRED", orderRoute: "DISABLED" },
    { source: "CRYPTOIZ", instrument: "SOL/USDC", bid: 181.02, ask: 181.21, mid: 181.115, spreadBps: 10.49, observedAt: new Date(now - 28_000).toISOString(), freshnessSeconds: 28, quality: "EXTERNAL_PENDING", provenance: "STATIC CONTRACT · EXTERNAL source/token validation pending", permissionScope: "PROVIDER_SESSION_REQUIRED", orderRoute: "DISABLED" },
    { source: "DYNAMIC_EXECUTION", instrument: "ETH/USDT", bid: 3820.1, ask: 3821.6, mid: 3820.85, spreadBps: 3.93, observedAt: new Date(now - 42_000).toISOString(), freshnessSeconds: 42, quality: "EXTERNAL_PENDING", provenance: "STATIC CONTRACT · external signal validation pending · not execution authority", permissionScope: "PROVIDER_SESSION_REQUIRED", orderRoute: "DISABLED" },
  ];
}

export function classifyNewsFreshness(publishedAt: string, nowMs = Date.now(), staleAfterMs = 30 * 60_000): "FRESH" | "STALE" {
  const age = nowMs - new Date(publishedAt).getTime();
  return age >= 0 && age <= staleAfterMs ? "FRESH" : "STALE";
}

export function getNewsItems(): NewsItem[] {
  return [
    { id: "news-001", headline: "Rates remain the dominant cross-asset variable into the next session", source: "MD90 STATIC CONTRACT · NOT NEWS EVIDENCE", instrument: "EUR/USD · USD/JPY", publishedAt: new Date(now - 8 * 60_000).toISOString(), relevance: 88, sentiment: "NEUTRAL", status: "PENDING_REVIEW" },
    { id: "news-002", headline: "Liquidity concentration detected near BTC 72.4k replay boundary", source: "MD90 STATIC CONTRACT · NOT MARKET EVIDENCE", instrument: "BTC/USDT", publishedAt: new Date(now - 16 * 60_000).toISOString(), relevance: 81, sentiment: "POSITIVE", status: "PENDING_REVIEW" },
    { id: "news-003", headline: "Solana DEX flow requires source-level validation before signal promotion", source: "Cryptoiz / external · PENDING REVIEW", instrument: "SOL/USDC", publishedAt: new Date(now - 31 * 60_000).toISOString(), relevance: 74, sentiment: "NEUTRAL", status: "PENDING_REVIEW" },
  ];
}
