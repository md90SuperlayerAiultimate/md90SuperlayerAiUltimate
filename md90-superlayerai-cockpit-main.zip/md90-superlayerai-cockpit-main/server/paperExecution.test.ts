import { describe, expect, it } from "vitest";
import { buildPaperExecution, reconcilePaperFill } from "@shared/paperExecution";

describe("paper execution state machine", () => {
  it("reconciles a paper fill without crossing the network boundary", () => {
    const execution = buildPaperExecution({ correlationId: "WF-test", timestamp: "2026-08-24T09:00:00.000Z", allowed: true, hasTrade: true });
    expect(execution.state).toBe("RECONCILED");
    expect(execution.orderRoute).toBe("PAPER");
    expect(execution.transitions.map((item) => item.to)).toEqual(["STAGED", "RISK_APPROVED", "SUBMITTED", "FILLED", "RECONCILED"]);
    expect(execution.liveRoute).toBe("LIVE_PENDING_APPROVAL");
    expect(execution.custody).toBe("DISABLED");
  });

  it("fails closed before paper submission when a gate is blocked", () => {
    const execution = buildPaperExecution({ correlationId: "WF-blocked", timestamp: "2026-08-24T09:00:00.000Z", allowed: false, hasTrade: false });
    expect(execution).toMatchObject({ state: "BLOCKED", orderRoute: "DISABLED", liveRoute: "LIVE_PENDING_APPROVAL", custody: "DISABLED" });
    expect(execution.transitions[0].event).toBe("PAPER_GATE_BLOCKED");
  });

  it("creates an explicit exception for partial fills and preserves remaining quantity", () => {
    expect(reconcilePaperFill(1, 0.75)).toMatchObject({ status: "EXCEPTION", category: "PARTIAL_FILL", remainingQuantity: 0.25 });
    expect(reconcilePaperFill(1, 1)).toMatchObject({ status: "RECONCILED", category: "FULL_FILL", remainingQuantity: 0 });
    expect(reconcilePaperFill(1, 0)).toMatchObject({ status: "EXCEPTION", category: "ZERO_FILL", remainingQuantity: 1 });
    expect(reconcilePaperFill(0, 0).category).toBe("INVALID_QUANTITY");
  });
});
