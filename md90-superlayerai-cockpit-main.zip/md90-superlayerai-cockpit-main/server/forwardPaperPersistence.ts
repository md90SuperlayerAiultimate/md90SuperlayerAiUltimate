import { and, desc, eq } from "drizzle-orm";
import { getDb } from "./db";
import { paperEquityPoints, paperFills, paperJournal, paperOrders, paperPositions, paperRiskStates, paperSessions, paperSignals, paperSnapshots, paperWorkflowEvents } from "../drizzle/schema";
import type { ForwardPaperResult } from "@shared/forwardPaperSession";
import type { ForwardComparison } from "@shared/forwardComparison";

function asDate(value: string | number | null | undefined) {
  const date = value === null || value === undefined ? new Date() : new Date(value);
  return Number.isNaN(date.getTime()) ? new Date() : date;
}

export async function persistForwardPaperSession(userId: number, result: ForwardPaperResult, provenance: string, correlationId: string, comparison?: ForwardComparison) {
  const db = await getDb();
  if (!db) return { persisted: false as const, reason: "database-unavailable" as const };
  const name = `md90 Forward Paper — ${result.symbol}`;
  const existing = await db.select().from(paperSessions).where(and(eq(paperSessions.userId, userId), eq(paperSessions.name, name))).orderBy(desc(paperSessions.updatedAt)).limit(1);
  let sessionId = existing[0]?.id;
  if (!sessionId) {
    const inserted = await db.insert(paperSessions).values({ userId, name, mode: "paper", startingEquity: result.equityCurve[0]?.equity ?? result.equity, equity: result.equity, peakEquity: Math.max(...result.equityCurve.map((point) => point.equity)), dailyPnl: result.realizedPnl, grossExposure: 0, realizedPnl: result.realizedPnl, unrealizedPnl: 0, maxDrawdownPct: result.maxDrawdownPct, tradeCount: result.fills }).$returningId();
    sessionId = inserted[0]?.id;
  } else {
    await db.update(paperSessions).set({ equity: result.equity, peakEquity: Math.max(...result.equityCurve.map((point) => point.equity)), dailyPnl: result.realizedPnl, realizedPnl: result.realizedPnl, maxDrawdownPct: result.maxDrawdownPct, tradeCount: result.fills }).where(eq(paperSessions.id, sessionId));
  }
  if (!sessionId) return { persisted: false as const, reason: "session-create-failed" as const };

  const intents = result.events.filter((event) => event.type === "ORDER_INTENT");
  for (const event of result.events) {
    const eventId = `${correlationId}:${event.type}:${event.index}:${event.clientOrderId ?? "none"}`;
    await db.insert(paperWorkflowEvents).values({ sessionId, eventId, idempotencyKey: `${userId}:${eventId}`, correlationId, causationId: correlationId, stage: event.type === "SIMULATED_FILL" ? "PAPER_FILL" : event.type === "RECONCILIATION" ? "RECONCILIATION" : "JOURNAL", eventType: `FORWARD_${event.type}`, instrument: result.symbol, payloadJson: JSON.stringify(event), provenance, occurredAt: asDate(event.timestamp) }).onDuplicateKeyUpdate({ set: { payloadJson: JSON.stringify(event), occurredAt: asDate(event.timestamp) } });
  }
  for (const event of result.events.filter((item) => item.type === "SIGNAL")) {
    const signalId = `${correlationId}:signal:${event.index}`.slice(0, 96);
    await db.insert(paperSignals).values({ sessionId, signalId, instrument: result.symbol, bias: event.direction ?? "NEUTRAL", score: 0, confidence: 0, source: "FORWARD_PAPER_LOOKBACK", observedAt: asDate(event.timestamp), provenance }).onDuplicateKeyUpdate({ set: { observedAt: asDate(event.timestamp), provenance } });
  }
  for (const intent of intents) {
    const orderId = intent.clientOrderId ?? `${correlationId}:order:${intent.index}`;
    const fill = result.events.find((event) => event.type === "SIMULATED_FILL" && event.clientOrderId === intent.clientOrderId);
    const fillPayload = fill?.payload ?? {};
    await db.insert(paperOrders).values({ sessionId, clientOrderId: orderId, signalId: `${correlationId}:signal:${intent.index}`.slice(0, 96), venue: result.venue, instrument: result.symbol, direction: intent.direction === "LONG" ? "BUY" : "SELL", intent: "ENTRY", quantity: Number(intent.quantity ?? 0), limitPrice: Number(intent.price ?? 0), status: fill ? "filled" : "rejected", rejectionReason: fill ? null : "No simulated fill accepted" }).onDuplicateKeyUpdate({ set: { status: fill ? "filled" : "rejected", quantity: Number(intent.quantity ?? 0), limitPrice: Number(intent.price ?? 0) } });
    const order = await db.select({ id: paperOrders.id }).from(paperOrders).where(eq(paperOrders.clientOrderId, orderId)).limit(1);
    if (order[0] && fill) {
      const existingFill = await db.select({ id: paperFills.id }).from(paperFills).where(eq(paperFills.orderId, order[0].id)).limit(1);
      if (!existingFill[0]) await db.insert(paperFills).values({ orderId: order[0].id, fillQuantity: Number(fill.quantity ?? 0), averagePrice: Number(fill.price ?? 0), fee: Number(fillPayload.fee ?? 0), slippageBps: Number(fillPayload.slippageBps ?? 0), filledAt: asDate(fill.timestamp) });
      const position = await db.select({ id: paperPositions.id }).from(paperPositions).where(and(eq(paperPositions.sessionId, sessionId), eq(paperPositions.instrument, result.symbol), eq(paperPositions.direction, intent.direction ?? "LONG"))).limit(1);
      const flat = result.events.some((event) => event.type === "JOURNAL" && event.index >= intent.index && (event.payload.event === "TIME_STOP_REVIEW" || event.payload.event === "SESSION_CLOSE_REVIEW"));
      const positionValues = { sessionId, venue: result.venue, instrument: result.symbol, direction: intent.direction ?? "LONG", quantity: flat ? 0 : Number(fill.quantity ?? 0), averageEntry: Number(fill.price ?? 0), markPrice: Number(fill.price ?? 0), unrealizedPnl: 0, openedAt: asDate(fill.timestamp), barClockAt: asDate(fill.timestamp), barsHeld: 0, baseTimeframe: "15m" };
      if (position[0]) await db.update(paperPositions).set(positionValues).where(eq(paperPositions.id, position[0].id));
      else await db.insert(paperPositions).values(positionValues);
    }
  }
  for (const point of result.equityCurve) {
    const pointEventId = `${correlationId}:equity:${point.index}`;
    const existingPoint = await db.select({ id: paperWorkflowEvents.id }).from(paperWorkflowEvents).where(eq(paperWorkflowEvents.eventId, pointEventId)).limit(1);
    if (!existingPoint[0]) {
      await db.insert(paperEquityPoints).values({ sessionId, timestamp: asDate(point.timestamp), equity: point.equity, realizedPnl: result.realizedPnl, unrealizedPnl: 0, drawdownPct: point.drawdownPct });
      await db.insert(paperWorkflowEvents).values({ sessionId, eventId: pointEventId, idempotencyKey: `${userId}:${pointEventId}`, correlationId, causationId: correlationId, stage: "JOURNAL", eventType: "FORWARD_EQUITY_POINT", instrument: result.symbol, payloadJson: JSON.stringify(point), provenance, occurredAt: asDate(point.timestamp) });
    }
  }
  for (const event of result.events.filter((item) => item.type === "JOURNAL" || item.type === "RECONCILIATION")) await db.insert(paperJournal).values({ sessionId, event: `FORWARD_${event.type}`, detail: JSON.stringify(event), provenance, timestamp: asDate(event.timestamp) });
  if (comparison) {
    const comparisonEventId = `${correlationId}:comparison`;
    const existingComparison = await db.select({ id: paperWorkflowEvents.id }).from(paperWorkflowEvents).where(eq(paperWorkflowEvents.eventId, comparisonEventId)).limit(1);
    if (!existingComparison[0]) {
      await db.insert(paperJournal).values({ sessionId, event: "FORWARD_BACKTEST_COMPARISON", detail: JSON.stringify({ correlationId, comparison }), provenance, timestamp: new Date() });
      await db.insert(paperWorkflowEvents).values({ sessionId, eventId: comparisonEventId, idempotencyKey: `${userId}:${comparisonEventId}`, correlationId, causationId: correlationId, stage: "JOURNAL", eventType: "FORWARD_BACKTEST_COMPARISON", instrument: result.symbol, payloadJson: JSON.stringify(comparison), provenance, occurredAt: new Date() });
    }
  }
  const lastEquityPoint = result.equityCurve.at(-1);
  const lastEquityMs = lastEquityPoint?.timestamp ? new Date(lastEquityPoint.timestamp).getTime() : NaN;
  const riskDataFreshnessSeconds = Number.isFinite(lastEquityMs) ? Math.max(0, Math.round((Date.now() - lastEquityMs) / 1000)) : Number.MAX_SAFE_INTEGER;
  await db.insert(paperRiskStates).values({ sessionId, dailyLossPct: result.equity < (result.equityCurve[0]?.equity ?? result.equity) ? Math.abs(result.realizedPnl / (result.equityCurve[0]?.equity || 1) * 100) : 0, grossExposurePct: 0, drawdownPct: result.maxDrawdownPct, dataFreshnessSeconds: riskDataFreshnessSeconds, liveApproval: "locked", evaluatedAt: new Date() });
  return { persisted: true as const, sessionId, symbol: result.symbol, correlationId, events: result.events.length, orders: result.orders, fills: result.fills, executionAuthority: result.executionAuthority, orderRoute: result.orderRoute };
}
