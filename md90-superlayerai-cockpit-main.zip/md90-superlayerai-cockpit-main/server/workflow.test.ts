import { describe, expect, it } from "vitest";
import { buildWorkflow } from "@shared/workflow";

const baseInput = {
  instrument: "BTC/USDT",
  baseTimeframe: "15m",
  higherTimeframe: "4h",
  generatedAt: "2026-08-24T09:00:00.000Z",
  provenance: "Deterministic replay",
  dataFreshnessSeconds: 3,
  riskChecks: [
    { label: "Daily loss limit", status: "PASS" as const, detail: "0 / 2%" },
    { label: "Live approval", status: "LOCKED" as const, detail: "Paper-only" },
  ],
  hasTrade: true,
};

describe("paper workflow contract", () => {
  it("creates a deterministic auditable path from source to journal", () => {
    const workflow = buildWorkflow(baseInput);
    expect(workflow.correlationId).toBe(buildWorkflow(baseInput).correlationId);
    expect(workflow.events.map((event) => event.stage)).toEqual(["SOURCE", "CONFLUENCE", "RISK_GATE", "PAPER_FILL", "JOURNAL"]);
    expect(workflow.events.at(-1)).toMatchObject({ state: "RECORDED", stage: "JOURNAL" });
    expect(workflow.decision).toBe("PAPER_ALLOWED");
    expect(workflow.liveRoute).toBe("LIVE_PENDING_APPROVAL");
    expect(workflow.custody).toBe("DISABLED");
  });

  it("blocks the decision when a pre-trade gate fails", () => {
    const workflow = buildWorkflow({ ...baseInput, dataFreshnessSeconds: 120, riskChecks: [{ label: "Data freshness", status: "LOCKED", detail: "120 sec / 90 sec" }] });
    expect(workflow.decision).toBe("PAPER_BLOCKED");
    expect(workflow.currentStage).toBe("SOURCE");
    expect(workflow.events.some((event) => event.state === "BLOCKED")).toBe(true);
    expect(workflow.liveRoute).toBe("LIVE_PENDING_APPROVAL");
  });
});
