export type DemoTradeDraft = {
  batchId: string;
  instrument: string;
  side: "LONG" | "SHORT";
  entryPrice: number;
  exitPrice: number;
  quantity: number;
  pnl: number;
  fee: number;
  outcome: "WIN" | "LOSS" | "FLAT";
  executedAt: Date;
  provenance: string;
};

const instruments = [
  { symbol: "BTC/USDT", price: 72400, step: 160 },
  { symbol: "ETH/USDT", price: 3820, step: 14 },
  { symbol: "EUR/USD", price: 1.086, step: 0.0016 },
  { symbol: "USD/JPY", price: 149.4, step: 0.22 },
  { symbol: "XAU/USD", price: 2385, step: 4.2 },
  { symbol: "SOL/USDT", price: 178, step: 1.8 },
  { symbol: "GBP/USD", price: 1.271, step: 0.0018 },
  { symbol: "AUD/USD", price: 0.659, step: 0.0014 },
];

function hashSeed(value: string) {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function unit(seed: number) {
  return (seed % 10_000) / 10_000;
}

export function demoBatchId(executedAt: Date) {
  const minuteBucket = Math.floor(executedAt.getTime() / 60_000);
  return `demo-${minuteBucket}`;
}

export function generateDemoBatch(executedAt = new Date()): DemoTradeDraft[] {
  const batchId = demoBatchId(executedAt);
  const canonicalExecutedAt = new Date(Math.floor(executedAt.getTime() / 60_000) * 60_000);
  return instruments.map((instrument, index) => {
    const seed = hashSeed(`${batchId}:${instrument.symbol}:${index}`);
    const side: "LONG" | "SHORT" = seed % 2 === 0 ? "LONG" : "SHORT";
    const win = unit(seed) > 0.36;
    const direction = win ? 1 : -1;
    const signedMove = direction * instrument.step * (0.65 + unit(seed >>> 3) * 0.7);
    const entryPrice = instrument.price + instrument.step * (unit(seed >>> 5) - 0.5);
    const exitPrice = side === "LONG" ? entryPrice + signedMove : entryPrice - signedMove;
    const quantity = instrument.symbol.includes("/") && instrument.price > 100 ? 0.01 : 1_000;
    const grossPnl = side === "LONG" ? (exitPrice - entryPrice) * quantity : (entryPrice - exitPrice) * quantity;
    const fee = Math.abs(entryPrice * quantity) * 0.0004;
    const pnl = Number((grossPnl - fee).toFixed(4));
    return {
      batchId: `${batchId}-${index}`,
      instrument: instrument.symbol,
      side,
      entryPrice: Number(entryPrice.toFixed(instrument.price < 10 ? 5 : 2)),
      exitPrice: Number(exitPrice.toFixed(instrument.price < 10 ? 5 : 2)),
      quantity,
      pnl,
      fee: Number(fee.toFixed(4)),
      outcome: pnl > 0.0001 ? "WIN" : pnl < -0.0001 ? "LOSS" : "FLAT",
      executedAt: canonicalExecutedAt,
      provenance: "MD90 demo paper simulator / deterministic batch",
    };
  });
}

export function calculateDemoStats(
  startingEquity: number,
  trades: Array<Pick<DemoTradeDraft, "pnl" | "outcome">>
) {
  const realizedPnl = trades.reduce((sum, trade) => sum + trade.pnl, 0);
  const wins = trades.filter((trade) => trade.outcome === "WIN").length;
  const losses = trades.filter((trade) => trade.outcome === "LOSS").length;
  const equity = startingEquity + realizedPnl;
  const winRatePct = trades.length ? (wins / trades.length) * 100 : 0;
  const expectancy = trades.length ? realizedPnl / trades.length : 0;
  const targetWinRatePct = 93;
  const sampleQuality = trades.length < 30 ? "INSUFFICIENT_SAMPLE" as const : winRatePct >= targetWinRatePct ? "MEETS_TARGET" as const : "TRACKING" as const;
  return {
    tradeCount: trades.length,
    wins,
    losses,
    realizedPnl: Number(realizedPnl.toFixed(4)),
    equity: Number(equity.toFixed(4)),
    winRatePct: Number(winRatePct.toFixed(2)),
    expectancy: Number(expectancy.toFixed(4)),
    targetWinRatePct,
    sampleQuality,
  };
}
