import { describe, expect, it } from "vitest";
import { runCanonicalReplayBacktest } from "./paperReplayBacktest";

describe("canonical paper replay backtest", () => {
  it("uses paper engine replay bars with explicit costs and no live route", () => {
    const result = runCanonicalReplayBacktest();
    expect(result).toMatchObject({ mode: "PAPER_BACKTEST", source: "server/paperEngine.ts:getCanonicalReplayPrices", bars: 24, trades: 11, feeBps: 10, slippageBps: 5, liveRoute: "DISABLED" });
    expect(result.realizedPnl).toBeGreaterThan(0);
    expect(result.targetStatus).toBe("TRACKING");
    expect(result.winRatePct).toBeLessThan(93);
  });
});
