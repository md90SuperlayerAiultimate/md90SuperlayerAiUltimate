import { and, desc, eq } from "drizzle-orm";
import { newsItems, paperEquityPoints, paperFills, paperJournal, paperOrders, paperPositions, paperRiskStates, paperSessions, paperSignals, paperSnapshots, paperReconciliationExceptions, paperWorkflowEvents, paperIdempotencyReceipts, shadowObservations } from "../drizzle/schema";
import { getDb } from "./db";
import type { PaperOverview } from "./paperEngine";
import type { NewsItem, ShadowObservation } from "./shadowAdapters";
import { advancePaperPositionClock, evaluatePaperTimeStop } from "@shared/paperPositionClock";
import { strategyConfig } from "@shared/strategyConfig";

const sessionCache = new Map<number, number>();
const persistedOverviewKeys = new Set<string>();

async function withCommandTransaction<T>(db: any, work: (transaction: any) => Promise<T>) {
  if (typeof db.transaction === "function") return db.transaction(work);
  return work(db);
}

export function overviewPersistenceKey(userId: number, generatedAt: string) {
  return `${userId}:${generatedAt.slice(0, 16)}`;
}

export function shouldPersistOverview(userId: number, generatedAt: string) {
  const key = overviewPersistenceKey(userId, generatedAt);
  if (persistedOverviewKeys.has(key)) return false;
  persistedOverviewKeys.add(key);
  return true;
}

export async function persistShadowAndNews(observations: ShadowObservation[], news: NewsItem[]) {
  const db = await getDb();
  if (!db) return { persisted: false as const };
  for (const item of observations) {
    const observedAt = new Date(item.observedAt);
    const existing = await db.select({ id: shadowObservations.id }).from(shadowObservations).where(and(eq(shadowObservations.source, item.source), eq(shadowObservations.instrument, item.instrument), eq(shadowObservations.observedAt, observedAt))).limit(1);
    const values = { source: item.source, instrument: item.instrument, bid: item.bid, ask: item.ask, mid: item.mid, spreadBps: item.spreadBps, observedAt, freshnessSeconds: item.freshnessSeconds, quality: item.quality, provenance: item.provenance };
    if (existing[0]) await db.update(shadowObservations).set(values).where(eq(shadowObservations.id, existing[0].id));
    else await db.insert(shadowObservations).values(values);
  }
  for (const item of news) {
    await db.insert(newsItems).values({ externalId: item.id, headline: item.headline, source: item.source, instrument: item.instrument, publishedAt: new Date(item.publishedAt), relevance: item.relevance, sentiment: item.sentiment, status: item.status }).onDuplicateKeyUpdate({ set: { headline: item.headline, source: item.source, instrument: item.instrument, relevance: item.relevance, sentiment: item.sentiment, status: item.status } });
  }
  return { persisted: true as const };
}

export async function getOrCreatePaperSession(userId: number, overview: PaperOverview) {
  const db = await getDb();
  if (!db) return undefined;
  let sessionId = sessionCache.get(userId);
  if (!sessionId) {
    const existing = await db.select({ id: paperSessions.id }).from(paperSessions).where(eq(paperSessions.userId, userId)).limit(1);
    if (existing[0]) sessionId = existing[0].id;
    else {
      const inserted = await db.insert(paperSessions).values({ userId, name: "md90 All-in-one Paper Session", mode: "paper", startingEquity: overview.metrics.equity, equity: overview.metrics.equity, peakEquity: overview.metrics.equity, dailyPnl: overview.metrics.realizedPnl, grossExposure: overview.metrics.grossExposurePct, realizedPnl: overview.metrics.realizedPnl, unrealizedPnl: overview.metrics.unrealizedPnl, maxDrawdownPct: Math.abs(overview.metrics.peakDrawdownPct), tradeCount: overview.metrics.tradeCount }).$returningId();
      sessionId = inserted[0]?.id;
    }
    if (sessionId) sessionCache.set(userId, sessionId);
  }
  return sessionId;
}

export async function getPaperJournal(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const session = await db.select({ id: paperSessions.id }).from(paperSessions).where(eq(paperSessions.userId, userId)).limit(1);
  if (!session[0]) return [];
  return db.select().from(paperJournal).where(eq(paperJournal.sessionId, session[0].id)).orderBy(desc(paperJournal.timestamp)).limit(50);
}

export async function getPaperTimeStopReview(userId: number, instrument: string) {
  const db = await getDb();
  if (!db) return { status: "blocked" as const, reason: "database-unavailable" as const };
  const session = await db.select({ id: paperSessions.id }).from(paperSessions).where(eq(paperSessions.userId, userId)).limit(1);
  if (!session[0]) return { status: "blocked" as const, reason: "session-not-found" as const };
  const positions = await db.select().from(paperPositions).where(and(eq(paperPositions.sessionId, session[0].id), eq(paperPositions.instrument, instrument)));
  const position = positions.find((item) => item.quantity > 0);
  if (!position) return { status: "blocked" as const, reason: "no-open-paper-position" as const };
  const review = evaluatePaperTimeStop({ openedAt: position.openedAt, barClockAt: position.barClockAt, barsHeld: position.barsHeld, baseTimeframe: position.baseTimeframe }, strategyConfig.fusion.timeStopBars);
  return { status: "ready" as const, positionId: position.id, instrument: position.instrument, openedAt: position.openedAt, baseTimeframe: position.baseTimeframe, ...review };
}

function stageForEvent(event: string) {
  if (event.includes("RISK")) return "RISK_GATE";
  if (event.includes("ORDER") || event.includes("FILL")) return "PAPER_FILL";
  if (event.includes("LIVE")) return "SAFETY";
  return "JOURNAL";
}

export async function persistPaperWorkflowEvents(userId: number, overview: PaperOverview, correlationId: string) {
  const db = await getDb();
  if (!db) return { persisted: false as const, count: 0, reason: "database-unavailable" as const };
  const sessionId = await getOrCreatePaperSession(userId, overview);
  if (!sessionId) return { persisted: false as const, count: 0, reason: "session-create-failed" as const };
  for (let index = 0; index < overview.journal.length; index += 1) {
    const entry = overview.journal[index];
    const eventId = `${correlationId}:journal:${index}:${entry.event}:${entry.timestamp}`;
    await db.insert(paperWorkflowEvents).values({
      sessionId,
      eventId,
      idempotencyKey: `${userId}:${eventId}`,
      correlationId,
      causationId: correlationId,
      stage: stageForEvent(entry.event),
      eventType: entry.event,
      instrument: overview.primary.market,
      payloadJson: JSON.stringify(entry),
      provenance: entry.provenance,
      occurredAt: new Date(entry.timestamp),
    }).onDuplicateKeyUpdate({ set: { eventId } });
  }
  return { persisted: true as const, count: overview.journal.length, sessionId };
}

export type ReconciliationExceptionInput = {
  exceptionKey: string;
  correlationId: string;
  instrument: string;
  category: string;
  severity?: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  expectedState: string;
  observedState: string;
  detail: string;
  firstSeenAt?: Date;
  lastSeenAt?: Date;
};

export async function upsertReconciliationException(userId: number, overview: PaperOverview, input: ReconciliationExceptionInput) {
  const db = await getDb();
  if (!db) return { persisted: false as const, reason: "database-unavailable" as const };
  const sessionId = await getOrCreatePaperSession(userId, overview);
  if (!sessionId) return { persisted: false as const, reason: "session-create-failed" as const };
  const now = input.lastSeenAt ?? new Date();
  const existing = await db.select({ id: paperReconciliationExceptions.id }).from(paperReconciliationExceptions).where(eq(paperReconciliationExceptions.exceptionKey, input.exceptionKey)).limit(1);
  if (existing[0]) {
    await db.update(paperReconciliationExceptions).set({ observedState: input.observedState, detail: input.detail, lastSeenAt: now }).where(eq(paperReconciliationExceptions.id, existing[0].id));
    return { persisted: true as const, created: false as const, id: existing[0].id };
  }
  const inserted = await db.insert(paperReconciliationExceptions).values({ sessionId, ...input, severity: input.severity ?? "MEDIUM", state: "OPEN", firstSeenAt: input.firstSeenAt ?? now, lastSeenAt: now });
  return { persisted: true as const, created: true as const, id: Number(inserted[0]?.insertId ?? 0) };
}

export async function getPaperWorkflowEvents(userId: number, correlationId?: string) {
  const db = await getDb();
  if (!db) return [];
  const session = await db.select({ id: paperSessions.id }).from(paperSessions).where(eq(paperSessions.userId, userId)).limit(1);
  if (!session[0]) return [];
  const rows = await db.select().from(paperWorkflowEvents).where(eq(paperWorkflowEvents.sessionId, session[0].id)).orderBy(desc(paperWorkflowEvents.occurredAt)).limit(200);
  return correlationId ? rows.filter((row) => row.correlationId === correlationId) : rows;
}

export async function closeLatestPaperPosition(userId: number, overview: PaperOverview, input: { correlationId: string; instrument: string; reason: string }) {
  const db = await getDb();
  if (!db) return { status: "blocked" as const, reason: "database-unavailable" as const };
  const sessionId = await getOrCreatePaperSession(userId, overview);
  if (!sessionId) return { status: "blocked" as const, reason: "session-create-failed" as const };
  return withCommandTransaction(db, async (transaction) => {
    const positions = await transaction.select().from(paperPositions).where(and(eq(paperPositions.sessionId, sessionId), eq(paperPositions.instrument, input.instrument)));
    const position = positions.find((item: typeof paperPositions.$inferSelect) => item.quantity > 0);
    if (!position) return { status: "blocked" as const, reason: "no-open-paper-position" as const };

    const clientOrderId = `close:${input.correlationId}`.slice(0, 96);
    const existing = await transaction.select({ id: paperOrders.id }).from(paperOrders).where(eq(paperOrders.clientOrderId, clientOrderId)).limit(1);
    if (existing[0]) return { status: "already-closed" as const, orderId: existing[0].id, positionId: position.id };

    const exitPrice = overview.primary.last;
    const exitDirection = position.direction === "SHORT" ? "BUY" : "SELL";
    const grossPnl = Number(((position.direction === "SHORT" ? position.averageEntry - exitPrice : exitPrice - position.averageEntry) * position.quantity).toFixed(8));
    const fee = Number((exitPrice * position.quantity * 0.0006).toFixed(8));
    const realizedPnl = Number((grossPnl - fee).toFixed(8));
    const now = new Date(overview.generatedAt);
    const inserted = await transaction.insert(paperOrders).values({ sessionId, clientOrderId, signalId: `close:${input.correlationId}`.slice(0, 96), venue: "REPLAY", instrument: position.instrument, direction: exitDirection, intent: "EXIT", quantity: position.quantity, limitPrice: exitPrice, status: "filled" }).$returningId();
    const orderId = inserted[0]?.id;
    if (!orderId) return { status: "blocked" as const, reason: "close-order-create-failed" as const };
    await transaction.insert(paperFills).values({ orderId, fillQuantity: position.quantity, averagePrice: exitPrice, fee, slippageBps: 0, filledAt: now });
    await transaction.update(paperPositions).set({ quantity: 0, markPrice: exitPrice, unrealizedPnl: 0 }).where(eq(paperPositions.id, position.id));
    const detail = JSON.stringify({ correlationId: input.correlationId, reason: input.reason, positionId: position.id, exitPrice, quantity: position.quantity, grossPnl, fee, realizedPnl, route: "PAPER_REPLAY_ONLY" });
    await transaction.insert(paperJournal).values({ sessionId, event: "PAPER_POSITION_CLOSED", detail, provenance: overview.provenance, timestamp: now });
    const eventId = `${input.correlationId}:position-closed`;
    await transaction.insert(paperWorkflowEvents).values({ sessionId, eventId, idempotencyKey: `${userId}:${eventId}`, correlationId: input.correlationId, causationId: input.correlationId, stage: "JOURNAL", eventType: "PAPER_POSITION_CLOSED", instrument: position.instrument, payloadJson: detail, provenance: overview.provenance, occurredAt: now }).onDuplicateKeyUpdate({ set: { eventId } });
    return { status: "closed" as const, orderId, positionId: position.id, exitPrice, quantity: position.quantity, grossPnl, fee, realizedPnl, route: "PAPER_REPLAY_ONLY" as const };
  });
}

export async function getReconciliationExceptions(userId: number, state?: "OPEN" | "ACKNOWLEDGED" | "RESOLVED") {
  const db = await getDb();
  if (!db) return [];
  const session = await db.select({ id: paperSessions.id }).from(paperSessions).where(eq(paperSessions.userId, userId)).limit(1);
  if (!session[0]) return [];
  const rows = await db.select().from(paperReconciliationExceptions).where(eq(paperReconciliationExceptions.sessionId, session[0].id)).orderBy(desc(paperReconciliationExceptions.lastSeenAt)).limit(100);
  return state ? rows.filter((row) => row.state === state) : rows;
}

export async function transitionReconciliationException(userId: number, exceptionId: number, state: "ACKNOWLEDGED" | "RESOLVED", resolutionNote?: string) {
  const db = await getDb();
  if (!db) return { updated: false as const, reason: "database-unavailable" as const };
  const session = await db.select({ id: paperSessions.id }).from(paperSessions).where(eq(paperSessions.userId, userId)).limit(1);
  if (!session[0]) return { updated: false as const, reason: "session-not-found" as const };
  const existing = await db.select({ id: paperReconciliationExceptions.id }).from(paperReconciliationExceptions).where(and(eq(paperReconciliationExceptions.id, exceptionId), eq(paperReconciliationExceptions.sessionId, session[0].id))).limit(1);
  if (!existing[0]) return { updated: false as const, reason: "exception-not-found" as const };
  return withCommandTransaction(db, async (transaction) => {
    await transaction.update(paperReconciliationExceptions).set({ state, resolutionNote: resolutionNote ?? null, resolvedAt: state === "RESOLVED" ? new Date() : null }).where(eq(paperReconciliationExceptions.id, exceptionId));
    return { updated: true as const, state };
  });
}

export async function claimPaperOverview(userId: number, overview: PaperOverview) {
  const db = await getDb();
  if (!db) return { claimed: false as const, reason: "database-unavailable" as const };
  const idempotencyKey = overviewPersistenceKey(userId, overview.generatedAt);
  const existing = await db.select({ id: paperIdempotencyReceipts.id }).from(paperIdempotencyReceipts).where(eq(paperIdempotencyReceipts.idempotencyKey, idempotencyKey)).limit(1);
  if (existing[0]) return { claimed: false as const, reason: "already-recorded" as const };
  try {
    await db.insert(paperIdempotencyReceipts).values({ userId, idempotencyKey, resource: "paper_overview", generatedAt: new Date(overview.generatedAt) });
    return { claimed: true as const };
  } catch (error) {
    const code = (error as { code?: string | number }).code;
    if (code === "ER_DUP_ENTRY" || code === 1062) return { claimed: false as const, reason: "already-recorded" as const };
    throw error;
  }
}

export async function persistPaperOverview(userId: number, overview: PaperOverview) {
  const key = overviewPersistenceKey(userId, overview.generatedAt);
  if (!shouldPersistOverview(userId, overview.generatedAt)) return { persisted: false as const, reason: "already-recorded" as const };
  const db = await getDb();
  if (!db) {
    persistedOverviewKeys.delete(key);
    return { persisted: false as const, reason: "database-unavailable" as const };
  }
  try {
    const claim = await claimPaperOverview(userId, overview);
    if (!claim.claimed) {
      if (claim.reason === "database-unavailable") persistedOverviewKeys.delete(key);
      return { persisted: false as const, reason: claim.reason };
    }
    const sessionId = await getOrCreatePaperSession(userId, overview);
    if (!sessionId) {
      persistedOverviewKeys.delete(key);
      return { persisted: false as const, reason: "session-create-failed" as const };
    }
    const generatedAt = new Date(overview.generatedAt);
  const spreadBps = Number((((overview.primary.ask - overview.primary.bid) / overview.primary.last) * 10_000).toFixed(2));
  await db.insert(paperSnapshots).values({ sessionId, venue: "REPLAY", instrument: overview.primary.market, timestamp: generatedAt, bid: overview.primary.bid, ask: overview.primary.ask, last: overview.primary.last, spreadBps, source: overview.provenance, quality: "valid" });
  await db.insert(paperSignals).values(overview.signals.map((signal) => ({ sessionId, signalId: `${signal.symbol}-${overview.generatedAt}`, instrument: signal.market, bias: signal.bias, score: signal.score, confidence: signal.confidence, source: signal.source, observedAt: generatedAt, provenance: overview.provenance })));
  for (const trade of overview.trades) {
    const existingOrder = await db.select({ id: paperOrders.id }).from(paperOrders).where(eq(paperOrders.clientOrderId, trade.id)).limit(1);
    if (!existingOrder[0]) {
      const orderRow = await db.insert(paperOrders).values({ sessionId, clientOrderId: trade.id, signalId: `${trade.instrument}-${overview.generatedAt}`, venue: "REPLAY", instrument: trade.instrument, direction: trade.side, intent: "ENTRY", quantity: trade.quantity, limitPrice: trade.price, status: "filled" }).$returningId();
      const orderId = orderRow[0]?.id;
      if (orderId) await db.insert(paperFills).values({ orderId, fillQuantity: trade.quantity, averagePrice: trade.price, fee: trade.fee, slippageBps: trade.slippageBps, filledAt: new Date(trade.timestamp) });
    }
  }
  for (const position of overview.positions) {
    const existing = (await db.select().from(paperPositions).where(and(eq(paperPositions.sessionId, sessionId), eq(paperPositions.instrument, position.instrument), eq(paperPositions.direction, position.direction))).limit(1))[0];
    const observedAt = new Date(overview.generatedAt);
    const positionValues = { sessionId, venue: "REPLAY", instrument: position.instrument, direction: position.direction, quantity: position.quantity, averageEntry: position.entry, markPrice: position.mark, unrealizedPnl: position.unrealizedPnl, baseTimeframe: overview.timeframe };
    if (existing) {
      const clock = advancePaperPositionClock({ openedAt: existing.openedAt, barClockAt: existing.barClockAt, barsHeld: existing.barsHeld, baseTimeframe: existing.baseTimeframe || overview.timeframe }, observedAt);
      await db.update(paperPositions).set({ ...positionValues, barClockAt: clock.barClockAt, barsHeld: clock.barsHeld }).where(eq(paperPositions.id, existing.id));
    } else await db.insert(paperPositions).values({ ...positionValues, openedAt: observedAt, barClockAt: observedAt, barsHeld: 0 });
  }
  await db.insert(paperRiskStates).values({ sessionId, dailyLossPct: 0, grossExposurePct: overview.metrics.grossExposurePct, drawdownPct: Math.abs(overview.metrics.peakDrawdownPct), dataFreshnessSeconds: overview.metrics.dataFreshnessSeconds, liveApproval: "locked" });
  for (const entry of overview.journal) {
    const timestamp = new Date(entry.timestamp);
    const existingJournal = await db.select({ id: paperJournal.id }).from(paperJournal).where(and(eq(paperJournal.sessionId, sessionId), eq(paperJournal.event, entry.event), eq(paperJournal.timestamp, timestamp))).limit(1);
    const journalValues = { sessionId, event: entry.event, detail: entry.detail, provenance: entry.provenance, timestamp };
    if (existingJournal[0]) await db.update(paperJournal).set(journalValues).where(eq(paperJournal.id, existingJournal[0].id));
    else await db.insert(paperJournal).values(journalValues);
  }
  for (const point of overview.equityCurve) {
    const timestamp = new Date(point.timestamp);
    const existingPoint = await db.select({ id: paperEquityPoints.id }).from(paperEquityPoints).where(and(eq(paperEquityPoints.sessionId, sessionId), eq(paperEquityPoints.timestamp, timestamp))).limit(1);
    const pointValues = { sessionId, timestamp, equity: point.equity, realizedPnl: overview.metrics.realizedPnl, unrealizedPnl: overview.metrics.unrealizedPnl, drawdownPct: point.drawdownPct };
    if (existingPoint[0]) await db.update(paperEquityPoints).set(pointValues).where(eq(paperEquityPoints.id, existingPoint[0].id));
    else await db.insert(paperEquityPoints).values(pointValues);
  }
    return { persisted: true as const, sessionId };
  } catch (error) {
    persistedOverviewKeys.delete(key);
    await db.delete(paperIdempotencyReceipts).where(eq(paperIdempotencyReceipts.idempotencyKey, key));
    throw error;
  }
}
