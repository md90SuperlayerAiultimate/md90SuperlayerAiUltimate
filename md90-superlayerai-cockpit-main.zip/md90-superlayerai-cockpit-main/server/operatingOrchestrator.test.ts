import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  getDb: vi.fn(),
  imports: vi.fn(),
  load: vi.fn(),
  session: vi.fn(),
  forward: vi.fn(),
  forwardPersist: vi.fn(),
}));

vi.mock("./db", () => ({ getDb: mocks.getDb }));
vi.mock("./datasetPersistence", () => ({ getExternalDatasetIngestions: mocks.imports, loadPersistedDatasetForParity: mocks.load }));
vi.mock("./paperPersistence", () => ({ getOrCreatePaperSession: mocks.session }));
vi.mock("./paperEngine", () => ({ getPaperOverview: vi.fn(() => ({ metrics: { grossExposurePct: 0, peakDrawdownPct: 0, dataFreshnessSeconds: 0 } })), evaluatePaperRisk: vi.fn(() => ({ approved: true, survivor: { reasons: [] }, dailyLossPass: true, exposurePass: true, drawdownPass: true, freshnessPass: true })) }));
vi.mock("./forwardPaperPersistence", () => ({ persistForwardPaperSession: mocks.forwardPersist }));
vi.mock("@shared/forwardPaperSession", () => ({ runForwardPaperSession: mocks.forward }));
vi.mock("@shared/sourceVectorRegistry", () => ({ validateSourceVectorEvidence: vi.fn(() => ({ ok: true })) }));
vi.mock("@shared/numericParity", () => ({ evaluateNumericParity: vi.fn(() => ({ overall: "MATCH", indicators: [] })) }));

function candles(count = 80) {
  return Array.from({ length: count }, (_, index) => ({ open: 1900 + index, high: 1902 + index, low: 1898 + index, close: 1901 + index, volume: 100 + index }));
}

function forwardResult() {
  return { mode: "FORWARD_PAPER", symbol: "XAUUSD", venue: "DUKASCOPY_FILE", status: "COMPLETED", barsObserved: 80, signals: 12, orders: 12, fills: 12, realizedPnl: 240, maxDrawdownPct: 0.8, equity: 100240, equityCurve: [{ index: 0, equity: 100000, drawdownPct: 0 }], events: [{ type: "JOURNAL", index: 79, timestamp: 80, payload: { realizedPnl: 240 } }], blockedReasons: [], dataQuality: "VALIDATED_OHLC", executionAuthority: "PAPER_ONLY", orderRoute: "DISABLED" } as const;
}

describe("Decision Orchestrator", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.imports.mockResolvedValue([{ id: 41, userId: 77, symbol: "XAUUSD", interval: "15m", source: "DUKASCOPY_FILE", barCount: 2912, checksum: "a".repeat(64), evidenceState: "READY", coverageClass: "LONG" }]);
    mocks.load.mockResolvedValue({ status: "READY", manifest: { id: 41, userId: 77, symbol: "XAUUSD", interval: "15m", source: "DUKASCOPY_FILE", checksum: "a".repeat(64), barCount: 2912, evidenceState: "READY", coverageClass: "LONG" }, series: { symbol: "XAUUSD", interval: "15m", venue: "DUKASCOPY_FILE", checksum: "a".repeat(64), candles: candles() } });
    mocks.session.mockResolvedValue(9001);
    mocks.forward.mockReturnValue(forwardResult());
    mocks.forwardPersist.mockResolvedValue({ persisted: true, sessionId: 9001, symbol: "XAUUSD", correlationId: "forward", events: 1, orders: 12, fills: 12, executionAuthority: "PAPER_ONLY", orderRoute: "DISABLED" });
  });

  it("persists a single user-scoped correlation graph and stops before PAPER when source parity is absent", async () => {
    const writes: any[] = [];
    mocks.getDb.mockResolvedValue({ insert: () => ({ values: (value: unknown) => { writes.push(value); return { onDuplicateKeyUpdate: async () => undefined }; } }) });
    const { runOperatingWorkflow } = await import("./operatingOrchestrator");
    const result = await runOperatingWorkflow({ userId: 77, ingestionId: 41, baseTimeframe: "15m", higherTimeframe: "4h", idempotencyKey: "op-xau-001" });
    expect(result.persisted).toBe(true);
    expect(result.state.outcome).toBe("PAPER_BLOCKED");
    expect(result.state.stage).toBe("AUDIT");
    expect(result.state.blockReasons).toContain("PARITY_REQUIRED");
    expect(result.state.authority).toBe("DISABLED");
    expect(writes.length).toBe(6);
    expect(mocks.forward).not.toHaveBeenCalled();
  });

  it("runs the canonical forward-paper and comparison handoff after parity and risk gates pass", async () => {
    const writes: any[] = [];
    mocks.getDb.mockResolvedValue({ insert: () => ({ values: (value: unknown) => { writes.push(value); return { onDuplicateKeyUpdate: async () => undefined }; } }) });
    const { runOperatingWorkflow } = await import("./operatingOrchestrator");
    const result = await runOperatingWorkflow({ userId: 77, ingestionId: 41, baseTimeframe: "15m", higherTimeframe: "4h", expected: { macdHistogram: 0.1 }, source: "PINE_ARTIFACT", artifactName: "source.pine", sourceArtifactChecksum: "b".repeat(64), sourceLineRange: "10-20", formulaVersion: "v1", idempotencyKey: "op-xau-forward" });
    expect(result.persisted).toBe(true);
    expect(result.state.outcome).toBe("COMPLETED");
    expect(result.state.stage).toBe("AUDIT");
    expect(result.forwardPaper?.executionAuthority).toBe("PAPER_ONLY");
    expect(result.comparison?.caveat).toBe("FORWARD_PAPER_NOT_LIVE");
    expect(mocks.forward).toHaveBeenCalledOnce();
    expect(mocks.forwardPersist).toHaveBeenCalledOnce();
    expect(writes.some((row) => row.stage === "PAPER_DECISION")).toBe(true);
    expect(writes.some((row) => row.stage === "AUDIT")).toBe(true);
  });

  it("fails closed before parity when storage evidence is stale or malformed", async () => {
    mocks.load.mockResolvedValue({ status: "INVALID", reason: "persisted-checksum-does-not-match-manifest" });
    const { runOperatingWorkflow } = await import("./operatingOrchestrator");
    const result = await runOperatingWorkflow({ userId: 77, ingestionId: 41, baseTimeframe: "15m", higherTimeframe: "4h", idempotencyKey: "op-xau-002" });
    expect(result.persisted).toBe(false);
    expect(result.reason).toBe("persisted-checksum-does-not-match-manifest");
    expect(result.state.outcome).toBe("PAPER_BLOCKED");
    expect(result.state.blockReasons).toContain("MANIFEST_STALE");
  });
});
