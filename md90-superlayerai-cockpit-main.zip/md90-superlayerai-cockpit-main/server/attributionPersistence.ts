import { and, desc, eq } from "drizzle-orm";
import { paperAttributionReports } from "../drizzle/schema";
import { getDb } from "./db";
import { runAndPersistDatasetReplay } from "./replayPersistence";
import { buildCrossInstrumentAttribution, type AttributionInput } from "@shared/crossInstrumentAttribution";

export async function runAndPersistCrossInstrumentAttribution(input: {
  userId: number;
  ingestionIds: number[];
  trainBars: number;
  testBars: number;
  startingEquity: number;
  feeBps: number;
  slippageBps: number;
}) {
  const uniqueIds = Array.from(new Set(input.ingestionIds)).slice(0, 5);
  const replayResults = await Promise.all(uniqueIds.map((ingestionId) => runAndPersistDatasetReplay(input.userId, ingestionId, input)));
  const blocked = replayResults.filter((result) => result.status !== "persisted" && result.status !== "UNAVAILABLE");
  if (blocked.length) return { status: "BLOCKED" as const, reason: "one-or-more-manifests-not-ready", results: replayResults };
  const usable = replayResults.map((result, index) => ({ result, ingestionId: uniqueIds[index] })).filter((item): item is { result: Extract<typeof item.result, { status: "persisted" }>; ingestionId: number } => item.result.status === "persisted");
  if (!usable.length) return { status: "UNAVAILABLE" as const, reason: "database-unavailable", results: replayResults };
  const reportInputs: AttributionInput[] = usable.map(({ result, ingestionId }) => ({ symbol: result.source.symbol ?? "UNKNOWN", ingestionId, checksum: result.source.checksum ?? "", timeframe: result.source.interval ?? `${input.testBars} bars`, regime: "REPLAY_UNCLASSIFIED", riskBlockReasons: [], replay: result.replay }));
  const report = buildCrossInstrumentAttribution(reportInputs);
  const correlationId = `attribution:${input.userId}:${uniqueIds.join("-")}:${input.trainBars}:${input.testBars}`;
  const reportKey = `${correlationId}:${input.feeBps}:${input.slippageBps}`;
  const db = await getDb();
  if (!db) return { status: "UNAVAILABLE" as const, reason: "database-unavailable", report, correlationId };
  const inserted = await db.insert(paperAttributionReports).values({ userId: input.userId, reportKey, correlationId, ingestionIdsJson: JSON.stringify(uniqueIds), sourceChecksumsJson: JSON.stringify(report.instruments.map((item) => ({ symbol: item.symbol, checksum: item.checksum }))), metricsJson: JSON.stringify({ ...report, params: input }), authority: report.executionAuthority }).$returningId();
  return { status: "persisted" as const, reportId: inserted[0]?.id ?? 0, correlationId, report, results: replayResults };
}

export async function getCrossInstrumentAttributionReports(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select().from(paperAttributionReports).where(eq(paperAttributionReports.userId, userId)).orderBy(desc(paperAttributionReports.createdAt)).limit(20);
  return rows.map((row) => ({ ...row, metrics: parseJson(row.metricsJson), ingestionIds: parseJsonArray(row.ingestionIdsJson), sourceChecksums: parseJson(row.sourceChecksumsJson), authority: "PAPER_DATASET_REPLAY" as const, orderRoute: "DISABLED" as const }));
}

function parseJson(value: string) { try { return JSON.parse(value) as Record<string, unknown>; } catch { return {}; } }
function parseJsonArray(value: string) { try { return JSON.parse(value) as number[]; } catch { return []; } }
