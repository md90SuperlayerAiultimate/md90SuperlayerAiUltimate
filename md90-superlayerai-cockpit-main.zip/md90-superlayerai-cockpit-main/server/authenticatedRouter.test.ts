import { beforeEach, describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const { closeLatestPaperPositionMock, getPaperJournalMock, getPaperTimeStopReviewMock, persistPaperOverviewMock, persistShadowAndNewsMock, persistPaperWorkflowEventsMock, transitionReconciliationExceptionMock, upsertReconciliationExceptionMock } = vi.hoisted(() => ({
  closeLatestPaperPositionMock: vi.fn().mockResolvedValue({ status: "closed", orderId: 72, positionId: 17, route: "PAPER_REPLAY_ONLY" }),
  getPaperJournalMock: vi.fn().mockResolvedValue([{ id: 1, event: "ORDER_FILLED", provenance: "test", detail: "persisted", timestamp: new Date() }]),
  getPaperTimeStopReviewMock: vi.fn().mockResolvedValue({ status: "ready", positionId: 17, instrument: "BTC/USDT", barsHeld: 10, configuredBars: 10, state: "PAPER_EXIT_REVIEW", authority: "ADVISORY_ONLY", executionAuthority: "DISABLED" }),
  persistPaperOverviewMock: vi.fn().mockResolvedValue({ persisted: true, sessionId: 9100 }),
  persistShadowAndNewsMock: vi.fn().mockResolvedValue({ persisted: true }),
  persistPaperWorkflowEventsMock: vi.fn().mockResolvedValue({ persisted: true, count: 3, sessionId: 9100 }),
  transitionReconciliationExceptionMock: vi.fn().mockResolvedValue({ updated: true, state: "RESOLVED" }),
  upsertReconciliationExceptionMock: vi.fn().mockResolvedValue({ persisted: true, created: false, id: 1 }),
}));
vi.mock("./paperPersistence", () => ({
  closeLatestPaperPosition: closeLatestPaperPositionMock,
  getPaperJournal: getPaperJournalMock,
  getPaperTimeStopReview: getPaperTimeStopReviewMock,
  persistPaperOverview: persistPaperOverviewMock,
  persistShadowAndNews: persistShadowAndNewsMock,
  persistPaperWorkflowEvents: persistPaperWorkflowEventsMock,
  transitionReconciliationException: transitionReconciliationExceptionMock,
  upsertReconciliationException: upsertReconciliationExceptionMock,
}));
const { finishPaperCommandMock, getPaperCommandRunMock, getPaperCommandRunsMock, startPaperCommandMock } = vi.hoisted(() => ({
  startPaperCommandMock: vi.fn().mockResolvedValue({ tracked: true, commandKey: "test-command" }),
  finishPaperCommandMock: vi.fn().mockResolvedValue({ tracked: true, commandKey: "test-command", state: "SUCCEEDED" }),
  getPaperCommandRunMock: vi.fn().mockResolvedValue(null),
  getPaperCommandRunsMock: vi.fn().mockResolvedValue([]),
}));
vi.mock("./commandPersistence", () => ({
  finishPaperCommand: finishPaperCommandMock,
  getPaperCommandRun: getPaperCommandRunMock,
  getPaperCommandRuns: getPaperCommandRunsMock,
  startPaperCommand: startPaperCommandMock,
}));
const { getExternalDatasetIngestionsMock, persistExternalDatasetMock } = vi.hoisted(() => ({
  getExternalDatasetIngestionsMock: vi.fn().mockResolvedValue([]),
  persistExternalDatasetMock: vi.fn().mockResolvedValue({ persisted: true, manifestId: 55 }),
}));
vi.mock("./datasetPersistence", () => ({
  getExternalDatasetIngestions: getExternalDatasetIngestionsMock,
  persistExternalDataset: persistExternalDatasetMock,
}));
const { normalizeManualHistoricalDatasetMock } = vi.hoisted(() => ({
  normalizeManualHistoricalDatasetMock: vi.fn().mockReturnValue({ symbol: "EURUSD", interval: "15m", checksum: "manual-checksum", candles: [{ openedAt: 1, open: 1.1, high: 1.2, low: 1.05, close: 1.15, volume: 42 }], freshnessSeconds: 0, orderRoute: "DISABLED", venue: "OPERATOR_UPLOAD" }),
}));
vi.mock("./manualDataset", () => ({
  normalizeManualHistoricalDataset: normalizeManualHistoricalDatasetMock,
}));

const context = (user: TrpcContext["user"]): TrpcContext => ({
  user,
  req: { protocol: "https", headers: {} } as TrpcContext["req"],
  res: {} as TrpcContext["res"],
});

const authenticatedUser = {
  id: 7701,
  openId: "authenticated-test-user",
  name: "Test Analyst",
  email: "analyst@example.test",
  loginMethod: "oauth",
  role: "user" as const,
  createdAt: new Date(),
  updatedAt: new Date(),
  lastSignedIn: new Date(),
};

describe("authenticated router boundaries", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("allows authenticated paper ingestion only for the authenticated user scope", async () => {
    const result = await appRouter.createCaller(context(authenticatedUser)).paper.ingest();
    expect(result).toMatchObject({ persisted: true, sessionId: 9100 });
    expect(persistPaperOverviewMock).toHaveBeenCalledWith(7701, expect.objectContaining({ mode: "PAPER" }));
  });

  it("records a paper decision in the authenticated user scope", async () => {
    const result = await appRouter.createCaller(context(authenticatedUser)).paper.decide({ timeframe: "15m", htf: "4h", symbol: "BTCUSDT", riskPct: 0.5 });
    expect(result).toMatchObject({ status: "recorded", riskPct: 0.5 });
    expect(result.correlation).toMatch(/^paper:BTCUSDT:15m:4h:/);
    expect(persistPaperOverviewMock).toHaveBeenCalledWith(7701, expect.objectContaining({ mode: "PAPER" }));
  });

  it("runs authenticated sync and close commands with the same user scope", async () => {
    const caller = appRouter.createCaller(context(authenticatedUser));
    const sync = await caller.paper.sync({ timeframe: "15m", htf: "4h", symbol: "BTCUSDT" });
    expect(sync).toMatchObject({ status: "synced" });
    expect(startPaperCommandMock).toHaveBeenCalledWith(7701, "SYNC", expect.any(String), expect.any(Object));
    expect(finishPaperCommandMock).toHaveBeenCalledWith(7701, "SYNC", expect.any(String), "SUCCEEDED", expect.any(Object));
    expect(persistPaperOverviewMock).toHaveBeenCalledWith(7701, expect.objectContaining({ mode: "PAPER" }));
    expect(persistShadowAndNewsMock).toHaveBeenCalled();

    const close = await caller.paper.close({ timeframe: "15m", symbol: "BTCUSDT", reason: "TIME_STOP" });
    expect(close).toMatchObject({ status: "closed", route: "PAPER_REPLAY_ONLY" });
    expect(startPaperCommandMock).toHaveBeenCalledWith(7701, "CLOSE", expect.any(String), expect.any(Object));
    expect(closeLatestPaperPositionMock).toHaveBeenCalledWith(7701, expect.objectContaining({ mode: "PAPER" }), expect.objectContaining({ reason: "TIME_STOP" }));

    await caller.paper.commands();
    expect(getPaperCommandRunsMock).toHaveBeenCalledWith(7701);
  });

  it("blocks non-replay instruments and anonymous paper decisions", async () => {
    await expect(appRouter.createCaller(context(authenticatedUser)).paper.decide({ symbol: "EURUSD", riskPct: 0.5 })).resolves.toMatchObject({ status: "blocked" });
    await expect(appRouter.createCaller(context(null)).paper.decide({ symbol: "BTCUSDT", riskPct: 0.5 })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("returns time-stop review only in the authenticated PAPER position scope", async () => {
    const caller = appRouter.createCaller(context(authenticatedUser));
    await expect(caller.paper.timeStop({ symbol: "BTCUSDT" })).resolves.toMatchObject({ status: "ready", state: "PAPER_EXIT_REVIEW", authority: "ADVISORY_ONLY", executionAuthority: "DISABLED" });
    expect(getPaperTimeStopReviewMock).toHaveBeenCalledWith(7701, "BTC/USDT");
    await expect(caller.paper.timeStop({ symbol: "EURUSD" })).resolves.toMatchObject({ status: "blocked" });
    await expect(appRouter.createCaller(context(null)).paper.timeStop({ symbol: "BTCUSDT" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("returns parametrically reproducible replay evidence and blocks uncertified symbols", async () => {
    const caller = appRouter.createCaller(context(null));
    const ready = await caller.paper.replay({ symbol: "BTCUSDT", trainBars: 12, testBars: 4 });
    expect(ready.status).toBe("ready");
    if (ready.status === "ready") expect(ready.replay.trainBars).toBe(12);
    await expect(caller.paper.replay({ symbol: "EURUSD", trainBars: 8, testBars: 4 })).resolves.toMatchObject({ status: "blocked" });
  });

  it("reads journal only through authenticated user scope", async () => {
    const result = await appRouter.createCaller(context(authenticatedUser)).paper.journal();
    expect(result[0]).toMatchObject({ event: "ORDER_FILLED" });
    expect(getPaperJournalMock).toHaveBeenCalledWith(7701);
    await expect(appRouter.createCaller(context(null)).paper.journal()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("returns learning evidence only from the authenticated PAPER journal and never opens promotion", async () => {
    const result = await appRouter.createCaller(context(authenticatedUser)).paper.learning();
    expect(result).toMatchObject({ authority: "PROPOSAL_ONLY", status: "EVIDENCE_REQUIRED", promotionRoute: "DISABLED" });
    expect(getPaperJournalMock).toHaveBeenCalledWith(7701);
    await expect(appRouter.createCaller(context(null)).paper.learning()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("retries only failed user-scoped safe PAPER command types", async () => {
    getPaperCommandRunMock.mockResolvedValueOnce({ id: 44, state: "FAILED", commandType: "SYNC", correlationId: "workflow:BTCUSDT:15m:4h:retry", payloadJson: JSON.stringify({ timeframe: "15m", htf: "4h", instrument: "BTCUSDT" }) });
    const result = await appRouter.createCaller(context(authenticatedUser)).paper.retry({ commandRunId: 44 });
    expect(result).toMatchObject({ status: "retried", commandRunId: 44, commandType: "SYNC" });
    expect(getPaperCommandRunMock).toHaveBeenCalledWith(7701, 44);
    expect(startPaperCommandMock).toHaveBeenCalledWith(7701, "SYNC", "workflow:BTCUSDT:15m:4h:retry", expect.any(Object));

    getPaperCommandRunsMock.mockResolvedValueOnce([{ id: 44, userId: 7701, commandType: "SYNC", state: "SUCCEEDED", attempts: 2, correlationId: "workflow:BTCUSDT:15m:4h:retry" }]);
    await expect(appRouter.createCaller(context(authenticatedUser)).paper.commands()).resolves.toMatchObject([{ id: 44, attempts: 2, state: "SUCCEEDED" }]);

    getPaperCommandRunMock.mockResolvedValueOnce({ id: 45, state: "BLOCKED", commandType: "CLOSE", correlationId: "close:retry", payloadJson: "{}" });
    await expect(appRouter.createCaller(context(authenticatedUser)).paper.retry({ commandRunId: 45 })).resolves.toMatchObject({ status: "blocked" });
    await expect(appRouter.createCaller(context(null)).paper.retry({ commandRunId: 44 })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("ingests validated manual EURUSD evidence only in the authenticated user scope", async () => {
    const payload = { symbol: "EURUSD" as const, interval: "15m" as const, format: "CSV" as const, source: "OPERATOR_UPLOAD" as const, contents: "timestamp,open,high,low,close,volume\n2026-08-25T00:00:00Z,1.1,1.2,1.05,1.15,42" };
    const result = await appRouter.createCaller(context(authenticatedUser)).datasets.ingestManual(payload);
    expect(result).toMatchObject({ status: "ingested", series: { symbol: "EURUSD", checksum: "manual-checksum", orderRoute: "DISABLED" } });
    expect(normalizeManualHistoricalDatasetMock).toHaveBeenCalledWith(payload);
    expect(persistExternalDatasetMock).toHaveBeenCalledWith(7701, expect.objectContaining({ symbol: "EURUSD", orderRoute: "DISABLED" }));
    expect(startPaperCommandMock).toHaveBeenCalledWith(7701, "DATASET_INGEST", expect.stringMatching(/^dataset-manual:EURUSD:15m:/), expect.objectContaining({ symbol: "EURUSD" }));
    await expect(appRouter.createCaller(context(null)).datasets.ingestManual(payload)).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("keeps public shadow/news routes without persistence for anonymous callers", async () => {
    const caller = appRouter.createCaller(context(null));
    await caller.shadow.observations();
    await caller.intel.news();
    expect(persistShadowAndNewsMock).not.toHaveBeenCalled();
  });
});
