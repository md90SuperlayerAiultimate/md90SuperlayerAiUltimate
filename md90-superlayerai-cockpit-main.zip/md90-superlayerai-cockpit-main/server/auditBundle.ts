import { createHash } from "node:crypto";
import { desc, eq, inArray } from "drizzle-orm";
import { auditParityVectors, datasetIngestions, paperAttributionReports, paperJournal, paperReplayRuns, paperSessions, paperWorkflowEvents } from "../drizzle/schema";
import { getDb } from "./db";

export type AuditBundleFilter = { correlationId?: string; from?: string; to?: string };

type BundleOptions = { filter?: AuditBundleFilter };

function recordDate(row: any): string | undefined {
  const value = row?.occurredAt ?? row?.createdAt ?? row?.timestamp;
  if (value instanceof Date) return value.toISOString();
  return typeof value === "string" || typeof value === "number" ? new Date(value).toISOString() : undefined;
}

function matchesFilter(row: any, filter: AuditBundleFilter) {
  const correlation = String(row?.correlationId ?? "");
  if (filter.correlationId?.trim() && correlation !== filter.correlationId.trim()) return false;
  const date = recordDate(row);
  if (filter.from && (!date || date < new Date(filter.from).toISOString())) return false;
  if (filter.to && (!date || date > new Date(filter.to).toISOString())) return false;
  return true;
}

function filterRows(rows: any[], filter: AuditBundleFilter) { return rows.filter((row) => matchesFilter(row, filter)); }

function stableValue(value: any): any {
  if (value instanceof Date) return value.toISOString();
  if (Array.isArray(value)) return value.map(stableValue);
  if (value && typeof value === "object") return Object.fromEntries(Object.keys(value).sort().map((key) => [key, stableValue(value[key])]));
  return value;
}

export function auditBundleSignature(bundle: unknown) {
  return createHash("sha256").update(JSON.stringify(stableValue(bundle))).digest("hex");
}

export async function buildAuditBundle(userId: number, options: BundleOptions = {}) {
  const db = await getDb();
  if (!db) return { status: "UNAVAILABLE" as const, reason: "database-unavailable" };
  const filter = options.filter ?? {};
  const [datasetsRaw, parityRaw, replaysRaw, attributionRaw, sessions] = await Promise.all([
    db.select().from(datasetIngestions).where(eq(datasetIngestions.userId, userId)).orderBy(desc(datasetIngestions.createdAt)).limit(100),
    db.select().from(auditParityVectors).where(eq(auditParityVectors.userId, userId)).orderBy(desc(auditParityVectors.createdAt)).limit(100),
    db.select().from(paperReplayRuns).where(eq(paperReplayRuns.userId, userId)).orderBy(desc(paperReplayRuns.createdAt)).limit(100),
    db.select().from(paperAttributionReports).where(eq(paperAttributionReports.userId, userId)).orderBy(desc(paperAttributionReports.createdAt)).limit(50),
    db.select({ id: paperSessions.id }).from(paperSessions).where(eq(paperSessions.userId, userId)).limit(100),
  ]);
  const sessionIds = sessions.map((session) => session.id);
  const [eventsRaw, journalsRaw] = sessionIds.length ? await Promise.all([
    db.select().from(paperWorkflowEvents).where(inArray(paperWorkflowEvents.sessionId, sessionIds)).orderBy(desc(paperWorkflowEvents.createdAt)).limit(500),
    db.select().from(paperJournal).where(inArray(paperJournal.sessionId, sessionIds)).orderBy(desc(paperJournal.timestamp)).limit(500),
  ]) : [[], []];
  const datasets = filterRows(datasetsRaw, filter);
  const parity = filterRows(parityRaw, filter);
  const replays = filterRows(replaysRaw, filter);
  const attribution = filterRows(attributionRaw, filter);
  const events = filterRows(eventsRaw, filter);
  const journals = filterRows(journalsRaw, filter);
  const safe = { datasets, parity, replays, attribution, events, journals, filter, generatedAt: new Date().toISOString(), authority: "PAPER_SHADOW_ONLY", orderRoute: "DISABLED", signatureVersion: "audit-bundle-sha256-v1", redaction: "No secrets, credentials, private keys, or live routes included." };
  const signature = auditBundleSignature({ ...safe, generatedAt: undefined });
  return { status: "READY" as const, bundle: { ...safe, signature } };
}

export function auditBundleJson(bundle: unknown) { return JSON.stringify(bundle, null, 2); }

export function auditBundleCsv(bundle: any) {
  const rows: string[][] = [["section", "record_id", "instrument", "status", "checksum", "correlation_id", "payload_json"]];
  const add = (section: string, id: string, instrument: string, status: string, checksum: string, correlation: string, payload: any) => rows.push([section, id, instrument, status, checksum, correlation, JSON.stringify(payload)]);
  for (const row of bundle.datasets ?? []) add("dataset", String(row.id), row.symbol, row.status, row.checksum, "", row);
  for (const row of bundle.parity ?? []) add("parity", String(row.id), row.symbol, row.parityStatus, row.datasetChecksum, "", row);
  for (const row of bundle.replays ?? []) add("replay", String(row.id), "", row.status, row.sourceChecksum, row.correlationId, row);
  for (const row of bundle.attribution ?? []) add("attribution", String(row.id), "MULTI", row.authority, "", row.correlationId, row);
  for (const row of bundle.events ?? []) add("workflow_event", String(row.id), row.instrument, row.stage, row.provenance, row.correlationId, row);
  for (const row of bundle.journals ?? []) add("journal", String(row.id), "", row.event, row.provenance, "", row);
  rows.push(["bundle", "signature", "", bundle.signatureVersion ?? "", "", "", JSON.stringify({ signature: bundle.signature, filter: bundle.filter, authority: bundle.authority, orderRoute: bundle.orderRoute })]);
  return rows.map((row) => row.map(csvEscape).join(",")).join("\n") + "\n";
}

function csvEscape(value: unknown) { const text = String(value ?? ""); return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text; }
