import { getPaperWorkflowEvents } from "./paperPersistence";

export async function getOperatingTimeline(userId: number, symbol?: string) {
  const events = await getPaperWorkflowEvents(userId);
  return events
    .filter((event) => event.correlationId.startsWith("operating:") && (!symbol || event.instrument === symbol))
    .slice(0, 120)
    .map((event) => ({
      id: event.id,
      eventId: event.eventId,
      correlationId: event.correlationId,
      causationId: event.causationId,
      stage: event.stage,
      eventType: event.eventType,
      instrument: event.instrument,
      payload: (() => { try { return JSON.parse(event.payloadJson) as Record<string, unknown>; } catch { return { parseError: true }; } })(),
      provenance: event.provenance,
      occurredAt: event.occurredAt,
      authority: "DISABLED" as const,
    }));
}
