export type PaperOrderRequest = {
  clientOrderId: string;
  instrument: string;
  side: "BUY" | "SELL";
  quantity: number;
  bid: number;
  ask: number;
  feeBps: number;
  slippageBps: number;
};

export type PaperOrderResult = {
  clientOrderId: string;
  status: "filled" | "partial";
  requestedQuantity: number;
  filledQuantity: number;
  averagePrice: number;
  fee: number;
  slippageBps: number;
};

/** Deterministic broker for replay/paper mode. It has no network or credential path. */
export class PaperBroker {
  private readonly orders = new Map<string, PaperOrderResult>();

  submit(request: PaperOrderRequest): PaperOrderResult {
    const previous = this.orders.get(request.clientOrderId);
    if (previous) return previous;
    if (request.quantity <= 0 || request.bid <= 0 || request.ask <= 0 || request.ask < request.bid) {
      throw new Error("Invalid paper order market state");
    }
    const fillRatio = request.quantity > 0.01 ? 0.75 : 1;
    const filledQuantity = Number((request.quantity * fillRatio).toFixed(8));
    const touch = request.side === "BUY" ? request.ask : request.bid;
    const slipFactor = request.side === "BUY" ? 1 + request.slippageBps / 10_000 : 1 - request.slippageBps / 10_000;
    const averagePrice = Number((touch * slipFactor).toFixed(2));
    const notional = filledQuantity * averagePrice;
    const fee = Number((notional * request.feeBps / 10_000).toFixed(2));
    const result: PaperOrderResult = {
      clientOrderId: request.clientOrderId,
      status: fillRatio < 1 ? "partial" : "filled",
      requestedQuantity: request.quantity,
      filledQuantity,
      averagePrice,
      fee,
      slippageBps: request.slippageBps,
    };
    this.orders.set(request.clientOrderId, result);
    return result;
  }
}
