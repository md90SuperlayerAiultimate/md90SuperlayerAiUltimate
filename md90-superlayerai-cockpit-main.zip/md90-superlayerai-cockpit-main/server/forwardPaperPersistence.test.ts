import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  getDb: vi.fn(),
}));

vi.mock("./db", () => ({ getDb: mocks.getDb }));

describe("forward paper persistence timestamps", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("persists equity and event timestamps from the forward-paper curve", async () => {
    const writes: Array<Record<string, unknown>> = [];
    const db = {
      select: () => ({
        from: () => ({
          where: () => ({
            orderBy: () => ({ limit: async () => [] }),
            limit: async () => [],
          }),
        }),
      }),
      insert: () => ({
        values: (value: Record<string, unknown>) => {
          writes.push(value);
          return {
            $returningId: async () => [{ id: 7001 }],
            onDuplicateKeyUpdate: async () => undefined,
          };
        },
      }),
      update: () => ({
        set: () => ({ where: async () => undefined }),
      }),
    };
    mocks.getDb.mockResolvedValue(db);

    const { persistForwardPaperSession } = await import("./forwardPaperPersistence");
    const candleTimestamp = "2026-02-19T02:55:00.000Z";
    const result = await persistForwardPaperSession(
      77,
      {
        mode: "FORWARD_PAPER",
        symbol: "XAUUSD",
        venue: "DUKASCOPY_FILE",
        status: "COMPLETED",
        barsObserved: 2,
        signals: 0,
        orders: 0,
        fills: 0,
        realizedPnl: 0,
        maxDrawdownPct: 0,
        equity: 100000,
        equityCurve: [
          { index: 0, equity: 100000, drawdownPct: 0, timestamp: candleTimestamp },
          { index: 1, equity: 100000, drawdownPct: 0, timestamp: candleTimestamp },
        ],
        events: [],
        blockedReasons: [],
        dataQuality: "VALIDATED_OHLC",
        executionAuthority: "PAPER_ONLY",
        orderRoute: "DISABLED",
      },
      "DUKASCOPY_FILE:checksum",
      "correlation-1",
    );

    expect(result.persisted).toBe(true);
    const equityRows = writes.filter((row) => "equity" in row && "drawdownPct" in row);
    const equityEvents = writes.filter((row) => row.eventType === "FORWARD_EQUITY_POINT");
    expect(equityRows).toHaveLength(2);
    expect(equityEvents).toHaveLength(2);
    expect(equityRows.every((row) => row.timestamp instanceof Date && row.timestamp.toISOString() === candleTimestamp)).toBe(true);
    expect(equityEvents.every((row) => row.occurredAt instanceof Date && row.occurredAt.toISOString() === candleTimestamp)).toBe(true);
  });
});
