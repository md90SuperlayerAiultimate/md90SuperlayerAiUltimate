import { and, desc, eq } from "drizzle-orm";
import { auditParityVectors } from "../drizzle/schema";
import { getDb } from "./db";
import { loadPersistedDatasetForParity } from "./datasetPersistence";
import { evaluateNumericParity, type ParityIndicatorName, type NumericParityResult } from "@shared/numericParity";
import { validateSourceVectorEvidence } from "@shared/sourceVectorRegistry";

type ExpectedVector = Partial<Record<ParityIndicatorName, number | null>>;

export async function evaluateAndPersistParity(input: {
  userId: number;
  ingestionId: number;
  expected: ExpectedVector;
  tolerance?: number;
  source: string;
  provenance: string;
  sourceArtifactChecksum: string;
  sourceLineRange: string;
  formulaVersion: string;
  artifactName: string;
}) {
  const sourceValidation = validateSourceVectorEvidence({ artifactName: input.artifactName, artifactChecksum: input.sourceArtifactChecksum, lineRange: input.sourceLineRange, formulaVersion: input.formulaVersion, symbol: "pending", interval: "pending", vector: input.expected });
  if (!sourceValidation.ok) return { status: "EVIDENCE_REQUIRED" as const, reason: sourceValidation.reason };
  const loaded = await loadPersistedDatasetForParity(input.userId, input.ingestionId);
  if (loaded.status !== "READY") return { status: loaded.status, reason: loaded.reason } as const;
  const result = evaluateNumericParity({
    symbol: loaded.series.symbol!,
    interval: loaded.series.interval!,
    source: input.source,
    checksum: loaded.series.checksum!,
    candles: loaded.series.candles!,
    expected: input.expected,
    tolerance: input.tolerance,
  });
  const db = await getDb();
  if (!db) return { status: "UNAVAILABLE" as const, reason: "database-unavailable" as const, result };
  const inserted = await db.insert(auditParityVectors).values({
    userId: input.userId,
    ingestionId: input.ingestionId,
    symbol: result.symbol,
    interval: result.interval,
    source: result.source,
    datasetChecksum: result.checksum,
    expectedJson: JSON.stringify(input.expected),
    actualJson: JSON.stringify(Object.fromEntries(result.rows.map((row) => [row.indicator, row.actual]))),
    tolerance: String(result.tolerance),
    parityStatus: result.overall === "EVIDENCE_REQUIRED" ? "EVIDENCE_REQUIRED" : result.overall,
    provenance: input.provenance,
    sourceTimestamp: loaded.manifest.sourceTimestamp,
    sourceArtifactChecksum: input.sourceArtifactChecksum,
    sourceLineRange: input.sourceLineRange,
    formulaVersion: input.formulaVersion,
  }).$returningId();
  return { status: "persisted" as const, recordId: inserted[0]?.id ?? 0, result };
}

export async function getPersistedParityVectors(userId: number, ingestionId?: number) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select().from(auditParityVectors).where(ingestionId ? and(eq(auditParityVectors.userId, userId), eq(auditParityVectors.ingestionId, ingestionId)) : eq(auditParityVectors.userId, userId)).orderBy(desc(auditParityVectors.createdAt)).limit(40);
  return rows.map((row) => ({
    ...row,
    expected: parseJson(row.expectedJson),
    actual: parseJson(row.actualJson),
    authority: "READ_ONLY" as const,
    executionAuthority: "DISABLED" as const,
  }));
}

function parseJson(value: string) {
  try { return JSON.parse(value) as Record<string, number | null>; } catch { return {}; }
}

export type PersistedParityResult = NumericParityResult;
