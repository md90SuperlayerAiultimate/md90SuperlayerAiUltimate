import { describe, expect, it } from "vitest";
import { calculateDemoStats, demoBatchId, generateDemoBatch } from "./demoSimulator";

describe("demo paper simulator", () => {
  it("generates a reproducible multi-asset batch for the same minute", () => {
    const time = new Date("2026-08-23T07:00:00.000Z");
    const first = generateDemoBatch(time);
    const second = generateDemoBatch(new Date("2026-08-23T07:00:42.000Z"));
    expect(demoBatchId(time)).toBe(demoBatchId(new Date("2026-08-23T07:00:42.000Z")));
    expect(first).toEqual(second);
    expect(first).toHaveLength(8);
    expect(new Set(first.map((trade) => trade.instrument)).size).toBe(8);
  });

  it("calculates win rate and expectancy from realized trade outcomes", () => {
    const stats = calculateDemoStats(10_000, [
      { pnl: 12, outcome: "WIN" },
      { pnl: -4, outcome: "LOSS" },
      { pnl: 8, outcome: "WIN" },
    ]);
    expect(stats).toMatchObject({ tradeCount: 3, wins: 2, losses: 1, winRatePct: 66.67, realizedPnl: 16, equity: 10_016, expectancy: 5.3333, targetWinRatePct: 93, sampleQuality: "INSUFFICIENT_SAMPLE" });
  });
});
