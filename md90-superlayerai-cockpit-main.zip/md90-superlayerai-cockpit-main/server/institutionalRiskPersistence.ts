import { buildInstitutionalRiskReport, type InstitutionalRiskReport, type RiskSeries } from "@shared/institutionalRiskAnalytics";
import { loadPersistedDatasetForParity } from "./datasetPersistence";

export type PersistedRiskReport = {
  status: "READY" | "PENDING" | "BLOCKED" | "UNAVAILABLE";
  report: InstitutionalRiskReport;
  manifests: Array<{ ingestionId: number; symbol: string; interval: string; checksum: string; sourceTimestamp: string; barCount: number }>;
  reasons: string[];
};

export async function buildPersistedInstitutionalRiskReport(userId: number, ingestionIds: number[]): Promise<PersistedRiskReport> {
  const uniqueIds = Array.from(new Set(ingestionIds)).slice(0, 5);
  const loaded = await Promise.all(uniqueIds.map((ingestionId) => loadPersistedDatasetForParity(userId, ingestionId)));
  const invalid = loaded.filter((item) => item.status !== "READY");
  const manifests = loaded.flatMap((item, index) => item.status === "READY" ? [{ ingestionId: uniqueIds[index], symbol: item.manifest.symbol, interval: item.manifest.interval, checksum: item.manifest.checksum, sourceTimestamp: item.manifest.sourceTimestamp.toISOString(), barCount: item.manifest.barCount }] : []);
  const series: RiskSeries[] = loaded.flatMap((item) => {
    if (item.status !== "READY" || !item.series.candles) return [];
    const closes = item.series.candles.map((candle) => Number(candle.close)).filter((close) => Number.isFinite(close) && close > 0);
    const returns = closes.slice(1).flatMap((close, index) => {
      const previous = closes[index];
      const value = previous > 0 ? Math.log(close / previous) : NaN;
      return Number.isFinite(value) ? [value] : [];
    });
    return [{ symbol: item.manifest.symbol, returns }];
  });
  const report = buildInstitutionalRiskReport(series, { minimumSample: 20 });
  const reasons = [...report.reasons, ...invalid.map((item) => item.reason)];
  const status = invalid.length && !series.length ? (invalid[0].status === "UNAVAILABLE" ? "UNAVAILABLE" : "PENDING") : report.status;
  return { status, report, manifests, reasons: Array.from(new Set(reasons)) };
}
