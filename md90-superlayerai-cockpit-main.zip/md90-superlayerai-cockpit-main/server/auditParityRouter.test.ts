import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const user = { id: 9911, openId: "parity-user", name: "Parity Analyst", email: "parity@example.test", loginMethod: "oauth", role: "user" as const, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() };
const context = (authenticated: boolean): TrpcContext => ({ user: authenticated ? user : null, req: { protocol: "https", headers: {} } as TrpcContext["req"], res: {} as TrpcContext["res"] });
const candles = Array.from({ length: 60 }, (_, index) => ({ open: 100 + index, high: 101 + index, low: 99 + index, close: 100.5 + index, volume: 1_000 + index }));

describe("audit.parityVector router", () => {
  it("returns provenance-bound read-only comparison for authenticated caller", async () => {
    const checksum = "d".repeat(64);
    const result = await appRouter.createCaller(context(true)).audit.parityVector({ symbol: "EURUSD", interval: "1m", source: "DUKASCOPY_FILE", checksum, candles, expected: {} });
    expect(result).toMatchObject({ authority: "READ_ONLY", source: "DUKASCOPY_FILE", symbol: "EURUSD", checksum, oosGate: "PENDING", executionAuthority: "DISABLED" });
    expect(result.overall).toBe("EVIDENCE_REQUIRED");
  });
  it("blocks anonymous callers before evaluating vectors", async () => {
    await expect(appRouter.createCaller(context(false)).audit.parityVector({ symbol: "XAUUSD", interval: "1m", source: "DUKASCOPY_FILE", checksum: "e".repeat(64), candles, expected: {} })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
});
