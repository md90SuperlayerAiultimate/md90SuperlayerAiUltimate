import { describe, expect, it } from "vitest";
import { buildDemoEquityPoint } from "./demoPersistence";

describe("demo equity persistence contract", () => {
  it("produces one deterministic curve point per successful batch", () => {
    const timestamp = new Date("2026-08-23T07:00:00.000Z");
    expect(buildDemoEquityPoint(1, "demo-1", timestamp, 100_500, 500, 100_500)).toEqual({ accountId: 1, batchId: "demo-1", timestamp, equity: 100_500, realizedPnl: 500, drawdownPct: 0 });
    expect(buildDemoEquityPoint(1, "demo-2", new Date("2026-08-23T07:01:00.000Z"), 99_000, -1_000, 100_500).drawdownPct).toBe(1.49);
  });
});
