import { parse as parseCookie } from "cookie";
import { eq } from "drizzle-orm";
import { COOKIE_NAME } from "@shared/const";
import { demoAccounts } from "../drizzle/schema";
import { createHeartbeatJob } from "./_core/heartbeat";
import { ensureDemoAccount, DEMO_ACCOUNT_SLUG } from "./demoPersistence";
import { getDb } from "./db";

export const DEMO_CRON = "0 */5 * * * *";

export function buildDemoHeartbeatJob() {
  return {
    name: "md90-demo-paper-24-7",
    cron: DEMO_CRON,
    path: "/api/scheduled/demo-paper",
    description: "Every 5 minutes, generate an idempotent PAPER-only demo batch for md90 observability.",
  } as const;
}

export async function scheduleDemoHeartbeat(cookieHeader: string | undefined) {
  const db = await getDb();
  if (!db) return { status: "unavailable" as const };
  const account = await ensureDemoAccount(db);
  if (account.scheduleCronTaskUid) return { status: "already_scheduled" as const, taskUid: account.scheduleCronTaskUid, cron: DEMO_CRON };
  const sessionToken = parseCookie(cookieHeader ?? "")[COOKIE_NAME] ?? "";
  const job = await createHeartbeatJob(buildDemoHeartbeatJob(), sessionToken);
  await db.update(demoAccounts).set({ scheduleCronTaskUid: job.taskUid }).where(eq(demoAccounts.slug, DEMO_ACCOUNT_SLUG));
  return { status: "scheduled" as const, taskUid: job.taskUid, cron: DEMO_CRON, nextExecutionAt: job.nextExecutionAt ?? null };
}
