export type BotMode = "PAPER" | "SHADOW" | "LIVE";
export type MarketRegime = "TREND" | "RANGE" | "SHOCK" | "UNKNOWN";
export type AdaptiveEntryDecision = "PAPER_ENTRY" | "WATCH" | "BLOCKED";

export type AdaptiveEntryInput = {
  regime: MarketRegime;
  score: number;
  confidence: number;
  atrPct: number;
  entryPrice: number;
  equity: number;
  riskBudgetPct: number;
  stopAtrMultiple?: number;
  observedSpreadBps: number;
  slippageToleranceBps: number;
  latencyMs: number;
  latencyBudgetMs: number;
  evidenceCount: number;
};

export type PositionLifecycle = "FLAT" | "ENTRY_VALIDATED" | "OPEN" | "SCALE_OUT" | "CLOSED";

export type ScaleOutDecision = { allowed: boolean; reason: string };

export type SurvivorModeInput = { riskPct: number; totalExposurePct: number; dailyLossPct: number; highImpactNews: boolean; volatilityShock: boolean; gammaVerified: boolean; institutionalFlowVerified: boolean };

export type DefiAction = "SIGN" | "DEPOSIT" | "WITHDRAW" | "LIVE_TRANSACTION" | "READ_ONLY_QUOTE";

export function defiExecutionBoundary(action: DefiAction) {
  if (action === "READ_ONLY_QUOTE") return { allowed: true as const, route: "PUBLIC_READ_ONLY" as const, reason: "market data only" };
  return { allowed: false as const, route: "DISABLED" as const, reason: `DeFi action ${action} is disabled by Safe Core` };
}

export function survivorModeGate(input: SurvivorModeInput) {
  const reasons: string[] = [];
  if (input.riskPct < 0.5 || input.riskPct > 1) reasons.push("risk-per-trade-outside-0.5-1pct");
  if (input.totalExposurePct > 3) reasons.push("total-exposure-over-3pct");
  if (input.dailyLossPct >= 3) reasons.push("daily-loss-limit-reached");
  if (input.highImpactNews) reasons.push("high-impact-news-lock");
  if (input.volatilityShock) reasons.push("volatility-shock-lock");
  if (!input.gammaVerified) reasons.push("gamma-provider-unverified");
  if (!input.institutionalFlowVerified) reasons.push("institutional-flow-provider-unverified");
  return { allowed: reasons.length === 0, route: "PAPER_OR_SHADOW_ONLY" as const, reasons };
}

export type AdaptiveEntryResult = {
  decision: AdaptiveEntryDecision;
  threshold: number;
  stopDistance: number;
  quantity: number;
  reasons: string[];
};

export type CanonicalVenueEvent = {
  venue: string;
  instrument: string;
  bid: number;
  ask: number;
  last: number;
  observedAt: string;
  source: string;
  quality: "VALID" | "STALE" | "PENDING_REVIEW";
  provenance: string;
};

export type ExecutionBoundary = {
  mode: BotMode;
  orderRoute: "PAPER_ONLY" | "DISABLED" | "LIVE_PENDING_APPROVAL";
  liveApproval: "LOCKED" | "REQUIRED";
};

export function normalizeVenueEvent(input: Partial<CanonicalVenueEvent>): CanonicalVenueEvent {
  if (!input.venue || !input.instrument || !input.source || !input.provenance) throw new Error("Missing venue event provenance");
  if (![input.bid, input.ask, input.last].every((value) => typeof value === "number" && Number.isFinite(value) && value > 0)) throw new Error("Invalid venue event prices");
  if (input.ask! < input.bid!) throw new Error("Venue event ask cannot be below bid");
  const observedAt = input.observedAt ?? new Date().toISOString();
  if (Number.isNaN(Date.parse(observedAt))) throw new Error("Invalid venue event timestamp");
  return { venue: input.venue, instrument: input.instrument, bid: input.bid!, ask: input.ask!, last: input.last!, observedAt, source: input.source, quality: input.quality ?? "VALID", provenance: input.provenance };
}

export function executionBoundary(mode: BotMode): ExecutionBoundary {
  if (mode === "PAPER") return { mode, orderRoute: "PAPER_ONLY", liveApproval: "LOCKED" };
  if (mode === "SHADOW") return { mode, orderRoute: "DISABLED", liveApproval: "LOCKED" };
  return { mode, orderRoute: "LIVE_PENDING_APPROVAL", liveApproval: "REQUIRED" };
}

export function validateScaleOut(state: PositionLifecycle, requestedPct: number): ScaleOutDecision {
  if (state === "FLAT") return { allowed: false, reason: "entry-not-validated" };
  if (state === "ENTRY_VALIDATED") return { allowed: false, reason: "position-not-open" };
  if (state === "CLOSED") return { allowed: false, reason: "position-already-closed" };
  if (!Number.isFinite(requestedPct) || requestedPct <= 0 || requestedPct > 100) return { allowed: false, reason: "invalid-scale-out-percent" };
  return { allowed: true, reason: "position-open" };
}

export function evaluateAdaptiveEntry(input: AdaptiveEntryInput): AdaptiveEntryResult {
  const threshold = input.regime === "TREND" ? 68 : input.regime === "RANGE" ? 78 : 86;
  const stopAtrMultiple = input.stopAtrMultiple ?? 1.8;
  const safeAtrPct = Math.min(Math.max(input.atrPct, 0.0005), 0.12);
  const stopDistance = input.entryPrice * safeAtrPct * stopAtrMultiple;
  const riskCapital = input.equity * Math.min(Math.max(input.riskBudgetPct, 0), 1) / 100;
  const quantity = stopDistance > 0 ? Number((riskCapital / stopDistance).toFixed(8)) : 0;
  const reasons: string[] = [];
  if (input.regime === "SHOCK" || input.regime === "UNKNOWN") reasons.push("regime-not-tradable");
  if (input.score < threshold) reasons.push(`score-below-${threshold}`);
  if (input.confidence < 55) reasons.push("confidence-below-floor");
  if (input.evidenceCount < 3) reasons.push("insufficient-evidence");
  if (input.observedSpreadBps > input.slippageToleranceBps) reasons.push("spread-exceeds-slippage-budget");
  if (input.latencyMs > input.latencyBudgetMs) reasons.push("latency-exceeds-budget");
  if (quantity <= 0 || !Number.isFinite(quantity)) reasons.push("invalid-risk-sized-quantity");
  const hardBlock = input.regime === "SHOCK" || input.regime === "UNKNOWN" || input.observedSpreadBps > input.slippageToleranceBps * 2 || input.latencyMs > input.latencyBudgetMs * 2;
  const decision: AdaptiveEntryDecision = hardBlock ? "BLOCKED" : reasons.length ? "WATCH" : "PAPER_ENTRY";
  return { decision, threshold, stopDistance: Number(stopDistance.toFixed(8)), quantity, reasons };
}
