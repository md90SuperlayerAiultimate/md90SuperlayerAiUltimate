import { describe, expect, it } from "vitest";
import { EVIDENCE_GATES, getEvidenceGates } from "@shared/evidenceGates";

describe("evidence gate register", () => {
  it("covers every external evidence-dependent gate", () => {
    expect(EVIDENCE_GATES.map((gate) => gate.id)).toEqual([
      "PROVIDER_ACCURACY",
      "MICROSTRUCTURE_FEEDS",
      "MULTI_ASSET_HISTORY",
      "PRODUCTION_HEARTBEAT",
      "LIVE_CUSTODY",
    ]);
    expect(EVIDENCE_GATES.filter((gate) => gate.status === "PENDING_EVIDENCE")).toHaveLength(4);
  });

  it("keeps live and custody explicitly disabled", () => {
    const live = EVIDENCE_GATES.find((gate) => gate.id === "LIVE_CUSTODY");
    expect(live?.status).toBe("DISABLED");
    expect(live?.operatorAction).toBe("DO_NOT_ENABLE");
    expect(live?.reason).toMatch(/signing|deposit|withdrawal/i);
  });

  it("returns copies so UI cannot mutate the canonical register", () => {
    const copy = getEvidenceGates();
    expect(copy).not.toBe(EVIDENCE_GATES);
    expect(copy).toEqual(EVIDENCE_GATES);
    copy[0]!.label = "mutated locally";
    expect(EVIDENCE_GATES[0]!.label).not.toBe("mutated locally");
  });
});
