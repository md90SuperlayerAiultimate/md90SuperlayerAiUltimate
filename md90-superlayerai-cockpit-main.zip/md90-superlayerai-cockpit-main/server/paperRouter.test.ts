import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { uiCopy } from "@shared/i18n";

const publicContext = (): TrpcContext => ({
  user: null,
  req: { protocol: "https", headers: {} } as TrpcContext["req"],
  res: {} as TrpcContext["res"],
});

describe("paper and institutional contracts", () => {
  it("delivers the full replay-to-dashboard lineage payload", async () => {
    const overview = await appRouter.createCaller(publicContext()).paper.overview();
    expect(overview.signals.length).toBeGreaterThan(0);
    expect(overview.positions.length).toBeGreaterThan(0);
    expect(overview.trades.length).toBeGreaterThan(0);
    expect(overview.journal.some((entry) => entry.event === "ORDER_FILLED")).toBe(true);
    expect(overview.riskChecks.some((check) => check.label === "Live approval" && check.status === "LOCKED")).toBe(true);
    expect(overview.modules.some((module) => module.status === "live-blocked")).toBe(true);
  });

  it("keeps shadow and news routes read-only with explicit provenance", async () => {
    const caller = appRouter.createCaller(publicContext());
    const shadow = await caller.shadow.observations();
    const news = await caller.intel.news();
    expect(shadow.orderRoute).toBe("DISABLED");
    expect(shadow.observations.some((item) => item.source === "FX")).toBe(true);
    expect(news.items.every((item) => item.source && item.publishedAt && (item.freshness === "FRESH" || item.freshness === "STALE") && (item.status === "SHADOW" || item.status === "PENDING_REVIEW"))).toBe(true);
    expect(news.items.some((item) => item.status === "PENDING_REVIEW")).toBe(true);
  });

  it("rejects paper ingestion for unauthenticated callers", async () => {
    const caller = appRouter.createCaller(publicContext());
    await expect(caller.paper.ingest()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(caller.paper.sync({ symbol: "BTCUSDT", timeframe: "15m", htf: "4h" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(caller.paper.close({ symbol: "BTCUSDT", timeframe: "15m", reason: "OPERATOR_REVIEW" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("exposes both language dictionaries for core terminal surfaces", () => {
    for (const locale of ["ID", "EN"] as const) {
      expect(uiCopy[locale].signalRoom).toBeTruthy();
      expect(uiCopy[locale].riskGate).toBeTruthy();
      expect(uiCopy[locale].news).toBeTruthy();
      expect(uiCopy[locale].shadowFeed).toBeTruthy();
    }
  });
});
