import { describe, expect, it } from "vitest";
import { buildReplayCandles, evaluatePaperRisk, getPaperOverview } from "./paperEngine";

describe("paper engine", () => {
  it("returns a deterministic paper-only overview with execution costs", () => {
    const overview = getPaperOverview();
    expect(overview.mode).toBe("PAPER");
    expect(overview.metrics.fees).toBeGreaterThan(0);
    expect(overview.metrics.slippageBps).toBe(5);
    expect(overview.trades).toHaveLength(1);
    expect(["filled", "partial"]).toContain(overview.trades[0]?.status);
    expect(overview.riskChecks.find((check) => check.label === "Live approval")?.status).toBe("LOCKED");
  });

  it("exposes valid OHLC candles derived from replay prices", () => {
    const candles = buildReplayCandles([100, 102, 101], 1_000_000);
    expect(candles).toHaveLength(3);
    expect(candles.every((candle) => candle.high >= Math.max(candle.open, candle.close) && candle.low <= Math.min(candle.open, candle.close))).toBe(true);
    expect(candles[0]?.timestamp).toBe("1969-12-31T23:46:40.000Z");
    expect(getPaperOverview().primary.candles.length).toBe(12);
  });

  it("resamples the canonical replay for the requested timeframe", () => {
    const oneHour = getPaperOverview("1h");
    const fourHour = getPaperOverview("4h");
    expect(oneHour.timeframe).toBe("1h");
    expect(oneHour.primary.candles.length).toBeLessThan(12);
    expect(fourHour.timeframe).toBe("4h");
    expect(fourHour.primary.candles[0]?.timestamp).not.toBe(oneHour.primary.candles[0]?.timestamp);
  });

  it("fails closed when any risk boundary is breached", () => {
    expect(evaluatePaperRisk({ dailyLossPct: 2.01, grossExposurePct: 10, drawdownPct: 1, dataFreshnessSeconds: 1 }).approved).toBe(false);
    expect(evaluatePaperRisk({ dailyLossPct: 0, grossExposurePct: 25.01, drawdownPct: 1, dataFreshnessSeconds: 1 }).approved).toBe(false);
    expect(evaluatePaperRisk({ dailyLossPct: 0, grossExposurePct: 10, drawdownPct: 10.01, dataFreshnessSeconds: 1 }).approved).toBe(false);
    expect(evaluatePaperRisk({ dailyLossPct: 0, grossExposurePct: 10, drawdownPct: 1, dataFreshnessSeconds: 91 }).approved).toBe(false);
  });

  it("exposes provenance and integration status for every delivered payload", () => {
    const overview = getPaperOverview();
    expect(overview.provenance).toContain("fee 10 bps");
    expect(overview.journal.some((entry) => entry.event === "LIVE_BLOCKED")).toBe(true);
    expect(overview.modules.some((module) => module.status === "live-blocked")).toBe(true);
  });
});
