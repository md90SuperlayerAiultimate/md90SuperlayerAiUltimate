import { describe, expect, it } from "vitest";
import { defiExecutionBoundary, evaluateAdaptiveEntry, executionBoundary, normalizeVenueEvent, survivorModeGate, validateScaleOut } from "./botContracts";

describe("bot contracts", () => {
  it("normalizes a venue event only when provenance and market state are valid", () => {
    const event = normalizeVenueEvent({ venue: "REPLAY", instrument: "BTC/USDT", bid: 72407, ask: 72412, last: 72410, source: "paper-engine", provenance: "deterministic replay" });
    expect(event.quality).toBe("VALID");
    expect(() => normalizeVenueEvent({ venue: "REPLAY", instrument: "BTC/USDT", bid: 10, ask: 9, last: 9, source: "paper-engine", provenance: "test" })).toThrow("ask cannot be below bid");
    expect(() => normalizeVenueEvent({ venue: "REPLAY", instrument: "BTC/USDT", bid: 10, ask: 11, last: 10, source: "", provenance: "test" })).toThrow("provenance");
  });

  it("adapts threshold and risk size without forcing weak entries", () => {
    const base = { regime: "TREND" as const, score: 72, confidence: 70, atrPct: 0.01, entryPrice: 100, equity: 10_000, riskBudgetPct: 0.5, observedSpreadBps: 3, slippageToleranceBps: 5, latencyMs: 80, latencyBudgetMs: 150, evidenceCount: 5 };
    const result = evaluateAdaptiveEntry(base);
    expect(result).toMatchObject({ decision: "PAPER_ENTRY", threshold: 68 });
    expect(result.stopDistance).toBeGreaterThan(0);
    expect(result.quantity).toBeGreaterThan(0);
    const highVolatility = evaluateAdaptiveEntry({ ...base, atrPct: 0.03 });
    expect(highVolatility.stopDistance).toBeGreaterThan(result.stopDistance);
    expect(highVolatility.quantity).toBeLessThan(result.quantity);
    expect(evaluateAdaptiveEntry({ ...base, regime: "RANGE", score: 72 }).decision).toBe("WATCH");
    expect(evaluateAdaptiveEntry({ ...base, regime: "SHOCK", score: 99 }).decision).toBe("BLOCKED");
    expect(evaluateAdaptiveEntry({ ...base, observedSpreadBps: 20 }).decision).toBe("BLOCKED");
    expect(evaluateAdaptiveEntry({ ...base, latencyMs: 400 }).decision).toBe("BLOCKED");
  });

  it("requires a valid open position before any scale-out", () => {
    expect(validateScaleOut("FLAT", 25)).toEqual({ allowed: false, reason: "entry-not-validated" });
    expect(validateScaleOut("ENTRY_VALIDATED", 25)).toEqual({ allowed: false, reason: "position-not-open" });
    expect(validateScaleOut("OPEN", 25)).toEqual({ allowed: true, reason: "position-open" });
    expect(validateScaleOut("OPEN", 0).allowed).toBe(false);
    expect(validateScaleOut("CLOSED", 25).allowed).toBe(false);
  });

  it("blocks DeFi custody and live actions while allowing public quote only", () => {
    expect(defiExecutionBoundary("READ_ONLY_QUOTE")).toMatchObject({ allowed: true, route: "PUBLIC_READ_ONLY" });
    for (const action of ["SIGN", "DEPOSIT", "WITHDRAW", "LIVE_TRANSACTION"] as const) {
      expect(defiExecutionBoundary(action)).toMatchObject({ allowed: false, route: "DISABLED" });
    }
  });

  it("enforces Survivor Mode risk and data locks", () => {
    const result = survivorModeGate({ riskPct: 1, totalExposurePct: 3, dailyLossPct: 0, highImpactNews: false, volatilityShock: false, gammaVerified: true, institutionalFlowVerified: true });
    expect(result).toMatchObject({ allowed: true, route: "PAPER_OR_SHADOW_ONLY" });
    const blocked = survivorModeGate({ riskPct: 2, totalExposurePct: 4, dailyLossPct: 3, highImpactNews: true, volatilityShock: true, gammaVerified: false, institutionalFlowVerified: false });
    expect(blocked.allowed).toBe(false);
    expect(blocked.reasons).toHaveLength(7);
  });

  it("keeps paper and shadow safe while requiring approval for live", () => {
    expect(executionBoundary("PAPER")).toMatchObject({ orderRoute: "PAPER_ONLY", liveApproval: "LOCKED" });
    expect(executionBoundary("SHADOW")).toMatchObject({ orderRoute: "DISABLED", liveApproval: "LOCKED" });
    expect(executionBoundary("LIVE")).toMatchObject({ orderRoute: "LIVE_PENDING_APPROVAL", liveApproval: "REQUIRED" });
  });
});
