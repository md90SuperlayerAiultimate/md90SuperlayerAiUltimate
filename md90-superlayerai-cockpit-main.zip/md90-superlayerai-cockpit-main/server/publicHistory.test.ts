import { describe, expect, it } from "vitest";
import { normalizeBinancePublicKlines } from "./publicHistory";

describe("public historical market data contract", () => {
  it("normalizes ordered Binance public klines with an auditable checksum and disabled order route", () => {
    const result = normalizeBinancePublicKlines([
      [1_700_000_000_000, "100", "104", "99", "102", "12.4", 1_700_000_899_999],
      [1_700_000_900_000, "102", "106", "101", "105", "9.1", 1_700_001_799_999],
    ], "btcusdt", "15m", 1_700_001_800_000, 1_700_001_790_000);
    expect(result).toMatchObject({ venue: "BINANCE_PUBLIC", mode: "SHADOW_EXTERNAL", symbol: "BTCUSDT", interval: "15m", orderRoute: "DISABLED", freshnessSeconds: 10 });
    expect(result.candles).toHaveLength(2);
    expect(result.checksum).toHaveLength(24);
  });

  it("rejects malformed or non-ascending candles instead of making a synthetic fallback", () => {
    expect(() => normalizeBinancePublicKlines([[1, "10", "9", "8", "9", "1", 2]], "BTCUSDT", "15m")).toThrow("Invalid historical OHLC relationship");
    expect(() => normalizeBinancePublicKlines([[10, "10", "11", "9", "10", "1", 11], [9, "10", "11", "9", "10", "1", 12]], "BTCUSDT", "15m")).toThrow("Historical candles are not ascending");
  });
});
