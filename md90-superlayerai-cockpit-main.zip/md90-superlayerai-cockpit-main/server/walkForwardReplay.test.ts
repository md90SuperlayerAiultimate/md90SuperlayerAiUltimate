import { describe, expect, it } from "vitest";
import { runCanonicalWalkForwardReplay } from "./walkForwardReplay";

describe("canonical walk-forward replay", () => {
  it("produces deterministic out-of-sample windows from canonical replay", () => {
    const result = runCanonicalWalkForwardReplay(8, 4);
    expect(result).toMatchObject({ mode: "PAPER_WALK_FORWARD", source: "server/paperEngine.ts:getCanonicalReplayPrices", trainBars: 8, testBars: 4, liveRoute: "DISABLED", targetStatus: "TRACKING" });
    expect(result.windows.length).toBeGreaterThan(0);
    expect(result.trades).toBe(result.wins + result.losses);
    expect(result.outOfSampleWinRatePct).toBeGreaterThanOrEqual(0);
    expect(result.outOfSampleWinRatePct).toBeLessThanOrEqual(100);
    expect(runCanonicalWalkForwardReplay(8, 4)).toEqual(result);
  });
});
