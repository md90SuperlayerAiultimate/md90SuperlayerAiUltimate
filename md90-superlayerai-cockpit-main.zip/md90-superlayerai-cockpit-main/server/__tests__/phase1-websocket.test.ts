import { describe, it, expect, beforeEach, vi } from 'vitest';
import { HardenedWebSocketClient } from '../../shared/websocket-client';

describe('Phase 1: Hardened WebSocket Client', () => {
  let client: HardenedWebSocketClient;

  beforeEach(() => {
    client = new HardenedWebSocketClient({
      url: 'ws://localhost:8080',
      pingInterval: 1000,
      messageTimeout: 500,
      reconnectionConfig: {
        baseDelay: 100,
        maxDelay: 500,
      },
    });
  });

  it('should track connection status', () => {
    expect(client.isConnected()).toBe(false);
  });

  it('should support graceful disconnect', () => {
    client.disconnect();
    expect(client.isConnected()).toBe(false);
  });

  it('should have reconnection manager configured', () => {
    expect(client).toBeDefined();
  });

  it('should timeout on slow messages', async () => {
    // This would need a real WebSocket for full testing
    // For now, just verify the client is initialized
    expect(client).toBeDefined();
  });
});
