/**
 * STEP 6: E2E Tests
 * Chaos testing untuk 50 concurrent reconnects
 */

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { ReconnectionManager } from '../../shared/reconnection-manager';
import { HardenedWebSocketClient } from '../../shared/websocket-client';
import { IdempotencyManager, IdempotencyState } from '../idempotency';
import { v4 as uuidv4 } from 'uuid';

describe('Phase 1: Reconnection & Idempotency E2E Tests', () => {
  let reconnectionManager: ReconnectionManager;
  let idempotencyManager: IdempotencyManager;

  beforeEach(() => {
    reconnectionManager = new ReconnectionManager({
      maxAttempts: 10,
      initialDelay: 100,
      maxDelay: 5000,
      exponentialBase: 2,
      jitterFactor: 0.1
    });
    idempotencyManager = new IdempotencyManager();
  });

  afterEach(() => {
    reconnectionManager.reset();
    idempotencyManager.destroy();
  });

  describe('ReconnectionManager', () => {
    it('should calculate exponential backoff correctly', () => {
      const delays: number[] = [];
      for (let i = 0; i < 5; i++) {
        const delay = reconnectionManager.getNextDelay();
        expect(delay).not.toBeNull();
        delays.push(delay!);
      }

      // Verify exponential growth
      for (let i = 1; i < delays.length; i++) {
        expect(delays[i]).toBeGreaterThan(delays[i - 1]);
      }
    });

    it('should respect max delay limit', () => {
      for (let i = 0; i < 15; i++) {
        const delay = reconnectionManager.getNextDelay();
        if (delay !== null) {
          expect(delay).toBeLessThanOrEqual(5000);
        }
      }
    });

    it('should return null after max attempts', () => {
      for (let i = 0; i < 10; i++) {
        expect(reconnectionManager.getNextDelay()).not.toBeNull();
      }
      expect(reconnectionManager.getNextDelay()).toBeNull();
    });

    it('should reset on success', () => {
      reconnectionManager.getNextDelay();
      reconnectionManager.getNextDelay();
      expect(reconnectionManager.getAttemptCount()).toBe(2);

      reconnectionManager.reset();
      expect(reconnectionManager.getAttemptCount()).toBe(0);
    });

    it('should add jitter to delays', () => {
      const delays: number[] = [];
      for (let i = 0; i < 10; i++) {
        reconnectionManager.reset();
        const delay = reconnectionManager.getNextDelay();
        if (delay) delays.push(delay);
      }

      // Check that delays vary (jitter is working)
      const uniqueDelays = new Set(delays);
      expect(uniqueDelays.size).toBeGreaterThan(1);
    });
  });

  describe('IdempotencyManager', () => {
    it('should register and track requests', () => {
      const request = {
        method: 'POST',
        url: '/orders',
        body: { symbol: 'BTC', quantity: 1 }
      };

      const key = idempotencyManager.generateKey(request);
      const idempotencyKey = idempotencyManager.registerRequest(uuidv4(), request);

      expect(idempotencyKey).toBeDefined();
      expect(idempotencyKey.state).toBe(IdempotencyState.PENDING);
    });

    it('should detect duplicate requests', () => {
      const request = {
        method: 'POST',
        url: '/orders',
        body: { symbol: 'BTC', quantity: 1 }
      };

      const key = idempotencyManager.generateKey(request);
      idempotencyManager.registerRequest(uuidv4(), request);
      idempotencyManager.updateState(key, IdempotencyState.SUCCESS, { orderId: '123' });

      expect(idempotencyManager.isDuplicate(key)).toBe(true);
    });

    it('should cache successful results', () => {
      const request = {
        method: 'POST',
        url: '/orders',
        body: { symbol: 'BTC', quantity: 1 }
      };

      const key = idempotencyManager.generateKey(request);
      idempotencyManager.registerRequest(uuidv4(), request);
      const result = { orderId: '123', status: 'created' };
      idempotencyManager.updateState(key, IdempotencyState.SUCCESS, result);

      const cached = idempotencyManager.getResult(key);
      expect(cached?.state).toBe(IdempotencyState.SUCCESS);
      expect(cached?.result).toEqual(result);
    });

    it('should cleanup expired keys', async () => {
      const request = {
        method: 'POST',
        url: '/orders',
        body: { symbol: 'BTC' }
      };

      const key = idempotencyManager.generateKey(request);
      idempotencyManager.registerRequest(uuidv4(), request);

      const statsBefore = idempotencyManager.getStats();
      expect(statsBefore.total).toBe(1);

      // Wait and cleanup (simulating TTL expiration)
      await new Promise(resolve => setTimeout(resolve, 100));

      // Manually trigger expiration check
      const result = idempotencyManager.getResult(key);
      expect(result?.state).toBe(IdempotencyState.PENDING);
    });
  });

  describe('Chaos Testing: 50 Concurrent Reconnects', () => {
    it('should handle 50 concurrent reconnection attempts', async () => {
      const managers = Array.from({ length: 50 }, () =>
        new ReconnectionManager({
          maxAttempts: 5,
          initialDelay: 50,
          maxDelay: 1000,
          exponentialBase: 2,
          jitterFactor: 0.1
        })
      );

      const delays = await Promise.all(
        managers.map(manager => {
          return new Promise<number[]>(resolve => {
            const delayList: number[] = [];
            const getDelays = () => {
              const delay = manager.getNextDelay();
              if (delay !== null) {
                delayList.push(delay);
                setTimeout(getDelays, delay);
              } else {
                resolve(delayList);
              }
            };
            getDelays();
          });
        })
      );

      // Verify all managers completed
      expect(delays).toHaveLength(50);

      // Verify each manager got exponential backoff
      delays.forEach(delayList => {
        expect(delayList.length).toBeGreaterThan(0);
        expect(delayList.length).toBeLessThanOrEqual(5);

        // Verify exponential growth
        for (let i = 1; i < delayList.length; i++) {
          expect(delayList[i]).toBeGreaterThanOrEqual(delayList[i - 1]);
        }
      });
    });

    it('should handle concurrent idempotency checks', async () => {
      const requestCount = 50;
      const requests = Array.from({ length: requestCount }, (_, i) => ({
        method: 'POST',
        url: '/orders',
        body: { symbol: `SYM${i}`, quantity: i + 1 }
      }));

      const results = await Promise.all(
        requests.map((request, index) => {
          return new Promise(resolve => {
            const requestId = uuidv4();
            const idempotencyKey = idempotencyManager.registerRequest(requestId, request);

            // Simulate processing
            setTimeout(() => {
              idempotencyManager.updateState(
                idempotencyKey.id,
                IdempotencyState.SUCCESS,
                { orderId: `order-${index}` }
              );
              resolve(idempotencyManager.getResult(idempotencyKey.id));
            }, Math.random() * 100);
          });
        })
      );

      // Verify all requests processed
      expect(results).toHaveLength(requestCount);

      // Verify stats
      const stats = idempotencyManager.getStats();
      expect(stats.total).toBeGreaterThan(0);
      expect(stats.byState[IdempotencyState.SUCCESS]).toBe(requestCount);
    });

    it('should handle stress test: rapid connect/disconnect cycles', async () => {
      const cycleCount = 20;
      const concurrency = 10;

      const stressCycles = Array.from({ length: cycleCount }, async () => {
        const promises = Array.from({ length: concurrency }, async () => {
          const manager = new ReconnectionManager({
            maxAttempts: 3,
            initialDelay: 10,
            maxDelay: 100,
            exponentialBase: 2,
            jitterFactor: 0.1
          });

          // Simulate connect attempt
          let attempts = 0;
          while (manager.getNextDelay() !== null) {
            attempts++;
          }

          return attempts;
        });

        return Promise.all(promises);
      });

      const allResults = await Promise.all(stressCycles);

      // Verify all cycles completed
      expect(allResults).toHaveLength(cycleCount);

      // Each cycle should have concurrency results
      allResults.forEach(cycleResults => {
        expect(cycleResults).toHaveLength(concurrency);
      });
    });

    it('should maintain data consistency during concurrent operations', async () => {
      const operations = 100;
      const results = [];

      // Concurrent write operations
      for (let i = 0; i < operations; i++) {
        const request = {
          method: 'POST',
          url: `/orders-${i}`,
          body: { id: i }
        };

        const key = idempotencyManager.generateKey(request);
        const idempotencyKey = idempotencyManager.registerRequest(uuidv4(), request);

        // Update with concurrent writes
        idempotencyManager.updateState(
          key,
          IdempotencyState.SUCCESS,
          { processed: true }
        );

        results.push(idempotencyManager.getResult(key));
      }

      // Verify consistency
      const stats = idempotencyManager.getStats();
      expect(stats.byState[IdempotencyState.SUCCESS]).toBeLessThanOrEqual(operations);

      // All results should be defined
      results.forEach(result => {
        expect(result).toBeDefined();
      });
    });
  });

  describe('Integration Tests', () => {
    it('should handle reconnection with idempotency recovery', async () => {
      // Simulate initial request
      const request = {
        method: 'POST',
        url: '/orders',
        body: { symbol: 'BTC', quantity: 1 }
      };

      const key = idempotencyManager.generateKey(request);
      const idempotencyKey = idempotencyManager.registerRequest(uuidv4(), request);

      // Simulate processing
      idempotencyManager.updateState(key, IdempotencyState.PROCESSING);

      // Simulate reconnection attempt
      const reconnectionDelay = reconnectionManager.getNextDelay();
      expect(reconnectionDelay).not.toBeNull();

      // After reconnection, result should still be cached
      idempotencyManager.updateState(key, IdempotencyState.SUCCESS, { orderId: '123' });

      const cachedResult = idempotencyManager.getResult(key);
      expect(cachedResult?.state).toBe(IdempotencyState.SUCCESS);
      expect(cachedResult?.result).toEqual({ orderId: '123' });
    });

    it('should handle failed requests with retry', async () => {
      const request = {
        method: 'POST',
        url: '/orders',
        body: { symbol: 'BTC', quantity: 1 }
      };

      const key = idempotencyManager.generateKey(request);
      let idempotencyKey = idempotencyManager.registerRequest(uuidv4(), request);

      // Simulate failure
      idempotencyManager.updateState(
        key,
        IdempotencyState.FAILED,
        undefined,
        'Network timeout'
      );

      // Simulate retry
      idempotencyKey = idempotencyManager.registerRequest(uuidv4(), request);

      // Should be in PENDING state for retry
      expect(idempotencyKey.state).toBe(IdempotencyState.PENDING);
      expect(idempotencyKey.retryCount).toBe(1);
    });
  });
});
