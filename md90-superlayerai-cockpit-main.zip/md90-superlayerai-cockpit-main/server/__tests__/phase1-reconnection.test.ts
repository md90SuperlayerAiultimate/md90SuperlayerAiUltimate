import { describe, it, expect, beforeEach, vi } from 'vitest';
import { ReconnectionManager } from '../../shared/reconnection-manager';

describe('Phase 1: Exponential Backoff & Reconnection', () => {
  let manager: ReconnectionManager;

  beforeEach(() => {
    manager = new ReconnectionManager({
      baseDelay: 100,
      maxDelay: 1600,
      maxAttempts: 10,
      jitterFactor: 0.1,
    });
  });

  it('should apply exponential backoff', async () => {
    const startTimes: number[] = [];

    // Measure actual wait times
    for (let i = 0; i < 3; i++) {
      startTimes.push(Date.now());
      await manager.wait();
    }

    const delay1 = startTimes[1] - startTimes[0];
    const delay2 = startTimes[2] - startTimes[1];

    // Delay should roughly double (with jitter)
    // First: ~100ms, Second: ~200ms, Third: ~400ms
    expect(delay1).toBeGreaterThan(50);
    expect(delay1).toBeLessThan(200);
    expect(delay2).toBeGreaterThan(150);
    expect(delay2).toBeLessThan(500);
  });

  it('should cap delay at maxDelay', async () => {
    const config = new ReconnectionManager({
      baseDelay: 1000,
      maxDelay: 2000,
      maxAttempts: 20,
      jitterFactor: 0,
    });

    // Simulate many attempts
    for (let i = 0; i < 10; i++) {
      await config.wait();
    }

    // After many attempts, delay should be capped at maxDelay
    expect(config.getAttempt()).toBeLessThanOrEqual(10);
  });

  it('should reset on successful connection', async () => {
    await manager.wait();
    expect(manager.getAttempt()).toBe(1);

    manager.reset();
    expect(manager.getAttempt()).toBe(0);
  });

  it('should throw error when max attempts exceeded', async () => {
    const config = new ReconnectionManager({
      baseDelay: 10,
      maxDelay: 50,
      maxAttempts: 3,
      jitterFactor: 0,
    });

    for (let i = 0; i < 3; i++) {
      await config.wait();
    }

    await expect(config.wait()).rejects.toThrow('Max reconnection attempts');
  });

  it('should include jitter in delays', async () => {
    const delays: number[] = [];

    for (let i = 0; i < 5; i++) {
      const start = Date.now();
      await manager.wait();
      delays.push(Date.now() - start);
    }

    // With jitter, delays should vary slightly
    const unique = new Set(delays).size;
    expect(unique).toBeGreaterThan(1);
  });

  it('should detect thundering herd (>5 reconnects/min)', async () => {
    const config = new ReconnectionManager({
      baseDelay: 10,
      maxDelay: 50,
      jitterFactor: 0,
    });

    const startTime = Date.now();
    const delays: number[] = [];

    // Trigger 7 reconnection attempts rapidly
    for (let i = 0; i < 7; i++) {
      const before = Date.now();
      await config.wait();
      delays.push(Date.now() - before);
    }

    // After 5 attempts, should detect herd and use max delay
    // 6th and 7th attempts should take ~50ms (maxDelay)
    if (delays[5] !== undefined && delays[6] !== undefined) {
      expect(delays[5]).toBeGreaterThanOrEqual(30); // Herd detection kicks in
    }
  });

  it('should track reconnection attempts', () => {
    expect(manager.getAttempt()).toBe(0);

    manager.wait().then(() => {
      expect(manager.getAttempt()).toBeGreaterThanOrEqual(1);
    });
  });
});
