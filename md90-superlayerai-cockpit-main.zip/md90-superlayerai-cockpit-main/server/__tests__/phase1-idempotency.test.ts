import { describe, it, expect, beforeEach } from 'vitest';
import {
  IdempotencyManager,
  OrderIntent,
} from '../../shared/idempotency';

describe('Phase 1: Idempotency & Retry Safety', () => {
  let manager: IdempotencyManager;

  beforeEach(() => {
    manager = new IdempotencyManager();
  });

  it('should generate unique idempotency keys', () => {
    const intent: OrderIntent = {
      symbol: 'BTC/USDT',
      side: 'BUY',
      quantity: 1.5,
      price: 45000,
      type: 'LIMIT',
    };

    const key1 = manager.generateKey(intent);
    const key2 = manager.generateKey(intent);

    expect(key1.clientOrderId).not.toBe(key2.clientOrderId);
    expect(key1.hash).toBe(key2.hash); // Same intent = same hash
  });

  it('should register and track order state', () => {
    const intent: OrderIntent = {
      symbol: 'ETH/USDT',
      side: 'SELL',
      quantity: 10,
      price: 2500,
      type: 'MARKET',
    };

    const key = manager.generateKey(intent);
    const orderState = manager.registerOrder(key, intent);

    expect(orderState.status).toBe('PENDING');
    expect(orderState.attempts).toBe(0);

    const retrieved = manager.getOrder(key.clientOrderId);
    expect(retrieved).toEqual(orderState);
  });

  it('should prevent duplicate submissions', () => {
    const intent: OrderIntent = {
      symbol: 'BTC/USDT',
      side: 'BUY',
      quantity: 2,
      price: 45000,
      type: 'LIMIT',
    };

    const key = manager.generateKey(intent);
    manager.registerOrder(key, intent);

    const isDuplicate = manager.isDuplicate(key.clientOrderId, intent);
    expect(isDuplicate).toBe(true);
  });

  it('should track retry attempts', () => {
    const intent: OrderIntent = {
      symbol: 'BTC/USDT',
      side: 'BUY',
      quantity: 1,
      price: 45000,
      type: 'LIMIT',
    };

    const key = manager.generateKey(intent);
    manager.registerOrder(key, intent);

    manager.recordRetry(key.clientOrderId);
    manager.recordRetry(key.clientOrderId);

    const order = manager.getOrder(key.clientOrderId);
    expect(order?.attempts).toBe(2);
  });

  it('should allow retry within limits', () => {
    const intent: OrderIntent = {
      symbol: 'BTC/USDT',
      side: 'BUY',
      quantity: 1,
      price: 45000,
      type: 'LIMIT',
    };

    const key = manager.generateKey(intent);
    manager.registerOrder(key, intent);

    expect(manager.canRetry(key.clientOrderId)).toBe(true);

    manager.recordRetry(key.clientOrderId);
    manager.recordRetry(key.clientOrderId);
    manager.recordRetry(key.clientOrderId);

    expect(manager.canRetry(key.clientOrderId)).toBe(false);
  });

  it('should update order state after exchange response', () => {
    const intent: OrderIntent = {
      symbol: 'ETH/USDT',
      side: 'BUY',
      quantity: 5,
      price: 2500,
      type: 'LIMIT',
    };

    const key = manager.generateKey(intent);
    manager.registerOrder(key, intent);

    manager.updateOrderState(
      key.clientOrderId,
      'EX-12345',
      'FILLED'
    );

    const order = manager.getOrder(key.clientOrderId);
    expect(order?.status).toBe('FILLED');
    expect(order?.exchangeOrderId).toBe('EX-12345');
  });

  it('should cleanup old orders', () => {
    const intent: OrderIntent = {
      symbol: 'BTC/USDT',
      side: 'BUY',
      quantity: 1,
      price: 45000,
      type: 'LIMIT',
    };

    const key = manager.generateKey(intent);
    manager.registerOrder(key, intent);

    const retrieved = manager.getOrder(key.clientOrderId);
    expect(retrieved).toBeDefined();

    // Manually set old timestamp for testing
    if (retrieved) {
      retrieved.timestamp = Date.now() - 25 * 60 * 60 * 1000; // 25 hours ago
    }

    manager.cleanup();

    const afterCleanup = manager.getOrder(key.clientOrderId);
    expect(afterCleanup).toBeUndefined();
  });
});
