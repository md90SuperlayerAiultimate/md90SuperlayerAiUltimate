import { describe, expect, it } from "vitest";
import { PaperBroker } from "./paperBroker";

describe("PaperBroker", () => {
  const request = {
    clientOrderId: "client-001",
    instrument: "BTC/USDT",
    side: "BUY" as const,
    quantity: 1,
    bid: 70_000,
    ask: 70_035,
    feeBps: 10,
    slippageBps: 5,
  };

  it("applies deterministic partial fill, slippage, and fee", () => {
    const result = new PaperBroker().submit(request);
    expect(result.status).toBe("partial");
    expect(result.filledQuantity).toBe(0.75);
    expect(result.averagePrice).toBeGreaterThan(request.ask);
    expect(result.fee).toBeGreaterThan(0);
  });

  it("returns the same result for duplicate client order ids", () => {
    const broker = new PaperBroker();
    const first = broker.submit(request);
    const second = broker.submit(request);
    expect(second).toEqual(first);
  });

  it("rejects invalid market state before creating a fill", () => {
    expect(() => new PaperBroker().submit({ ...request, ask: 69_000 })).toThrow("Invalid paper order market state");
  });
});
