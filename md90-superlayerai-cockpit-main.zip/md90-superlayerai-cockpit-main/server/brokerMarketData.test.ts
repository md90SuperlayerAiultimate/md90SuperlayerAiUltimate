import { describe, expect, it, vi } from "vitest";
import { fetchBinancePublicTicker, normalizePublicTicker } from "./brokerMarketData";

describe("broker market-data boundary", () => {
  it("normalizes a public ticker and keeps order route disabled", () => {
    const ticker = normalizePublicTicker({ symbol: "BTCUSDT", bidPrice: "100", askPrice: "100.1" }, 1_000);
    expect(ticker.symbol).toBe("BTCUSDT");
    expect(ticker.spreadBps).toBeCloseTo(9.995, 2);
    expect(ticker.orderRoute).toBe("DISABLED");
    expect(ticker.venue).toBe("BINANCE_PUBLIC");
  });

  it("marks source data stale when the exchange timestamp is older than policy", () => {
    const ticker = normalizePublicTicker({ symbol: "BTCUSDT", bidPrice: "100", askPrice: "100.1" }, 20_000, 1_000);
    expect(ticker.health).toBe("STALE");
  });

  it("blocks malformed or crossed quotes", () => {
    expect(() => normalizePublicTicker({ symbol: "BTCUSDT", bidPrice: "bad", askPrice: "100" }, 1_000)).toThrow("Invalid broker ticker");
    expect(() => normalizePublicTicker({ symbol: "BTCUSDT", bidPrice: "101", askPrice: "100" }, 1_000)).toThrow("Invalid broker ticker");
  });

  it("retries once after a transient rate limit and never exposes a credential or order route", async () => {
    const fetchImpl = vi.fn()
      .mockResolvedValueOnce({ ok: false, status: 429 })
      .mockResolvedValueOnce({ ok: true, headers: new Headers(), json: async () => ({ symbol: "BTCUSDT", bidPrice: "100", askPrice: "100.1" }) });
    const ticker = await fetchBinancePublicTicker("BTCUSDT", fetchImpl as typeof fetch, 1_000);
    expect(fetchImpl).toHaveBeenCalledTimes(2);
    expect(ticker.orderRoute).toBe("DISABLED");
    expect(String(fetchImpl.mock.calls[0]?.[1])).not.toContain("apiKey");
  });

  it("handles timeout/abort and incomplete payload as blocked", async () => {
    const timeoutFetch = vi.fn((_url: string, init?: RequestInit) => new Promise((_resolve, reject) => {
      init?.signal?.addEventListener("abort", () => reject(new DOMException("aborted", "AbortError")));
    }));
    await expect(fetchBinancePublicTicker("BTCUSDT", timeoutFetch as typeof fetch, 1_000, 1)).rejects.toThrow("BINANCE_PUBLIC_BLOCKED");
    const incomplete = vi.fn().mockResolvedValue({ ok: true, headers: new Headers(), json: async () => ({ symbol: "BTCUSDT" }) });
    await expect(fetchBinancePublicTicker("BTCUSDT", incomplete as typeof fetch, 1_000)).rejects.toThrow("BINANCE_PUBLIC_BLOCKED: Incomplete broker ticker");
  });
});
