import { describe, expect, it, vi } from "vitest";

const { loadPersistedDatasetForParity } = vi.hoisted(() => ({ loadPersistedDatasetForParity: vi.fn() }));
vi.mock("./datasetPersistence", () => ({ loadPersistedDatasetForParity }));

import { buildPersistedInstitutionalRiskReport } from "./institutionalRiskPersistence";

function readyManifest(symbol: string, id: number, count = 32) {
  const candles = Array.from({ length: count }, (_, index) => {
    const close = 100 + index * (symbol === "EURUSD" ? 0.2 : 0.35);
    return { open: close - 0.1, high: close + 0.2, low: close - 0.2, close, volume: 10 };
  });
  return { status: "READY" as const, manifest: { symbol, interval: "15m", checksum: `${String(id).repeat(64).slice(0, 64)}`, sourceTimestamp: new Date("2026-08-27T00:00:00Z"), barCount: candles.length }, series: { symbol, interval: "15m", venue: "DUKASCOPY_FILE", checksum: `${String(id).repeat(64).slice(0, 64)}`, candles } };
}

describe("persisted institutional risk report", () => {
  it("derives real-manifest returns and preserves provenance metadata", async () => {
    loadPersistedDatasetForParity.mockImplementation(async (_userId: number, id: number) => readyManifest(id === 1 ? "EURUSD" : "XAUUSD", id));
    const result = await buildPersistedInstitutionalRiskReport(7, [1, 2]);
    expect(result.status).toBe("READY");
    expect(result.report.symbols).toEqual(["EURUSD", "XAUUSD"]);
    expect(result.report.sampleSize).toBe(31);
    expect(result.report.correlation).toHaveLength(2);
    expect(result.manifests.map((manifest) => manifest.symbol)).toEqual(["EURUSD", "XAUUSD"]);
    expect(result.reasons).toEqual([]);
  });

  it("fails closed when a persisted manifest has too few returns", async () => {
    loadPersistedDatasetForParity.mockResolvedValue(readyManifest("EURUSD", 1, 4));
    const result = await buildPersistedInstitutionalRiskReport(7, [1]);
    expect(result.status).toBe("PENDING");
    expect(result.report.historicalVaR).toBeNull();
    expect(result.reasons).toContain("INSUFFICIENT_SAMPLE");
  });

  it("never exposes execution authority", async () => {
    loadPersistedDatasetForParity.mockResolvedValue(readyManifest("EURUSD", 1));
    const result = await buildPersistedInstitutionalRiskReport(7, [1]);
    expect(result.report.status).toBe("READY");
    expect(result.report.reasons).not.toContain("LIVE");
  });
});
