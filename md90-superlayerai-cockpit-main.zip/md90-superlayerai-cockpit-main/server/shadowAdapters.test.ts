import { describe, expect, it } from "vitest";
import { classifyNewsFreshness, getNewsItems, getShadowObservations } from "./shadowAdapters";

describe("shadow adapters", () => {
  it("covers crypto and FX observations without an order route", () => {
    const observations = getShadowObservations();
    expect(observations.some((item) => item.source === "FX" && item.instrument === "EUR/USD")).toBe(true);
    expect(observations.every((item) => item.freshnessSeconds >= 0 && item.provenance.length > 0 && item.permissionScope && item.orderRoute === "DISABLED")).toBe(true);
    expect(observations.find((item) => item.source === "CRYPTOIZ")?.permissionScope).toBe("PROVIDER_SESSION_REQUIRED");
    expect(observations.find((item) => item.source === "DYNAMIC_EXECUTION")?.permissionScope).toBe("PROVIDER_SESSION_REQUIRED");
  });

  it("classifies news freshness and expiry deterministically", () => {
    const now = Date.parse("2026-08-23T06:00:00.000Z");
    expect(classifyNewsFreshness("2026-08-23T05:45:00.000Z", now)).toBe("FRESH");
    expect(classifyNewsFreshness("2026-08-23T05:29:59.000Z", now)).toBe("STALE");
    expect(classifyNewsFreshness("2026-08-23T06:01:00.000Z", now)).toBe("STALE");
  });

  it("keeps news items reviewable with source and relevance", () => {
    const items = getNewsItems();
    expect(items.length).toBeGreaterThan(0);
    expect(items.every((item) => item.source && item.instrument && item.relevance >= 0 && item.relevance <= 100)).toBe(true);
  });
});
