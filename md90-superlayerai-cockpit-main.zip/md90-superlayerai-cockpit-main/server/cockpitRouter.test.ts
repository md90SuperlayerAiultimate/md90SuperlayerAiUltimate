import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const publicContext = (): TrpcContext => ({
  user: null,
  req: { protocol: "https", headers: {} } as TrpcContext["req"],
  res: {} as TrpcContext["res"],
});

describe("unified cockpit snapshot", () => {
  it("returns one auditable paper-to-shadow payload", async () => {
    const snapshot = await appRouter.createCaller(publicContext()).cockpit.snapshot({ timeframe: "15m", symbol: "EURUSD" });
    expect(snapshot.timeframe).toMatchObject({ base: "15m", htf: "4h", source: "CANONICAL_CONTEXT" });
    const mtfa = await appRouter.createCaller(publicContext()).cockpit.snapshot({ timeframe: "1h", htf: "1d", symbol: "EURUSD" });
    expect(mtfa.timeframe).toMatchObject({ base: "1h", htf: "1d", symbol: "OANDA:EURUSD" });
    expect(snapshot.paper).toBeNull();
    expect(snapshot.paperAvailability).toMatchObject({ status: "PENDING_DATASET", source: "SHADOW_ONLY" });
    expect(snapshot.workflow.decision).toBe("PAPER_BLOCKED");
    expect(snapshot.shadow.observations.length).toBeGreaterThan(0);
    expect(snapshot.news.items.length).toBeGreaterThan(0);
    expect(snapshot.demo.account.slug).toBe("md90-demo-paper");
    expect(snapshot.broker).toMatchObject({ venue: "OANDA_PUBLIC", symbol: "EURUSD", orderRoute: "DISABLED", health: "UNAVAILABLE" });
    expect(snapshot.safety).toMatchObject({ operationMode: "PAPER_SHADOW", liveRoute: "LIVE_PENDING_APPROVAL", custody: "DISABLED" });
  });
});
