import { paperWorkflowEvents } from "../drizzle/schema";
import { getDb } from "./db";
import { getPaperOverview, evaluatePaperRisk } from "./paperEngine";
import { getExternalDatasetIngestions, loadPersistedDatasetForParity } from "./datasetPersistence";
import { getOrCreatePaperSession } from "./paperPersistence";
import { evaluateNumericParity, type ParityIndicatorName } from "@shared/numericParity";
import { appendOperatingEvent, blockOperatingState, createOperatingState, type OperatingEvent, type OperatingState } from "@shared/operatingCockpit";
import { validateSourceVectorEvidence } from "@shared/sourceVectorRegistry";
import { runForwardPaperSession } from "@shared/forwardPaperSession";
import { runDatasetReplay } from "./datasetReplay";
import { compareForwardToBacktest } from "@shared/forwardComparison";
import { persistForwardPaperSession } from "./forwardPaperPersistence";

export type OperatingRunInput = {
  userId: number;
  ingestionId: number;
  baseTimeframe: string;
  higherTimeframe: string;
  expected?: Partial<Record<ParityIndicatorName, number | null>>;
  source?: string;
  tolerance?: number;
  artifactName?: string;
  sourceArtifactChecksum?: string;
  sourceLineRange?: string;
  formulaVersion?: string;
  idempotencyKey: string;
};

function event(state: OperatingState, stage: OperatingEvent["stage"], type: string, evidence: OperatingEvent["evidence"], payload: Record<string, unknown>, now: number, authority: OperatingEvent["authority"] = state.authority): OperatingEvent {
  return { eventId: `${state.correlationId}:${stage.toLowerCase()}`, correlationId: state.correlationId, causationId: state.events.at(-1)?.eventId, stage, type, symbol: state.symbol, occurredAt: now, inputChecksum: state.sourceChecksum, outputChecksum: state.sourceChecksum, evidence, authority, payload };
}

export async function runOperatingBatch(input: { userId: number; ingestionIds: number[]; baseTimeframe: string; higherTimeframe: string; expectedByIngestion?: Record<string, Partial<Record<ParityIndicatorName, number | null>>>; source?: string; artifactName?: string; sourceArtifactChecksum?: string; sourceLineRange?: string; formulaVersion?: string; tolerance?: number; idempotencyKey: string }) {
  const results = [];
  for (let index = 0; index < input.ingestionIds.length; index += 1) {
    const ingestionId = input.ingestionIds[index];
    results.push(await runOperatingWorkflow({ userId: input.userId, ingestionId, baseTimeframe: input.baseTimeframe, higherTimeframe: input.higherTimeframe, expected: input.expectedByIngestion?.[String(ingestionId)], source: input.source, artifactName: input.artifactName, sourceArtifactChecksum: input.sourceArtifactChecksum, sourceLineRange: input.sourceLineRange, formulaVersion: input.formulaVersion, tolerance: input.tolerance, idempotencyKey: `${input.idempotencyKey}:${index}` }));
  }
  return { status: "completed" as const, count: results.length, results, authority: "PAPER_SHADOW_ONLY" as const, orderRoute: "DISABLED" as const };
}

export async function runOperatingWorkflow(input: OperatingRunInput): Promise<{ state: OperatingState; persisted: boolean; sessionId?: number; reason?: string; forwardPaper?: ReturnType<typeof runForwardPaperSession>; comparison?: ReturnType<typeof compareForwardToBacktest>; forwardPersisted?: Awaited<ReturnType<typeof persistForwardPaperSession>> }> {
  const imports = await getExternalDatasetIngestions(input.userId);
  const manifest = imports.find((item) => item.id === input.ingestionId);
  if (!manifest) {
    const state = createOperatingState({ correlationId: `operating:${input.userId}:${input.idempotencyKey}`, userId: input.userId, symbol: "UNKNOWN", baseTimeframe: input.baseTimeframe, higherTimeframe: input.higherTimeframe, authority: "DISABLED", evidence: "BLOCKED", policyVersion: "operating-v1" });
    return { state: blockOperatingState(state, ["MANIFEST_MISSING"]), persisted: false, reason: "user-scoped-manifest-not-found" };
  }

  const correlationId = `operating:${input.userId}:${manifest.id}:${manifest.checksum}:${input.idempotencyKey}`.slice(0, 160);
  let state = createOperatingState({ correlationId, userId: input.userId, symbol: manifest.symbol, baseTimeframe: input.baseTimeframe, higherTimeframe: input.higherTimeframe, authority: "SHADOW", evidence: manifest.evidenceState === "READY" ? "READY" : "PENDING", policyVersion: "operating-v1", sourceChecksum: manifest.checksum });
  const now = Date.now();
  state = appendOperatingEvent(state, event(state, "NORMALIZE", "DATASET_NORMALIZED", state.evidence, { ingestionId: manifest.id, bars: manifest.barCount, interval: manifest.interval, coverageClass: manifest.coverageClass }, now));
  const loaded = await loadPersistedDatasetForParity(input.userId, manifest.id);
  if (loaded.status !== "READY" || !loaded.series.symbol || !loaded.series.interval || !loaded.series.checksum || !loaded.series.candles) return { state: blockOperatingState(state, ["MANIFEST_STALE"]), persisted: false, reason: loaded.status === "READY" ? "persisted-series-shape-invalid" : loaded.reason };
  const persistedSeries = { symbol: loaded.series.symbol!, interval: loaded.series.interval!, checksum: loaded.series.checksum!, candles: loaded.series.candles! };
  const hasExpectedVector = Boolean(input.expected && Object.keys(input.expected).length > 0);
  const sourceEvidence = hasExpectedVector && input.artifactName && input.sourceArtifactChecksum && input.sourceLineRange && input.formulaVersion ? validateSourceVectorEvidence({ artifactName: input.artifactName, artifactChecksum: input.sourceArtifactChecksum, lineRange: input.sourceLineRange, formulaVersion: input.formulaVersion, symbol: persistedSeries.symbol, interval: persistedSeries.interval, vector: input.expected ?? {} }) : { ok: false as const, reason: "ARTIFACT_CHECKSUM_REQUIRED" as const };
  const parityReady = hasExpectedVector && sourceEvidence.ok;
  state = appendOperatingEvent(state, event(state, "PARITY", "NUMERIC_PARITY_EVALUATED", parityReady ? "READY" : "PENDING", { expectedProvided: hasExpectedVector, source: input.source ?? "source-of-truth artifact required", artifactName: input.artifactName ?? null, sourceArtifactChecksum: input.sourceArtifactChecksum ?? null, sourceLineRange: input.sourceLineRange ?? null, formulaVersion: input.formulaVersion ?? null, sourceValidation: sourceEvidence.ok ? "BOUND" : sourceEvidence.reason }, now + 1));
  const parity = evaluateNumericParity({ symbol: persistedSeries.symbol, interval: persistedSeries.interval, source: input.source ?? manifest.source, checksum: persistedSeries.checksum, candles: persistedSeries.candles, expected: parityReady ? input.expected ?? {} : {}, tolerance: input.tolerance });
  const parityBlocked = !parityReady || parity.overall !== "MATCH";
  state = appendOperatingEvent(state, event(state, "CONFLUENCE", "MTFA_CONFLUENCE_EVALUATED", parityBlocked ? "PENDING" : "MATCH", { parityOverall: parity.overall, mtfa: `${input.baseTimeframe}/${input.higherTimeframe}` }, now + 2));
  // Evaluate risk freshness against the manifest being run, not the unrelated legacy snapshot.
  // Exposure and drawdown are zero at this pre-trade stage because this run has no position yet.
  const lastCandle = persistedSeries.candles.at(-1) as { closedAt?: string | number | null; timestamp?: string | number | null; openedAt?: string | number | null } | undefined;
  const lastCandleAt = lastCandle ? lastCandle.closedAt ?? lastCandle.timestamp ?? lastCandle.openedAt : null;
  const lastCandleMs = lastCandleAt ? new Date(lastCandleAt).getTime() : NaN;
  const dataFreshnessSeconds = Number.isFinite(lastCandleMs) ? Math.max(0, Math.round((now - lastCandleMs) / 1000)) : Number.MAX_SAFE_INTEGER;
  const risk = evaluatePaperRisk({ dailyLossPct: 0, grossExposurePct: 0, drawdownPct: 0, dataFreshnessSeconds, riskPct: 0.5 });
  const riskBlocked = !risk.approved;
  state = appendOperatingEvent(state, event(state, "RISK_GATE", "PROTECTIVE_POLICY_EVALUATED", riskBlocked ? "BLOCKED" : "READY", { approved: risk.approved, reasons: risk.survivor.reasons, checks: { dailyLoss: risk.dailyLossPass, exposure: risk.exposurePass, drawdown: risk.drawdownPass, freshness: risk.freshnessPass } }, now + 3));
  const reasons = [...(parityBlocked ? [parity.overall === "MISMATCH" ? "PARITY_MISMATCH" as const : "PARITY_REQUIRED" as const] : []), ...(riskBlocked ? ["RISK_POLICY_HOLD" as const] : [])];
  let forwardPaper: ReturnType<typeof runForwardPaperSession> | undefined;
  let comparison: ReturnType<typeof compareForwardToBacktest> | undefined;
  if (reasons.length) {
    state = appendOperatingEvent(state, event(state, "AUDIT", "OPERATING_RUN_BLOCKED_AUDITED", "BLOCKED", { blockedReasons: reasons, route: "PAPER_SHADOW_ONLY", orderRoute: "DISABLED" }, now + 4, "DISABLED"));
    state = blockOperatingState(state, reasons, now + 5);
  } else {
    state = appendOperatingEvent(state, event(state, "PAPER_DECISION", "PAPER_DECISION_RECORDED", "MATCH", { outcome: "PAPER_CANDIDATE", route: "PAPER_REPLAY_ONLY" }, now + 4));
    state = appendOperatingEvent(state, event(state, "PAPER_FILL", "PAPER_FILL_STAGED", "MATCH", { route: "PAPER_REPLAY_ONLY", liveAuthority: "DISABLED" }, now + 5));
    state = appendOperatingEvent(state, event(state, "POSITION", "PAPER_POSITION_PROJECTED", "MATCH", { state: "PAPER_ONLY" }, now + 6));
    state = appendOperatingEvent(state, event(state, "JOURNAL", "PAPER_JOURNAL_PROJECTED", "MATCH", { correlationId }, now + 7));
    state = appendOperatingEvent(state, event(state, "AUDIT", "OPERATING_RUN_AUDITED", "MATCH", { eventCount: 9, authority: "DISABLED_FOR_LIVE" }, now + 8));
    forwardPaper = runForwardPaperSession(persistedSeries.candles, { symbol: persistedSeries.symbol, venue: manifest.source, lookbackBars: 20, maxHoldingBars: 10, startingEquity: 100_000, riskFraction: 0.005, feeBps: 10, slippageBps: 5, spreadBps: 2 });
    const backtest = runDatasetReplay(persistedSeries.candles, { trainBars: Math.min(240, Math.max(32, Math.floor(persistedSeries.candles.length / 3))), testBars: Math.min(96, Math.max(8, Math.floor(persistedSeries.candles.length / 12))), startingEquity: 100_000, feeBps: 10, slippageBps: 5 });
    const forwardWinRatePct = forwardPaper.fills ? Number((forwardPaper.events.filter((item) => item.type === "JOURNAL" && Number(item.payload.realizedPnl ?? 0) > 0).length / forwardPaper.fills * 100).toFixed(2)) : 0;
    comparison = compareForwardToBacktest({ symbol: persistedSeries.symbol, interval: persistedSeries.interval, manifestChecksum: persistedSeries.checksum, backtest: { trades: backtest.trades, winRatePct: backtest.outOfSampleWinRatePct, realizedPnl: backtest.realizedPnl, expectancy: backtest.expectancy, maxDrawdownPct: backtest.maxDrawdownPct }, forward: { trades: forwardPaper.fills, winRatePct: forwardWinRatePct, realizedPnl: forwardPaper.realizedPnl, expectancy: forwardPaper.fills ? Number((forwardPaper.realizedPnl / forwardPaper.fills).toFixed(4)) : 0, maxDrawdownPct: forwardPaper.maxDrawdownPct } });
  }
  const db = await getDb();
  if (!db) return { state, persisted: false, reason: "database-unavailable" };
  const overview = getPaperOverview(input.baseTimeframe);
  const sessionId = await getOrCreatePaperSession(input.userId, overview);
  if (!sessionId) return { state, persisted: false, reason: "session-create-failed" };
  const forwardPersisted = forwardPaper && comparison ? await persistForwardPaperSession(input.userId, forwardPaper, `${manifest.source}:${manifest.checksum}`, state.correlationId, comparison) : undefined;
  for (const item of state.events) {
    await db.insert(paperWorkflowEvents).values({ sessionId, eventId: item.eventId, idempotencyKey: `${input.userId}:${item.eventId}`, correlationId: item.correlationId, causationId: item.causationId, stage: item.stage, eventType: item.type, instrument: item.symbol, payloadJson: JSON.stringify(item.payload), provenance: `${manifest.source}:${manifest.checksum}`, occurredAt: new Date(item.occurredAt) }).onDuplicateKeyUpdate({ set: { eventId: item.eventId } });
  }
  return { state, persisted: true, sessionId, ...(forwardPaper ? { forwardPaper, comparison, forwardPersisted } : {}) };
}
