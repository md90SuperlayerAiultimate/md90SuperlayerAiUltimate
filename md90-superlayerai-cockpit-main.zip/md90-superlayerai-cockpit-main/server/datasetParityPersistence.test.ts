import { beforeEach, describe, expect, it, vi } from "vitest";

const { getDbMock, storageGetSignedUrlMock, fetchMock } = vi.hoisted(() => ({
  getDbMock: vi.fn(),
  storageGetSignedUrlMock: vi.fn(),
  fetchMock: vi.fn(),
}));
vi.mock("./db", () => ({ getDb: getDbMock }));
vi.mock("./storage", () => ({ storageGetSignedUrl: storageGetSignedUrlMock, storagePut: vi.fn() }));
vi.stubGlobal("fetch", fetchMock);

describe("persisted dataset parity loader", () => {
  beforeEach(() => {
    getDbMock.mockReset(); storageGetSignedUrlMock.mockReset(); fetchMock.mockReset();
  });

  it("reads only a user-scoped manifest and validates object checksum", async () => {
    const checksum = "a".repeat(64);
    getDbMock.mockResolvedValue({ select: () => ({ from: () => ({ where: () => ({ limit: async () => [{ id: 7, userId: 42, checksum, storageKey: "datasets/42/a.json" }] }) }) }) });
    storageGetSignedUrlMock.mockResolvedValue("https://signed.test/datasets/42/a.json");
    fetchMock.mockResolvedValue({ ok: true, json: async () => ({ symbol: "EURUSD", interval: "15m", venue: "DUKASCOPY_FILE", checksum, candles: [{ open: 1, high: 2, low: 0.5, close: 1.5, volume: 1 }, { open: 1.5, high: 2.5, low: 1, close: 2, volume: 2 }] }) });
    const { loadPersistedDatasetForParity } = await import("./datasetPersistence");
    const result = await loadPersistedDatasetForParity(42, 7);
    expect(result).toMatchObject({ status: "READY", manifest: { id: 7, userId: 42 }, series: { symbol: "EURUSD", checksum } });
    expect(storageGetSignedUrlMock).toHaveBeenCalledWith("datasets/42/a.json");
  });

  it("fails closed when the persisted object checksum differs", async () => {
    const manifestChecksum = "b".repeat(64);
    getDbMock.mockResolvedValue({ select: () => ({ from: () => ({ where: () => ({ limit: async () => [{ id: 8, userId: 42, checksum: manifestChecksum, storageKey: "datasets/42/b.json" }] }) }) }) });
    storageGetSignedUrlMock.mockResolvedValue("https://signed.test/datasets/42/b.json");
    fetchMock.mockResolvedValue({ ok: true, json: async () => ({ symbol: "XAUUSD", interval: "1m", venue: "DUKASCOPY_FILE", checksum: "c".repeat(64), candles: [{ open: 1, high: 2, low: 0.5, close: 1.5 }, { open: 1.5, high: 2.5, low: 1, close: 2 }] }) });
    const { loadPersistedDatasetForParity } = await import("./datasetPersistence");
    await expect(loadPersistedDatasetForParity(42, 8)).resolves.toMatchObject({ status: "INVALID", reason: "persisted-checksum-does-not-match-manifest" });
  });
});
