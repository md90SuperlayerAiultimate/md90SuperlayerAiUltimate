import { beforeEach, describe, expect, it, vi } from "vitest";
import { getPaperOverview } from "./paperEngine";

const getDbMock = vi.fn();
vi.mock("./db", () => ({ getDb: getDbMock }));

function createRecordingDb() {
  const writes: Array<{ table: unknown; value: unknown }> = [];
  const db = {
    select: () => ({
      from: () => ({
        where: () => ({ limit: async () => [] }),
      }),
    }),
    insert: (table: unknown) => ({
      values: (value: unknown) => {
        writes.push({ table, value });
        return {
          $returningId: async () => [{ id: 9001 }],
          onDuplicateKeyUpdate: async () => undefined,
        };
      },
    }),
  };
  return { db, writes };
}

describe("authenticated paper persistence contract", () => {
  beforeEach(() => {
    getDbMock.mockReset();
  });

  it("retries the same time bucket after a temporary database outage", async () => {
    const { db } = createRecordingDb();
    const overview = { ...getPaperOverview(), generatedAt: "2026-08-23T06:31:00.000Z" };
    getDbMock.mockResolvedValueOnce(undefined).mockResolvedValue(db);
    const { persistPaperOverview } = await import("./paperPersistence");

    await expect(persistPaperOverview(7002, overview)).resolves.toMatchObject({ persisted: false, reason: "database-unavailable" });
    await expect(persistPaperOverview(7002, overview)).resolves.toMatchObject({ persisted: true, sessionId: 9001 });
  });

  it("writes workflow events with durable correlation and idempotency keys", async () => {
    const { db, writes } = createRecordingDb();
    getDbMock.mockResolvedValue(db);
    const overview = { ...getPaperOverview(), generatedAt: "2026-08-23T06:32:00.000Z" };
    const { persistPaperWorkflowEvents } = await import("./paperPersistence");
    const result = await persistPaperWorkflowEvents(7003, overview, "WF-test-durable");
    expect(result).toMatchObject({ persisted: true, count: overview.journal.length, sessionId: 9001 });
    const eventWrites = writes.filter(({ value }) => !Array.isArray(value) && value.eventId);
    expect(eventWrites).toHaveLength(overview.journal.length);
    expect(eventWrites[0].value).toMatchObject({ correlationId: "WF-test-durable", instrument: overview.primary.market, provenance: overview.journal[0].provenance });
    expect((eventWrites[0].value as { idempotencyKey: string }).idempotencyKey).toContain("7003:WF-test-durable");
  });

  it("writes full overview collections for the authenticated user scope", async () => {
    const { db, writes } = createRecordingDb();
    getDbMock.mockResolvedValue(db);
    const overview = { ...getPaperOverview(), generatedAt: "2026-08-23T06:30:00.000Z" };

    const { persistPaperOverview } = await import("./paperPersistence");
    const result = await persistPaperOverview(7001, overview);

    expect(result).toMatchObject({ persisted: true, sessionId: 9001 });
    expect(writes.length).toBeGreaterThan(9);
    const hasValue = (predicate: (value: any) => boolean) => writes.some(({ value }) => !Array.isArray(value) && predicate(value));
    expect(hasValue((value) => value.userId === 7001 && value.mode === "paper")).toBe(true);
    expect(hasValue((value) => value.instrument === overview.primary.market && value.venue === "REPLAY")).toBe(true);
    expect(writes.some(({ value }) => Array.isArray(value) && value.length === overview.signals.length)).toBe(true);
    expect(hasValue((value) => value.clientOrderId === overview.trades[0].id && value.status === "filled")).toBe(true);
    expect(hasValue((value) => value.fillQuantity === overview.trades[0].quantity)).toBe(true);
    expect(hasValue((value) => value.instrument === overview.positions[0].instrument && value.sessionId === 9001)).toBe(true);
    expect(hasValue((value) => value.liveApproval === "locked")).toBe(true);
    expect(writes.filter(({ value }) => !Array.isArray(value) && value.event).length).toBe(overview.journal.length);
    expect(writes.filter(({ value }) => !Array.isArray(value) && value.sessionId === 9001 && typeof value.equity === "number").length).toBe(overview.equityCurve.length);
  });

  it("closes an open PAPER position with durable order, fill, journal, and workflow lineage", async () => {
    const writes: Array<{ table: unknown; value: unknown }> = [];
    const updates: unknown[] = [];
    const readQueue = [
      [{ id: 9004 }],
      [{ id: 501, sessionId: 9004, instrument: "BTC/USDT", direction: "LONG", quantity: 0.01, averageEntry: 100_000, markPrice: 100_100, unrealizedPnl: 1 }],
      [],
    ];
    const transactionMock = vi.fn();
    const db = {
      select: () => ({ from: () => ({ where: () => {
        const rows = readQueue.shift() ?? [];
        return Object.assign(Promise.resolve(rows), { limit: async () => rows });
      } }) }),
      insert: (table: unknown) => ({ values: (value: unknown) => {
        writes.push({ table, value });
        return { $returningId: async () => [{ id: 701 }], onDuplicateKeyUpdate: async () => undefined };
      } }),
      update: () => ({ set: (value: unknown) => ({ where: async () => { updates.push(value); } }) }),
    };
    transactionMock.mockImplementation(async (work) => work(db));
    Object.assign(db, { transaction: transactionMock });
    getDbMock.mockResolvedValue(db);
    const overview = { ...getPaperOverview(), generatedAt: "2026-08-23T06:33:00.000Z" };
    const { closeLatestPaperPosition } = await import("./paperPersistence");

    const result = await closeLatestPaperPosition(9004, overview, { correlationId: "close-test-1", instrument: "BTC/USDT", reason: "TIME_STOP" });

    expect(result).toMatchObject({ status: "closed", orderId: 701, positionId: 501, route: "PAPER_REPLAY_ONLY" });
    expect(writes.some(({ value }) => !Array.isArray(value) && value.clientOrderId === "close:close-test-1" && value.intent === "EXIT" && value.status === "filled")).toBe(true);
    expect(writes.some(({ value }) => !Array.isArray(value) && value.fillQuantity === 0.01)).toBe(true);
    expect(writes.some(({ value }) => !Array.isArray(value) && value.event === "PAPER_POSITION_CLOSED")).toBe(true);
    expect(writes.some(({ value }) => !Array.isArray(value) && value.eventType === "PAPER_POSITION_CLOSED" && value.correlationId === "close-test-1")).toBe(true);
    expect(updates).toContainEqual(expect.objectContaining({ quantity: 0, unrealizedPnl: 0 }));
    expect(transactionMock).toHaveBeenCalledTimes(1);
  });
});
