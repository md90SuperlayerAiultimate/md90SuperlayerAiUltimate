import { loadPersistedDatasetForParity } from "./datasetPersistence";
import { runStrategyAdapterReplay, buildStrategyAdapterAttribution } from "@shared/strategyAdapterReplay";
import { strategyAdapterRegistry } from "@shared/strategyAdapters";

export async function runPersistedStrategyAdapterComparison(userId: number, input: { ingestionIds: number[]; trainBars: number; testBars: number; startingEquity: number; feeBps: number; slippageBps: number }) {
  const uniqueIds = Array.from(new Set(input.ingestionIds)).slice(0, 5);
  const datasets = await Promise.all(uniqueIds.map((ingestionId) => loadPersistedDatasetForParity(userId, ingestionId)));
  const results = datasets.map((loaded, index) => {
    if (loaded.status !== "READY") return { ingestionId: uniqueIds[index], status: loaded.status, reason: loaded.reason };
    const adapterResults = strategyAdapterRegistry.map((adapter) => runStrategyAdapterReplay(loaded.series.candles ?? [], adapter, input));
    return { ingestionId: uniqueIds[index], status: "READY" as const, symbol: loaded.series.symbol, interval: loaded.series.interval, checksum: loaded.series.checksum, coverageClass: loaded.manifest.coverageClass, evidenceState: loaded.manifest.evidenceState, sourceTimestamp: loaded.manifest.sourceTimestamp, limitation: loaded.manifest.limitation, adapters: adapterResults, attribution: buildStrategyAdapterAttribution(adapterResults) };
  });
  return { status: "READY" as const, mode: "PAPER_ADAPTER_REPLAY" as const, authority: "PAPER_ONLY" as const, orderRoute: "DISABLED" as const, results, note: "Adapter comparison is evidence-bound to persisted user-scoped datasets; no adapter has live authority or automatic promotion." };
}
