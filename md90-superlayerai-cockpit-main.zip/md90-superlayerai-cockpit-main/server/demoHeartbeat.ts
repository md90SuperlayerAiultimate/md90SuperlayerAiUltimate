import { runDemoBatch } from "./demoPersistence";

export async function executeDemoHeartbeat(
  user: { isCron?: boolean; taskUid?: string },
  executedAt = new Date()
) {
  if (!user.isCron || !user.taskUid) return { httpStatus: 403 as const, error: "cron-only" as const };
  const result = await runDemoBatch(executedAt);
  return { httpStatus: 200 as const, ok: true as const, taskUid: user.taskUid, ...result };
}
