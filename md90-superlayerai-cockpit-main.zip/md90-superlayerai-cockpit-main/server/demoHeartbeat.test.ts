import { describe, expect, it, vi } from "vitest";

const { runDemoBatch } = vi.hoisted(() => ({ runDemoBatch: vi.fn() }));
vi.mock("./demoPersistence", () => ({ runDemoBatch }));

import { executeDemoHeartbeat } from "./demoHeartbeat";

describe("demo heartbeat boundary", () => {
  it("rejects a non-cron caller before touching the simulator", async () => {
    runDemoBatch.mockReset();
    await expect(executeDemoHeartbeat({ isCron: false }, new Date("2026-08-23T07:00:00.000Z"))).resolves.toEqual({ httpStatus: 403, error: "cron-only" });
    expect(runDemoBatch).not.toHaveBeenCalled();
  });

  it("runs only for a cron identity and forwards the batch result", async () => {
    runDemoBatch.mockResolvedValue({ status: "completed", batchId: "demo-1", tradeCount: 8 });
    await expect(executeDemoHeartbeat({ isCron: true, taskUid: "task-demo-1" }, new Date("2026-08-23T07:00:00.000Z"))).resolves.toMatchObject({ httpStatus: 200, ok: true, taskUid: "task-demo-1", tradeCount: 8 });
    expect(runDemoBatch).toHaveBeenCalledOnce();
  });
});
