import { describe, expect, it } from "vitest";
import { uiCopy } from "@shared/i18n";
import { overviewPersistenceKey, shouldPersistOverview } from "./paperPersistence";

describe("platform contracts", () => {
  it("deduplicates repeated overview writes within the same minute", () => {
    const generatedAt = "2026-08-23T06:06:00.000Z";
    expect(overviewPersistenceKey(99, generatedAt)).toBe("99:2026-08-23T06:06");
    expect(shouldPersistOverview(99, generatedAt)).toBe(true);
    expect(shouldPersistOverview(99, generatedAt)).toBe(false);
  });

  it("keeps required terminal labels in both locales", () => {
    const required = ["workspace", "signalRoom", "paperEngine", "riskGate", "news", "shadowFeed", "orderDisabled"] as const;
    for (const locale of ["ID", "EN"] as const) for (const key of required) expect(uiCopy[locale][key]).toBeTruthy();
  });
});
