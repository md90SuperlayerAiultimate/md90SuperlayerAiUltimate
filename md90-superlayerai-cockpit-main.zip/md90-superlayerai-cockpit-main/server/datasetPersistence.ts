import { and, desc, eq } from "drizzle-orm";
import { datasetIngestions } from "../drizzle/schema";
import type { PublicHistoricalSeries } from "./publicHistory";
import type { ExternalHistoricalSeries } from "./manualDataset";
import { getDb } from "./db";
import { storageGetSignedUrl, storagePut } from "./storage";
import { assessDatasetCoverage } from "@shared/datasetCoverage";

type PersistableDatasetSeries = PublicHistoricalSeries | ExternalHistoricalSeries;

export function externalDatasetKey(series: PersistableDatasetSeries) {
  return `${series.venue}:${series.symbol}:${series.interval}:${series.checksum}`;
}

export async function persistExternalDataset(userId: number, series: PersistableDatasetSeries) {
  const db = await getDb();
  if (!db) return { persisted: false as const, reason: "database-unavailable" as const };
  const datasetKey = externalDatasetKey(series);
  const existing = await db.select().from(datasetIngestions).where(and(eq(datasetIngestions.userId, userId), eq(datasetIngestions.datasetKey, datasetKey))).limit(1);
  if (existing[0]) return { persisted: false as const, reason: "already-ingested" as const, ingestion: existing[0] };
  const first = series.candles[0];
  const last = series.candles.at(-1);
  if (!first || !last) return { persisted: false as const, reason: "empty-series" as const };
  const coverage = assessDatasetCoverage(series.candles);
  const object = await storagePut(`datasets/${userId}/${series.symbol}-${series.interval}-${series.checksum}.json`, JSON.stringify(series), "application/json");
  const limitation = `SHADOW_EXTERNAL only; ${coverage.classification} coverage / ${coverage.evaluationState}; ${coverage.reason} Source observation is not canonical paper replay and has no execution authority.`;
  const values = {
    userId,
    datasetKey,
    source: series.venue,
    mode: series.mode,
    symbol: series.symbol,
    interval: series.interval,
    coverageStart: new Date(first.openedAt),
    coverageEnd: new Date(last.closedAt),
    barCount: series.candles.length,
    coverageClass: coverage.classification,
    evidenceState: (coverage.evaluationState === "REVIEW_READY" ? "READY" : "EVIDENCE_REQUIRED") as "READY" | "EVIDENCE_REQUIRED",
    checksum: series.checksum,
    storageKey: object.key,
    storageUrl: object.url,
    sourceTimestamp: new Date(series.sourceTimestamp),
    fetchedAt: new Date(series.receivedAt),
    status: "READY" as const,
    limitation,
  };
  const inserted = await db.insert(datasetIngestions).values(values).$returningId();
  return { persisted: true as const, ingestionId: inserted[0]?.id ?? 0, datasetKey, storageUrl: object.url, checksum: series.checksum, barCount: series.candles.length, coverage };
}

export async function getExternalDatasetIngestions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(datasetIngestions).where(eq(datasetIngestions.userId, userId)).orderBy(desc(datasetIngestions.fetchedAt)).limit(40);
}

export async function loadPersistedDatasetForParity(userId: number, ingestionId: number) {
  const db = await getDb();
  if (!db) return { status: "UNAVAILABLE" as const, reason: "database-unavailable" as const };
  const rows = await db.select().from(datasetIngestions).where(and(eq(datasetIngestions.id, ingestionId), eq(datasetIngestions.userId, userId))).limit(1);
  const manifest = rows[0];
  if (!manifest) return { status: "NOT_FOUND" as const, reason: "user-scoped-manifest-not-found" as const };
  if (!manifest.storageKey) return { status: "INVALID" as const, reason: "manifest-has-no-storage-key" as const };
  const signedUrl = await storageGetSignedUrl(manifest.storageKey);
  const response = await fetch(signedUrl);
  if (!response.ok) return { status: "UNAVAILABLE" as const, reason: `storage-read-failed-${response.status}` as const };
  const series = await response.json() as { symbol?: string; interval?: string; venue?: string; checksum?: string; candles?: Array<{ open: number; high: number; low: number; close: number; volume?: number }> };
  if (!series.symbol || !series.interval || !series.venue || !series.checksum || !Array.isArray(series.candles) || series.candles.length < 2) return { status: "INVALID" as const, reason: "persisted-series-shape-invalid" as const };
  if (series.checksum !== manifest.checksum) return { status: "INVALID" as const, reason: "persisted-checksum-does-not-match-manifest" as const };
  return { status: "READY" as const, manifest, series };
}
