import { eq, desc } from "drizzle-orm";
import { demoAccounts, demoEquityPoints, demoRuns, demoTrades } from "../drizzle/schema";
import { getDb } from "./db";
import { calculateDemoStats, generateDemoBatch } from "./demoSimulator";

export const DEMO_ACCOUNT_SLUG = "md90-demo-paper";
const STARTING_EQUITY = 100_000;

export function buildDemoEquityPoint(accountId: number, batchId: string, executedAt: Date, equity: number, realizedPnl: number, peakEquity: number) {
  const drawdownPct = peakEquity ? Math.max(0, ((peakEquity - equity) / peakEquity) * 100) : 0;
  return { accountId, batchId, timestamp: executedAt, equity, realizedPnl, drawdownPct: Number(drawdownPct.toFixed(2)) };
}

export async function ensureDemoAccount(db: any) {
  const existing = await db.select().from(demoAccounts).where(eq(demoAccounts.slug, DEMO_ACCOUNT_SLUG)).limit(1);
  if (existing[0]) return existing[0];
  const inserted = await db.insert(demoAccounts).values({
    slug: DEMO_ACCOUNT_SLUG,
    displayName: "md90 Demo Paper Account",
    startingEquity: STARTING_EQUITY,
    equity: STARTING_EQUITY,
    peakEquity: STARTING_EQUITY,
  }).$returningId();
  return (await db.select().from(demoAccounts).where(eq(demoAccounts.id, inserted[0].id)).limit(1))[0];
}

export async function runDemoBatch(executedAt = new Date()) {
  const db = await getDb();
  if (!db) return { status: "unavailable" as const };
  const batch = generateDemoBatch(executedAt);
  const account = await ensureDemoAccount(db);
  const existingRun = await db.select().from(demoRuns).where(eq(demoRuns.batchId, batch[0].batchId.split("-").slice(0, -1).join("-") || batch[0].batchId)).limit(1);
  const runBatchId = batch[0].batchId.split("-").slice(0, -1).join("-") || batch[0].batchId;
  if (existingRun[0]) return { status: "skipped" as const, accountId: account.id, batchId: runBatchId, tradeCount: existingRun[0].tradeCount };

  await db.insert(demoTrades).values(batch.map((trade) => ({ ...trade, accountId: account.id, batchId: trade.batchId })));
  await db.insert(demoRuns).values({ accountId: account.id, batchId: runBatchId, tradeCount: batch.length, executedAt, status: "completed" });
  const allTrades = await db.select({ pnl: demoTrades.pnl, outcome: demoTrades.outcome }).from(demoTrades).where(eq(demoTrades.accountId, account.id));
  const stats = calculateDemoStats(account.startingEquity, allTrades);
  const peakEquity = Math.max(account.peakEquity, stats.equity);
  const equityPoint = buildDemoEquityPoint(account.id, runBatchId, executedAt, stats.equity, stats.realizedPnl, peakEquity);
  await db.insert(demoEquityPoints).values(equityPoint);
  await db.update(demoAccounts).set({
    equity: stats.equity,
    peakEquity,
    realizedPnl: stats.realizedPnl,
    tradeCount: stats.tradeCount,
    wins: stats.wins,
    losses: stats.losses,
    winRatePct: stats.winRatePct,
    maxDrawdownPct: equityPoint.drawdownPct,
    lastBatchId: runBatchId,
    lastRunAt: executedAt,
  }).where(eq(demoAccounts.id, account.id));
  return { status: "completed" as const, accountId: account.id, batchId: runBatchId, tradeCount: batch.length, stats };
}

export async function getDemoOverview() {
  const db = await getDb();
  if (!db) return {
    status: "unavailable" as const,
    mode: "DEMO_PAPER" as const,
    reason: "database-unavailable" as const,
    account: { slug: DEMO_ACCOUNT_SLUG, displayName: "md90 Demo Paper", startingEquity: STARTING_EQUITY, lastRunAt: null, lastBatchId: null, scheduleCronTaskUid: null },
    stats: { totalTrades: 0, tradeCount: 0, wins: 0, losses: 0, winRatePct: 0, expectancy: 0, realizedPnl: 0, equity: STARTING_EQUITY, peakEquity: STARTING_EQUITY, maxDrawdownPct: 0, targetWinRatePct: 93, sampleQuality: "INSUFFICIENT_SAMPLE" as const, orderRoute: "DISABLED" as const },
    equityCurve: [],
    trades: [],
  };
  const account = await ensureDemoAccount(db);
  const trades = await db.select().from(demoTrades).where(eq(demoTrades.accountId, account.id)).orderBy(desc(demoTrades.executedAt)).limit(100);
  const equityCurve = await db.select().from(demoEquityPoints).where(eq(demoEquityPoints.accountId, account.id)).orderBy(desc(demoEquityPoints.timestamp)).limit(100);
  const allTrades = await db.select({ pnl: demoTrades.pnl, outcome: demoTrades.outcome }).from(demoTrades).where(eq(demoTrades.accountId, account.id));
  const stats = calculateDemoStats(account.startingEquity, allTrades);
  return {
    status: "ready" as const,
    mode: "DEMO_PAPER" as const,
    account: { slug: account.slug, displayName: account.displayName, startingEquity: account.startingEquity, lastRunAt: account.lastRunAt, lastBatchId: account.lastBatchId, scheduleCronTaskUid: account.scheduleCronTaskUid },
    stats: { ...stats, peakEquity: account.peakEquity, maxDrawdownPct: account.maxDrawdownPct, orderRoute: "DISABLED" as const },
    equityCurve,
    trades,
  };
}
