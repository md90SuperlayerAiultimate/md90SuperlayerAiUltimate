import { and, desc, eq, sql } from "drizzle-orm";
import { paperCommandRuns } from "../drizzle/schema";
import { getDb } from "./db";

export type PaperCommandType = "SYNC" | "DECIDE" | "CLOSE" | "RECONCILIATION" | "DATASET_INGEST";
export type PaperCommandState = "STARTED" | "SUCCEEDED" | "FAILED" | "BLOCKED";

export function paperCommandKey(type: PaperCommandType, correlationId: string) {
  return `${type}:${correlationId}`.slice(0, 180);
}

export async function startPaperCommand(userId: number, type: PaperCommandType, correlationId: string, payload: unknown) {
  const db = await getDb();
  if (!db) return { tracked: false as const, reason: "database-unavailable" as const };
  const commandKey = paperCommandKey(type, correlationId);
  const now = new Date();
  await db.insert(paperCommandRuns).values({ userId, commandKey, commandType: type, correlationId, state: "STARTED", attempts: 1, payloadJson: JSON.stringify(payload), startedAt: now }).onDuplicateKeyUpdate({ set: { state: "STARTED", attempts: sql`${paperCommandRuns.attempts} + 1`, payloadJson: JSON.stringify(payload), resultJson: null, failureReason: null, startedAt: now, completedAt: null, updatedAt: now } });
  return { tracked: true as const, commandKey };
}

export async function finishPaperCommand(userId: number, type: PaperCommandType, correlationId: string, state: Exclude<PaperCommandState, "STARTED">, result: unknown, failureReason?: string) {
  const db = await getDb();
  if (!db) return { tracked: false as const, reason: "database-unavailable" as const };
  const now = new Date();
  const commandKey = paperCommandKey(type, correlationId);
  await db.update(paperCommandRuns).set({ state, resultJson: JSON.stringify(result), failureReason: failureReason ?? null, completedAt: now }).where(and(eq(paperCommandRuns.userId, userId), eq(paperCommandRuns.commandKey, commandKey)));
  return { tracked: true as const, commandKey, state };
}

export async function getPaperCommandRuns(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(paperCommandRuns).where(eq(paperCommandRuns.userId, userId)).orderBy(desc(paperCommandRuns.startedAt)).limit(60);
}

export async function getPaperCommandRun(userId: number, commandRunId: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(paperCommandRuns).where(and(eq(paperCommandRuns.userId, userId), eq(paperCommandRuns.id, commandRunId))).limit(1);
  return rows[0] ?? null;
}
