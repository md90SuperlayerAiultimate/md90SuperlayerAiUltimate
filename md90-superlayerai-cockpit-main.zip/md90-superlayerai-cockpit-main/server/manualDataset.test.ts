import { describe, expect, it } from "vitest";
import { normalizeManualHistoricalDataset } from "./manualDataset";

describe("manual FX/XAU dataset normalizer", () => {
  it("normalizes an auditable EURUSD CSV dataset without execution authority", () => {
    const series = normalizeManualHistoricalDataset({
      source: "DUKASCOPY_FILE", symbol: "EURUSD", interval: "15m", format: "CSV", now: 1_700_100_000_000,
      contents: "timestamp,open,high,low,close,volume\n1700100000000,1.0800,1.0810,1.0790,1.0805,140\n1700100900000,1.0805,1.0820,1.0800,1.0815,120",
    });
    expect(series).toMatchObject({ venue: "DUKASCOPY_FILE", symbol: "EURUSD", mode: "SHADOW_EXTERNAL", orderRoute: "DISABLED" });
    expect(series.candles).toHaveLength(2);
    expect(series.checksum).toHaveLength(24);
  });

  it("accepts the official Dukascopy UTC CSV header and derives interval-close time", () => {
    const series = normalizeManualHistoricalDataset({
      source: "DUKASCOPY_FILE", symbol: "EURUSD", interval: "1m", format: "CSV", now: Date.parse("2026-08-25T00:02:00+00:00"),
      contents: "Etc/UTC,Open,High,Low,Close,Volume\n2026-08-25T00:00:00+00:00,1.16679,1.16695,1.16675,1.1669,177750000\n2026-08-25T00:01:00+00:00,1.16689,1.16701,1.16689,1.1669,147240000",
    });
    expect(series.candles[0]).toMatchObject({ openedAt: Date.parse("2026-08-25T00:00:00+00:00"), closedAt: Date.parse("2026-08-25T00:01:00+00:00") });
    expect(series.candles[1]?.volume).toBe(147240000);
    expect(series.orderRoute).toBe("DISABLED");
  });

  it("normalizes the verified XAUUSD Dukascopy CSV shape without changing evidence-only authority", () => {
    const series = normalizeManualHistoricalDataset({
      source: "DUKASCOPY_FILE", symbol: "XAUUSD", interval: "1m", format: "CSV", now: Date.parse("2026-08-25T00:02:00+00:00"),
      contents: "Etc/UTC,Open,High,Low,Close,Volume\n2026-08-25T00:00:00+00:00,4679.875,4688.965,4678.565,4688.255,43500\n2026-08-25T00:01:00+00:00,4688.165,4688.955,4684.505,4684.705,27750",
    });
    expect(series).toMatchObject({ venue: "DUKASCOPY_FILE", symbol: "XAUUSD", interval: "1m", orderRoute: "DISABLED" });
    expect(series.candles).toHaveLength(2);
  });

  it("supports the added intraday intervals without changing evidence-only authority", () => {
    const series = normalizeManualHistoricalDataset({
      source: "OPERATOR_UPLOAD", symbol: "EURUSD", interval: "30m", format: "JSON", now: 1_700_100_000_000,
      contents: JSON.stringify([
        { timestamp: 1_700_100_000_000, open: 1.08, high: 1.081, low: 1.079, close: 1.0805, volume: 10 },
        { timestamp: 1_700_101_800_000, open: 1.0805, high: 1.082, low: 1.08, close: 1.0815, volume: 12 },
      ]),
    });
    expect(series.interval).toBe("30m");
    expect(series.candles[0]?.closedAt).toBe(1_700_101_800_000);
    expect(series.orderRoute).toBe("DISABLED");
  });

  it("requires explicit calendar closes for monthly candles", () => {
    expect(() => normalizeManualHistoricalDataset({
      source: "OPERATOR_UPLOAD", symbol: "XAUUSD", interval: "1M", format: "JSON", contents: JSON.stringify([
        { timestamp: 1_700_100_000_000, open: 2000, high: 2002, low: 1998, close: 2001, volume: 5 },
        { timestamp: 1_702_692_000_000, open: 2001, high: 2003, low: 1999, close: 2002, volume: 6 },
      ]),
    })).toThrow("Monthly candles require an explicit close timestamp");

    const series = normalizeManualHistoricalDataset({
      source: "OPERATOR_UPLOAD", symbol: "XAUUSD", interval: "1M", format: "JSON", contents: JSON.stringify([
        { timestamp: 1_700_100_000_000, closedAt: 1_702_692_000_000, open: 2000, high: 2002, low: 1998, close: 2001, volume: 5 },
        { timestamp: 1_702_692_000_001, closedAt: 1_705_370_400_000, open: 2001, high: 2003, low: 1999, close: 2002, volume: 6 },
      ]),
    });
    expect(series.interval).toBe("1M");
  });

  it("rejects missing volume and invalid XAUUSD OHLC instead of filling fake values", () => {
    expect(() => normalizeManualHistoricalDataset({ source: "OPERATOR_UPLOAD", symbol: "XAUUSD", interval: "1h", format: "JSON", contents: JSON.stringify([{ timestamp: 1_700_100_000_000, open: 2000, high: 1999, low: 1998, close: 1999, volume: 5 }]) })).toThrow("Invalid uploaded OHLC relationship");
    expect(() => normalizeManualHistoricalDataset({ source: "OPERATOR_UPLOAD", symbol: "XAUUSD", interval: "1h", format: "JSON", contents: JSON.stringify([{ timestamp: 1_700_100_000_000, open: 2000, high: 2002, low: 1998, close: 2001 }]) })).toThrow("Invalid volume");
  });
});
