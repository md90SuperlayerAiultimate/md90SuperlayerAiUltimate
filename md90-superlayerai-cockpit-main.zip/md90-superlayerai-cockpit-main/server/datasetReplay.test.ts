import { describe, expect, it } from "vitest";
import { runDatasetReplay } from "./datasetReplay";

function candles(count: number) {
  return Array.from({ length: count }, (_, index) => {
    const close = 100 + index * 0.2 + (index % 11 === 0 ? 0.4 : 0);
    return { timestamp: index * 900_000, open: close - 0.1, high: close + 0.25, low: close - 0.25, close, volume: 1000 + index };
  });
}

describe("dataset cohort replay", () => {
  it("produces persisted-dataset OOS metrics with explicit costs and disabled authority", () => {
    const result = runDatasetReplay(candles(768), { trainBars: 240, testBars: 96, startingEquity: 100_000, feeBps: 10, slippageBps: 5 });
    expect(result.mode).toBe("PAPER_DATASET_REPLAY");
    expect(result.bars).toBe(768);
    expect(result.trades).toBeGreaterThan(0);
    expect(result.wins + result.losses + result.flats).toBe(result.trades);
    expect(result.equityCurve.length).toBe(result.trades + 1);
    expect(result.feeBps).toBe(10);
    expect(result.slippageBps).toBe(5);
    expect(result.attribution.longTrades + result.attribution.shortTrades).toBe(result.trades);
    expect(result.orderRoute).toBe("DISABLED");
    expect(result.executionAuthority).toBe("DISABLED");
  });

  it("does not invent a cohort when the dataset cannot fit one complete window", () => {
    const result = runDatasetReplay(candles(64), { trainBars: 240, testBars: 96 });
    expect(result.trades).toBe(0);
    expect(result.outOfSampleWinRatePct).toBe(0);
    expect(result.realizedPnl).toBe(0);
    expect(result.targetStatus).toBe("TRACKING");
  });
});
