import { describe, expect, it } from "vitest";
import { auditBundleCsv, auditBundleJson } from "./auditBundle";

describe("audit bundle serialization", () => {
  const bundle = { datasets: [{ id: 1, symbol: "EURUSD", status: "READY", checksum: "a".repeat(64), note: "source, official" }], parity: [], replays: [], attribution: [], events: [], journals: [], authority: "PAPER_SHADOW_ONLY", orderRoute: "DISABLED" };
  it("serializes JSON with safety markers", () => {
    const json = auditBundleJson(bundle);
    expect(json).toContain("PAPER_SHADOW_ONLY");
    expect(json).toContain("DISABLED");
    expect(json).not.toMatch(/privateKey|secret|apiKey/i);
  });
  it("escapes CSV payload JSON deterministically", () => {
    const csv = auditBundleCsv(bundle);
    expect(csv.split("\n")[0]).toContain("payload_json");
    expect(csv).toContain('"{""id"":1');
    expect(csv).toContain("source, official");
  });
});
