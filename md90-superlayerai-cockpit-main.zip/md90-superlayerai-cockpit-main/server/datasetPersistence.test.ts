import { beforeEach, describe, expect, it, vi } from "vitest";
import { normalizeBinancePublicKlines } from "./publicHistory";

const { getDbMock, storagePutMock } = vi.hoisted(() => ({ getDbMock: vi.fn(), storagePutMock: vi.fn() }));
vi.mock("./db", () => ({ getDb: getDbMock }));
vi.mock("./storage", () => ({ storagePut: storagePutMock }));

describe("external dataset manifest contract", () => {
  beforeEach(() => {
    getDbMock.mockReset();
    storagePutMock.mockReset();
  });
  it("creates a stable user-scoped ingestion key from validated source, symbol, interval, and checksum", async () => {
    const series = normalizeBinancePublicKlines([[1, "10", "11", "9", "10", "1", 2]], "BTCUSDT", "15m", 3, 3);
    const { externalDatasetKey } = await import("./datasetPersistence");
    const key = externalDatasetKey(series);
    expect(key).toContain("BINANCE_PUBLIC:BTCUSDT:15m:");
    expect(key).toContain(series.checksum);
  });

  it("persists only a storage pointer and source manifest for the authenticated user", async () => {
    const writes: unknown[] = [];
    const db = {
      select: () => ({ from: () => ({ where: () => ({ limit: async () => [] }) }) }),
      insert: () => ({ values: (value: unknown) => { writes.push(value); return { $returningId: async () => [{ id: 44 }] }; } }),
    };
    getDbMock.mockResolvedValue(db);
    storagePutMock.mockResolvedValue({ key: "datasets/44/btc.json", url: "/manus-storage/datasets/44/btc.json" });
    const series = normalizeBinancePublicKlines([[1, "10", "11", "9", "10", "1", 2]], "BTCUSDT", "15m", 3, 3);
    const { persistExternalDataset } = await import("./datasetPersistence");

    const result = await persistExternalDataset(44, series);

    expect(result).toMatchObject({ persisted: true, ingestionId: 44, barCount: 1, storageUrl: "/manus-storage/datasets/44/btc.json" });
    expect(storagePutMock).toHaveBeenCalledWith(expect.stringContaining("datasets/44/BTCUSDT-15m"), expect.any(String), "application/json");
    expect(writes[0]).toMatchObject({ userId: 44, source: "BINANCE_PUBLIC", mode: "SHADOW_EXTERNAL", symbol: "BTCUSDT", barCount: 1, storageKey: "datasets/44/btc.json" });
  });
});
