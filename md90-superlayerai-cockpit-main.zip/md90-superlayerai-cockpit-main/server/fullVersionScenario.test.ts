import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const { persistPaperOverviewMock, persistShadowAndNewsMock, persistPaperWorkflowEventsMock, upsertReconciliationExceptionMock } = vi.hoisted(() => ({
  persistPaperOverviewMock: vi.fn().mockResolvedValue({ persisted: true, sessionId: 9200 }),
  persistShadowAndNewsMock: vi.fn().mockResolvedValue({ persisted: true }),
  persistPaperWorkflowEventsMock: vi.fn().mockResolvedValue({ persisted: true, count: 3, sessionId: 9200 }),
  upsertReconciliationExceptionMock: vi.fn().mockResolvedValue({ persisted: true, created: false, id: 1 }),
}));
vi.mock("./paperPersistence", () => ({ persistPaperOverview: persistPaperOverviewMock, persistShadowAndNews: persistShadowAndNewsMock, persistPaperWorkflowEvents: persistPaperWorkflowEventsMock, upsertReconciliationException: upsertReconciliationExceptionMock }));

const user = { id: 8801, openId: "scenario-user", name: "Scenario Analyst", email: "scenario@example.test", loginMethod: "oauth", role: "user" as const, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() };
const context = (authenticated: boolean): TrpcContext => ({ user: authenticated ? user : null, req: { protocol: "https", headers: {} } as TrpcContext["req"], res: {} as TrpcContext["res"] });

describe("full-version All-in-one scenario", () => {
  it("links context, evidence, risk, paper decision, fill and reconciliation", async () => {
    const caller = appRouter.createCaller(context(true));
    const snapshot = await caller.cockpit.snapshot({ symbol: "BTCUSDT", timeframe: "15m", htf: "4h" });
    expect(snapshot.timeframe).toMatchObject({ base: "15m", htf: "4h", symbol: "BINANCE:BTCUSDT" });
    expect(snapshot.workflow.events.map((event) => event.stage)).toEqual(["SOURCE", "CONFLUENCE", "RISK_GATE", "PAPER_FILL", "JOURNAL"]);
    expect(snapshot.execution).toMatchObject({ state: "RECONCILED", orderRoute: "PAPER", liveRoute: "LIVE_PENDING_APPROVAL", custody: "DISABLED" });
    const decision = await caller.paper.decide({ symbol: "BTCUSDT", timeframe: "15m", htf: "4h", riskPct: 0.5 });
    expect(decision).toMatchObject({ status: "recorded", riskPct: 0.5 });
    expect(persistPaperOverviewMock).toHaveBeenCalledWith(8801, expect.objectContaining({ mode: "PAPER" }));
    expect(persistPaperWorkflowEventsMock).toHaveBeenCalled();
  }, 15_000);

  it("blocks missing replay datasets and anonymous paper execution", async () => {
    const authenticated = appRouter.createCaller(context(true));
    const shadowOnly = await authenticated.cockpit.snapshot({ symbol: "EURUSD", timeframe: "15m", htf: "4h" });
    expect(shadowOnly).toMatchObject({ paper: null, paperAvailability: { status: "PENDING_DATASET", source: "SHADOW_ONLY" }, execution: { state: "BLOCKED", orderRoute: "DISABLED" } });
    await expect(authenticated.paper.decide({ symbol: "EURUSD", riskPct: 0.5 })).resolves.toMatchObject({ status: "blocked" });
    await expect(appRouter.createCaller(context(false)).paper.decide({ symbol: "BTCUSDT", riskPct: 0.5 })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  }, 15_000);
});
