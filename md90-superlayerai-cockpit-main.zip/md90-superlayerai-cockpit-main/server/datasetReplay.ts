export type ReplayCandle = {
  timestamp?: string | number;
  openedAt?: string | number;
  closedAt?: string | number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
};

export type DatasetReplayParams = {
  trainBars: number;
  testBars: number;
  startingEquity?: number;
  feeBps?: number;
  slippageBps?: number;
};

export function runDatasetReplay(candles: ReplayCandle[], params: DatasetReplayParams) {
  const trainBars = Math.max(32, Math.floor(params.trainBars));
  const testBars = Math.max(8, Math.floor(params.testBars));
  const startingEquity = params.startingEquity ?? 100_000;
  const feeBps = params.feeBps ?? 10;
  const slippageBps = params.slippageBps ?? 5;
  const windows: Array<Record<string, unknown>> = [];
  const equityCurve = [{ index: 0, equity: startingEquity, drawdownPct: 0 }];
  let equity = startingEquity;
  let peak = startingEquity;

  for (let cursor = 0; cursor + trainBars + testBars <= candles.length; cursor += testBars) {
    const train = candles.slice(cursor, cursor + trainBars);
    const test = candles.slice(cursor + trainBars, cursor + trainBars + testBars);
    const trainStart = train[0];
    const trainEnd = train.at(-1);
    const testStart = test[0];
    const testEnd = test.at(-1);
    if (!trainStart || !trainEnd || !testStart || !testEnd || trainStart.close <= 0 || trainEnd.close <= 0 || testStart.close <= 0 || testEnd.close <= 0) continue;
    const direction = trainEnd.close >= trainStart.close ? "LONG" : "SHORT";
    const grossReturn = direction === "LONG" ? testEnd.close / testStart.close - 1 : testStart.close / testEnd.close - 1;
    const roundTripCost = (feeBps + slippageBps) * 2 / 10_000;
    const netReturn = grossReturn - roundTripCost;
    const pnl = Number((equity * 0.03 * netReturn).toFixed(2));
    equity = Number((equity + pnl).toFixed(2));
    peak = Math.max(peak, equity);
    const drawdownPct = Number(((peak - equity) / peak * 100).toFixed(4));
    equityCurve.push({ index: cursor + trainBars + testBars, equity, drawdownPct });
    windows.push({
      trainStart: cursor,
      trainEnd: cursor + trainBars,
      testStart: cursor + trainBars,
      testEnd: cursor + trainBars + testBars,
      direction,
      trainReturnPct: Number(((trainEnd.close / trainStart.close - 1) * 100).toFixed(4)),
      testReturnPct: Number(((testEnd.close / testStart.close - 1) * 100).toFixed(4)),
      netReturnBps: Number((netReturn * 10_000).toFixed(4)),
      pnl,
      outcome: pnl > 0 ? "WIN" : pnl < 0 ? "LOSS" : "FLAT",
      testTimestamp: testEnd.closedAt ?? testEnd.timestamp ?? testEnd.openedAt ?? null,
    });
  }

  const trades = windows.length;
  const wins = windows.filter((window) => window.outcome === "WIN").length;
  const losses = windows.filter((window) => window.outcome === "LOSS").length;
  const realizedPnl = Number((equity - startingEquity).toFixed(2));
  const expectancy = trades ? Number((realizedPnl / trades).toFixed(2)) : 0;
  const maxDrawdownPct = Number(Math.max(0, ...equityCurve.map((point) => point.drawdownPct)).toFixed(4));
  const longTrades = windows.filter((window) => window.direction === "LONG").length;
  const shortTrades = windows.filter((window) => window.direction === "SHORT").length;
  const first = candles[0];
  const last = candles.at(-1);
  return {
    mode: "PAPER_DATASET_REPLAY" as const,
    strategyVersion: "trend-window-v1",
    bars: candles.length,
    trainBars,
    testBars,
    feeBps,
    slippageBps,
    trades,
    wins,
    losses,
    flats: trades - wins - losses,
    outOfSampleWinRatePct: trades ? Number((wins / trades * 100).toFixed(2)) : 0,
    realizedPnl,
    expectancy,
    maxDrawdownPct,
    equityCurve,
    windows,
    attribution: { longTrades, shortTrades, longSharePct: trades ? Number((longTrades / trades * 100).toFixed(2)) : 0 },
    coverage: { start: first ? first.openedAt ?? first.timestamp ?? null : null, end: last ? last.closedAt ?? last.timestamp ?? last.openedAt ?? null : null },
    targetWinRatePct: 93,
    targetStatus: "TRACKING" as const,
    source: "Persisted user-scoped external dataset",
    orderRoute: "DISABLED" as const,
    executionAuthority: "DISABLED" as const,
  };
}
