import { createHash } from "node:crypto";

export type PublicHistoricalCandle = {
  openedAt: number;
  closedAt: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
};

export type PublicHistoricalSeries = {
  venue: "BINANCE_PUBLIC";
  mode: "SHADOW_EXTERNAL";
  symbol: string;
  interval: string;
  candles: PublicHistoricalCandle[];
  sourceTimestamp: number;
  receivedAt: number;
  checksum: string;
  freshnessSeconds: number;
  provenance: string;
  orderRoute: "DISABLED";
};

const BINANCE_PUBLIC_BASE = "https://data-api.binance.vision";
const SUPPORTED_INTERVALS = new Set(["1m", "5m", "15m", "1h", "4h", "1d"]);

function normalizeSymbol(symbol: string) {
  const normalized = symbol.trim().toUpperCase();
  if (!/^[A-Z0-9]{5,20}$/.test(normalized)) throw new Error("Invalid historical market symbol");
  return normalized;
}

function normalizeInterval(interval: string) {
  const normalized = interval.trim();
  if (!SUPPORTED_INTERVALS.has(normalized)) throw new Error("Unsupported historical interval");
  return normalized;
}

function asFiniteNumber(value: unknown, label: string) {
  const number = Number(value);
  if (!Number.isFinite(number) || number < 0) throw new Error(`Invalid historical ${label}`);
  return number;
}

export function normalizeBinancePublicKlines(payload: unknown, symbol: string, interval: string, receivedAt = Date.now(), sourceTimestamp = receivedAt): PublicHistoricalSeries {
  if (!Array.isArray(payload) || payload.length === 0) throw new Error("Historical series is empty");
  const normalizedSymbol = normalizeSymbol(symbol);
  const normalizedInterval = normalizeInterval(interval);
  const candles = payload.map((row) => {
    if (!Array.isArray(row) || row.length < 7) throw new Error("Invalid historical candle row");
    const openedAt = asFiniteNumber(row[0], "open time");
    const open = asFiniteNumber(row[1], "open");
    const high = asFiniteNumber(row[2], "high");
    const low = asFiniteNumber(row[3], "low");
    const close = asFiniteNumber(row[4], "close");
    const volume = asFiniteNumber(row[5], "volume");
    const closedAt = asFiniteNumber(row[6], "close time");
    if (openedAt >= closedAt || low > high || open < low || open > high || close < low || close > high) throw new Error("Invalid historical OHLC relationship");
    return { openedAt, closedAt, open, high, low, close, volume };
  });
  for (let index = 1; index < candles.length; index += 1) {
    if (candles[index - 1]!.openedAt >= candles[index]!.openedAt) throw new Error("Historical candles are not ascending");
  }
  const checksum = createHash("sha256").update(JSON.stringify(candles)).digest("hex").slice(0, 24);
  return {
    venue: "BINANCE_PUBLIC",
    mode: "SHADOW_EXTERNAL",
    symbol: normalizedSymbol,
    interval: normalizedInterval,
    candles,
    sourceTimestamp,
    receivedAt,
    checksum,
    freshnessSeconds: Math.max(0, Math.floor((receivedAt - sourceTimestamp) / 1000)),
    provenance: "binance-data-api public klines; observation-only",
    orderRoute: "DISABLED",
  };
}

export async function fetchBinancePublicHistory(symbol: string, interval: string, limit = 120, fetchImpl: typeof fetch = fetch, now = Date.now(), timeoutMs = 5_000) {
  const normalizedSymbol = normalizeSymbol(symbol);
  const normalizedInterval = normalizeInterval(interval);
  const normalizedLimit = Math.max(10, Math.min(300, Math.floor(limit)));
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetchImpl(`${BINANCE_PUBLIC_BASE}/api/v3/klines?symbol=${encodeURIComponent(normalizedSymbol)}&interval=${encodeURIComponent(normalizedInterval)}&limit=${normalizedLimit}`, { signal: controller.signal });
    if (!response.ok) throw new Error(`Historical HTTP ${response.status}`);
    const headerTime = response.headers.get("date");
    const sourceTimestamp = headerTime && Number.isFinite(Date.parse(headerTime)) ? Date.parse(headerTime) : now;
    return normalizeBinancePublicKlines(await response.json(), normalizedSymbol, normalizedInterval, now, sourceTimestamp);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Historical request failed";
    throw new Error(`BINANCE_PUBLIC_HISTORY_BLOCKED: ${message}`);
  } finally {
    clearTimeout(timeout);
  }
}
