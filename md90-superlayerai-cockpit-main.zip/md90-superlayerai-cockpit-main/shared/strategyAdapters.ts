export type StrategyEvidenceState = "REFERENCE_ONLY" | "PAPER_CANDIDATE" | "CERTIFIED_PAPER";
export type AdapterSignal = "LONG" | "SHORT" | "NEUTRAL";

export type AdapterSnapshot = {
  rsi?: number;
  stochastic?: number;
  sma?: number;
  emaFast?: number;
  emaSlow?: number;
  htfEma?: number;
  macdHistogram?: number;
  atr?: number;
  atrMinimum?: number;
  volumeRatio?: number;
  close?: number;
  open?: number;
};

export type StrategyAdapter = {
  id: string;
  name: string;
  sourceClass: "PINE" | "MQL5" | "PYTHON" | "USER_PARAMETER_SET";
  provenance: string;
  sourceChecksum?: string;
  evidenceState: StrategyEvidenceState;
  authority: "PAPER_ONLY";
  parameters: Record<string, number | string | boolean>;
  evaluate(snapshot: AdapterSnapshot): { signal: AdapterSignal; gates: string[]; blockedReasons: string[]; exitPolicy: { slAtr: number; tpRr: number; timeStopBars: number; trailingAtr?: number } };
};

function direction(snapshot: AdapterSnapshot) {
  const close = snapshot.close ?? 0;
  const fast = snapshot.emaFast ?? close;
  const slow = snapshot.emaSlow ?? close;
  if (fast > slow && close >= fast) return "LONG" as const;
  if (fast < slow && close <= fast) return "SHORT" as const;
  return "NEUTRAL" as const;
}

export const fusionV9ImpAdapter: StrategyAdapter = {
  id: "fusion-v9-imp-paper",
  name: "FUSION V9-IMP · isolated PAPER adapter",
  sourceClass: "MQL5",
  provenance: "MD90_ULTIMATE_FUSION_EA_v2-1.mq5(1).txt · parameter contract; external order methods excluded",
  sourceChecksum: "0f3145deeb394bce95fa0c701ab803b5d458c2daf8ed2b546f62b83fe5564e33",
  evidenceState: "PAPER_CANDIDATE",
  authority: "PAPER_ONLY",
  parameters: { htfEmaLength: 100, emaFastLength: 12, emaSlowLength: 26, atrLength: 14, atrMinimum: 0.0001, rsiLength: 14, rsiLevel: 50, stochK: 5, stochD: 3, volumeFactor: 1.5, slAtr: 2.5, tpRr: 2, timeStopBars: 10, trailingAtr: 1.5 },
  evaluate(snapshot) {
    const gates: string[] = []; const blockedReasons: string[] = []; const dir = direction(snapshot);
    if (dir === "NEUTRAL") blockedReasons.push("EMA_DIRECTION_UNRESOLVED"); else gates.push(`EMA_${dir}`);
    if (snapshot.htfEma === undefined || snapshot.close === undefined) blockedReasons.push("HTF_OR_CLOSE_MISSING"); else if (dir === "LONG" ? snapshot.close <= snapshot.htfEma : snapshot.close >= snapshot.htfEma) blockedReasons.push("HTF_TREND_BLOCK"); else gates.push("HTF_TREND");
    if (snapshot.rsi === undefined || (dir === "LONG" ? snapshot.rsi <= 50 : snapshot.rsi >= 50)) blockedReasons.push("RSI_FILTER_BLOCK"); else gates.push("RSI");
    if (snapshot.stochastic === undefined || (dir === "LONG" ? snapshot.stochastic <= 50 : snapshot.stochastic >= 50)) blockedReasons.push("STOCH_FILTER_BLOCK"); else gates.push("STOCH");
    if (snapshot.atr === undefined || snapshot.atr < 0.0001) blockedReasons.push("ATR_MINIMUM_BLOCK"); else gates.push("ATR");
    if (snapshot.volumeRatio === undefined || snapshot.volumeRatio < 1.5) blockedReasons.push("VOLUME_FACTOR_BLOCK"); else gates.push("VOLUME");
    return { signal: blockedReasons.length ? "NEUTRAL" : dir, gates, blockedReasons, exitPolicy: { slAtr: 2.5, tpRr: 2, timeStopBars: 10, trailingAtr: 1.5 } };
  },
};

export const matariAlphaAdapter: StrategyAdapter = {
  id: "matari-alpha-paper",
  name: "Matari Candle Enhanced + Alpha · isolated PAPER adapter",
  sourceClass: "PINE",
  provenance: "User-provided indicator parameter set · source code/vector pending",
  evidenceState: "REFERENCE_ONLY",
  authority: "PAPER_ONLY",
  parameters: { rsiLength: 14, rsiMidline: 50, stochasticK: 14, stochasticD: 3, smaLength: 20, macdFast: 12, macdSlow: 26, macdSignal: 9, confluence: "FLEXIBLE", slAtr: 2, tpRr: 2 },
  evaluate(snapshot) {
    const gates: string[] = []; const blockedReasons: string[] = []; const dir = direction(snapshot);
    if (dir === "NEUTRAL") blockedReasons.push("EMA_DIRECTION_UNRESOLVED"); else gates.push(`EMA_${dir}`);
    if (snapshot.rsi === undefined || (dir === "LONG" ? snapshot.rsi <= 50 : snapshot.rsi >= 50)) blockedReasons.push("RSI_FILTER_BLOCK"); else gates.push("RSI");
    if (snapshot.stochastic === undefined || (dir === "LONG" ? snapshot.stochastic <= 50 : snapshot.stochastic >= 50)) blockedReasons.push("STOCH_FILTER_BLOCK"); else gates.push("STOCH");
    if (snapshot.sma === undefined || snapshot.close === undefined || (dir === "LONG" ? snapshot.close <= snapshot.sma : snapshot.close >= snapshot.sma)) blockedReasons.push("SMA_TREND_BLOCK"); else gates.push("SMA");
    if (snapshot.macdHistogram === undefined || (dir === "LONG" ? snapshot.macdHistogram <= 0 : snapshot.macdHistogram >= 0)) blockedReasons.push("MACD_MOMENTUM_BLOCK"); else gates.push("MACD");
    return { signal: blockedReasons.length ? "NEUTRAL" : dir, gates, blockedReasons, exitPolicy: { slAtr: 2, tpRr: 2, timeStopBars: 10 } };
  },
};

export const pythonReferenceAdapter: StrategyAdapter = {
  id: "python-omni-reference-paper",
  name: "Python Omni-source · isolated PAPER reference adapter",
  sourceClass: "PYTHON",
  provenance: "md90_refactor_v1 Python archive · static audit only; source import/execution excluded",
  evidenceState: "REFERENCE_ONLY",
  authority: "PAPER_ONLY",
  parameters: { execution: "blocked", sourceImport: false, liveRoute: false },
  evaluate() {
    return { signal: "NEUTRAL", gates: [], blockedReasons: ["PYTHON_SOURCE_REVIEW_ONLY"], exitPolicy: { slAtr: 0, tpRr: 0, timeStopBars: 0 } };
  },
};

export const fusionProAdvancedAdapter: StrategyAdapter = {
  id: "fusion-pro-advanced-paper",
  name: "FUSION_PRO_ADVANCED_V1 · isolated PAPER adapter",
  sourceClass: "MQL5",
  provenance: "pasted_content.txt re-upload · static MQL5 audit only; CTrade/timer/terminal execution excluded",
  sourceChecksum: "f15dc7188f647a62fe1790673de977c66875ba0e898bd854b31f9e2e0af97c2c",
  evidenceState: "REFERENCE_ONLY",
  authority: "PAPER_ONLY",
  parameters: { fixedLot: 0.01, tpRr: 2, slAtr: 2.5, timeStopBars: 10, trailingAtr: 1.5, htf: "H4", emaFast: 12, emaSlow: 26, atrLength: 14, rsiLevel: 50, volumeFactor: 1.5 },
  evaluate(snapshot) {
    const result = fusionV9ImpAdapter.evaluate(snapshot);
    return { ...result, exitPolicy: { slAtr: 2.5, tpRr: 2, timeStopBars: 10, trailingAtr: 1.5 } };
  },
};

export const strategyAdapterRegistry = [fusionV9ImpAdapter, matariAlphaAdapter, pythonReferenceAdapter, fusionProAdvancedAdapter] as const;
