import { describe, expect, it } from "vitest";
import { auditMultiTimeframeEvidence, type MultiTimeframeDataset } from "./multiTimeframeEvidence";
import { BASE_TIMEFRAMES } from "./timeframe";

const candle = (timestamp: string, close = 100) => ({ openedAt: timestamp, closedAt: timestamp, open: close, high: close + 1, low: close - 1, close, volume: 10 });

function dataset(interval: MultiTimeframeDataset["interval"], latestTimestamp: string, symbol = "EURUSD"): MultiTimeframeDataset {
  const step = { "1m": 60000, "3m": 180000, "5m": 300000, "15m": 900000, "30m": 1800000, "1h": 3600000, "4h": 14400000, "1d": 86400000, "1M": 2592000000 }[interval];
  const firstTimestamp = new Date(Date.parse(latestTimestamp) - step).toISOString();
  return { symbol, interval, candles: [candle(firstTimestamp), candle(latestTimestamp, 101)], source: "Dukascopy", checksum: "a".repeat(64), persisted: true };
}

describe("multi-timeframe evidence", () => {
  it("returns READY only when all canonical timeframes are persisted and aligned", () => {
    const result = auditMultiTimeframeEvidence(BASE_TIMEFRAMES.map((interval) => dataset(interval, "2026-08-30T10:00:00.000Z")), Date.parse("2026-08-30T10:30:00.000Z"));
    expect(result.status).toBe("READY");
    expect(result.reasons).toEqual([]);
    expect(result.freshnessSeconds).toBe(1800);
  });

  it("keeps partial evidence pending instead of inventing missing timeframes", () => {
    const result = auditMultiTimeframeEvidence([dataset("15m", "2026-08-30T10:00:00.000Z")], Date.parse("2026-08-30T10:30:00.000Z"));
    expect(result.status).toBe("PENDING");
    expect(result.reasons).toContain("MISSING_TIMEFRAMES:1m,3m,5m,30m,1h,4h,1d,1M");
    expect(result.intervals["4h"]).toBeNull();
  });

  it("blocks cross-symbol datasets and detects timestamp desynchronization", () => {
    const mismatch = auditMultiTimeframeEvidence([
      dataset("15m", "2026-08-30T10:00:00.000Z"),
      dataset("1h", "2026-08-30T10:00:00.000Z", "XAUUSD"),
    ]);
    expect(mismatch.status).toBe("BLOCKED");
    expect(mismatch.reasons).toContain("SYMBOL_MISMATCH");

    const desync = auditMultiTimeframeEvidence([
      dataset("15m", "2026-08-30T10:00:00.000Z"),
      dataset("1h", "2026-08-30T15:00:00.000Z"),
    ]);
    expect(desync.conflictReasons).toContain("TIMESTAMP_DESYNC:15m↔1h");
    expect(desync.reasons).toContain("MTF_CONFLICT");
  });
});
