import { describe, expect, it } from "vitest";
import { evaluateLearningEvidence } from "./learningEvidence";

describe("learning evidence contract", () => {
  it("keeps ordinary journal activity below the promotion evidence floor", () => {
    const evidence = evaluateLearningEvidence([{ event: "ORDER_FILLED" }, { event: "RISK_PASS" }]);
    expect(evidence).toMatchObject({ authority: "PROPOSAL_ONLY", status: "EVIDENCE_REQUIRED", outOfSampleGate: "PENDING", promotionRoute: "DISABLED" });
    expect(evidence.posterior).toMatchObject({ wins: 0, losses: 0, mean: 0.5, sampleGate: "PENDING" });
  });

  it("can become review-ready only after a labeled closed-sample floor", () => {
    const events = Array.from({ length: 30 }, (_, index) => ({ event: index % 2 ? "POSITION_CLOSED_PROFIT" : "ORDER_CLOSED_LOSS" }));
    expect(evaluateLearningEvidence(events)).toMatchObject({ status: "REVIEW_READY", outOfSampleGate: "PASS", promotionRoute: "DISABLED", posterior: { wins: 15, losses: 15, alpha: 16, beta: 16, mean: 0.5, sampleGate: "PASS" } });
  });
});
