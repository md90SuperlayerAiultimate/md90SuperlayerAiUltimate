import { describe, expect, it } from "vitest";
import { artifactVectorCatalog, extractSourceVectorArtifact, validateSourceVectorEvidence } from "./sourceVectorRegistry";

describe("source vector registry", () => {
  const base = { artifactName: "source.pine", artifactChecksum: "a".repeat(64), lineRange: "L10-L20", formulaVersion: "pine-v1", symbol: "XAUUSD", interval: "15m", vector: { vwap: 1.25 } };
  it("accepts complete artifact-bound evidence", () => expect(validateSourceVectorEvidence(base)).toMatchObject({ ok: true }));
  it("rejects missing source checksum and vector", () => {
    expect(validateSourceVectorEvidence({ ...base, artifactChecksum: "" })).toMatchObject({ ok: false, reason: "ARTIFACT_CHECKSUM_REQUIRED" });
    expect(validateSourceVectorEvidence({ ...base, vector: {} })).toMatchObject({ ok: false, reason: "VECTOR_REQUIRED" });
  });
});

describe("source vector artifact extraction", () => {
  it("extracts supported literals with deterministic line provenance", () => {
    const result = extractSourceVectorArtifact(["// source", "macd_histogram = -0.125", "obv: 1200", "mfi => 54.2", "vwap = 1.0875", "bbwidth = 2.5", "volume_ratio = 1.4", "buy_pressure_pct = 62.25"].join("\n"));
    expect(result.vector).toEqual({ macdHistogram: -0.125, obv: 1200, mfi: 54.2, vwap: 1.0875, bollingerWidthPct: 2.5, volumeRatio: 1.4, buyPressurePct: 62.25 });
    expect(result.lineRange).toBe("L2-L8");
    expect(result.unresolved).toEqual([]);
  });

  it("does not treat unrelated period numbers as vector literals", () => {
    const result = extractSourceVectorArtifact("rsi(14)\nplot(macdHistogram, 12, 26, 9)\nvolumeRatio = 1.5");
    expect(result.vector).toEqual({ volumeRatio: 1.5 });
    expect(result.unresolved).toContain("macdHistogram");
  });

  it("binds the re-uploaded MQL5 payload to its current checksum without promoting parity", () => {
    const artifact = artifactVectorCatalog.find((entry) => entry.artifactName === "pasted_content.txt");
    expect(artifact).toMatchObject({
      artifactChecksum: "f15dc7188f647a62fe1790673de977c66875ba0e898bd854b31f9e2e0af97c2c",
      status: "PENDING_VECTOR",
    });
    expect(artifact?.formulaVersion).toContain("mql5-fusion-pro-advanced-v1");
  });

  it("keeps incomplete source files visibly unresolved", () => {
    const result = extractSourceVectorArtifact("macdHistogram = 1.2\n// no other expected values");
    expect(result.unresolved).toHaveLength(6);
    expect(validateSourceVectorEvidence({ artifactName: "source.pine", artifactChecksum: "a".repeat(64), lineRange: result.lineRange, formulaVersion: "v1", symbol: "EURUSD", interval: "15m", vector: result.vector })).toMatchObject({ ok: true });
  });
});
