export const PAPER_EXECUTION_STATES = ["STAGED", "RISK_APPROVED", "SUBMITTED", "FILLED", "RECONCILED"] as const;
export type PaperExecutionState = (typeof PAPER_EXECUTION_STATES)[number] | "BLOCKED";

export type PaperExecutionTransition = {
  from: PaperExecutionState | "NONE";
  to: PaperExecutionState;
  event: string;
  detail: string;
  timestamp: string;
};

export type PaperExecution = {
  state: PaperExecutionState;
  orderRoute: "PAPER" | "DISABLED";
  liveRoute: "LIVE_PENDING_APPROVAL";
  custody: "DISABLED";
  transitions: PaperExecutionTransition[];
};

export type PaperFillReconciliation = {
  status: "RECONCILED" | "EXCEPTION";
  category: "FULL_FILL" | "PARTIAL_FILL" | "ZERO_FILL" | "INVALID_QUANTITY";
  requestedQuantity: number;
  filledQuantity: number;
  remainingQuantity: number;
  detail: string;
};

export function reconcilePaperFill(requestedQuantity: number, filledQuantity: number): PaperFillReconciliation {
  if (requestedQuantity <= 0 || filledQuantity < 0 || filledQuantity > requestedQuantity) return { status: "EXCEPTION", category: "INVALID_QUANTITY", requestedQuantity, filledQuantity, remainingQuantity: Math.max(0, requestedQuantity - filledQuantity), detail: "Fill quantity is outside the requested quantity bounds." };
  if (filledQuantity === 0) return { status: "EXCEPTION", category: "ZERO_FILL", requestedQuantity, filledQuantity, remainingQuantity: requestedQuantity, detail: "No quantity was filled; paper order remains unresolved." };
  if (filledQuantity < requestedQuantity) return { status: "EXCEPTION", category: "PARTIAL_FILL", requestedQuantity, filledQuantity, remainingQuantity: Number((requestedQuantity - filledQuantity).toFixed(8)), detail: "Paper broker filled only part of the requested quantity; remaining quantity requires review." };
  return { status: "RECONCILED", category: "FULL_FILL", requestedQuantity, filledQuantity, remainingQuantity: 0, detail: "Requested quantity was fully filled and is eligible for reconciliation." };
}

type TransitionTuple = [PaperExecutionState | "NONE", PaperExecutionState, string, string];

export function buildPaperExecution(input: { correlationId: string; timestamp: string; allowed: boolean; hasTrade: boolean }): PaperExecution {
  if (!input.allowed) return { state: "BLOCKED", orderRoute: "DISABLED", liveRoute: "LIVE_PENDING_APPROVAL", custody: "DISABLED", transitions: [{ from: "NONE", to: "BLOCKED", event: "PAPER_GATE_BLOCKED", detail: `Workflow ${input.correlationId} cannot submit a paper order until pre-trade gates pass.`, timestamp: input.timestamp }] };
  const hasTrade = input.hasTrade;
  const states: TransitionTuple[] = [
    ["NONE", "STAGED", "PAPER_INTENT_STAGED", "Paper intent created from the selected evidence context."],
    ["STAGED", "RISK_APPROVED", "RISK_GATE_PASSED", "Survivor Mode approved the bounded paper risk budget."],
    ["RISK_APPROVED", "SUBMITTED", "PAPER_ORDER_SUBMITTED", "Order submitted only to the in-process paper broker."],
    ["SUBMITTED", hasTrade ? "FILLED" : "STAGED", hasTrade ? "PAPER_FILL_RECEIVED" : "PAPER_FILL_PENDING", hasTrade ? "Bid/ask-aware simulated fill received." : "No fill exists yet; order remains staged."],
  ];
  if (hasTrade) states.push(["FILLED", "RECONCILED", "PAPER_RECONCILED", "Fill, fee, slippage, position, and journal are linked by correlation ID."]);
  return { state: hasTrade ? "RECONCILED" : "STAGED", orderRoute: "PAPER", liveRoute: "LIVE_PENDING_APPROVAL", custody: "DISABLED", transitions: states.map(([from, to, event, detail]) => ({ from, to, event, detail, timestamp: input.timestamp })) };
}
