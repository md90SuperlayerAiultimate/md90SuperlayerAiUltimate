import { describe, expect, it } from "vitest";
import { runStrategyAdapterReplay, buildStrategyAdapterAttribution } from "./strategyAdapterReplay";
import { fusionV9ImpAdapter, matariAlphaAdapter } from "./strategyAdapters";

function candles(count: number) {
  return Array.from({ length: count }, (_, index) => {
    const close = 100 + index * 0.08;
    return { timestamp: index, open: close - 0.02, high: close + 0.2, low: close - 0.2, close, volume: 100 + index };
  });
}

describe("strategy adapter cohort replay", () => {
  it("replays an adapter on OOS windows with explicit costs and disabled authority", () => {
    const result = runStrategyAdapterReplay(candles(768), fusionV9ImpAdapter, { trainBars: 240, testBars: 96, startingEquity: 100_000, feeBps: 10, slippageBps: 5 });
    expect(result.mode).toBe("PAPER_ADAPTER_REPLAY");
    expect(result.strategyId).toBe("fusion-v9-imp-paper");
    expect(result.bars).toBe(768);
    expect(result.feeBps).toBe(10);
    expect(result.slippageBps).toBe(5);
    expect(result.sampleSize + result.blockedWindows).toBeGreaterThan(0);
    expect(result.orderRoute).toBe("DISABLED");
    expect(result.authority).toBe("PAPER_ONLY");
  });

  it("keeps unresolved signal evidence visible as blocked windows", () => {
    const flat = Array.from({ length: 400 }, (_, index) => ({ timestamp: index, open: 100, high: 100.2, low: 99.8, close: 100 }));
    const result = runStrategyAdapterReplay(flat, matariAlphaAdapter, { trainBars: 240, testBars: 96 });
    expect(result.blockedWindows).toBeGreaterThan(0);
    expect(result.blockedReasons.some((reason) => reason.reason === "EMA_DIRECTION_UNRESOLVED")).toBe(true);
    expect(result.evidenceState).toBe("REFERENCE_ONLY");
  });

  it("builds deterministic strategy-level attribution without live fields", () => {
    const first = runStrategyAdapterReplay(candles(512), fusionV9ImpAdapter, { trainBars: 240, testBars: 96 });
    const second = runStrategyAdapterReplay(candles(512), matariAlphaAdapter, { trainBars: 240, testBars: 96 });
    const report = buildStrategyAdapterAttribution([first, second]);
    expect(report).toHaveLength(2);
    expect(report.map((item) => item.strategyId)).toEqual(["fusion-v9-imp-paper", "matari-alpha-paper"]);
    expect(report.every((item) => item.orderRoute === "DISABLED")).toBe(true);
    expect(JSON.stringify(report)).not.toContain("apiKey");
  });
});
