export type PaperPositionClockState = { openedAt: Date; barClockAt: Date | null; barsHeld: number; baseTimeframe: string };

const intervalMs: Record<string, number> = { "1m": 60_000, "5m": 300_000, "15m": 900_000, "1h": 3_600_000, "4h": 14_400_000, "1d": 86_400_000 };

export function paperBarIntervalMs(timeframe: string) {
  const value = intervalMs[timeframe];
  if (!value) throw new Error("Unsupported PAPER bar-clock timeframe");
  return value;
}

export function floorPaperBarClock(timestamp: Date, timeframe: string) {
  const interval = paperBarIntervalMs(timeframe);
  return new Date(Math.floor(timestamp.getTime() / interval) * interval);
}

export function advancePaperPositionClock(state: PaperPositionClockState, observedAt: Date) {
  const baseTimeframe = state.baseTimeframe;
  const observedClock = floorPaperBarClock(observedAt, baseTimeframe);
  if (!state.barClockAt) return { barClockAt: observedClock, barsHeld: state.barsHeld, advancedBy: 0 };
  const existingClock = floorPaperBarClock(state.barClockAt, baseTimeframe);
  const advancedBy = Math.max(0, Math.floor((observedClock.getTime() - existingClock.getTime()) / paperBarIntervalMs(baseTimeframe)));
  return { barClockAt: advancedBy ? observedClock : existingClock, barsHeld: state.barsHeld + advancedBy, advancedBy };
}

export function evaluatePaperTimeStop(state: PaperPositionClockState, configuredBars: number) {
  if (configuredBars < 1) throw new Error("Configured PAPER time-stop must be positive");
  const barsRemaining = Math.max(0, configuredBars - state.barsHeld);
  return { authority: "ADVISORY_ONLY" as const, configuredBars, barsHeld: state.barsHeld, barsRemaining, state: state.barsHeld >= configuredBars ? "PAPER_EXIT_REVIEW" as const : "PENDING" as const, executionAuthority: "DISABLED" as const };
}
