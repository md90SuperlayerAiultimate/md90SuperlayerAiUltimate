import { describe, expect, it } from "vitest";
import { runForwardPaperSession, type ForwardPaperConfig } from "./forwardPaperSession";

const config: ForwardPaperConfig = { symbol: "EURUSD", venue: "DUKASCOPY_FILE", lookbackBars: 2, maxHoldingBars: 2, startingEquity: 100_000, feeBps: 10, slippageBps: 5, spreadBps: 2 };

function candles(count = 12) {
  return Array.from({ length: count }, (_, index) => ({ timestamp: 1_700_000_000_000 + index * 900_000, open: 100 + index, high: 101 + index, low: 99 + index, close: 100.5 + index, volume: 100 }));
}

describe("forward paper session", () => {
  it("processes persisted candles through signal, fill, mark, and time-stop journal events", () => {
    const result = runForwardPaperSession(candles(), config);
    expect(result.status).toBe("COMPLETED");
    expect(result.dataQuality).toBe("VALIDATED_OHLC");
    expect(result.barsObserved).toBe(12);
    expect(result.signals).toBeGreaterThan(0);
    expect(result.orders).toBe(result.fills);
    expect(result.events.some((event) => event.type === "SIMULATED_FILL")).toBe(true);
    expect(result.events.some((event) => event.payload.event === "TIME_STOP_REVIEW")).toBe(true);
    expect(result.orderRoute).toBe("DISABLED");
    expect(result.executionAuthority).toBe("PAPER_ONLY");
  });

  it("blocks invalid OHLC without manufacturing a fill", () => {
    const result = runForwardPaperSession([{ ...candles(1)[0], high: 1, low: 999 }], config);
    expect(result.status).toBe("BLOCKED");
    expect(result.fills).toBe(0);
    expect(result.blockedReasons).toContain("INVALID_OHLC:0");
    expect(result.orderRoute).toBe("DISABLED");
  });

  it("uses explicit cost parameters and emits order intent metadata", () => {
    const result = runForwardPaperSession(candles(), config);
    const intent = result.events.find((event) => event.type === "ORDER_INTENT");
    const fill = result.events.find((event) => event.type === "SIMULATED_FILL");
    expect(intent?.payload).toMatchObject({ feeBps: 10, slippageBps: 5, spreadBps: 2, orderRoute: "DISABLED" });
    expect(fill?.payload).toMatchObject({ authority: "PAPER_ONLY", slippageBps: 5, status: "partial" });
  });
});
