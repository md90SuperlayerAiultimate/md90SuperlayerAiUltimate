import { describe, expect, it } from "vitest";
import { compareForwardToBacktest } from "./forwardComparison";

describe("forward versus backtest comparison", () => {
  it("computes deterministic deltas and treats higher drawdown as degraded", () => {
    const report = compareForwardToBacktest({ symbol: "EURUSD", interval: "15m", manifestChecksum: "a".repeat(64), backtest: { trades: 20, winRatePct: 60, realizedPnl: 1000, expectancy: 50, maxDrawdownPct: 4 }, forward: { trades: 18, winRatePct: 50, realizedPnl: 700, expectancy: 38.88, maxDrawdownPct: 7 } });
    expect(report.status).toBe("COMPARABLE");
    expect(report.delta).toEqual({ trades: -2, winRatePct: -10, realizedPnl: -300, expectancy: -11.12, maxDrawdownPct: 3 });
    expect(report.divergence.winRatePct).toBe("DEGRADED");
    expect(report.divergence.pnl).toBe("DEGRADED");
    expect(report.divergence.drawdown).toBe("DEGRADED");
    expect(report.executionAuthority).toBe("PAPER_ONLY");
    expect(report.orderRoute).toBe("DISABLED");
  });

  it("fails closed when either cohort has no trades", () => {
    const report = compareForwardToBacktest({ symbol: "XAUUSD", interval: "15m", manifestChecksum: "b".repeat(64), backtest: { trades: 0, winRatePct: 0, realizedPnl: 0, expectancy: 0, maxDrawdownPct: 0 }, forward: { trades: 4, winRatePct: 50, realizedPnl: 20, expectancy: 5, maxDrawdownPct: 1 } });
    expect(report.status).toBe("INSUFFICIENT_SAMPLE");
  });
});
