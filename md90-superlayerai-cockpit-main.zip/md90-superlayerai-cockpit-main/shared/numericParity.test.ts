import { describe, expect, it } from "vitest";
import { analyzeArtifactParity, type ParityCandle } from "./artifactParity";
import { evaluateNumericParity, parityIndicatorNames } from "./numericParity";

const candles = (withVolume = true): ParityCandle[] => Array.from({ length: 60 }, (_, index) => {
  const close = 100 + index * 0.25 + Math.sin(index / 3);
  const open = close - (index % 2 === 0 ? 0.1 : -0.08);
  return { open, high: Math.max(open, close) + 0.2, low: Math.min(open, close) - 0.2, close, ...(withVolume ? { volume: 1000 + index * 10 } : {}) };
});

describe("numeric parity vectors", () => {
  it("matches every available canonical indicator within tolerance", () => {
    const input = candles();
    const indicators = analyzeArtifactParity(input).indicators;
    const expected = Object.fromEntries(parityIndicatorNames.map((name) => [name, indicators[name].value]));
    const result = evaluateNumericParity({ symbol: "EURUSD", interval: "1m", source: "DUKASCOPY_FILE", checksum: "a".repeat(64), candles: input, expected, tolerance: 1e-6 });
    expect(result.overall).toBe("MATCH");
    expect(result.rows.every((row) => row.status === "MATCH")).toBe(true);
    expect(result.executionAuthority).toBe("DISABLED");
  });
  it("detects a mismatch without changing authority", () => {
    const result = evaluateNumericParity({ symbol: "XAUUSD", interval: "1m", source: "DUKASCOPY_FILE", checksum: "b".repeat(64), candles: candles(), expected: { vwap: 999 } });
    expect(result.overall).toBe("MISMATCH");
    expect(result.rows.find((row) => row.indicator === "vwap")?.status).toBe("MISMATCH");
    expect(result.authority).toBe("READ_ONLY");
  });
  it("does not pass volume indicators when OHLCV is incomplete", () => {
    const result = evaluateNumericParity({ symbol: "EURUSD", interval: "1m", source: "DUKASCOPY_FILE", checksum: "c".repeat(64), candles: candles(false), expected: { obv: 0, mfi: 50, vwap: 100, volumeRatio: 1 } });
    expect(result.overall).toBe("EVIDENCE_REQUIRED");
    expect(result.rows.filter((row) => ["obv", "mfi", "vwap", "volumeRatio"].includes(row.indicator)).every((row) => row.status === "NOT_EVALUATED")).toBe(true);
  });
});
