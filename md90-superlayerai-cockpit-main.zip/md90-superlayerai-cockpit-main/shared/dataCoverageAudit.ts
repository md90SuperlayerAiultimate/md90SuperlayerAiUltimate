import type { ReplayCandle } from "../server/datasetReplay";

export type CoverageAudit = {
  status: "READY" | "BLOCKED" | "INSUFFICIENT";
  bars: number;
  validBars: number;
  invalidBars: number;
  outOfOrder: number;
  expectedIntervalMs: number | null;
  medianIntervalMs: number | null;
  gaps: number;
  coverageStart: string | number | null;
  coverageEnd: string | number | null;
  reasons: string[];
};

function timeOf(candle: ReplayCandle): number | null {
  const raw = candle.closedAt ?? candle.timestamp ?? candle.openedAt;
  if (raw === undefined || raw === null) return null;
  const value = typeof raw === "number" ? raw : Date.parse(raw);
  return Number.isFinite(value) ? value : null;
}

function validOhlc(candle: ReplayCandle): boolean {
  return [candle.open, candle.high, candle.low, candle.close].every((value) => Number.isFinite(value) && value > 0)
    && candle.high >= Math.max(candle.open, candle.close)
    && candle.low <= Math.min(candle.open, candle.close);
}

function median(values: number[]): number | null {
  if (!values.length) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

export function auditDatasetCoverage(candles: ReplayCandle[], expectedIntervalMs?: number): CoverageAudit {
  const reasons: string[] = [];
  const times = candles.map(timeOf);
  const validBars = candles.filter(validOhlc).length;
  const invalidBars = candles.length - validBars;
  const outOfOrder = times.slice(1).reduce<number>((count, value, index) => count + (value !== null && times[index] !== null && value <= (times[index] as number) ? 1 : 0), 0);
  const intervals = times.slice(1).flatMap((value, index) => value !== null && times[index] !== null && value > (times[index] as number) ? [value - (times[index] as number)] : []);
  const medianIntervalMs = median(intervals);
  const target = expectedIntervalMs && expectedIntervalMs > 0 ? expectedIntervalMs : medianIntervalMs;
  const gaps = target ? intervals.filter((interval) => interval > target * 1.5).length : 0;
  if (candles.length < 2) reasons.push("INSUFFICIENT_BARS");
  if (invalidBars) reasons.push(`INVALID_OHLC:${invalidBars}`);
  if (outOfOrder) reasons.push(`OUT_OF_ORDER:${outOfOrder}`);
  if (!times.every((value) => value !== null)) reasons.push("INVALID_TIMESTAMP");
  if (gaps) reasons.push(`CADENCE_GAPS:${gaps}`);
  const blocked = invalidBars > 0 || outOfOrder > 0 || reasons.includes("INVALID_TIMESTAMP");
  return {
    status: blocked ? "BLOCKED" : candles.length < 2 ? "INSUFFICIENT" : "READY",
    bars: candles.length,
    validBars,
    invalidBars,
    outOfOrder,
    expectedIntervalMs: expectedIntervalMs ?? null,
    medianIntervalMs,
    gaps,
    coverageStart: candles[0] ? candles[0].closedAt ?? candles[0].timestamp ?? candles[0].openedAt ?? null : null,
    coverageEnd: candles.at(-1) ? candles.at(-1)?.closedAt ?? candles.at(-1)?.timestamp ?? candles.at(-1)?.openedAt ?? null : null,
    reasons,
  };
}
