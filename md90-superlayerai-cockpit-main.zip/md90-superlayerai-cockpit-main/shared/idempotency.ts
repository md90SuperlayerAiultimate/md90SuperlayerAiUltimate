import { randomUUID } from 'crypto';
import { Logger } from '../server/_core/logger';

export interface IdempotencyKey {
  clientOrderId: string;
  timestamp: number;
  hash: string;
}

export interface OrderIntent {
  symbol: string;
  side: 'BUY' | 'SELL';
  quantity: number;
  price: number;
  type: 'MARKET' | 'LIMIT';
}

export interface OrderState {
  clientOrderId: string;
  exchangeOrderId?: string;
  status: 'PENDING' | 'FILLED' | 'PARTIAL' | 'CANCELLED' | 'REJECTED';
  timestamp: number;
  lastUpdated: number;
  attempts: number;
  intent: OrderIntent;
}

export class IdempotencyManager {
  private orderStates = new Map<string, OrderState>();
  private logger: Logger;
  private maxRetries = 3;
  private retryTimeout = 5000; // 5 seconds

  constructor(logger?: Logger) {
    this.logger = logger || new Logger('IdempotencyManager');
  }

  /**
   * Generate unique idempotency key for order intent
   */
  generateKey(intent: OrderIntent): IdempotencyKey {
    const clientOrderId = randomUUID();
    const hash = this.hashIntent(intent);

    return {
      clientOrderId,
      timestamp: Date.now(),
      hash,
    };
  }

  /**
   * Register order intent in state machine
   */
  registerOrder(key: IdempotencyKey, intent: OrderIntent): OrderState {
    const orderState: OrderState = {
      clientOrderId: key.clientOrderId,
      status: 'PENDING',
      timestamp: key.timestamp,
      lastUpdated: Date.now(),
      attempts: 0,
      intent,
    };

    this.orderStates.set(key.clientOrderId, orderState);
    this.logger.info(
      `Order registered: ${key.clientOrderId} | ${intent.symbol} ${intent.side} ${intent.quantity}`
    );

    return orderState;
  }

  /**
   * Update order state after exchange response
   */
  updateOrderState(
    clientOrderId: string,
    exchangeOrderId: string,
    status: OrderState['status']
  ): void {
    const order = this.orderStates.get(clientOrderId);
    if (!order) {
      throw new Error(`Order ${clientOrderId} not found in state machine`);
    }

    order.exchangeOrderId = exchangeOrderId;
    order.status = status;
    order.lastUpdated = Date.now();

    this.logger.info(
      `Order updated: ${clientOrderId} -> ${status} (exchangeId: ${exchangeOrderId})`
    );
  }

  /**
   * Check if order can be retried (idempotency guard)
   */
  canRetry(clientOrderId: string): boolean {
    const order = this.orderStates.get(clientOrderId);
    if (!order) return true; // New order

    const timeSinceLastAttempt = Date.now() - order.lastUpdated;
    const canRetryByTime = timeSinceLastAttempt > this.retryTimeout;
    const canRetryByAttempts = order.attempts < this.maxRetries;

    return canRetryByTime && canRetryByAttempts && order.status === 'PENDING';
  }

  /**
   * Record retry attempt
   */
  recordRetry(clientOrderId: string): void {
    const order = this.orderStates.get(clientOrderId);
    if (!order) {
      throw new Error(`Order ${clientOrderId} not found`);
    }

    order.attempts++;
    order.lastUpdated = Date.now();

    this.logger.warn(
      `Retry ${order.attempts}/${this.maxRetries} for order ${clientOrderId}`
    );
  }

  /**
   * Detect duplicate order submission
   */
  isDuplicate(clientOrderId: string, intent: OrderIntent): boolean {
    const order = this.orderStates.get(clientOrderId);
    if (!order) return false;

    const intentHash = this.hashIntent(intent);
    return order.intent && this.hashIntent(order.intent) === intentHash;
  }

  /**
   * Get order state
   */
  getOrder(clientOrderId: string): OrderState | undefined {
    return this.orderStates.get(clientOrderId);
  }

  /**
   * Cleanup old orders (>24h)
   */
  cleanup(): void {
    const now = Date.now();
    const maxAge = 24 * 60 * 60 * 1000; // 24 hours

    for (const [clientOrderId, order] of this.orderStates.entries()) {
      if (now - order.timestamp > maxAge) {
        this.orderStates.delete(clientOrderId);
        this.logger.info(`Cleaned up order: ${clientOrderId}`);
      }
    }
  }

  private hashIntent(intent: OrderIntent): string {
    const str = `${intent.symbol}|${intent.side}|${intent.quantity}|${intent.price}|${intent.type}`;
    return Buffer.from(str).toString('base64');
  }
}
