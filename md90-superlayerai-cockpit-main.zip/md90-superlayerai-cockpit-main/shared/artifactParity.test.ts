import { describe, expect, it } from "vitest";
import { analyzeArtifactParity } from "./artifactParity";

const candles = Array.from({ length: 64 }, (_, index) => {
  const base = 100 + index * 0.4;
  return { open: base, high: base + 1.4, low: base - 1, close: base + (index % 3 === 0 ? -0.2 : 0.8), volume: 100 + index };
});

describe("artifact parity analyzer", () => {
  it("keeps short or incomplete evidence in review-only state", () => {
    const result = analyzeArtifactParity(candles.slice(-12));
    expect(result.status).toBe("EVIDENCE_REQUIRED");
    expect(result.executionAuthority).toBe("DISABLED");
    expect(result.limitations.some((item) => item.includes("canonical OHLC"))).toBe(true);
  });

  it("produces deterministic layer, gate, and no-order evidence from complete OHLCV", () => {
    const first = analyzeArtifactParity(candles);
    const second = analyzeArtifactParity(candles);
    expect(first).toEqual(second);
    expect(first.layers).toHaveLength(17);
    expect(first.gates).toHaveLength(5);
    expect(first.fusion.weightedScore).toBeGreaterThanOrEqual(0);
    expect(first.fusion.weightedScore).toBeLessThanOrEqual(1);
    expect(first.fusion.weightedScore).toBe(Math.max(first.fusion.weightedBuyScore, first.fusion.weightedSellScore));
    expect(first.authority).toBe("READ_ONLY");
    expect(first.executionAuthority).toBe("DISABLED");
    expect(first.indicators.macdHistogram.state).toBe("READY");
    expect(first.indicators.obv.state).toBe("READY");
    expect(first.indicators.mfi.state).toBe("READY");
    expect(first.indicators.vwap.state).toBe("READY");
    expect(first.indicators.bollingerWidthPct.state).toBe("READY");
    expect(first.indicators.volumeRatio.state).toBe("READY");
    expect(first.indicators.buyPressurePct.state).toBe("READY");
  });

  it("keeps volume-derived indicators fail-visible when canonical volume is absent", () => {
    const result = analyzeArtifactParity(candles.map(({ volume: _volume, ...candle }) => candle));
    expect(result.indicators.macdHistogram.state).toBe("READY");
    expect(result.indicators.bollingerWidthPct.state).toBe("READY");
    expect(result.indicators.obv).toMatchObject({ state: "NOT_EVALUATED", value: null });
    expect(result.indicators.mfi).toMatchObject({ state: "NOT_EVALUATED", value: null });
    expect(result.indicators.vwap).toMatchObject({ state: "NOT_EVALUATED", value: null });
    expect(result.executionAuthority).toBe("DISABLED");
  });
});
