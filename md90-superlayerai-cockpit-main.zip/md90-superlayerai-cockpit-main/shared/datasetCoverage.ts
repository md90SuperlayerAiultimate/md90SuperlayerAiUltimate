export type DatasetCoverage = { barCount: number; durationHours: number; classification: "SHORT" | "MEDIUM" | "LONG"; evaluationState: "EVIDENCE_REQUIRED" | "REVIEW_READY"; reason: string };

export function assessDatasetCoverage(candles: Array<{ openedAt: number; closedAt: number }>): DatasetCoverage {
  const first = candles[0];
  const last = candles.at(-1);
  const durationHours = first && last ? Math.max(0, (last.closedAt - first.openedAt) / 3_600_000) : 0;
  const barCount = candles.length;
  const classification = durationHours >= 24 * 30 || barCount >= 2_000 ? "LONG" as const : durationHours >= 24 * 7 || barCount >= 500 ? "MEDIUM" as const : "SHORT" as const;
  const evaluationState = classification === "LONG" ? "REVIEW_READY" as const : "EVIDENCE_REQUIRED" as const;
  const reason = classification === "LONG" ? "Coverage reaches a long-form review threshold; provenance and independent replay validation remain required." : classification === "MEDIUM" ? "Coverage is usable for inspection but below the long-form review threshold." : "Coverage is too short for long-form evaluation; upload a longer official export.";
  return { barCount, durationHours: Number(durationHours.toFixed(2)), classification, evaluationState, reason };
}
