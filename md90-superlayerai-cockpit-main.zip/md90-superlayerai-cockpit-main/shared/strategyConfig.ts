import { canonicalTimeframe } from "./timeframe";

export const strategyConfig = {
  name: "MATARI CANDLE ENHANCED + ALPHA / FUSION V9-IMP",
  mode: "COMBINED_HYBRID" as const,
  matari: {
    rsiPeriod: 14, rsiMidline: 50, stochasticK: 14, stochasticKSmoothing: 3, stochasticD: 3,
    htf: "CHART", htfTrendConfirmation: true, confluence: "FLEXIBLE" as const, showStatusDashboard: true,
    showSRLabels: true, showSRLines: true, pivotSensitivity: 5, engulfingTrigger: true,
    smaTrend: { enabled: true, period: 20 }, macd: { enabled: true, fast: 12, slow: 26, signal: 9 },
  },
  fusion: {
    fixedLot: 0.01, tpRR: 2, slAtrFactor: 2.5, timeStopBars: 10, trailingStop: true,
    trailingAtrDistance: 1.5, trailingStartMultiplier: 1, htf: "4H", htfEmaLength: 100,
    emaFast: 12, emaSlow: 26, atrLength: 14, atrMinimum: 0.0001, rsiLength: 14,
    rsiLevel: 50, stochasticK: 5, stochasticD: 3, stochasticLevel: 50, volumeFactor: 1.5,
  },
  timeframe: canonicalTimeframe,
  execution: { liveRoute: "DISABLED" as const, paperRoute: "ENABLED" as const, shadowRoute: "OBSERVE_ONLY" as const },
} as const;

export type StrategyConfig = typeof strategyConfig;
