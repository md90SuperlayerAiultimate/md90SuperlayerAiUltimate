export const WORKFLOW_STAGES = ["SOURCE", "CONFLUENCE", "RISK_GATE", "PAPER_FILL", "JOURNAL"] as const;
export type WorkflowStage = (typeof WORKFLOW_STAGES)[number];
export type WorkflowState = "QUALIFIED" | "CONFIRMED" | "PASSED" | "STAGED" | "FILLED" | "RECORDED" | "BLOCKED";

export type PaperWorkflowEvent = {
  id: string;
  stage: WorkflowStage;
  state: WorkflowState;
  title: string;
  detail: string;
  provenance: string;
  timestamp: string;
};

export type PaperWorkflow = {
  correlationId: string;
  mode: "PAPER_SHADOW";
  instrument: string;
  baseTimeframe: string;
  higherTimeframe: string;
  currentStage: WorkflowStage;
  decision: "PAPER_ALLOWED" | "PAPER_BLOCKED";
  decisionReason: string;
  liveRoute: "LIVE_PENDING_APPROVAL";
  custody: "DISABLED";
  events: PaperWorkflowEvent[];
};

type WorkflowInput = {
  instrument: string;
  baseTimeframe: string;
  higherTimeframe: string;
  generatedAt: string;
  provenance: string;
  dataFreshnessSeconds: number;
  riskChecks: Array<{ label: string; status: "PASS" | "LOCKED"; detail: string }>;
  hasTrade: boolean;
};

function stableId(value: string) {
  let hash = 2166136261;
  for (const character of value) hash = Math.imul(hash ^ character.charCodeAt(0), 16777619);
  return (hash >>> 0).toString(16).padStart(8, "0");
}

export function buildWorkflow(input: WorkflowInput): PaperWorkflow {
  const correlationId = `WF-${stableId(`${input.instrument}:${input.baseTimeframe}:${input.higherTimeframe}:${input.generatedAt}`)}`;
  const riskLocked = input.riskChecks.find((check) => check.label !== "Live approval" && check.status === "LOCKED");
  const paperAllowed = !riskLocked && input.dataFreshnessSeconds <= 90;
  const time = input.generatedAt;
  const event = (stage: WorkflowStage, state: WorkflowState, title: string, detail: string, suffix: string): PaperWorkflowEvent => ({ id: `${correlationId}-${suffix}`, stage, state, title, detail, provenance: input.provenance, timestamp: time });
  const events: PaperWorkflowEvent[] = [
    event("SOURCE", input.dataFreshnessSeconds <= 90 ? "QUALIFIED" : "BLOCKED", "Market context qualified", `${input.instrument} · freshness ${input.dataFreshnessSeconds}s · ${input.baseTimeframe} base`, "source"),
    event("CONFLUENCE", paperAllowed ? "CONFIRMED" : "BLOCKED", "Signal confluence reviewed", paperAllowed ? "Canonical replay and shadow context available" : "Confluence paused until source/risk gate clears", "confluence"),
    event("RISK_GATE", paperAllowed ? "PASSED" : "BLOCKED", "Survivor Mode evaluated", riskLocked ? `${riskLocked.label}: ${riskLocked.detail}` : "0.5–1.0% risk budget · 3.0% exposure cap", "risk"),
    event("PAPER_FILL", input.hasTrade && paperAllowed ? "FILLED" : "STAGED", input.hasTrade && paperAllowed ? "Paper fill recorded" : "Paper decision staged", input.hasTrade && paperAllowed ? "Bid/ask-aware fill available in the paper ledger" : "No network order authority; paper mutation remains the only action", "fill"),
    event("JOURNAL", input.hasTrade && paperAllowed ? "RECORDED" : "STAGED", "Attribution and journal linked", `Correlation ${correlationId} · provenance retained`, "journal"),
  ];
  const currentStage = events.find((item) => item.state === "BLOCKED")?.stage ?? (input.hasTrade ? "JOURNAL" : "PAPER_FILL");
  return { correlationId, mode: "PAPER_SHADOW", instrument: input.instrument, baseTimeframe: input.baseTimeframe, higherTimeframe: input.higherTimeframe, currentStage, decision: paperAllowed ? "PAPER_ALLOWED" : "PAPER_BLOCKED", decisionReason: paperAllowed ? "All pre-paper gates pass; live route remains unavailable." : `Paper blocked: ${riskLocked?.label ?? "data freshness"}`, liveRoute: "LIVE_PENDING_APPROVAL", custody: "DISABLED", events };
}
