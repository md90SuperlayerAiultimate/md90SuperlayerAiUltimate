import { ReconnectionManager } from './reconnection-manager';
import { Logger } from '../server/_core/logger';
import { IdempotencyManager, IdempotencyRequest, IdempotencyState } from '../server/idempotency';
import { v4 as uuidv4 } from 'uuid';

export interface WebSocketMessage {
  id: string;
  type: 'request' | 'response' | 'event' | 'PING' | 'PONG';
  action?: string;
  payload?: any;
  idempotencyKey?: string;
  timestamp: number;
}

export interface WebSocketConfig {
  url: string;
  reconnectionConfig?: any;
  pingInterval?: number;
  messageTimeout?: number;
  idempotencyEnabled?: boolean;
}

export class HardenedWebSocketClient {
  private ws: WebSocket | null = null;
  private reconnectionManager: ReconnectionManager;
  private idempotencyManager: IdempotencyManager;
  private logger: Logger;
  private url: string;
  private pingInterval: NodeJS.Timeout | null = null;
  private pingIntervalMs: number;
  private messageTimeoutMs: number;
  private pendingMessages = new Map<string, any>();
  private messageHandlers = new Map<string, (data: any) => void>();
  private messageId = 0;
  private isDestroyed = false;
  private idempotencyEnabled: boolean;

  constructor(config: WebSocketConfig, logger?: Logger) {
    this.url = config.url;
    this.logger = logger || new Logger('HardenedWebSocketClient');
    this.reconnectionManager = new ReconnectionManager(
      config.reconnectionConfig
    );
    this.idempotencyManager = new IdempotencyManager();
    this.pingIntervalMs = config.pingInterval || 25000;
    this.messageTimeoutMs = config.messageTimeout || 5000;
    this.idempotencyEnabled = config.idempotencyEnabled ?? true;
  }

  /**
   * Connect with automatic reconnection on failure
   */
  async connect(): Promise<void> {
    if (this.isDestroyed) return;

    try {
      await this.internalConnect();
    } catch (error) {
      this.logger.error(`Connection failed: ${error}`);
      await this.handleReconnection();
    }
  }

  private async internalConnect(): Promise<void> {
    return new Promise((resolve, reject) => {
      const connectTimeout = setTimeout(() => {
        reject(new Error('WebSocket connection timeout'));
      }, 10000);

      this.ws = new WebSocket(this.url);

      this.ws.onopen = () => {
        clearTimeout(connectTimeout);
        this.reconnectionManager.reset();
        this.setupPingPong();
        this.logger.info(`Connected to ${this.url}`);
        resolve();
      };

      this.ws.onmessage = (event) => this.handleMessage(event.data);
      this.ws.onerror = (event) => {
        clearTimeout(connectTimeout);
        reject(new Error(`WebSocket error: ${event}`));
      };
      this.ws.onclose = () => this.handleClose();
    });
  }

  /**
   * Handle reconnection with exponential backoff
   */
  private async handleReconnection(): Promise<void> {
    while (!this.isDestroyed) {
      try {
        const delay = this.reconnectionManager.getNextDelay();
        if (delay === null) {
          this.logger.error('Max reconnection attempts reached');
          return;
        }

        this.logger.info(`Reconnecting in ${delay}ms (attempt ${this.reconnectionManager.getAttemptCount()})`);
        await new Promise(resolve => setTimeout(resolve, delay));
        
        await this.internalConnect();
        return;
      } catch (error) {
        this.logger.error(
          `Reconnection attempt ${this.reconnectionManager.getAttemptCount()} failed: ${error}`
        );
      }
    }
  }

  /**
   * Setup PING/PONG keep-alive to prevent idle timeout
   */
  private setupPingPong(): void {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
    }

    this.pingInterval = setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        try {
          const message: WebSocketMessage = {
            id: uuidv4(),
            type: 'PING',
            timestamp: Date.now()
          };
          this.ws.send(JSON.stringify(message));
          this.logger.debug('PING sent');
        } catch (error) {
          this.logger.error(`PING failed: ${error}`);
        }
      }
    }, this.pingIntervalMs);
  }

  /**
   * Handle incoming message
   */
  private handleMessage(data: string): void {
    try {
      const message: WebSocketMessage = JSON.parse(data);

      if (message.type === 'PONG') {
        this.logger.debug('PONG received');
        return;
      }

      // Handle response messages
      if (message.type === 'response') {
        this.handleResponse(message);
        return;
      }

      // Handle event messages
      if (message.type === 'event') {
        this.handleEvent(message);
        return;
      }

      // Handle pending request responses
      if (message.id && this.pendingMessages.has(message.id)) {
        const pending = this.pendingMessages.get(message.id);
        clearTimeout(pending.timeout);

        // Update idempotency state if available
        if (message.idempotencyKey) {
          this.idempotencyManager.updateState(
            message.idempotencyKey,
            IdempotencyState.SUCCESS,
            message.payload
          );
        }

        pending.resolve(message);
        this.pendingMessages.delete(message.id);
      }
    } catch (error) {
      this.logger.error(`Message parsing error: ${error}`);
    }
  }

  /**
   * Handle response dari server
   */
  private handleResponse(message: WebSocketMessage): void {
    if (message.id && this.pendingMessages.has(message.id)) {
      const pending = this.pendingMessages.get(message.id);
      clearTimeout(pending.timeout);

      // Update idempotency state
      if (message.idempotencyKey) {
        this.idempotencyManager.updateState(
          message.idempotencyKey,
          IdempotencyState.SUCCESS,
          message.payload
        );
      }

      pending.resolve(message.payload);
      this.pendingMessages.delete(message.id);
    }
  }

  /**
   * Handle event dari server
   */
  private handleEvent(message: WebSocketMessage): void {
    if (!message.action) return;

    const handler = this.messageHandlers.get(message.action);
    if (handler) {
      try {
        handler(message.payload);
      } catch (error) {
        this.logger.error(`Event handler error for ${message.action}: ${error}`);
      }
    }
  }

  /**
   * Handle connection close
   */
  private handleClose(): void {
    this.logger.warn('Connection closed. Attempting reconnection...');
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
    }
    this.handleReconnection().catch((error) => {
      this.logger.error(`Reconnection failed: ${error}`);
    });
  }

  /**
   * Send message dengan idempotency tracking
   */
  async send<T>(message: any, idempotencyKey?: string): Promise<T> {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      throw new Error('WebSocket not connected');
    }

    const messageId = uuidv4();
    const finalIdempotencyKey = idempotencyKey || uuidv4();

    // Register untuk idempotency
    if (this.idempotencyEnabled) {
      const idempotencyRequest: IdempotencyRequest = {
        method: 'WS',
        url: message.action || 'unknown',
        body: message.payload
      };

      this.idempotencyManager.registerRequest(messageId, idempotencyRequest);
    }

    // Check duplikasi
    if (this.idempotencyEnabled && this.idempotencyManager.isDuplicate(finalIdempotencyKey)) {
      const result = this.idempotencyManager.getResult(finalIdempotencyKey);
      if (result?.state === IdempotencyState.SUCCESS && result?.result) {
        this.logger.info(`[Idempotency] Returning cached result for ${finalIdempotencyKey}`);
        return result.result as T;
      }
    }

    const payload: WebSocketMessage = {
      id: messageId,
      type: 'request',
      action: message.action,
      payload: message.payload,
      idempotencyKey: finalIdempotencyKey,
      timestamp: Date.now()
    };

    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pendingMessages.delete(messageId);
        
        if (this.idempotencyEnabled) {
          this.idempotencyManager.updateState(
            finalIdempotencyKey,
            IdempotencyState.FAILED,
            undefined,
            `Message timeout after ${this.messageTimeoutMs}ms`
          );
        }

        reject(new Error(`Message timeout after ${this.messageTimeoutMs}ms`));
      }, this.messageTimeoutMs);

      this.pendingMessages.set(messageId, {
        resolve,
        timeout,
      });

      try {
        this.ws!.send(JSON.stringify(payload));
      } catch (error) {
        clearTimeout(timeout);
        this.pendingMessages.delete(messageId);

        if (this.idempotencyEnabled) {
          this.idempotencyManager.updateState(
            finalIdempotencyKey,
            IdempotencyState.FAILED,
            undefined,
            error instanceof Error ? error.message : String(error)
          );
        }

        reject(error);
      }
    });
  }

  /**
   * Subscribe ke event
   */
  on(action: string, handler: (data: any) => void): () => void {
    this.messageHandlers.set(action, handler);
    return () => {
      this.messageHandlers.delete(action);
    };
  }

  /**
   * Wait for connection
   */
  async waitForConnection(timeout: number = 10000): Promise<void> {
    return new Promise((resolve, reject) => {
      if (this.isConnected()) {
        resolve();
        return;
      }

      const timer = setTimeout(() => {
        reject(new Error('Connection timeout'));
      }, timeout);

      const checkConnection = setInterval(() => {
        if (this.isConnected()) {
          clearInterval(checkConnection);
          clearTimeout(timer);
          resolve();
        }
      }, 100);
    });
  }

  /**
   * Get statistics
   */
  getStats(): {
    connected: boolean;
    pendingRequests: number;
    reconnectionAttempts: number;
    idempotencyKeys: number;
  } {
    return {
      connected: this.isConnected(),
      pendingRequests: this.pendingMessages.size,
      reconnectionAttempts: this.reconnectionManager.getAttemptCount(),
      idempotencyKeys: this.idempotencyManager.getStats().total
    };
  }

  /**
   * Graceful disconnect
   */
  disconnect(): void {
    this.isDestroyed = true;
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
    }
    if (this.ws) {
      this.ws.close(1000, 'Normal closure');
      this.ws = null;
    }
    this.idempotencyManager.destroy();
    this.messageHandlers.clear();
  }

  /**
   * Check connection status
   */
  isConnected(): boolean {
    return this.ws !== null && this.ws.readyState === WebSocket.OPEN;
  }
}
