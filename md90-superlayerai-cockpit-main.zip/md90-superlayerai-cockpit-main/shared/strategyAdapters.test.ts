import { describe, expect, it } from "vitest";
import { fusionProAdvancedAdapter, fusionV9ImpAdapter, matariAlphaAdapter, pythonReferenceAdapter, strategyAdapterRegistry } from "./strategyAdapters";

describe("isolated EA strategy adapters", () => {
  it("keeps every adapter PAPER-only and provenance-bound", () => {
    expect(strategyAdapterRegistry.length).toBeGreaterThanOrEqual(2);
    for (const adapter of strategyAdapterRegistry) {
      expect(adapter.authority).toBe("PAPER_ONLY");
      expect(adapter.id).toMatch(/paper/);
      expect(adapter.provenance.length).toBeGreaterThan(20);
      expect(adapter.parameters).toBeTruthy();
    }
    expect(fusionV9ImpAdapter.sourceChecksum).toMatch(/^[a-f0-9]{64}$/);
    expect(matariAlphaAdapter.evidenceState).toBe("REFERENCE_ONLY");
  });

  it("keeps Python source review-only without importing or executing uploaded code", () => {
    const result = pythonReferenceAdapter.evaluate({ close: 100, emaFast: 101, emaSlow: 99 });
    expect(result.signal).toBe("NEUTRAL");
    expect(result.blockedReasons).toEqual(["PYTHON_SOURCE_REVIEW_ONLY"]);
    expect(pythonReferenceAdapter.sourceClass).toBe("PYTHON");
    expect(pythonReferenceAdapter.evidenceState).toBe("REFERENCE_ONLY");
    expect(pythonReferenceAdapter.authority).toBe("PAPER_ONLY");
    expect(fusionProAdvancedAdapter.sourceChecksum).toBe("f15dc7188f647a62fe1790673de977c66875ba0e898bd854b31f9e2e0af97c2c");
    expect(fusionProAdvancedAdapter.evidenceState).toBe("REFERENCE_ONLY");
    expect(fusionProAdvancedAdapter.authority).toBe("PAPER_ONLY");
  });

  it("keeps the re-uploaded FUSION_PRO adapter isolated and parameter-bound", () => {
    const result = fusionProAdvancedAdapter.evaluate({ close: 1.3, emaFast: 1.2, emaSlow: 1.1, htfEma: 1.0, rsi: 60, stochastic: 60, atr: 0.01, volumeRatio: 2 });
    expect(result.signal).toBe("LONG");
    expect(result.exitPolicy).toEqual({ slAtr: 2.5, tpRr: 2, timeStopBars: 10, trailingAtr: 1.5 });
    expect(fusionProAdvancedAdapter.parameters.fixedLot).toBe(0.01);
  });

  it("returns deterministic blocked reasons when evidence is incomplete", () => {
    const first = fusionV9ImpAdapter.evaluate({ close: 1.1, emaFast: 1.2, emaSlow: 1.1 });
    const second = fusionV9ImpAdapter.evaluate({ close: 1.1, emaFast: 1.2, emaSlow: 1.1 });
    expect(first).toEqual(second);
    expect(first.signal).toBe("NEUTRAL");
    expect(first.blockedReasons).toEqual(expect.arrayContaining(["HTF_OR_CLOSE_MISSING", "RSI_FILTER_BLOCK", "STOCH_FILTER_BLOCK", "ATR_MINIMUM_BLOCK", "VOLUME_FACTOR_BLOCK"]));
    expect(first.exitPolicy).toMatchObject({ slAtr: 2.5, tpRr: 2, timeStopBars: 10 });
  });

  it("does not promote reference-only Matari source without vectors", () => {
    const result = matariAlphaAdapter.evaluate({ close: 106, emaFast: 105, emaSlow: 100, htfEma: 102, rsi: 60, stochastic: 70, sma: 101, macdHistogram: 1 });
    expect(result.signal).toBe("LONG");
    expect(matariAlphaAdapter.evidenceState).toBe("REFERENCE_ONLY");
    expect(matariAlphaAdapter.authority).toBe("PAPER_ONLY");
  });
});
