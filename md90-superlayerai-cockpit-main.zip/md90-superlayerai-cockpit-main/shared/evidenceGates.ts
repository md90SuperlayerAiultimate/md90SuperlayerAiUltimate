export type EvidenceGateStatus = "PENDING_EVIDENCE" | "DISABLED";

export type EvidenceGateId =
  | "PROVIDER_ACCURACY"
  | "MICROSTRUCTURE_FEEDS"
  | "MULTI_ASSET_HISTORY"
  | "PRODUCTION_HEARTBEAT"
  | "LIVE_CUSTODY";

export type EvidenceGate = {
  id: EvidenceGateId;
  label: string;
  status: EvidenceGateStatus;
  source: string;
  reason: string;
  requiredEvidence: string;
  operatorAction: "REVIEW" | "DO_NOT_ENABLE";
};

export const EVIDENCE_GATES: readonly EvidenceGate[] = [
  {
    id: "PROVIDER_ACCURACY",
    label: "Cryptoiz / Dynamic Execution accuracy",
    status: "PENDING_EVIDENCE",
    source: "PRIVATE_PROVIDER_CONTRACT",
    reason: "No authoritative private feed, timestamped payload, or independent accuracy ledger is available.",
    requiredEvidence: "Permissioned feed contract, raw timestamps, replayable samples, and out-of-sample comparison.",
    operatorAction: "REVIEW",
  },
  {
    id: "MICROSTRUCTURE_FEEDS",
    label: "DOM / gamma / COT authority",
    status: "PENDING_EVIDENCE",
    source: "SHADOW_REFERENCE_ONLY",
    reason: "Current modules are typed shadow/reference contracts, not authoritative live feeds.",
    requiredEvidence: "Provider identity, raw payload provenance, freshness SLA, and deterministic parser tests.",
    operatorAction: "REVIEW",
  },
  {
    id: "MULTI_ASSET_HISTORY",
    label: "Independent multi-asset history",
    status: "PENDING_EVIDENCE",
    source: "CANONICAL_REPLAY_BARS",
    reason: "Canonical replay coverage currently qualifies BTC only; other instruments remain shadow-only or pending dataset.",
    requiredEvidence: "Licensed OHLCV history per instrument, timezone/session metadata, corporate/event adjustments, and walk-forward windows.",
    operatorAction: "REVIEW",
  },
  {
    id: "PRODUCTION_HEARTBEAT",
    label: "Production 24/7 worker registration",
    status: "PENDING_EVIDENCE",
    source: "PAPER_HEARTBEAT",
    reason: "Heartbeat and reconciliation are paper-only; a production worker registration and runbook evidence are not complete.",
    requiredEvidence: "Registered worker identity, failure/retry evidence, alert routing, reconciliation logs, and operator runbook.",
    operatorAction: "REVIEW",
  },
  {
    id: "LIVE_CUSTODY",
    label: "Live trading and custody authority",
    status: "DISABLED",
    source: "SAFE_CORE_POLICY",
    reason: "Network orders, signing, transfer, deposit, and withdrawal are deliberately unavailable.",
    requiredEvidence: "Separate governance approval would be required; no UI or runtime action may bypass this gate.",
    operatorAction: "DO_NOT_ENABLE",
  },
] as const;

export function getEvidenceGates(): EvidenceGate[] {
  return EVIDENCE_GATES.map((gate) => ({ ...gate }));
}
