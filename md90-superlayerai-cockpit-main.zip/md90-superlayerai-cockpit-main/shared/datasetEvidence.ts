export type DatasetEvidenceStatus = "CANONICAL_INTERNAL" | "PERSISTED_EXTERNAL" | "PENDING_EXTERNAL_DATA";

export type DatasetEvidence = {
  symbol: string;
  assetClass: "CRYPTO" | "FX" | "METALS";
  status: DatasetEvidenceStatus;
  source: string;
  coverageBars: number;
  checksum: string | null;
  benchmark: string;
  limitation: string;
};

const evidenceBySymbol: Record<string, DatasetEvidence> = {
  BTCUSDT: {
    symbol: "BTCUSDT",
    assetClass: "CRYPTO",
    status: "CANONICAL_INTERNAL",
    source: "paperEngine canonical replay bars",
    coverageBars: 24,
    checksum: null,
    benchmark: "walk-forward-v1 with fee/slippage assumptions",
    limitation: "Internal canonical sample; not an independent market-data certification.",
  },
  ETHUSDT: {
    symbol: "ETHUSDT",
    assetClass: "CRYPTO",
    status: "PENDING_EXTERNAL_DATA",
    source: "No dataset attached",
    coverageBars: 0,
    checksum: null,
    benchmark: "Not run",
    limitation: "Paper replay remains blocked until an independently sourced dataset is attached and verified.",
  },
  SOLUSDT: {
    symbol: "SOLUSDT",
    assetClass: "CRYPTO",
    status: "PENDING_EXTERNAL_DATA",
    source: "No dataset attached",
    coverageBars: 0,
    checksum: null,
    benchmark: "Not run",
    limitation: "Paper replay remains blocked until an independently sourced dataset is attached and verified.",
  },
  EURUSD: {
    symbol: "EURUSD",
    assetClass: "FX",
    status: "PENDING_EXTERNAL_DATA",
    source: "No dataset attached",
    coverageBars: 0,
    checksum: null,
    benchmark: "Not run",
    limitation: "Paper replay remains blocked until an independently sourced dataset is attached and verified.",
  },
  XAUUSD: {
    symbol: "XAUUSD",
    assetClass: "METALS",
    status: "PENDING_EXTERNAL_DATA",
    source: "No dataset attached",
    coverageBars: 0,
    checksum: null,
    benchmark: "Not run",
    limitation: "Paper replay remains blocked until an independently sourced dataset is attached and verified.",
  },
};

export function getDatasetEvidence(symbol: string): DatasetEvidence {
  return evidenceBySymbol[symbol.toUpperCase()] ?? {
    symbol: symbol.toUpperCase(),
    assetClass: "CRYPTO",
    status: "PENDING_EXTERNAL_DATA",
    source: "Unknown instrument",
    coverageBars: 0,
    checksum: null,
    benchmark: "Not run",
    limitation: "Instrument is not registered in the dataset evidence manifest.",
  };
}

export function listDatasetEvidence() {
  return Object.values(evidenceBySymbol);
}
