import { analyzeArtifactParity, type IndicatorEvidence, type ParityCandle } from "./artifactParity";

export const parityIndicatorNames = ["macdHistogram", "obv", "mfi", "vwap", "bollingerWidthPct", "volumeRatio", "buyPressurePct"] as const;
export type ParityIndicatorName = (typeof parityIndicatorNames)[number];
export type NumericParityStatus = "MATCH" | "MISMATCH" | "NOT_EVALUATED" | "EVIDENCE_REQUIRED";
export type NumericParityInput = { symbol: string; interval: string; source: string; checksum: string; candles: ParityCandle[]; expected: Partial<Record<ParityIndicatorName, number | null>>; tolerance?: number };
export type NumericParityRow = { indicator: ParityIndicatorName; actual: number | null; expected: number | null; delta: number | null; status: NumericParityStatus; detail: string };
export type NumericParityResult = { authority: "READ_ONLY"; source: string; symbol: string; interval: string; checksum: string; tolerance: number; rows: NumericParityRow[]; overall: "MATCH" | "MISMATCH" | "EVIDENCE_REQUIRED"; oosGate: "PENDING"; executionAuthority: "DISABLED" };

function getIndicator(name: ParityIndicatorName, indicators: Record<ParityIndicatorName, IndicatorEvidence>) { return indicators[name]; }

export function evaluateNumericParity(input: NumericParityInput): NumericParityResult {
  const tolerance = input.tolerance ?? 1e-6;
  const indicators = analyzeArtifactParity(input.candles).indicators;
  const rows = parityIndicatorNames.map((indicator) => {
    const actualEvidence = getIndicator(indicator, indicators);
    const expected = input.expected[indicator];
    if (actualEvidence.state !== "READY" || typeof actualEvidence.value !== "number") return { indicator, actual: null, expected: expected ?? null, delta: null, status: "NOT_EVALUATED" as const, detail: actualEvidence.detail };
    if (typeof expected !== "number" || !Number.isFinite(expected)) return { indicator, actual: actualEvidence.value, expected: null, delta: null, status: "EVIDENCE_REQUIRED" as const, detail: "Source expected value is required for numeric comparison." };
    const delta = Math.abs(actualEvidence.value - expected);
    return { indicator, actual: actualEvidence.value, expected, delta: Number(delta.toFixed(10)), status: delta <= tolerance ? "MATCH" as const : "MISMATCH" as const, detail: `${actualEvidence.detail}; tolerance ${tolerance}` };
  });
  const overall = rows.some((row) => row.status === "MISMATCH") ? "MISMATCH" as const : rows.some((row) => row.status === "EVIDENCE_REQUIRED" || row.status === "NOT_EVALUATED") ? "EVIDENCE_REQUIRED" as const : "MATCH" as const;
  return { authority: "READ_ONLY", source: input.source, symbol: input.symbol, interval: input.interval, checksum: input.checksum, tolerance, rows, overall, oosGate: "PENDING", executionAuthority: "DISABLED" };
}
