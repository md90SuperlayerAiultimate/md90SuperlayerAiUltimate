export type ComparisonMetrics = {
  trades: number;
  winRatePct: number;
  realizedPnl: number;
  expectancy: number;
  maxDrawdownPct: number;
};

export type ForwardComparison = {
  status: "COMPARABLE" | "INSUFFICIENT_SAMPLE";
  dimensions: { symbol: string; interval: string; manifestChecksum: string };
  backtest: ComparisonMetrics;
  forward: ComparisonMetrics;
  delta: ComparisonMetrics;
  divergence: { winRatePct: "IMPROVED" | "DEGRADED" | "FLAT"; pnl: "IMPROVED" | "DEGRADED" | "FLAT"; drawdown: "IMPROVED" | "DEGRADED" | "FLAT" };
  caveat: "FORWARD_PAPER_NOT_LIVE";
  executionAuthority: "PAPER_ONLY";
  orderRoute: "DISABLED";
};

function direction(value: number, tolerance = 0.0001): "IMPROVED" | "DEGRADED" | "FLAT" {
  if (Math.abs(value) <= tolerance) return "FLAT";
  return value > 0 ? "IMPROVED" : "DEGRADED";
}

export function compareForwardToBacktest(input: { symbol: string; interval: string; manifestChecksum: string; backtest: ComparisonMetrics; forward: ComparisonMetrics }): ForwardComparison {
  const delta = {
    trades: input.forward.trades - input.backtest.trades,
    winRatePct: Number((input.forward.winRatePct - input.backtest.winRatePct).toFixed(4)),
    realizedPnl: Number((input.forward.realizedPnl - input.backtest.realizedPnl).toFixed(4)),
    expectancy: Number((input.forward.expectancy - input.backtest.expectancy).toFixed(4)),
    maxDrawdownPct: Number((input.forward.maxDrawdownPct - input.backtest.maxDrawdownPct).toFixed(4)),
  };
  return {
    status: input.backtest.trades > 0 && input.forward.trades > 0 ? "COMPARABLE" : "INSUFFICIENT_SAMPLE",
    dimensions: { symbol: input.symbol, interval: input.interval, manifestChecksum: input.manifestChecksum },
    backtest: input.backtest,
    forward: input.forward,
    delta,
    divergence: { winRatePct: direction(delta.winRatePct), pnl: direction(delta.realizedPnl), drawdown: direction(-delta.maxDrawdownPct) },
    caveat: "FORWARD_PAPER_NOT_LIVE",
    executionAuthority: "PAPER_ONLY",
    orderRoute: "DISABLED",
  };
}
