import type { ReplayCandle, DatasetReplayParams } from "../server/datasetReplay";
import type { AdapterSnapshot, StrategyAdapter, AdapterSignal } from "./strategyAdapters";

export type AdapterReplayWindow = {
  trainStart: number;
  trainEnd: number;
  testStart: number;
  testEnd: number;
  signal: AdapterSignal;
  outcome: "WIN" | "LOSS" | "FLAT" | "BLOCKED";
  pnl: number;
  netReturnBps: number;
  blockedReasons: string[];
  gates: string[];
  testTimestamp: string | number | null;
};

function average(values: number[]) { return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : undefined; }
function ema(values: number[], length: number) {
  if (values.length < length) return undefined;
  const alpha = 2 / (length + 1);
  let current = values.slice(0, length).reduce((sum, value) => sum + value, 0) / length;
  for (const value of values.slice(length)) current = alpha * value + (1 - alpha) * current;
  return current;
}
function snapshotAt(candles: ReplayCandle[], index: number): AdapterSnapshot {
  const history = candles.slice(Math.max(0, index - 100), index + 1);
  const closes = history.map((candle) => candle.close).filter((value) => Number.isFinite(value) && value > 0);
  const current = candles[index];
  const fast = ema(closes, 12);
  const slow = ema(closes, 26);
  const htf = ema(closes, 50);
  const mean = average(closes.slice(-14));
  const range = history.slice(-14).map((candle) => Math.max(0, candle.high - candle.low));
  const atr = average(range);
  const previousMean = average(closes.slice(-28, -14));
  const stochastic = mean && previousMean ? Math.max(0, Math.min(100, 50 + ((mean / previousMean) - 1) * 500)) : undefined;
  const volume = history.slice(-14).map((candle) => candle.volume ?? 0);
  const avgVolume = average(volume.slice(0, -1));
  const volumeRatio = avgVolume && avgVolume > 0 ? (volume.at(-1) ?? 0) / avgVolume : undefined;
  const macdFast = fast ?? current.close;
  const macdSlow = slow ?? current.close;
  return { close: current.close, open: current.open, emaFast: fast, emaSlow: slow, htfEma: htf, sma: mean, rsi: stochastic, stochastic, atr, atrMinimum: atr, volumeRatio, macdHistogram: macdFast - macdSlow };
}

export function runStrategyAdapterReplay(candles: ReplayCandle[], adapter: StrategyAdapter, params: DatasetReplayParams) {
  const trainBars = Math.max(32, Math.floor(params.trainBars));
  const testBars = Math.max(8, Math.floor(params.testBars));
  const startingEquity = params.startingEquity ?? 100_000;
  const feeBps = params.feeBps ?? 10;
  const slippageBps = params.slippageBps ?? 5;
  const roundTripCost = (feeBps + slippageBps) * 2 / 10_000;
  const windows: AdapterReplayWindow[] = [];
  let equity = startingEquity;
  let peak = startingEquity;
  let maxDrawdownPct = 0;
  const blockCounts = new Map<string, number>();

  for (let cursor = 0; cursor + trainBars + testBars <= candles.length; cursor += testBars) {
    const testStart = cursor + trainBars;
    const testEnd = testStart + testBars;
    const first = candles[testStart];
    const last = candles[testEnd - 1];
    if (!first || !last || first.close <= 0 || last.close <= 0) continue;
    const evaluation = adapter.evaluate(snapshotAt(candles, testStart));
    for (const reason of evaluation.blockedReasons) blockCounts.set(reason, (blockCounts.get(reason) ?? 0) + 1);
    if (evaluation.signal === "NEUTRAL") {
      windows.push({ trainStart: cursor, trainEnd: testStart, testStart, testEnd, signal: evaluation.signal, outcome: "BLOCKED", pnl: 0, netReturnBps: 0, blockedReasons: evaluation.blockedReasons, gates: evaluation.gates, testTimestamp: last.closedAt ?? last.timestamp ?? last.openedAt ?? null });
      continue;
    }
    const grossReturn = evaluation.signal === "LONG" ? last.close / first.close - 1 : first.close / last.close - 1;
    const netReturn = grossReturn - roundTripCost;
    const pnl = Number((equity * 0.03 * netReturn).toFixed(2));
    equity = Number((equity + pnl).toFixed(2));
    peak = Math.max(peak, equity);
    const drawdownPct = Number(((peak - equity) / peak * 100).toFixed(4));
    maxDrawdownPct = Math.max(maxDrawdownPct, drawdownPct);
    windows.push({ trainStart: cursor, trainEnd: testStart, testStart, testEnd, signal: evaluation.signal, outcome: pnl > 0 ? "WIN" : pnl < 0 ? "LOSS" : "FLAT", pnl, netReturnBps: Number((netReturn * 10_000).toFixed(4)), blockedReasons: evaluation.blockedReasons, gates: evaluation.gates, testTimestamp: last.closedAt ?? last.timestamp ?? last.openedAt ?? null });
  }
  const executed = windows.filter((window) => window.outcome !== "BLOCKED");
  const wins = executed.filter((window) => window.outcome === "WIN").length;
  const losses = executed.filter((window) => window.outcome === "LOSS").length;
  const longTrades = executed.filter((window) => window.signal === "LONG").length;
  const shortTrades = executed.filter((window) => window.signal === "SHORT").length;
  return {
    mode: "PAPER_ADAPTER_REPLAY" as const,
    strategyId: adapter.id,
    strategyName: adapter.name,
    evidenceState: adapter.evidenceState,
    authority: "PAPER_ONLY" as const,
    orderRoute: "DISABLED" as const,
    bars: candles.length, trainBars, testBars, feeBps, slippageBps,
    sampleSize: executed.length, blockedWindows: windows.length - executed.length,
    wins, losses, flats: executed.length - wins - losses,
    outOfSampleWinRatePct: executed.length ? Number((wins / executed.length * 100).toFixed(2)) : 0,
    realizedPnl: Number((equity - startingEquity).toFixed(2)),
    expectancy: executed.length ? Number(((equity - startingEquity) / executed.length).toFixed(2)) : 0,
    maxDrawdownPct: Number(maxDrawdownPct.toFixed(4)),
    longTrades, shortTrades,
    blockedReasons: Array.from(blockCounts.entries()).map(([reason, count]) => ({ reason, count })).sort((a, b) => b.count - a.count),
    windows,
  };
}

export function buildStrategyAdapterAttribution(results: Array<ReturnType<typeof runStrategyAdapterReplay>>) {
  return results.map((result) => ({ strategyId: result.strategyId, strategyName: result.strategyName, evidenceState: result.evidenceState, authority: result.authority, sampleSize: result.sampleSize, blockedWindows: result.blockedWindows, hitRatePct: result.outOfSampleWinRatePct, realizedPnl: result.realizedPnl, expectancy: result.expectancy, maxDrawdownPct: result.maxDrawdownPct, longTrades: result.longTrades, shortTrades: result.shortTrades, blockedReasons: result.blockedReasons, orderRoute: result.orderRoute }));
}
