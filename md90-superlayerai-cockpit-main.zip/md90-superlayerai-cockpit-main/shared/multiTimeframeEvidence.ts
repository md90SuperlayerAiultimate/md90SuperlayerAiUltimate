import type { ReplayCandle } from "../server/datasetReplay";
import { auditDatasetCoverage, type CoverageAudit } from "./dataCoverageAudit";
import { BASE_TIMEFRAMES, type BaseTimeframe } from "./timeframe";

export type MultiTimeframeDataset = {
  symbol: string;
  interval: BaseTimeframe;
  candles: ReplayCandle[];
  source: string;
  checksum: string | null;
  persisted: boolean;
  sourceTimestamp?: string | number | null;
};

export type MultiTimeframeEvidence = {
  status: "READY" | "BLOCKED" | "PENDING";
  symbol: string;
  intervals: Record<BaseTimeframe, CoverageAudit | null>;
  freshnessSeconds: number | null;
  conflictReasons: string[];
  reasons: string[];
};

const intervalMs: Record<BaseTimeframe, number> = {
  "1m": 60 * 1000,
  "3m": 3 * 60 * 1000,
  "5m": 5 * 60 * 1000,
  "15m": 15 * 60 * 1000,
  "30m": 30 * 60 * 1000,
  "1h": 60 * 60 * 1000,
  "4h": 4 * 60 * 60 * 1000,
  "1d": 24 * 60 * 60 * 1000,
  "1M": 30 * 24 * 60 * 60 * 1000,
};

function timestamp(value: string | number | null | undefined): number | null {
  if (value === null || value === undefined) return null;
  const parsed = typeof value === "number" ? value : Date.parse(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function lastCandleTimestamp(candles: ReplayCandle[]) {
  const last = candles.at(-1);
  if (!last) return null;
  return timestamp(last.closedAt ?? last.timestamp ?? last.openedAt);
}

export function auditMultiTimeframeEvidence(
  datasets: MultiTimeframeDataset[],
  nowMs = Date.now(),
): MultiTimeframeEvidence {
  const symbol = datasets[0]?.symbol ?? "";
  const intervals = Object.fromEntries(BASE_TIMEFRAMES.map((interval) => [interval, null])) as Record<BaseTimeframe, CoverageAudit | null>;
  const reasons: string[] = [];
  const conflictReasons: string[] = [];

  if (!symbol) reasons.push("SYMBOL_REQUIRED");
  if (!datasets.length) reasons.push("NO_PERSISTED_TIMEFRAMES");
  if (datasets.length < BASE_TIMEFRAMES.length) reasons.push(`MISSING_TIMEFRAMES:${BASE_TIMEFRAMES.filter((interval) => !datasets.some((dataset) => dataset.interval === interval)).join(",")}`);
  if (datasets.some((dataset) => dataset.symbol !== symbol)) reasons.push("SYMBOL_MISMATCH");
  if (datasets.some((dataset) => !dataset.persisted)) reasons.push("PERSISTENCE_REQUIRED");
  if (datasets.some((dataset) => !dataset.source.trim() || !dataset.checksum)) reasons.push("PROVENANCE_REQUIRED");

  for (const dataset of datasets) {
    const coverage = auditDatasetCoverage(dataset.candles, intervalMs[dataset.interval]);
    intervals[dataset.interval] = coverage;
    if (coverage.status !== "READY") reasons.push(`${dataset.interval}:${coverage.status}`);
  }

  const latest = datasets.flatMap((dataset) => {
    const value = lastCandleTimestamp(dataset.candles);
    return value === null ? [] : [{ interval: dataset.interval, value }];
  });
  const newest = latest.length ? Math.max(...latest.map((entry) => entry.value)) : null;
  const freshnessSeconds = newest === null ? null : Math.max(0, Math.floor((nowMs - newest) / 1000));
  if (newest !== null && freshnessSeconds !== null && freshnessSeconds > 2 * 24 * 60 * 60) reasons.push("STALE_LATEST_CANDLE");

  const base = latest.find((entry) => entry.interval === "15m");
  for (const entry of latest) {
    if (entry.interval === "15m" || !base) continue;
    if (Math.abs(entry.value - base.value) > intervalMs[entry.interval] * 2) conflictReasons.push(`TIMESTAMP_DESYNC:15m↔${entry.interval}`);
  }
  if (conflictReasons.length) reasons.push("MTF_CONFLICT");

  const hasBlocking = reasons.some((reason) => reason.includes("BLOCKED") || reason.includes("MISMATCH") || reason.includes("REQUIRED") || reason === "MTF_CONFLICT");
  const hasPending = reasons.length > 0 || datasets.length < BASE_TIMEFRAMES.length;
  return {
    status: hasBlocking ? "BLOCKED" : hasPending ? "PENDING" : "READY",
    symbol,
    intervals,
    freshnessSeconds,
    conflictReasons,
    reasons,
  };
}
