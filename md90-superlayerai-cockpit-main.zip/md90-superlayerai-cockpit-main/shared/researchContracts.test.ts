import { describe, expect, it } from "vitest";
import { calculateLq, classifyResearchFreshness, researchExecutionGate, type ResearchSnapshot } from "./researchContracts";

describe("research contracts", () => {
  it("calculates deterministic LQ expansion zones from OHLC", () => {
    expect(calculateLq(100, 110, 90, 105)).toMatchObject({ lq: 101.25, upper: 121.25, lower: 81.25, quality: "VERIFIED" });
  });

  it("classifies timestamped research as stale after the freshness budget", () => {
    expect(classifyResearchFreshness("2026-01-01T00:00:00.000Z", Date.parse("2026-01-01T00:02:00.000Z"), 90)).toBe("STALE");
    expect(classifyResearchFreshness(undefined)).toBe("PENDING_REVIEW");
  });

  it("fails closed when microstructure providers are not verified", () => {
    const snapshot: ResearchSnapshot = {
      mode: "SHADOW", liquidityZones: [],
      orderFlow: { source: "none", quality: "PENDING_REVIEW" },
      gamma: { source: "none", quality: "PENDING_REVIEW" },
      institutionalFlow: { source: "none", quality: "PENDING_REVIEW" },
      lq: calculateLq(100, 110, 90, 105), provenance: "paper-replay",
    };
    const gate = researchExecutionGate(snapshot);
    expect(gate.allowed).toBe(false);
    expect(gate.route).toBe("PAPER_OR_SHADOW_ONLY");
    expect(gate.reasons).toEqual(expect.arrayContaining(["order-flow-not-verified", "gamma-not-verified", "institutional-flow-not-verified"]));
  });
});
