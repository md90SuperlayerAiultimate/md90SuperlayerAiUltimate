import { describe, expect, it } from "vitest";
import { annualizedVolatility, buildInstitutionalRiskReport, correlationCoefficient, historicalVaR } from "./institutionalRiskAnalytics";

describe("institutional risk analytics", () => {
  const returns = Array.from({ length: 24 }, (_, index) => (index % 2 === 0 ? 0.01 : -0.005));

  it("keeps volatility, correlation, VaR, stress, and risk-parity deterministic", () => {
    expect(annualizedVolatility(returns)).toBeGreaterThan(0);
    expect(correlationCoefficient(returns, returns)).toBe(1);
    expect(historicalVaR(returns, 0.95, 20)).toBeGreaterThanOrEqual(0);
    const report = buildInstitutionalRiskReport([
      { symbol: "EURUSD", returns },
      { symbol: "XAUUSD", returns: returns.map((value) => value * 0.8) },
    ]);
    expect(report.status).toBe("READY");
    expect(report.sampleSize).toBe(24);
    expect(Object.values(report.riskParityWeights).reduce((sum, value) => sum + value, 0)).toBeCloseTo(1);
    expect(report.correlation[0][0]).toBe(1);
    expect(report.stress.shockedMean).toBeLessThan(report.stress.baselineMean!);
  });

  it("fails visibly when evidence sample is insufficient or absent", () => {
    expect(buildInstitutionalRiskReport([{ symbol: "BTCUSDT", returns: [0.01] }]).status).toBe("PENDING");
    expect(buildInstitutionalRiskReport([])).toMatchObject({ status: "PENDING", reasons: ["NO_RETURN_SERIES"] });
    expect(historicalVaR([0.01, -0.01], 0.95, 20)).toBeNull();
  });

  it("blocks duplicate symbols rather than silently merging series", () => {
    const report = buildInstitutionalRiskReport([{ symbol: "EURUSD", returns }, { symbol: "EURUSD", returns }]);
    expect(report.status).toBe("BLOCKED");
    expect(report.reasons).toContain("DUPLICATE_SYMBOL");
  });
});
