import { describe, expect, it } from "vitest";
import { artifactOutboundBoundaries } from "./artifactBoundary";

describe("artifact outbound boundary", () => {
  it("fails closed for every execution, custody, notification, connector, and mutable-release action", () => {
    const decisions = artifactOutboundBoundaries(["ORDER_SUBMIT", "ORDER_CANCEL", "WALLET_SIGN", "PRIVATE_KEY_USE", "DEPOSIT", "WITHDRAW", "WEBHOOK_COMMAND", "TELEGRAM_NOTIFY", "QDRANT_WRITE", "EXTERNAL_GRAPH", "GITHUB_PUSH", "AUTO_TUNE_PROMOTION", "MODEL_RELEASE"]);
    expect(decisions).toHaveLength(13);
    for (const decision of decisions) expect(decision).toMatchObject({ allowed: false, route: "DISABLED" });
    expect(decisions.find((decision) => decision.action === "AUTO_TUNE_PROMOTION")?.reason).toMatch(/replay\/OOS/i);
  });
});
