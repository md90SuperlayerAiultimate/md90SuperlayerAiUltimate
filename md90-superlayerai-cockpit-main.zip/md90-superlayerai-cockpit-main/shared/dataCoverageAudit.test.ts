import { describe, expect, it } from "vitest";
import { auditDatasetCoverage } from "./dataCoverageAudit";

const candle = (timestamp: number, close = 100) => ({ timestamp, open: close - 1, high: close + 1, low: close - 2, close, volume: 10 });

describe("dataset coverage audit", () => {
  it("accepts ordered valid candles and reports median cadence", () => {
    const result = auditDatasetCoverage([candle(0), candle(900_000), candle(1_800_000)], 900_000);
    expect(result).toMatchObject({ status: "READY", bars: 3, validBars: 3, invalidBars: 0, medianIntervalMs: 900_000, gaps: 0, reasons: [] });
  });

  it("flags cadence gaps without inventing replacement rows", () => {
    const result = auditDatasetCoverage([candle(0), candle(900_000), candle(3_600_000)], 900_000);
    expect(result.status).toBe("READY");
    expect(result.gaps).toBe(1);
    expect(result.reasons).toContain("CADENCE_GAPS:1");
    expect(result.bars).toBe(3);
  });

  it("blocks invalid OHLC and out-of-order timestamps", () => {
    const result = auditDatasetCoverage([{ ...candle(900_000), high: 1, low: 999 }, candle(0)]);
    expect(result.status).toBe("BLOCKED");
    expect(result.reasons).toEqual(expect.arrayContaining(["INVALID_OHLC:1", "OUT_OF_ORDER:1"]));
  });

  it("requires at least two bars", () => {
    expect(auditDatasetCoverage([candle(0)]).status).toBe("INSUFFICIENT");
  });
});
