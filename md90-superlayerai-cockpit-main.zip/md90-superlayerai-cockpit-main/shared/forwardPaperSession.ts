import { PaperBroker, type PaperOrderResult } from "../server/paperBroker";
import type { ReplayCandle } from "../server/datasetReplay";

export type ForwardPaperConfig = {
  symbol: string;
  venue: string;
  lookbackBars?: number;
  maxHoldingBars?: number;
  startingEquity?: number;
  riskFraction?: number;
  feeBps?: number;
  slippageBps?: number;
  spreadBps?: number;
};

export type ForwardPaperEvent = {
  type: "OBSERVATION" | "SIGNAL" | "ORDER_INTENT" | "SIMULATED_FILL" | "POSITION_MARK" | "JOURNAL" | "RECONCILIATION";
  index: number;
  timestamp: string | number | null;
  clientOrderId?: string;
  direction?: "LONG" | "SHORT";
  quantity?: number;
  price?: number;
  payload: Record<string, unknown>;
};

export type ForwardPaperResult = {
  mode: "FORWARD_PAPER";
  symbol: string;
  venue: string;
  status: "COMPLETED" | "BLOCKED";
  barsObserved: number;
  signals: number;
  orders: number;
  fills: number;
  realizedPnl: number;
  maxDrawdownPct: number;
  equity: number;
  equityCurve: Array<{ index: number; equity: number; drawdownPct: number; timestamp: string | number | null }>;
  events: ForwardPaperEvent[];
  blockedReasons: string[];
  dataQuality: "VALIDATED_OHLC" | "BLOCKED";
  executionAuthority: "PAPER_ONLY";
  orderRoute: "DISABLED";
};

function timestampOf(candle: ReplayCandle): string | number | null {
  return candle.closedAt ?? candle.timestamp ?? candle.openedAt ?? null;
}

function validCandle(candle: ReplayCandle): boolean {
  return [candle.open, candle.high, candle.low, candle.close].every((value) => Number.isFinite(value) && value > 0) && candle.high >= Math.max(candle.open, candle.close) && candle.low <= Math.min(candle.open, candle.close);
}

function markEquity(equity: number, peak: number) {
  return { equity: Number(equity.toFixed(2)), drawdownPct: Number((peak ? Math.max(0, (peak - equity) / peak * 100) : 0).toFixed(4)) };
}

export function runForwardPaperSession(candles: ReplayCandle[], config: ForwardPaperConfig): ForwardPaperResult {
  const lookbackBars = Math.max(2, Math.floor(config.lookbackBars ?? 20));
  const maxHoldingBars = Math.max(1, Math.floor(config.maxHoldingBars ?? 10));
  const startingEquity = config.startingEquity ?? 100_000;
  const riskFraction = Math.min(0.01, Math.max(0.005, config.riskFraction ?? 0.005));
  const feeBps = Math.max(0, config.feeBps ?? 10);
  const slippageBps = Math.max(0, config.slippageBps ?? 5);
  const spreadBps = Math.max(0, config.spreadBps ?? 2);
  const events: ForwardPaperEvent[] = [];
  const blockedReasons: string[] = [];
  const broker = new PaperBroker();
  let equity = startingEquity;
  let peak = startingEquity;
  let position: { direction: "LONG" | "SHORT"; quantity: number; entryPrice: number; openedIndex: number } | null = null;
  let realizedPnl = 0;
  let signals = 0;
  let orders = 0;
  let fills = 0;
  const equityCurve = [{ index: 0, equity: startingEquity, drawdownPct: 0, timestamp: candles[0] ? timestampOf(candles[0]) : null }];

  for (let index = 0; index < candles.length; index += 1) {
    const candle = candles[index];
    if (!candle || !validCandle(candle)) {
      blockedReasons.push(`INVALID_OHLC:${index}`);
      continue;
    }
    events.push({ type: "OBSERVATION", index, timestamp: timestampOf(candle), payload: { symbol: config.symbol, venue: config.venue, close: candle.close, volume: candle.volume ?? null, source: "PERSISTED_CANDLE" } });
    if (position) {
      const mark = position.direction === "LONG" ? candle.close - position.entryPrice : position.entryPrice - candle.close;
      const unrealized = mark * position.quantity;
      const marked = markEquity(equity + unrealized, peak);
      peak = Math.max(peak, marked.equity);
      events.push({ type: "POSITION_MARK", index, timestamp: timestampOf(candle), direction: position.direction, quantity: position.quantity, price: candle.close, payload: { unrealizedPnl: Number(unrealized.toFixed(2)), barsHeld: index - position.openedIndex } });
      if (index - position.openedIndex >= maxHoldingBars) {
        realizedPnl = Number((realizedPnl + unrealized).toFixed(2));
        equity = Number((equity + unrealized).toFixed(2));
        events.push({ type: "JOURNAL", index, timestamp: timestampOf(candle), direction: position.direction, payload: { event: "TIME_STOP_REVIEW", realizedPnl: Number(unrealized.toFixed(2)), authority: "PAPER_ONLY" } });
        position = null;
      }
    }
    if (index < lookbackBars || position) continue;
    const reference = candles[index - lookbackBars];
    if (!reference || !validCandle(reference)) continue;
    const direction = candle.close > reference.close ? "LONG" : candle.close < reference.close ? "SHORT" : null;
    if (!direction) continue;
    signals += 1;
    events.push({ type: "SIGNAL", index, timestamp: timestampOf(candle), direction, payload: { rule: "CLOSE_VS_LOOKBACK", lookbackBars, source: "PERSISTED_CANDLE" } });
    const quantity = Number((equity * riskFraction / candle.close).toFixed(8));
    if (quantity <= 0) {
      blockedReasons.push(`INVALID_QUANTITY:${index}`);
      continue;
    }
    orders += 1;
    const clientOrderId = `${config.symbol.replace(/[^A-Za-z0-9]/g, "")}-forward-${index}-${direction}`;
    const halfSpread = candle.close * spreadBps / 20_000;
    const bid = candle.close - halfSpread;
    const ask = candle.close + halfSpread;
    events.push({ type: "ORDER_INTENT", index, timestamp: timestampOf(candle), clientOrderId, direction, quantity, price: direction === "LONG" ? ask : bid, payload: { feeBps, slippageBps, spreadBps, orderRoute: "DISABLED" } });
    let fill: PaperOrderResult;
    try {
      fill = broker.submit({ clientOrderId, instrument: config.symbol, side: direction === "LONG" ? "BUY" : "SELL", quantity, bid, ask, feeBps, slippageBps });
    } catch (error) {
      blockedReasons.push(`FILL_REJECTED:${index}`);
      events.push({ type: "RECONCILIATION", index, timestamp: timestampOf(candle), clientOrderId, direction, payload: { state: "BLOCKED", reason: error instanceof Error ? error.message : "fill-error" } });
      continue;
    }
    fills += 1;
    position = { direction, quantity: fill.filledQuantity, entryPrice: fill.averagePrice, openedIndex: index };
    equity = Number((equity - fill.fee).toFixed(2));
    events.push({ type: "SIMULATED_FILL", index, timestamp: timestampOf(candle), clientOrderId, direction, quantity: fill.filledQuantity, price: fill.averagePrice, payload: { status: fill.status, requestedQuantity: fill.requestedQuantity, fee: fill.fee, slippageBps: fill.slippageBps, authority: "PAPER_ONLY" } });
    const marked = markEquity(equity, peak);
    peak = Math.max(peak, marked.equity);
    equityCurve.push({ index, timestamp: timestampOf(candle), ...marked });
  }
  if (position) {
    const last = candles.at(-1);
    if (last && validCandle(last)) {
      const unrealized = (position.direction === "LONG" ? last.close - position.entryPrice : position.entryPrice - last.close) * position.quantity;
      realizedPnl = Number((realizedPnl + unrealized).toFixed(2));
      equity = Number((equity + unrealized).toFixed(2));
      events.push({ type: "JOURNAL", index: candles.length - 1, timestamp: timestampOf(last), direction: position.direction, payload: { event: "SESSION_CLOSE_REVIEW", realizedPnl: Number(unrealized.toFixed(2)), authority: "PAPER_ONLY" } });
    }
  }
  peak = Math.max(peak, equity);
  const finalMark = markEquity(equity, peak);
  equityCurve.push({ index: candles.length, timestamp: candles.at(-1) ? timestampOf(candles.at(-1)!) : null, ...finalMark });
  return { mode: "FORWARD_PAPER", symbol: config.symbol, venue: config.venue, status: blockedReasons.some((reason) => reason.startsWith("INVALID_OHLC")) && !events.some((event) => event.type === "SIMULATED_FILL") ? "BLOCKED" : "COMPLETED", barsObserved: candles.length, signals, orders, fills, realizedPnl, maxDrawdownPct: Math.max(...equityCurve.map((point) => point.drawdownPct)), equity, equityCurve, events, blockedReasons: Array.from(new Set(blockedReasons)), dataQuality: blockedReasons.some((reason) => reason.startsWith("INVALID_OHLC")) ? "BLOCKED" : "VALIDATED_OHLC", executionAuthority: "PAPER_ONLY", orderRoute: "DISABLED" };
}
