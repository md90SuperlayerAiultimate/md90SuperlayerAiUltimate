import type { ArtifactParity } from "./artifactParity";

export type ProtectiveOutcome = "PAPER_CANDIDATE" | "REVIEW" | "BLOCKED";
export type MarketSession = "ASIA" | "EUROPE" | "US" | "PACIFIC" | "MAINTENANCE";

export type ProtectivePolicy = {
  authority: "ADVISORY_ONLY";
  outcome: ProtectiveOutcome;
  session: MarketSession;
  regime: string;
  reasonCodes: string[];
  survivorCaps: { riskPctMax: number; dailyLossPctMax: number; drawdownPctMax: number; maxConsecutiveLosses: number; maxTradesPerDay: number };
};

function marketSession(nowMs: number): MarketSession {
  const hour = new Date(nowMs).getUTCHours();
  if (hour >= 21 && hour < 22) return "MAINTENANCE";
  if (hour < 7) return "ASIA";
  if (hour < 12) return "EUROPE";
  if (hour < 21) return "US";
  return "PACIFIC";
}

export function evaluateProtectivePolicy(input: { parity: ArtifactParity; dailyLossPct: number; drawdownPct: number; consecutiveLosses: number; tradesToday: number; nowMs?: number }): ProtectivePolicy {
  const caps = { riskPctMax: 1, dailyLossPctMax: 3, drawdownPctMax: 10, maxConsecutiveLosses: 3, maxTradesPerDay: 8 };
  const session = marketSession(input.nowMs ?? Date.now());
  const reasonCodes: string[] = [];
  if (session === "MAINTENANCE") reasonCodes.push("session-maintenance-lock");
  if (input.dailyLossPct >= caps.dailyLossPctMax) reasonCodes.push("daily-loss-circuit-breaker");
  if (input.drawdownPct >= caps.drawdownPctMax) reasonCodes.push("drawdown-circuit-breaker");
  if (input.consecutiveLosses >= caps.maxConsecutiveLosses) reasonCodes.push("consecutive-loss-pause");
  if (input.tradesToday >= caps.maxTradesPerDay) reasonCodes.push("max-daily-trades-reached");
  if (input.parity.regime.confidence < 0.55) reasonCodes.push("regime-confidence-below-floor");
  if (input.parity.status !== "READY_FOR_REVIEW") reasonCodes.push("parity-evidence-incomplete");
  if (!input.parity.gates.every((gate) => gate.passed)) reasonCodes.push("five-gate-confluence-incomplete");
  const hardLocked = reasonCodes.some((reason) => ["session-maintenance-lock", "daily-loss-circuit-breaker", "drawdown-circuit-breaker", "consecutive-loss-pause", "max-daily-trades-reached"].includes(reason));
  const outcome: ProtectiveOutcome = hardLocked ? "BLOCKED" : reasonCodes.length ? "REVIEW" : "PAPER_CANDIDATE";
  return { authority: "ADVISORY_ONLY", outcome, session, regime: input.parity.regime.label, reasonCodes, survivorCaps: caps };
}
