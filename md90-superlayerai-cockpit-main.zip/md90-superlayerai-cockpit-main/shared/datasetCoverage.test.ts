import { describe, expect, it } from "vitest";
import { assessDatasetCoverage } from "./datasetCoverage";

const candles = (count: number, intervalMs: number) => Array.from({ length: count }, (_, index) => ({ openedAt: index * intervalMs, closedAt: (index + 1) * intervalMs }));

describe("dataset coverage manifest", () => {
  it("keeps short and medium source files evidence-required", () => {
    expect(assessDatasetCoverage(candles(48, 15 * 60_000))).toMatchObject({ classification: "SHORT", evaluationState: "EVIDENCE_REQUIRED" });
    expect(assessDatasetCoverage(candles(700, 15 * 60_000))).toMatchObject({ classification: "MEDIUM", evaluationState: "EVIDENCE_REQUIRED" });
  });

  it("marks longer real-file coverage review-ready without changing execution authority", () => {
    expect(assessDatasetCoverage(candles(2_000, 15 * 60_000))).toMatchObject({ classification: "LONG", evaluationState: "REVIEW_READY", barCount: 2_000 });
  });
});
