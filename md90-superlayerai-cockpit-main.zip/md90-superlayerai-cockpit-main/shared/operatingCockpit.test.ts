import { describe, expect, it } from "vitest";
import { appendOperatingEvent, blockOperatingState, canAdvanceOperatingStage, createOperatingState, humanizeBlockReason } from "./operatingCockpit";

describe("operating cockpit state machine", () => {
  const base = createOperatingState({ correlationId: "op:1", userId: 7, symbol: "XAUUSD", baseTimeframe: "15m", higherTimeframe: "4h", authority: "SHADOW", evidence: "READY", policyVersion: "policy-v1", sourceChecksum: "abc" }, 100);

  it("requires linear stage progression and preserves one correlation graph", () => {
    expect(canAdvanceOperatingStage(base, "NORMALIZE")).toBe(true);
    expect(canAdvanceOperatingStage(base, "RISK_GATE")).toBe(false);
    const normalized = appendOperatingEvent(base, { eventId: "e1", correlationId: "op:1", stage: "NORMALIZE", type: "DATASET_NORMALIZED", symbol: "XAUUSD", occurredAt: 110, evidence: "READY", authority: "SHADOW", inputChecksum: "abc", outputChecksum: "def", payload: { bars: 2912 } });
    expect(normalized.stage).toBe("NORMALIZE");
    expect(normalized.events).toHaveLength(2);
    expect(normalized.events[0].stage).toBe("INGEST");
    expect(appendOperatingEvent(normalized, normalized.events[0])).toBe(normalized);
  });

  it("completes the full canonical graph only through sequential stages", () => {
    let state = base;
    const stages = ["NORMALIZE", "PARITY", "CONFLUENCE", "RISK_GATE", "PAPER_DECISION", "PAPER_FILL", "POSITION", "JOURNAL", "AUDIT"] as const;
    stages.forEach((stage, index) => { state = appendOperatingEvent(state, { eventId: `full-${index}`, correlationId: "op:1", causationId: state.events.at(-1)?.eventId, stage, type: `STAGE_${stage}`, symbol: "XAUUSD", occurredAt: 200 + index, evidence: "MATCH", authority: stage.startsWith("PAPER") || stage === "POSITION" || stage === "JOURNAL" ? "PAPER" : "SHADOW", payload: {} }); });
    expect(state.stage).toBe("AUDIT");
    expect(state.outcome).toBe("COMPLETED");
    expect(state.events).toHaveLength(10);
  });

  it("rejects cross-context events and blocks paper progression fail-closed", () => {
    expect(() => appendOperatingEvent(base, { eventId: "bad", correlationId: "other", stage: "NORMALIZE", type: "DATASET_NORMALIZED", symbol: "XAUUSD", occurredAt: 110, evidence: "READY", authority: "SHADOW", payload: {} })).toThrow("correlation-mismatch");
    expect(() => appendOperatingEvent(base, { eventId: "bad", correlationId: "op:1", stage: "NORMALIZE", type: "DATASET_NORMALIZED", symbol: "EURUSD", occurredAt: 110, evidence: "READY", authority: "SHADOW", payload: {} })).toThrow("instrument-mismatch");
    const blocked = blockOperatingState(base, ["PARITY_REQUIRED", "RISK_POLICY_HOLD"], 120);
    expect(blocked.outcome).toBe("PAPER_BLOCKED");
    expect(blocked.authority).toBe("DISABLED");
    expect(blocked.blockReasons).toEqual(["PARITY_REQUIRED", "RISK_POLICY_HOLD"]);
  });

  it("provides bilingual operator explanations", () => {
    expect(humanizeBlockReason("MANIFEST_MISSING", "id")).toMatch(/Manifest/);
    expect(humanizeBlockReason("MANIFEST_MISSING", "en")).toMatch(/manifest/i);
  });
});
