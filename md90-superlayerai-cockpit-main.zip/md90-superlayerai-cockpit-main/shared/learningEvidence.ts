export type LearningJournalEvent = { event: string; timestamp?: Date | string | number };
export type LearningEvidence = {
  authority: "PROPOSAL_ONLY";
  status: "EVIDENCE_REQUIRED" | "REVIEW_READY";
  closedSampleSize: number;
  outcomeLabeledSampleSize: number;
  outOfSampleGate: "PENDING" | "PASS";
  promotionRoute: "DISABLED";
  posterior: { wins: number; losses: number; alpha: number; beta: number; mean: number; sampleGate: "PENDING" | "PASS" };
  reasonCodes: string[];
};

export function evaluateLearningEvidence(events: LearningJournalEvent[]): LearningEvidence {
  const closed = events.filter((event) => event.event.startsWith("POSITION_CLOSED") || event.event.startsWith("ORDER_CLOSED"));
  const labeled = closed.filter((event) => /PROFIT|LOSS|BREAKEVEN/.test(event.event));
  const wins = labeled.filter((event) => event.event.includes("PROFIT")).length;
  const losses = labeled.filter((event) => event.event.includes("LOSS")).length;
  const alpha = 1 + wins;
  const beta = 1 + losses;
  const reasonCodes: string[] = [];
  if (closed.length < 30) reasonCodes.push("closed-sample-below-30");
  if (labeled.length < 30) reasonCodes.push("outcome-labels-insufficient");
  const outOfSampleGate = closed.length >= 30 && labeled.length >= 30 ? "PASS" as const : "PENDING" as const;
  return { authority: "PROPOSAL_ONLY", status: outOfSampleGate === "PASS" ? "REVIEW_READY" : "EVIDENCE_REQUIRED", closedSampleSize: closed.length, outcomeLabeledSampleSize: labeled.length, outOfSampleGate, promotionRoute: "DISABLED", posterior: { wins, losses, alpha, beta, mean: Number((alpha / (alpha + beta)).toFixed(4)), sampleGate: outOfSampleGate }, reasonCodes };
}
