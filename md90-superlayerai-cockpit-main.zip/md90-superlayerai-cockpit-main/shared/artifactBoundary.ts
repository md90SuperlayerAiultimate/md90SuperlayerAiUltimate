export type ArtifactOutboundAction = "ORDER_SUBMIT" | "ORDER_CANCEL" | "WALLET_SIGN" | "PRIVATE_KEY_USE" | "DEPOSIT" | "WITHDRAW" | "WEBHOOK_COMMAND" | "TELEGRAM_NOTIFY" | "QDRANT_WRITE" | "EXTERNAL_GRAPH" | "GITHUB_PUSH" | "AUTO_TUNE_PROMOTION" | "MODEL_RELEASE";

export type ArtifactBoundaryDecision = { action: ArtifactOutboundAction; allowed: false; route: "DISABLED"; reason: string };

const reasonByAction: Record<ArtifactOutboundAction, string> = {
  ORDER_SUBMIT: "External order submission is disabled outside PAPER simulation.",
  ORDER_CANCEL: "External order cancellation is disabled outside PAPER simulation.",
  WALLET_SIGN: "Wallet signing is disabled by custody boundary.",
  PRIVATE_KEY_USE: "Private-key use is disabled by credential boundary.",
  DEPOSIT: "Deposit is disabled by custody boundary.",
  WITHDRAW: "Withdrawal is disabled by custody boundary.",
  WEBHOOK_COMMAND: "Inbound webhook commands are disabled until a dedicated authorization contract exists.",
  TELEGRAM_NOTIFY: "Outbound Telegram notification is disabled until a dedicated notification contract exists.",
  QDRANT_WRITE: "Vector-store writes are disabled until privacy and retention contracts exist.",
  EXTERNAL_GRAPH: "External graph connector is disabled until provider scope and data-retention contracts exist.",
  GITHUB_PUSH: "Repository mutation is disabled for artifact workflows.",
  AUTO_TUNE_PROMOTION: "Automatic tuner promotion is disabled until replay/OOS approval exists.",
  MODEL_RELEASE: "Model release is disabled until an audited approval workflow exists.",
};

export function artifactOutboundBoundary(action: ArtifactOutboundAction): ArtifactBoundaryDecision {
  return { action, allowed: false, route: "DISABLED", reason: reasonByAction[action] };
}

export function artifactOutboundBoundaries(actions: ArtifactOutboundAction[]): ArtifactBoundaryDecision[] {
  return actions.map(artifactOutboundBoundary);
}
