import { describe, expect, it } from "vitest";
import { atomicFindings, filterAuditFindings } from "./auditMatrix";

describe("atomic audit matrix", () => {
  it("keeps the register non-empty and filters status/classification deterministically", () => {
    expect(atomicFindings.length).toBeGreaterThanOrEqual(13);
    const blocked = filterAuditFindings({ status: "BLOCKED" });
    expect(blocked.length).toBeGreaterThan(0);
    expect(blocked.every((finding) => finding.status === "BLOCKED")).toBe(true);
    expect(filterAuditFindings({ classification: "CUSTODY" }).every((finding) => finding.classification === "CUSTODY")).toBe(true);
  });
  it("supports checksum prefix and proof/search trace filters", () => {
    const finding = atomicFindings[0];
    expect(filterAuditFindings({ checksum: finding.sha256.slice(0, 16) })).toContainEqual(finding);
    expect(filterAuditFindings({ search: finding.proof })).toContainEqual(finding);
    expect(filterAuditFindings({ artifact: finding.artifact })).toContainEqual(finding);
  });
});
