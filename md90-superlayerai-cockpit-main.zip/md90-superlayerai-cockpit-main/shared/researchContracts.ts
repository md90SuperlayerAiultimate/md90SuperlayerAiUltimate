export type ResearchQuality = "VERIFIED" | "STALE" | "PENDING_REVIEW" | "UNAVAILABLE";
export type ResearchMode = "PAPER" | "SHADOW" | "READ_ONLY";
export type ResearchFreshness = "FRESH" | "STALE" | "PENDING_REVIEW";

export function classifyResearchFreshness(observedAt?: string, nowMs = Date.now(), staleAfterSeconds = 90): ResearchFreshness {
  if (!observedAt) return "PENDING_REVIEW";
  const observedMs = Date.parse(observedAt);
  if (!Number.isFinite(observedMs)) return "PENDING_REVIEW";
  return (nowMs - observedMs) / 1000 <= staleAfterSeconds ? "FRESH" : "STALE";
}

export type LiquidityZone = { level: number; kind: "SUPPORT" | "RESISTANCE" | "MAGNETIC"; source: string; observedAt: string };
export type OrderFlowSnapshot = { bidAskDepthRatio?: number; delta?: number; absorption?: boolean; source: string; quality: ResearchQuality };
export type GammaSnapshot = { netGex?: number; zeroGammaLevel?: number; callWall?: number; putWall?: number; regime?: "POSITIVE" | "NEGATIVE" | "UNKNOWN"; source: string; quality: ResearchQuality };
export type InstitutionalFlowSnapshot = { managedFundsNetLong?: number; commercialNetPosition?: number; openInterestChangePct?: number; biasScore?: number; source: string; quality: ResearchQuality };
export type LqSnapshot = { open: number; high: number; low: number; close: number; lq: number; upper: number; lower: number; source: string; quality: ResearchQuality; observedAt?: string };

export type ResearchSnapshot = {
  mode: ResearchMode;
  liquidityZones: LiquidityZone[];
  orderFlow: OrderFlowSnapshot;
  gamma: GammaSnapshot;
  institutionalFlow: InstitutionalFlowSnapshot;
  lq: LqSnapshot;
  provenance: string;
};

export function calculateLq(open: number, high: number, low: number, close: number, source = "OHLC") : LqSnapshot {
  const values = [open, high, low, close];
  if (!values.every((value) => Number.isFinite(value) && value > 0) || high < low) throw new Error("Invalid LQ OHLC");
  const lq = (open + high + low + close) / 4;
  const range = high - low;
  return { open, high, low, close, lq, upper: lq + range, lower: lq - range, source, quality: "VERIFIED", observedAt: new Date().toISOString() };
}

export function researchExecutionGate(snapshot: ResearchSnapshot) {
  const reasons: string[] = [];
  if (!snapshot.provenance) reasons.push("missing-provenance");
  if (snapshot.mode === "READ_ONLY") reasons.push("read-only-research");
  if (snapshot.orderFlow.quality !== "VERIFIED") reasons.push("order-flow-not-verified");
  if (snapshot.gamma.quality !== "VERIFIED") reasons.push("gamma-not-verified");
  if (snapshot.institutionalFlow.quality !== "VERIFIED") reasons.push("institutional-flow-not-verified");
  return { allowed: false as const, route: "PAPER_OR_SHADOW_ONLY" as const, reasons };
}
