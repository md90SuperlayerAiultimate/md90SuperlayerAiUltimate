export const INSTRUMENTS = [
  { id: "BTCUSDT", label: "BTC/USDT", tradingView: "BINANCE:BTCUSDT", venue: "BINANCE_PUBLIC", assetClass: "CRYPTO", paperReplay: true },
  { id: "ETHUSDT", label: "ETH/USDT", tradingView: "BINANCE:ETHUSDT", venue: "BINANCE_PUBLIC", assetClass: "CRYPTO", paperReplay: false },
  { id: "SOLUSDT", label: "SOL/USDT", tradingView: "BINANCE:SOLUSDT", venue: "BINANCE_PUBLIC", assetClass: "CRYPTO", paperReplay: false },
  { id: "EURUSD", label: "EUR/USD", tradingView: "OANDA:EURUSD", venue: "OANDA_PUBLIC", assetClass: "FX", paperReplay: false },
  { id: "XAUUSD", label: "XAU/USD", tradingView: "OANDA:XAUUSD", venue: "OANDA_PUBLIC", assetClass: "METALS", paperReplay: false },
] as const;

export type InstrumentId = (typeof INSTRUMENTS)[number]["id"];
export type InstrumentDefinition = (typeof INSTRUMENTS)[number];

export const DEFAULT_INSTRUMENT = INSTRUMENTS[0];

export function getInstrument(id: string): InstrumentDefinition {
  return INSTRUMENTS.find((item) => item.id === id.toUpperCase()) ?? DEFAULT_INSTRUMENT;
}
