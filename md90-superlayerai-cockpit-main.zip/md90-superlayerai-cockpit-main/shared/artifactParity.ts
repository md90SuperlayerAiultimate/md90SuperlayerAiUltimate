export type ParityDirection = "BUY" | "SELL" | "NEUTRAL";
export type ParityCandle = { open: number; high: number; low: number; close: number; volume?: number };

export type ParityLayer = {
  id: number;
  label: string;
  direction: ParityDirection;
  strength: number;
  reason: string;
};

export type IndicatorEvidence = {
  state: "READY" | "NOT_EVALUATED";
  value: number | null;
  detail: string;
};

export type ArtifactParity = {
  authority: "READ_ONLY";
  status: "READY_FOR_REVIEW" | "EVIDENCE_REQUIRED";
  source: string;
  requiredBars: number;
  availableBars: number;
  regime: { label: string; confidence: number; adx: number; atrPct: number };
  fusion: { direction: ParityDirection; score: number; weightedScore: number; weightedBuyScore: number; weightedSellScore: number; activeLayers: number; buyVotes: number; sellVotes: number };
  gates: Array<{ id: string; label: string; passed: boolean; detail: string }>;
  levels: { entry: number; stop: number; takeProfit: number; riskReward: number } | null;
  layers: ParityLayer[];
  indicators: {
    macdHistogram: IndicatorEvidence;
    obv: IndicatorEvidence;
    mfi: IndicatorEvidence;
    vwap: IndicatorEvidence;
    bollingerWidthPct: IndicatorEvidence;
    volumeRatio: IndicatorEvidence;
    buyPressurePct: IndicatorEvidence;
  };
  limitations: string[];
  executionAuthority: "DISABLED";
};

const layer = (id: number, label: string, direction: ParityDirection, strength: number, reason: string): ParityLayer => ({ id, label, direction, strength, reason });
const neutral = (id: number, label: string, reason: string): ParityLayer => layer(id, label, "NEUTRAL", 0, reason);
const direction = (value: number): ParityDirection => value > 0 ? "BUY" : value < 0 ? "SELL" : "NEUTRAL";
const clamp = (value: number, min = 0, max = 1) => Math.max(min, Math.min(max, value));
const average = (values: number[]) => values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;
const fusionWeights = [0.08, 0.07, 0.06, 0.05, 0.08, 0.06, 0.07, 0.04, 0.07, 0.08, 0.07, 0.04, 0.04, 0.06, 0.06, 0.05, 0.02] as const;

function ema(values: number[], period: number) {
  if (values.length < period) return 0;
  const weight = 2 / (period + 1);
  let value = average(values.slice(0, period));
  for (const close of values.slice(period)) value = close * weight + value * (1 - weight);
  return value;
}

function atr(candles: ParityCandle[], period = 14) {
  if (candles.length < period + 1) return 0;
  const ranges = candles.slice(1).map((candle, index) => Math.max(candle.high - candle.low, Math.abs(candle.high - candles[index].close), Math.abs(candle.low - candles[index].close)));
  return average(ranges.slice(-period));
}

function rsi(closes: number[], period = 14) {
  if (closes.length < period + 1) return 50;
  let gains = 0;
  let losses = 0;
  for (let index = closes.length - period; index < closes.length; index++) {
    const change = closes[index] - closes[index - 1];
    if (change > 0) gains += change;
    else losses -= change;
  }
  if (!losses) return 100;
  return 100 - 100 / (1 + gains / losses);
}

function stochastic(candles: ParityCandle[], period = 14) {
  if (candles.length < period) return { k: 50, d: 50 };
  const values = candles.slice(-(period + 2)).map((_, offset, source) => {
    const ending = source.slice(0, offset + 1);
    const window = ending.slice(-period);
    const high = Math.max(...window.map((item) => item.high));
    const low = Math.min(...window.map((item) => item.low));
    const close = ending[ending.length - 1].close;
    return high === low ? 50 : ((close - low) / (high - low)) * 100;
  });
  return { k: values[values.length - 1] ?? 50, d: average(values.slice(-3)) };
}

function adx(candles: ParityCandle[], period = 14) {
  if (candles.length < period + 2) return { value: 0, plus: 0, minus: 0 };
  const rows = candles.slice(1).map((candle, index) => {
    const previous = candles[index];
    const up = candle.high - previous.high;
    const down = previous.low - candle.low;
    return {
      tr: Math.max(candle.high - candle.low, Math.abs(candle.high - previous.close), Math.abs(candle.low - previous.close)),
      plus: up > down && up > 0 ? up : 0,
      minus: down > up && down > 0 ? down : 0,
    };
  }).slice(-period);
  const totalTr = rows.reduce((sum, item) => sum + item.tr, 0);
  const plus = totalTr ? (100 * rows.reduce((sum, item) => sum + item.plus, 0)) / totalTr : 0;
  const minus = totalTr ? (100 * rows.reduce((sum, item) => sum + item.minus, 0)) / totalTr : 0;
  return { value: plus + minus ? (100 * Math.abs(plus - minus)) / (plus + minus) : 0, plus, minus };
}

function unavailable(detail: string): IndicatorEvidence {
  return { state: "NOT_EVALUATED", value: null, detail };
}

function ready(value: number, detail: string): IndicatorEvidence {
  return { state: "READY", value: Number(value.toFixed(6)), detail };
}

function auxiliaryIndicators(candles: ParityCandle[]) {
  const closes = candles.map((candle) => candle.close);
  const opens = candles.map((candle) => candle.open);
  const highs = candles.map((candle) => candle.high);
  const lows = candles.map((candle) => candle.low);
  const hasVolume = candles.every((candle) => typeof candle.volume === "number" && Number.isFinite(candle.volume));
  const volumes = hasVolume ? candles.map((candle) => candle.volume as number) : [];
  const macdHistogram = closes.length < 35 ? unavailable("Need 35 closes for MACD 12/26/9.") : (() => {
    const fast = Array.from({ length: closes.length - 11 }, (_, index) => ema(closes.slice(0, index + 12), 12));
    const slow = Array.from({ length: closes.length - 25 }, (_, index) => ema(closes.slice(0, index + 26), 26));
    const aligned = Math.min(fast.length, slow.length);
    const line = fast.slice(-aligned).map((value, index) => value - slow[slow.length - aligned + index]);
    const signal = ema(line, 9);
    const histogram = line[line.length - 1] - signal;
    return ready(histogram, `MACD 12/26/9 histogram ${histogram.toFixed(4)}`);
  })();
  const obv = !hasVolume ? unavailable("Canonical OHLCV volume required for OBV.") : (() => {
    let value = 0;
    for (let index = 1; index < closes.length; index += 1) value += closes[index] > closes[index - 1] ? volumes[index] : closes[index] < closes[index - 1] ? -volumes[index] : 0;
    return ready(value, `OBV cumulative canonical volume ${value.toFixed(2)}`);
  })();
  const mfi = !hasVolume || closes.length < 15 ? unavailable("Need 15 canonical OHLCV bars for MFI14.") : (() => {
    let positive = 0;
    let negative = 0;
    for (let index = closes.length - 14; index < closes.length; index += 1) {
      const typical = (highs[index] + lows[index] + closes[index]) / 3;
      const priorTypical = (highs[index - 1] + lows[index - 1] + closes[index - 1]) / 3;
      if (typical > priorTypical) positive += typical * volumes[index];
      else negative += typical * volumes[index];
    }
    const value = negative === 0 ? 100 : 100 - 100 / (1 + positive / negative);
    return ready(value, `MFI14 ${value.toFixed(2)}`);
  })();
  const vwap = !hasVolume || !closes.length ? unavailable("Canonical OHLCV volume required for VWAP.") : (() => {
    let priceVolume = 0;
    let totalVolume = 0;
    for (let index = 0; index < closes.length; index += 1) {
      priceVolume += ((highs[index] + lows[index] + closes[index]) / 3) * volumes[index];
      totalVolume += volumes[index];
    }
    const value = totalVolume ? priceVolume / totalVolume : closes[closes.length - 1];
    return ready(value, `Canonical VWAP ${value.toFixed(4)}`);
  })();
  const bollingerWidthPct = closes.length < 20 ? unavailable("Need 20 closes for Bollinger width.") : (() => {
    const window = closes.slice(-20);
    const mid = average(window);
    const variance = average(window.map((value) => (value - mid) ** 2));
    const width = mid ? ((4 * Math.sqrt(variance)) / mid) * 100 : 0;
    return ready(width, `Bollinger 20/2 width ${width.toFixed(3)}%`);
  })();
  const volumeRatio = !hasVolume || volumes.length < 2 ? unavailable("At least two canonical volume bars required for volume ratio.") : (() => {
    const history = volumes.slice(Math.max(0, volumes.length - 21), -1);
    const baseline = average(history);
    const value = baseline ? volumes[volumes.length - 1] / baseline : 1;
    return ready(value, `Last volume / trailing baseline ${value.toFixed(3)}×`);
  })();
  const buyPressurePct = !closes.length ? unavailable("Canonical OHLC bars required for buy pressure.") : (() => {
    const window = candles.slice(-14);
    const value = (window.filter((candle) => candle.close > candle.open).length / window.length) * 100;
    return ready(value, `Bullish bodies over ${window.length} bars ${value.toFixed(1)}%`);
  })();
  return { macdHistogram, obv, mfi, vwap, bollingerWidthPct, volumeRatio, buyPressurePct };
}

function candleDirection(candle: ParityCandle) {
  return direction(candle.close - candle.open);
}

export function analyzeArtifactParity(candles: ParityCandle[]): ArtifactParity {
  const source = "Pine MD90_ALLIN · MQL5 Ultimate Fusion · Python data_provider (read-only parity)";
  const requiredBars = 50;
  const limitations: string[] = [];
  if (candles.length < requiredBars) limitations.push(`Need ${requiredBars} canonical OHLC bars; received ${candles.length}.`);
  const volumesAvailable = candles.every((candle) => typeof candle.volume === "number" && Number.isFinite(candle.volume));
  if (!volumesAvailable) limitations.push("Volume-dependent layers remain neutral until authenticated historical OHLCV is available.");
  const closes = candles.map((candle) => candle.close);
  const price = closes.at(-1) ?? 0;
  const currentAtr = atr(candles);
  const indicators = auxiliaryIndicators(candles);
  const ema9 = ema(closes, 9);
  const ema21 = ema(closes, 21);
  const rsiValue = rsi(closes);
  const stoch = stochastic(candles);
  const trend = adx(candles);
  const recent20 = candles.slice(-20);
  const rangeHigh = recent20.length ? Math.max(...recent20.map((candle) => candle.high)) : price;
  const rangeLow = recent20.length ? Math.min(...recent20.map((candle) => candle.low)) : price;
  const range = Math.max(rangeHigh - rangeLow, Number.EPSILON);
  const rangeMid = (rangeHigh + rangeLow) / 2;
  const latest = candles.at(-1);
  const prior = candles.at(-2);
  const isBullEngulf = Boolean(latest && prior && latest.close > latest.open && prior.close < prior.open && latest.close >= prior.open && latest.open <= prior.close);
  const isBearEngulf = Boolean(latest && prior && latest.close < latest.open && prior.close > prior.open && latest.close <= prior.open && latest.open >= prior.close);
  const layers: ParityLayer[] = [
    layer(1, "SNR", price <= rangeLow + currentAtr * 0.35 ? "BUY" : price >= rangeHigh - currentAtr * 0.35 ? "SELL" : "NEUTRAL", currentAtr ? 0.7 : 0, currentAtr ? `20-bar range ${rangeLow.toFixed(2)}–${rangeHigh.toFixed(2)}` : "ATR/history unavailable"),
    layer(2, "EMA", ema9 && ema21 ? direction(ema9 - ema21) : "NEUTRAL", ema9 && ema21 ? clamp(Math.abs(ema9 - ema21) / Math.max(currentAtr, 1)) : 0, ema9 && ema21 ? `EMA9 ${ema9.toFixed(2)} vs EMA21 ${ema21.toFixed(2)}` : "Need 21 closes"),
    layer(3, "RSI", rsiValue < 30 ? "BUY" : rsiValue > 70 ? "SELL" : "NEUTRAL", rsiValue < 30 ? clamp((30 - rsiValue) / 30) : rsiValue > 70 ? clamp((rsiValue - 70) / 30) : 0, `RSI14 ${rsiValue.toFixed(1)}`),
    layer(4, "STOCH", stoch.k < 20 && stoch.k > stoch.d ? "BUY" : stoch.k > 80 && stoch.k < stoch.d ? "SELL" : "NEUTRAL", Math.abs(stoch.k - stoch.d) / 100, `K ${stoch.k.toFixed(1)} / D ${stoch.d.toFixed(1)}`),
    neutral(5, "ORDER_BLOCK", "No certified order-block detector input."),
    indicators.volumeRatio.state === "READY" && indicators.buyPressurePct.state === "READY" ? layer(6, "VOLUME", (indicators.buyPressurePct.value ?? 50) > 55 ? "BUY" : (indicators.buyPressurePct.value ?? 50) < 45 ? "SELL" : "NEUTRAL", clamp(Math.abs((indicators.buyPressurePct.value ?? 50) - 50) / 50) * clamp(Math.abs((indicators.volumeRatio.value ?? 1) - 1)), `${indicators.volumeRatio.detail}; ${indicators.buyPressurePct.detail}`) : neutral(6, "VOLUME", "Canonical OHLCV required."),
    neutral(7, "MTF", "Independent HTF candle set required; no same-TF substitution."),
    neutral(8, "ORDER_FLOW", "No certified order-flow source."),
    neutral(9, "ULTRA", "Independent lower-timeframe candle set required."),
    layer(10, "PRIME_SWING", price > rangeMid ? "BUY" : price < rangeMid ? "SELL" : "NEUTRAL", clamp(Math.abs(price - rangeMid) / range), `Range midpoint ${rangeMid.toFixed(2)}`),
    closes.length >= 50 ? layer(11, "MACRO", direction(price - ema(closes, 50)), clamp(Math.abs(price - ema(closes, 50)) / Math.max(currentAtr, 1)), "EMA50 macro proxy") : neutral(11, "MACRO", "Need 50 closes for macro parity."),
    indicators.vwap.state === "READY" ? layer(12, "VWAP", price > (indicators.vwap.value ?? price) ? "BUY" : price < (indicators.vwap.value ?? price) ? "SELL" : "NEUTRAL", currentAtr ? clamp(Math.abs(price - (indicators.vwap.value ?? price)) / currentAtr) : 0, indicators.vwap.detail) : neutral(12, "VWAP", "Canonical OHLCV required."),
    currentAtr && price ? layer(13, "ATR", trend.plus > trend.minus ? "BUY" : trend.minus > trend.plus ? "SELL" : "NEUTRAL", clamp(currentAtr / price / 0.02), `ATR14 ${(currentAtr / price * 100).toFixed(3)}%`) : neutral(13, "ATR", "Need 15 bars."),
    price <= rangeHigh - range * 0.618 ? layer(14, "OTE", "BUY", 0.5, "Retracement zone proxy") : price >= rangeLow + range * 0.618 ? layer(14, "OTE", "SELL", 0.5, "Retracement zone proxy") : neutral(14, "OTE", "Outside retracement evidence zone."),
    latest && prior && latest.high > prior.high && latest.close < prior.high ? layer(15, "LIQUIDITY_SWEEP", "SELL", 0.7, "High sweep then close below prior high") : latest && prior && latest.low < prior.low && latest.close > prior.low ? layer(15, "LIQUIDITY_SWEEP", "BUY", 0.7, "Low sweep then close above prior low") : neutral(15, "LIQUIDITY_SWEEP", "No confirmed local sweep."),
    isBullEngulf ? layer(16, "MASTER_CALL", "BUY", 0.8, "Bullish engulfing") : isBearEngulf ? layer(16, "MASTER_CALL", "SELL", 0.8, "Bearish engulfing") : neutral(16, "MASTER_CALL", "No certified engulfing trigger."),
    neutral(17, "TIME_STOP", "Requires durable open-position age; read-only analyzer does not invent it."),
  ];
  const active = layers.filter((layer) => layer.direction !== "NEUTRAL");
  const buyVotes = active.filter((layer) => layer.direction === "BUY").length;
  const sellVotes = active.filter((layer) => layer.direction === "SELL").length;
  const fusionDirection = buyVotes > sellVotes ? "BUY" : sellVotes > buyVotes ? "SELL" : "NEUTRAL";
  const fusionScore = active.length ? Math.max(buyVotes, sellVotes) / active.length : 0;
  const totalWeight = fusionWeights.reduce((sum, value) => sum + value, 0);
  const weightedBuyScore = layers.reduce((sum, item, index) => sum + (item.direction === "BUY" ? fusionWeights[index] * item.strength : 0), 0) / totalWeight;
  const weightedSellScore = layers.reduce((sum, item, index) => sum + (item.direction === "SELL" ? fusionWeights[index] * item.strength : 0), 0) / totalWeight;
  const weightedScore = Math.max(weightedBuyScore, weightedSellScore);
  const byId = (id: number) => layers[id - 1];
  const gate1 = byId(2).direction !== "NEUTRAL" && byId(2).direction === byId(7).direction && byId(7).direction === byId(10).direction;
  const gate2 = byId(14).direction !== "NEUTRAL" && byId(14).direction === byId(15).direction;
  const gate3 = [3, 4, 6, 12].filter((id) => byId(id).direction === fusionDirection).length >= 3;
  const gate4 = byId(16).direction === fusionDirection && byId(9).direction === fusionDirection;
  const stop = fusionDirection === "BUY" ? price - currentAtr * 1.5 : fusionDirection === "SELL" ? price + currentAtr * 1.5 : 0;
  const takeProfit = fusionDirection === "BUY" ? price + currentAtr * 2 : fusionDirection === "SELL" ? price - currentAtr * 2 : 0;
  const riskReward = stop && price ? Math.abs(takeProfit - price) / Math.abs(price - stop) : 0;
  const gate5 = byId(17).strength >= 0.5 && riskReward >= 1.5;
  const regime = trend.value >= 25 ? trend.plus > trend.minus ? "TREND_UP" : "TREND_DOWN" : currentAtr / Math.max(price, 1) > 0.002 ? "VOLATILE" : "TRANSITION";
  return {
    authority: "READ_ONLY",
    status: limitations.length ? "EVIDENCE_REQUIRED" : "READY_FOR_REVIEW",
    source,
    requiredBars,
    availableBars: candles.length,
    regime: { label: regime, confidence: Number(clamp(trend.value / 50, 0, 1).toFixed(2)), adx: Number(trend.value.toFixed(2)), atrPct: Number((currentAtr / Math.max(price, 1) * 100).toFixed(3)) },
    fusion: { direction: fusionDirection, score: Number(fusionScore.toFixed(3)), weightedScore: Number(weightedScore.toFixed(3)), weightedBuyScore: Number(weightedBuyScore.toFixed(3)), weightedSellScore: Number(weightedSellScore.toFixed(3)), activeLayers: active.length, buyVotes, sellVotes },
    gates: [
      { id: "G1", label: "EMA / MTF / Prime Swing", passed: gate1, detail: gate1 ? "Directional confluence observed." : "MTF evidence not yet certified or disagreeing." },
      { id: "G2", label: "OTE / Liquidity Sweep", passed: gate2, detail: gate2 ? "Retracement and sweep align." : "No aligned retracement/sweep." },
      { id: "G3", label: "Momentum confirmation", passed: gate3, detail: gate3 ? "Three momentum layers align." : "Insufficient aligned momentum evidence." },
      { id: "G4", label: "Master / Ultra", passed: gate4, detail: gate4 ? "Trigger and lower-TF align." : "Lower-timeframe evidence unavailable or not aligned." },
      { id: "G5", label: "Time stop / RR", passed: gate5, detail: gate5 ? "Durable time-stop and reward evidence pass." : "No durable time-stop evidence in read-only analysis." },
    ],
    levels: fusionDirection === "NEUTRAL" || !currentAtr ? null : { entry: Number(price.toFixed(2)), stop: Number(stop.toFixed(2)), takeProfit: Number(takeProfit.toFixed(2)), riskReward: Number(riskReward.toFixed(2)) },
    layers,
    indicators,
    limitations,
    executionAuthority: "DISABLED",
  };
}
