import { describe, expect, it } from "vitest";
import { advancePaperPositionClock, evaluatePaperTimeStop, floorPaperBarClock } from "./paperPositionClock";

describe("PAPER position bar clock", () => {
  it("advances only on a new canonical timeframe bucket", () => {
    const state = { openedAt: new Date("2026-08-25T00:00:00Z"), barClockAt: new Date("2026-08-25T00:00:00Z"), barsHeld: 2, baseTimeframe: "15m" };
    expect(advancePaperPositionClock(state, new Date("2026-08-25T00:14:59Z"))).toMatchObject({ barsHeld: 2, advancedBy: 0 });
    expect(advancePaperPositionClock(state, new Date("2026-08-25T00:31:00Z"))).toMatchObject({ barsHeld: 4, advancedBy: 2, barClockAt: new Date("2026-08-25T00:30:00Z") });
    expect(floorPaperBarClock(new Date("2026-08-25T00:31:00Z"), "15m")).toEqual(new Date("2026-08-25T00:30:00Z"));
  });

  it("returns review-only time-stop status and never an execution route", () => {
    expect(evaluatePaperTimeStop({ openedAt: new Date(), barClockAt: new Date(), barsHeld: 9, baseTimeframe: "15m" }, 10)).toMatchObject({ state: "PENDING", barsRemaining: 1, authority: "ADVISORY_ONLY", executionAuthority: "DISABLED" });
    expect(evaluatePaperTimeStop({ openedAt: new Date(), barClockAt: new Date(), barsHeld: 10, baseTimeframe: "15m" }, 10)).toMatchObject({ state: "PAPER_EXIT_REVIEW", barsRemaining: 0, executionAuthority: "DISABLED" });
  });
});
