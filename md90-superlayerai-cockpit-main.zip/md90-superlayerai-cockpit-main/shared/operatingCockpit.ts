export const OPERATING_STAGES = [
  "INGEST",
  "NORMALIZE",
  "PARITY",
  "CONFLUENCE",
  "RISK_GATE",
  "PAPER_DECISION",
  "PAPER_FILL",
  "POSITION",
  "JOURNAL",
  "AUDIT",
] as const;

export type OperatingStage = (typeof OPERATING_STAGES)[number];
export type OperatingAuthority = "PAPER" | "SHADOW" | "DISABLED";
export type OperatingEvidence = "PENDING" | "READY" | "MATCH" | "MISMATCH" | "BLOCKED";
export type OperatingOutcome = "RUNNING" | "PAPER_CANDIDATE" | "PAPER_BLOCKED" | "COMPLETED" | "FAILED";

export type OperatingContext = {
  correlationId: string;
  causationId?: string;
  userId: number;
  symbol: string;
  baseTimeframe: string;
  higherTimeframe: string;
  authority: OperatingAuthority;
  evidence: OperatingEvidence;
  policyVersion: string;
  sourceChecksum?: string;
};

export type OperatingBlockReason =
  | "AUTH_REQUIRED"
  | "MANIFEST_MISSING"
  | "MANIFEST_STALE"
  | "PARITY_REQUIRED"
  | "PARITY_MISMATCH"
  | "MTFA_INCOMPLETE"
  | "RISK_POLICY_HOLD"
  | "PAPER_ONLY"
  | "LIVE_DISABLED";

export type OperatingEvent = {
  eventId: string;
  correlationId: string;
  causationId?: string;
  stage: OperatingStage;
  type: string;
  symbol: string;
  occurredAt: number;
  inputChecksum?: string;
  outputChecksum?: string;
  evidence: OperatingEvidence;
  authority: OperatingAuthority;
  payload: Record<string, unknown>;
};

export type OperatingState = OperatingContext & {
  stage: OperatingStage;
  outcome: OperatingOutcome;
  events: OperatingEvent[];
  blockReasons: OperatingBlockReason[];
  lastUpdatedAt: number;
};

export function createOperatingState(context: OperatingContext, now = Date.now()): OperatingState {
  const startEvent: OperatingEvent = { eventId: `${context.correlationId}:ingest`, correlationId: context.correlationId, causationId: undefined, stage: "INGEST", type: "OPERATING_RUN_STARTED", symbol: context.symbol, occurredAt: now, inputChecksum: context.sourceChecksum, outputChecksum: context.sourceChecksum, evidence: context.evidence, authority: context.authority, payload: { policyVersion: context.policyVersion, baseTimeframe: context.baseTimeframe, higherTimeframe: context.higherTimeframe } };
  return { ...context, stage: "INGEST", outcome: "RUNNING", events: [startEvent], blockReasons: [], lastUpdatedAt: now };
}

export function appendOperatingEvent(state: OperatingState, event: OperatingEvent): OperatingState {
  if (event.correlationId !== state.correlationId) throw new Error("correlation-mismatch");
  if (event.symbol !== state.symbol) throw new Error("instrument-mismatch");
  const duplicate = state.events.find((candidate) => candidate.eventId === event.eventId);
  if (duplicate) return state;
  if (!canAdvanceOperatingStage(state, event.stage)) throw new Error(`invalid-stage-transition:${state.stage}->${event.stage}`);
  const nextOutcome: OperatingOutcome = event.stage === "AUDIT" ? "COMPLETED" : state.outcome;
  return { ...state, stage: event.stage, evidence: event.evidence, authority: event.authority, events: [...state.events, event], outcome: nextOutcome, lastUpdatedAt: event.occurredAt };
}

export function blockOperatingState(state: OperatingState, reasons: OperatingBlockReason[], now = Date.now()): OperatingState {
  return { ...state, outcome: "PAPER_BLOCKED", blockReasons: Array.from(new Set([...state.blockReasons, ...reasons])), authority: "DISABLED", lastUpdatedAt: now };
}

export function canAdvanceOperatingStage(state: OperatingState, nextStage: OperatingStage): boolean {
  const current = OPERATING_STAGES.indexOf(state.stage);
  const next = OPERATING_STAGES.indexOf(nextStage);
  const isAuditClosure = nextStage === "AUDIT" && current >= OPERATING_STAGES.indexOf("RISK_GATE");
  return (next === current + 1 || isAuditClosure) && state.outcome === "RUNNING";
}

export function humanizeBlockReason(reason: OperatingBlockReason, language: "id" | "en" = "id"): string {
  const labels = {
    AUTH_REQUIRED: ["Autentikasi operator diperlukan", "Operator authentication required"],
    MANIFEST_MISSING: ["Manifest dataset belum tersedia", "Dataset manifest is missing"],
    MANIFEST_STALE: ["Dataset sudah stale", "Dataset is stale"],
    PARITY_REQUIRED: ["Parity source vector diperlukan", "Source parity vector is required"],
    PARITY_MISMATCH: ["Parity indikator mismatch", "Indicator parity mismatch"],
    MTFA_INCOMPLETE: ["Konfirmasi MTFA belum lengkap", "MTFA confirmation is incomplete"],
    RISK_POLICY_HOLD: ["Risk policy menahan keputusan", "Risk policy is holding the decision"],
    PAPER_ONLY: ["Keputusan hanya boleh PAPER", "Decision is PAPER-only"],
    LIVE_DISABLED: ["Live execution dinonaktifkan", "Live execution is disabled"],
  } satisfies Record<OperatingBlockReason, [string, string]>;
  return labels[reason][language === "id" ? 0 : 1];
}
