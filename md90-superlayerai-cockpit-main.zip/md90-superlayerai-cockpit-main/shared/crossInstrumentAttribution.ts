export type AttributionInput = {
  symbol: string;
  ingestionId: number;
  checksum: string;
  timeframe?: string;
  regime?: string;
  riskBlockReasons?: string[];
  replay: {
    trades: number;
    wins: number;
    losses: number;
    flats: number;
    outOfSampleWinRatePct: number;
    realizedPnl: number;
    expectancy: number;
    maxDrawdownPct: number;
    attribution?: { longTrades?: number; shortTrades?: number; longSharePct?: number };
    windows?: Array<{ direction?: string; outcome?: string; pnl?: number; testTimestamp?: string | number | null; regime?: string; timeframe?: string; riskBlockReason?: string }>;
  };
};

type GroupAccumulator = { key: string; dimension: string; value: string; trades: number; wins: number; losses: number; flats: number; realizedPnl: number; riskBlocks: number; symbols: Set<string>; };

function addGroup(groups: Map<string, GroupAccumulator>, dimension: string, value: string, input: AttributionInput, trades: number, wins: number, losses: number, flats: number, pnl: number, riskBlocks = 0) {
  const safeValue = value.trim() || "UNKNOWN";
  const key = `${dimension}:${safeValue}`;
  const current = groups.get(key) ?? { key, dimension, value: safeValue, trades: 0, wins: 0, losses: 0, flats: 0, realizedPnl: 0, riskBlocks: 0, symbols: new Set<string>() };
  current.trades += trades; current.wins += wins; current.losses += losses; current.flats += flats; current.realizedPnl += pnl; current.riskBlocks += riskBlocks; current.symbols.add(input.symbol); groups.set(key, current);
}

export function buildCrossInstrumentAttribution(inputs: AttributionInput[]) {
  const groups = new Map<string, GroupAccumulator>();
  const instruments = inputs.map((input) => {
    const windows = input.replay.windows ?? [];
    const timeframe = input.timeframe ?? "UNKNOWN";
    const regime = input.regime ?? "UNKNOWN";
    const riskReasons = input.riskBlockReasons?.length ? input.riskBlockReasons : ["NONE_RECORDED"];
    addGroup(groups, "instrument", input.symbol, input, input.replay.trades, input.replay.wins, input.replay.losses, input.replay.flats, input.replay.realizedPnl);
    addGroup(groups, "timeframe", timeframe, input, input.replay.trades, input.replay.wins, input.replay.losses, input.replay.flats, input.replay.realizedPnl);
    addGroup(groups, "regime", regime, input, input.replay.trades, input.replay.wins, input.replay.losses, input.replay.flats, input.replay.realizedPnl);
    riskReasons.forEach((reason) => addGroup(groups, "risk_block_reason", reason, input, 0, 0, 0, 0, 0, 1));
    windows.forEach((window) => {
      const outcome = String(window.outcome ?? "FLAT").toUpperCase();
      const win = outcome === "WIN" ? 1 : 0;
      const loss = outcome === "LOSS" ? 1 : 0;
      const flat = win || loss ? 0 : 1;
      const pnl = Number(window.pnl ?? 0);
      addGroup(groups, "oos_window", window.testTimestamp ? new Date(window.testTimestamp).toISOString().slice(0, 10) : "UNKNOWN_DATE", input, 1, win, loss, flat, pnl);
      addGroup(groups, "regime", window.regime ?? regime, input, 1, win, loss, flat, pnl);
      addGroup(groups, "timeframe", window.timeframe ?? timeframe, input, 1, win, loss, flat, pnl);
      if (window.riskBlockReason) addGroup(groups, "risk_block_reason", window.riskBlockReason, input, 0, 0, 0, 0, 0, 1);
    });
    return {
      symbol: input.symbol,
      ingestionId: input.ingestionId,
      checksum: input.checksum,
      timeframe,
      regime,
      trades: input.replay.trades,
      wins: input.replay.wins,
      losses: input.replay.losses,
      flats: input.replay.flats,
      hitRatePct: input.replay.outOfSampleWinRatePct,
      realizedPnl: input.replay.realizedPnl,
      expectancy: input.replay.expectancy,
      maxDrawdownPct: input.replay.maxDrawdownPct,
      longTrades: input.replay.attribution?.longTrades ?? 0,
      shortTrades: input.replay.attribution?.shortTrades ?? 0,
      pnlSharePct: 0,
    };
  });
  const totalTrades = instruments.reduce((sum, item) => sum + item.trades, 0);
  const totalWins = instruments.reduce((sum, item) => sum + item.wins, 0);
  const realizedPnl = Number(instruments.reduce((sum, item) => sum + item.realizedPnl, 0).toFixed(2));
  const totalAbsPnl = instruments.reduce((sum, item) => sum + Math.abs(item.realizedPnl), 0);
  const withShares = instruments.map((item) => ({ ...item, pnlSharePct: totalAbsPnl ? Number((Math.abs(item.realizedPnl) / totalAbsPnl * 100).toFixed(2)) : 0 }));
  const comparativeGroups = Array.from(groups.values()).map((group) => ({ ...group, symbols: Array.from(group.symbols), realizedPnl: Number(group.realizedPnl.toFixed(2)), hitRatePct: group.trades ? Number((group.wins / group.trades * 100).toFixed(2)) : 0 })).sort((a, b) => a.dimension.localeCompare(b.dimension) || a.value.localeCompare(b.value));
  return {
    reportVersion: "cross-instrument-attribution-v2",
    instruments: withShares,
    comparativeGroups,
    aggregate: {
      instrumentCount: withShares.length,
      totalTrades,
      totalWins,
      totalLosses: instruments.reduce((sum, item) => sum + item.losses, 0),
      totalFlats: instruments.reduce((sum, item) => sum + item.flats, 0),
      hitRatePct: totalTrades ? Number((totalWins / totalTrades * 100).toFixed(2)) : 0,
      realizedPnl,
      expectancy: totalTrades ? Number((realizedPnl / totalTrades).toFixed(2)) : 0,
      worstMaxDrawdownPct: Number(Math.max(0, ...instruments.map((item) => item.maxDrawdownPct)).toFixed(4)),
      positiveContributors: withShares.filter((item) => item.realizedPnl > 0).map((item) => item.symbol),
      negativeContributors: withShares.filter((item) => item.realizedPnl < 0).map((item) => item.symbol),
    },
    authority: "PAPER_DATASET_REPLAY" as const,
    orderRoute: "DISABLED" as const,
    executionAuthority: "DISABLED" as const,
  };
}
