import { describe, expect, it } from "vitest";
import { proposePaperTrade } from "./artifactTradeProposal";
import type { ArtifactParity } from "./artifactParity";
import type { ProtectivePolicy } from "./protectivePolicy";

const parity: ArtifactParity = { authority: "READ_ONLY", status: "READY_FOR_REVIEW", source: "test", requiredBars: 50, availableBars: 50, regime: { label: "TREND_UP", confidence: 0.8, adx: 31, atrPct: 0.5 }, fusion: { direction: "BUY", score: 0.9, weightedScore: 0.7, weightedBuyScore: 0.7, weightedSellScore: 0, activeLayers: 8, buyVotes: 8, sellVotes: 0 }, gates: [], levels: { entry: 100, stop: 98.5, takeProfit: 102, riskReward: 1.33 }, layers: [], indicators: { macdHistogram: { state: "NOT_EVALUATED", value: null, detail: "test" }, obv: { state: "NOT_EVALUATED", value: null, detail: "test" }, mfi: { state: "NOT_EVALUATED", value: null, detail: "test" }, vwap: { state: "NOT_EVALUATED", value: null, detail: "test" }, bollingerWidthPct: { state: "NOT_EVALUATED", value: null, detail: "test" }, volumeRatio: { state: "NOT_EVALUATED", value: null, detail: "test" }, buyPressurePct: { state: "NOT_EVALUATED", value: null, detail: "test" } }, limitations: [], executionAuthority: "DISABLED" };
const policy: ProtectivePolicy = { authority: "ADVISORY_ONLY", outcome: "PAPER_CANDIDATE", session: "EUROPE", regime: "TREND_UP", reasonCodes: [], survivorCaps: { riskPctMax: 1, dailyLossPctMax: 3, drawdownPctMax: 10, maxConsecutiveLosses: 3, maxTradesPerDay: 8 } };

describe("artifact paper trade proposal", () => {
  it("keeps missing independent HTF and position age in review", () => {
    const proposal = proposePaperTrade({ parity, protection: policy, baseTimeframe: "15m", htfTimeframe: "4h", independentHtf: false });
    expect(proposal).toMatchObject({ authority: "ADVISORY_ONLY", outcome: "REVIEW", executionAuthority: "DISABLED", timeStop: { state: "NOT_EVALUATED" }, multiTimeframe: { state: "MISSING" } });
    expect(proposal.reasonCodes).toContain("independent-htf-evidence-required");
  });

  it("derives PAPER-only ATR plan and time-stop review without initiating execution", () => {
    const proposal = proposePaperTrade({ parity, protection: policy, baseTimeframe: "15m", htfTimeframe: "4h", independentHtf: true, durablePositionBars: 10 });
    expect(proposal).toMatchObject({ outcome: "PAPER_CANDIDATE", direction: "BUY", stop: 97.5, takeProfit: 105, timeStop: { state: "PAPER_EXIT_REVIEW" }, partialExit: { state: "ADVISORY_ONLY" }, executionAuthority: "DISABLED" });
  });

  it("preserves protective block regardless of favorable levels", () => {
    const proposal = proposePaperTrade({ parity, protection: { ...policy, outcome: "BLOCKED", reasonCodes: ["daily-loss-circuit-breaker"] }, baseTimeframe: "15m", htfTimeframe: "4h", independentHtf: true });
    expect(proposal.outcome).toBe("BLOCKED");
    expect(proposal.executionAuthority).toBe("DISABLED");
  });
});
