import { describe, expect, it } from "vitest";
import { evaluateProtectivePolicy } from "./protectivePolicy";
import type { ArtifactParity } from "./artifactParity";

const parity = (overrides: Partial<ArtifactParity> = {}): ArtifactParity => ({
  authority: "READ_ONLY", status: "READY_FOR_REVIEW", source: "test", requiredBars: 50, availableBars: 50,
  regime: { label: "TREND_UP", confidence: 0.8, adx: 31, atrPct: 0.3 },
  fusion: { direction: "BUY", score: 0.9, weightedScore: 0.7, weightedBuyScore: 0.7, weightedSellScore: 0, activeLayers: 8, buyVotes: 8, sellVotes: 0 },
  gates: ["G1", "G2", "G3", "G4", "G5"].map((id) => ({ id, label: id, passed: true, detail: "test" })),
  levels: null, layers: [], indicators: { macdHistogram: { state: "NOT_EVALUATED", value: null, detail: "test" }, obv: { state: "NOT_EVALUATED", value: null, detail: "test" }, mfi: { state: "NOT_EVALUATED", value: null, detail: "test" }, vwap: { state: "NOT_EVALUATED", value: null, detail: "test" }, bollingerWidthPct: { state: "NOT_EVALUATED", value: null, detail: "test" }, volumeRatio: { state: "NOT_EVALUATED", value: null, detail: "test" }, buyPressurePct: { state: "NOT_EVALUATED", value: null, detail: "test" } }, limitations: [], executionAuthority: "DISABLED", ...overrides,
});

describe("protective advisory policy", () => {
  it("offers a candidate only with complete evidence and no protective lock", () => {
    const result = evaluateProtectivePolicy({ parity: parity(), dailyLossPct: 0, drawdownPct: 0, consecutiveLosses: 0, tradesToday: 1, nowMs: Date.UTC(2026, 7, 25, 9) });
    expect(result).toMatchObject({ authority: "ADVISORY_ONLY", outcome: "PAPER_CANDIDATE", session: "EUROPE" });
  });

  it("holds incomplete evidence and hard-blocks circuit-breaker conditions", () => {
    const review = evaluateProtectivePolicy({ parity: parity({ status: "EVIDENCE_REQUIRED" }), dailyLossPct: 0, drawdownPct: 0, consecutiveLosses: 0, tradesToday: 1, nowMs: Date.UTC(2026, 7, 25, 9) });
    expect(review.outcome).toBe("REVIEW");
    expect(review.reasonCodes).toContain("parity-evidence-incomplete");
    const blocked = evaluateProtectivePolicy({ parity: parity(), dailyLossPct: 3, drawdownPct: 0, consecutiveLosses: 0, tradesToday: 1, nowMs: Date.UTC(2026, 7, 25, 9) });
    expect(blocked.outcome).toBe("BLOCKED");
    expect(blocked.reasonCodes).toContain("daily-loss-circuit-breaker");
  });
});
