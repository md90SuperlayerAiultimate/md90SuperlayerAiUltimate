export type RiskSeries = { symbol: string; returns: number[] };
export type RiskStatus = "READY" | "PENDING" | "BLOCKED";

export type InstitutionalRiskReport = {
  status: RiskStatus;
  symbols: string[];
  sampleSize: number;
  annualizedVolatility: Record<string, number | null>;
  correlation: number[][];
  riskParityWeights: Record<string, number>;
  historicalVaR: number | null;
  stress: { shock: number; baselineMean: number | null; shockedMean: number | null };
  reasons: string[];
};

function finiteReturns(values: number[]) {
  return values.filter((value) => Number.isFinite(value));
}

function mean(values: number[]) {
  return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : null;
}

function standardDeviation(values: number[]) {
  if (values.length < 2) return null;
  const average = mean(values)!;
  return Math.sqrt(values.reduce((sum, value) => sum + (value - average) ** 2, 0) / (values.length - 1));
}

export function annualizedVolatility(values: number[], periodsPerYear = 252) {
  const clean = finiteReturns(values);
  const deviation = standardDeviation(clean);
  return deviation === null || !Number.isFinite(periodsPerYear) || periodsPerYear <= 0 ? null : deviation * Math.sqrt(periodsPerYear);
}

export function correlationCoefficient(left: number[], right: number[]) {
  const size = Math.min(left.length, right.length);
  if (size < 2) return null;
  const a = left.slice(-size);
  const b = right.slice(-size);
  const meanA = mean(a)!;
  const meanB = mean(b)!;
  const numerator = a.reduce((sum, value, index) => sum + (value - meanA) * (b[index] - meanB), 0);
  const denominator = Math.sqrt(a.reduce((sum, value) => sum + (value - meanA) ** 2, 0) * b.reduce((sum, value) => sum + (value - meanB) ** 2, 0));
  return denominator > 0 ? numerator / denominator : null;
}

export function historicalVaR(values: number[], confidence = 0.95, minimumSample = 20) {
  const clean = finiteReturns(values).sort((a, b) => a - b);
  if (clean.length < minimumSample || confidence <= 0 || confidence >= 1) return null;
  const index = Math.max(0, Math.min(clean.length - 1, Math.floor((1 - confidence) * clean.length)));
  return -clean[index];
}

export function buildInstitutionalRiskReport(series: RiskSeries[], options: { periodsPerYear?: number; confidence?: number; stressShock?: number; minimumSample?: number } = {}): InstitutionalRiskReport {
  const symbols = series.map((item) => item.symbol);
  const clean = series.map((item) => ({ symbol: item.symbol, returns: finiteReturns(item.returns) }));
  const reasons: string[] = [];
  if (!clean.length) reasons.push("NO_RETURN_SERIES");
  if (clean.some((item) => item.returns.length < (options.minimumSample ?? 20))) reasons.push("INSUFFICIENT_SAMPLE");
  if (new Set(symbols).size !== symbols.length) reasons.push("DUPLICATE_SYMBOL");
  const volatilities = Object.fromEntries(clean.map((item) => [item.symbol, annualizedVolatility(item.returns, options.periodsPerYear)]));
  const weights: Record<string, number> = {};
  const inverse = clean.map((item) => ({ symbol: item.symbol, value: volatilities[item.symbol] && volatilities[item.symbol]! > 0 ? 1 / volatilities[item.symbol]! : 0 }));
  const inverseTotal = inverse.reduce((sum, item) => sum + item.value, 0);
  for (const item of inverse) weights[item.symbol] = inverseTotal > 0 ? item.value / inverseTotal : 0;
  const correlation = clean.map((left) => clean.map((right) => correlationCoefficient(left.returns, right.returns) ?? 0));
  const combined = clean.flatMap((item) => item.returns);
  const shock = options.stressShock ?? -0.05;
  const baselineMean = mean(combined);
  const status: RiskStatus = reasons.includes("NO_RETURN_SERIES") || reasons.includes("INSUFFICIENT_SAMPLE") ? "PENDING" : reasons.includes("DUPLICATE_SYMBOL") ? "BLOCKED" : "READY";
  return { status, symbols, sampleSize: clean.length ? Math.min(...clean.map((item) => item.returns.length)) : 0, annualizedVolatility: volatilities, correlation, riskParityWeights: weights, historicalVaR: historicalVaR(combined, options.confidence, options.minimumSample), stress: { shock, baselineMean, shockedMean: baselineMean === null ? null : baselineMean + shock }, reasons };
}
