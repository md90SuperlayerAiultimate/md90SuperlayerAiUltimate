import type { ArtifactParity } from "./artifactParity";
import type { ProtectivePolicy } from "./protectivePolicy";
import { strategyConfig } from "./strategyConfig";

export type PaperTradeProposal = {
  authority: "ADVISORY_ONLY";
  outcome: "PAPER_CANDIDATE" | "REVIEW" | "BLOCKED";
  direction: "BUY" | "SELL" | "NONE";
  entry: number | null;
  stop: number | null;
  takeProfit: number | null;
  partialExit: { triggerRiskMultiple: number; fractionPct: number; state: "ADVISORY_ONLY" };
  timeStop: { configuredBars: number; observedBars: number | null; state: "NOT_EVALUATED" | "PENDING" | "PAPER_EXIT_REVIEW" };
  multiTimeframe: { base: string; htf: string; independent: boolean; state: "MISSING" | "CONFIRMED" };
  reasonCodes: string[];
  executionAuthority: "DISABLED";
};

export function proposePaperTrade(input: { parity: ArtifactParity; protection: ProtectivePolicy; baseTimeframe: string; htfTimeframe: string; independentHtf: boolean; durablePositionBars?: number | null }): PaperTradeProposal {
  const reasonCodes = [...input.protection.reasonCodes];
  const multiTimeframe = { base: input.baseTimeframe, htf: input.htfTimeframe, independent: input.independentHtf, state: input.independentHtf ? "CONFIRMED" as const : "MISSING" as const };
  if (!input.independentHtf) reasonCodes.push("independent-htf-evidence-required");
  const observedBars = input.durablePositionBars ?? null;
  const timeStopState = observedBars === null ? "NOT_EVALUATED" as const : observedBars >= strategyConfig.fusion.timeStopBars ? "PAPER_EXIT_REVIEW" as const : "PENDING" as const;
  if (timeStopState === "NOT_EVALUATED") reasonCodes.push("durable-position-age-required");
  const direction = input.parity.fusion.direction === "BUY" || input.parity.fusion.direction === "SELL" ? input.parity.fusion.direction : "NONE";
  if (direction === "NONE" || !input.parity.levels) reasonCodes.push("directional-atr-levels-required");
  const entry = input.parity.levels?.entry ?? null;
  const parityStop = input.parity.levels?.stop ?? null;
  const inferredAtr = entry && parityStop ? Math.abs(entry - parityStop) / 1.5 : null;
  const stop = entry && inferredAtr && direction !== "NONE" ? Number((direction === "BUY" ? entry - inferredAtr * strategyConfig.fusion.slAtrFactor : entry + inferredAtr * strategyConfig.fusion.slAtrFactor).toFixed(8)) : null;
  const takeProfit = entry && stop && direction !== "NONE" ? Number((direction === "BUY" ? entry + Math.abs(entry - stop) * strategyConfig.fusion.tpRR : entry - Math.abs(entry - stop) * strategyConfig.fusion.tpRR).toFixed(8)) : null;
  const blocked = input.protection.outcome === "BLOCKED";
  const candidate = input.protection.outcome === "PAPER_CANDIDATE" && input.independentHtf && Boolean(stop && takeProfit);
  return {
    authority: "ADVISORY_ONLY",
    outcome: blocked ? "BLOCKED" : candidate ? "PAPER_CANDIDATE" : "REVIEW",
    direction,
    entry,
    stop,
    takeProfit,
    partialExit: { triggerRiskMultiple: 1, fractionPct: 50, state: "ADVISORY_ONLY" },
    timeStop: { configuredBars: strategyConfig.fusion.timeStopBars, observedBars, state: timeStopState },
    multiTimeframe,
    reasonCodes: Array.from(new Set(reasonCodes)),
    executionAuthority: "DISABLED",
  };
}
