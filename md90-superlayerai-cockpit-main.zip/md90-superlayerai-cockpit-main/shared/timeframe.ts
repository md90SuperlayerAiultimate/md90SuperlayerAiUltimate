export const BASE_TIMEFRAMES = ["1m", "3m", "5m", "15m", "30m", "1h", "4h", "1d", "1M"] as const;
export const HTF_TIMEFRAMES = ["same", ...BASE_TIMEFRAMES] as const;

export type BaseTimeframe = (typeof BASE_TIMEFRAMES)[number];
export type HtfTimeframe = (typeof HTF_TIMEFRAMES)[number];
export type TimeframeSyncStatus = "SYNCED" | "MISMATCH" | "PENDING";

export type CanonicalTimeframe = {
  base: BaseTimeframe;
  htf: HtfTimeframe;
  symbol: string;
  source: "PAPER_REPLAY" | "TRADINGVIEW_WIDGET";
  timezone: "Etc/UTC";
  updatedAt: number;
};

export const canonicalTimeframe: CanonicalTimeframe = {
  base: "15m",
  htf: "4h",
  symbol: "BINANCE:BTCUSDT",
  source: "PAPER_REPLAY",
  timezone: "Etc/UTC",
  updatedAt: 0,
};

export function normalizeTimeframe(value: string): BaseTimeframe | HtfTimeframe {
  const raw = value.trim();
  const normalized = raw.toLowerCase();
  if (normalized === "m1" || normalized === "1min" || normalized === "1minute") return "1m";
  if (normalized === "m3" || normalized === "3min" || normalized === "3minute") return "3m";
  if (normalized === "m5" || normalized === "5min" || normalized === "5minute") return "5m";
  if (normalized === "15" || normalized === "15m" || normalized === "15min") return "15m";
  if (normalized === "30" || normalized === "30m" || normalized === "30min") return "30m";
  if (normalized === "60" || normalized === "1h" || normalized === "1hour") return "1h";
  if (normalized === "240" || normalized === "4h" || normalized === "4hour") return "4h";
  if (normalized === "d" || normalized === "1d" || normalized === "daily") return "1d";
  if (raw === "1M" || normalized === "1mo" || normalized === "1month" || normalized === "monthly") return "1M";
  if (normalized === "same" || normalized === "chart") return "same";
  return "15m";
}

export function timeframeToTradingViewInterval(value: BaseTimeframe | HtfTimeframe): string {
  const intervals: Record<BaseTimeframe, string> = { "1m": "1", "3m": "3", "5m": "5", "15m": "15", "30m": "30", "1h": "60", "4h": "240", "1d": "D", "1M": "M" };
  return value === "same" ? intervals[canonicalTimeframe.base] : intervals[value];
}

export function getTimeframeSyncStatus(base: BaseTimeframe, chart: BaseTimeframe | HtfTimeframe, htf: HtfTimeframe): TimeframeSyncStatus {
  if (chart === base && (htf === "same" || htf !== base)) return "SYNCED";
  return "MISMATCH";
}

export function formatTimeframe(value: BaseTimeframe | HtfTimeframe): string {
  return value === "same" ? "Same TF" : value.toUpperCase();
}
