import { parityIndicatorNames, type ParityIndicatorName } from "./numericParity";

export type SourceVector = Partial<Record<ParityIndicatorName, number | null>>;

export type SourceVectorEvidence = {
  artifactName: string;
  artifactChecksum: string;
  lineRange: string;
  formulaVersion: string;
  symbol: string;
  interval: string;
  vector: SourceVector;
  sourceTimestamp?: string;
};

export type SourceVectorValidation =
  | { ok: true; evidence: SourceVectorEvidence; key: string }
  | { ok: false; reason: "ARTIFACT_CHECKSUM_REQUIRED" | "LINE_RANGE_REQUIRED" | "FORMULA_VERSION_REQUIRED" | "VECTOR_REQUIRED" | "VECTOR_VALUE_INVALID" };

export type ExtractedSourceVector = {
  vector: SourceVector;
  lineRange: string;
  matchedLines: Partial<Record<ParityIndicatorName, number>>;
  unresolved: ParityIndicatorName[];
};

const aliases: Record<ParityIndicatorName, string[]> = {
  macdHistogram: ["macdhistogram", "macd_histogram", "macd histogram", "macdhist"],
  obv: ["obv"],
  mfi: ["mfi", "money flow index"],
  vwap: ["vwap"],
  bollingerWidthPct: ["bollingerwidthpct", "bollinger_width_pct", "bollinger width", "bbwidth"],
  volumeRatio: ["volumeratio", "volume_ratio", "volume ratio"],
  buyPressurePct: ["buypressurepct", "buy_pressure_pct", "buy pressure", "buypressure"],
};

function normalizeKey(value: string) {
  return value.toLowerCase().replace(/[\[\]().%:$'"`]/g, "").replace(/[-\s]+/g, "_");
}

function findIndicator(line: string): ParityIndicatorName | undefined {
  const normalized = normalizeKey(line);
  return parityIndicatorNames.find((indicator) => aliases[indicator].some((alias) => normalized.includes(normalizeKey(alias))));
}

function extractNumber(line: string): number | undefined {
  const match = line.match(/(?:=|:|=>|\bvalue\b\s*)\s*(-?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?)/i);
  if (!match) return undefined;
  const value = Number(match[1]);
  return Number.isFinite(value) ? value : undefined;
}

export function extractSourceVectorArtifact(text: string): ExtractedSourceVector {
  const vector: SourceVector = {};
  const matchedLines: Partial<Record<ParityIndicatorName, number>> = {};
  const lines = text.split(/\r?\n/);
  lines.forEach((line, index) => {
    const indicator = findIndicator(line);
    const value = extractNumber(line);
    if (indicator && value !== undefined && vector[indicator] === undefined) {
      vector[indicator] = value;
      matchedLines[indicator] = index + 1;
    }
  });
  const lineValues = Object.values(matchedLines);
  const lineRange = lineValues.length ? `L${Math.min(...lineValues)}-L${Math.max(...lineValues)}` : "";
  return { vector, lineRange, matchedLines, unresolved: parityIndicatorNames.filter((indicator) => vector[indicator] === undefined) };
}

export function validateSourceVectorEvidence(input: SourceVectorEvidence): SourceVectorValidation {
  if (!/^[a-f0-9]{64}$/i.test(input.artifactChecksum)) return { ok: false, reason: "ARTIFACT_CHECKSUM_REQUIRED" };
  if (!input.artifactName.trim() || !input.lineRange.trim()) return { ok: false, reason: "LINE_RANGE_REQUIRED" };
  if (!input.formulaVersion.trim()) return { ok: false, reason: "FORMULA_VERSION_REQUIRED" };
  const entries = Object.entries(input.vector);
  if (!entries.length) return { ok: false, reason: "VECTOR_REQUIRED" };
  if (entries.some(([name, value]) => !parityIndicatorNames.includes(name as ParityIndicatorName) || (value !== null && (typeof value !== "number" || !Number.isFinite(value))))) return { ok: false, reason: "VECTOR_VALUE_INVALID" };
  return { ok: true, evidence: input, key: sourceVectorKey(input) };
}

export function sourceVectorKey(input: Pick<SourceVectorEvidence, "artifactChecksum" | "symbol" | "interval" | "lineRange" | "formulaVersion">) {
  return [input.artifactChecksum.toLowerCase(), input.symbol, input.interval, input.lineRange, input.formulaVersion].join(":");
}

export const artifactVectorCatalog = [
  { artifactName: "MD90_ALLIN_FIXED.pine.txt", artifactChecksum: null, lineRange: "source upload required", formulaVersion: "pine-17-layer-5-gate", status: "PENDING_SOURCE_FILE" as const },
  { artifactName: "data_provider.py + detectors.py", artifactChecksum: null, lineRange: "source upload required", formulaVersion: "python-indicator-contract-v1", status: "PENDING_SOURCE_FILE" as const },
  { artifactName: "Ultimate Fusion MQL5 EA", artifactChecksum: null, lineRange: "source upload required", formulaVersion: "mql5-fusion-v9-imp", status: "PENDING_SOURCE_FILE" as const },
  { artifactName: "pasted_content.txt", artifactChecksum: "f15dc7188f647a62fe1790673de977c66875ba0e898bd854b31f9e2e0af97c2c", lineRange: "MQL5 payload L1-L1498; vector fixture assignment not established", formulaVersion: "mql5-fusion-pro-advanced-v1-static-audit", status: "PENDING_VECTOR" as const },
  { artifactName: "pasted_content_2.txt", artifactChecksum: "8dc7ca756d44fd072568a73d0d0a987463058ce9c73d9549d64666e09b7abef2", lineRange: "mixed Pine/MQL payload; split required", formulaVersion: "pine-mql5-mixed-static-audit", status: "PENDING_VECTOR" as const },
  { artifactName: "pasted_content_3.txt", artifactChecksum: "f74710b638f8f4429a04fd50face3ab83ec65d5b4b32125cedc13cb38fc4b2aa", lineRange: "no canonical vector assignment found", formulaVersion: "pine-supreme-battle-static-audit", status: "PENDING_VECTOR" as const },
  { artifactName: "pasted_content_4.txt", artifactChecksum: "c6c2f8ea8f94a229f415b55e0fe18b3077558997a6f1f84d1db2dd1e7257d0d6", lineRange: "tuple/syntax review required", formulaVersion: "pine-mega-konfluensi-static-audit", status: "PENDING_VECTOR" as const },
  { artifactName: "pasted_content_5.txt", artifactChecksum: "2d15f3dd1abf55f56f592a45b7992e79072d4c612e0e8f8170871af9ec4c08b8", lineRange: "no canonical vector assignment found", formulaVersion: "pine-matari-fusion-v9-static-audit", status: "PENDING_VECTOR" as const },
  { artifactName: "pasted_content_6.txt", artifactChecksum: "a269d5af016041ada0ba63316f1c50a2d89a42cd08e1d053345c61a2b537d724", lineRange: "no canonical vector assignment found", formulaVersion: "pine-hedgefusion-v1-static-audit", status: "PENDING_VECTOR" as const },
] as const;
