import { describe, expect, it } from "vitest";
import { buildCrossInstrumentAttribution } from "./crossInstrumentAttribution";

describe("cross-instrument attribution", () => {
  it("aggregates instrument contributions without changing source metrics", () => {
    const result = buildCrossInstrumentAttribution([
      { symbol: "EURUSD", ingestionId: 1, checksum: "e".repeat(64), replay: { trades: 10, wins: 6, losses: 4, flats: 0, outOfSampleWinRatePct: 60, realizedPnl: 100, expectancy: 10, maxDrawdownPct: 2, attribution: { longTrades: 6 } } },
      { symbol: "XAUUSD", ingestionId: 2, checksum: "x".repeat(64), replay: { trades: 5, wins: 2, losses: 3, flats: 0, outOfSampleWinRatePct: 40, realizedPnl: -25, expectancy: -5, maxDrawdownPct: 4, attribution: { longTrades: 1 } } },
    ]);
    expect(result.aggregate).toMatchObject({ instrumentCount: 2, totalTrades: 15, totalWins: 8, hitRatePct: 53.33, realizedPnl: 75, positiveContributors: ["EURUSD"], negativeContributors: ["XAUUSD"] });
    expect(result.instruments[0]).toMatchObject({ symbol: "EURUSD", checksum: "e".repeat(64), pnlSharePct: 80 });
    expect(result.orderRoute).toBe("DISABLED");
  });
});

  it("builds auditable comparative groups from the same replay windows", () => {
    const result = buildCrossInstrumentAttribution([{ symbol: "EURUSD", ingestionId: 1, checksum: "e".repeat(64), timeframe: "15m", regime: "TREND", riskBlockReasons: ["NEWS_LOCK"], replay: { trades: 2, wins: 1, losses: 1, flats: 0, outOfSampleWinRatePct: 50, realizedPnl: 12, expectancy: 6, maxDrawdownPct: 1, windows: [{ outcome: "WIN", pnl: 8, testTimestamp: "2026-06-01T00:00:00Z", regime: "TREND", timeframe: "15m" }, { outcome: "LOSS", pnl: 4, testTimestamp: "2026-06-02T00:00:00Z", regime: "RANGE", timeframe: "15m", riskBlockReason: "VOLATILITY_LOCK" }] } }]);
    expect(result.reportVersion).toBe("cross-instrument-attribution-v2");
    expect(result.comparativeGroups).toEqual(expect.arrayContaining([
      expect.objectContaining({ dimension: "instrument", value: "EURUSD", trades: 2 }),
      expect.objectContaining({ dimension: "timeframe", value: "15m" }),
      expect.objectContaining({ dimension: "regime", value: "TREND" }),
      expect.objectContaining({ dimension: "risk_block_reason", value: "NEWS_LOCK", riskBlocks: 1 }),
      expect.objectContaining({ dimension: "oos_window", value: "2026-06-01" }),
    ]));
  });
