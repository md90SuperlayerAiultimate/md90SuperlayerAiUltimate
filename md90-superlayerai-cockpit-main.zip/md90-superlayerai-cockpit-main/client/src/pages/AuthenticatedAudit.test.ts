import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const source = readFileSync(resolve(process.cwd(), "client/src/pages/AuthenticatedAudit.tsx"), "utf8");

describe("AuthenticatedAudit protected E2E surface", () => {
  it("gates paper, shadow, and news queries on the authenticated session", () => {
    expect(source).toContain("trpc.auth.me.useQuery()");
    expect(source).toContain("trpc.paper.overview.useQuery(undefined, { enabled: authenticated })");
    expect(source).toContain("trpc.shadow.observations.useQuery(undefined, { enabled: authenticated })");
    expect(source).toContain("trpc.intel.news.useQuery(undefined, { enabled: authenticated })");
  });

  it("covers the authenticated audit in both Indonesian and English", () => {
    expect(source).toContain('useState<"ID" | "EN">("ID")');
    expect(source).toContain('setLanguage(id ? "EN" : "ID")');
    expect(source).toContain("Verifikasi persistence & akses");
    expect(source).toContain("Persistence & access verification");
    expect(source).toContain("Tidak ada API key");
    expect(source).toContain("No API key, seed phrase, private key");
  });

  it("keeps live and custody paths explicitly absent", () => {
    expect(source).toContain('live: "Live route"');
    expect(source).toContain("DISABLED");
    expect(source).toContain("No API key, seed phrase, private key, signing, deposit, withdrawal, or network order");
    expect(source).not.toMatch(/\b(placeOrder|createOrder|signTransaction|sendTransaction|withdraw)\s*\(/i);
  });
});
