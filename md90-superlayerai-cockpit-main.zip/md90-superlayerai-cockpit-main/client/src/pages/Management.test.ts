import { describe, expect, it } from "vitest";
import { resolveManagementIntake } from "@/lib/managementIntake";

const base = { apiKey: "key-123456789", walletAddress: "", scopeConfirmed: true, requestedScopes: ["market-data", "read-only"] };

describe("Management Plane credential intake", () => {
  it("returns a local-review success and instructs the page to clear the secret", () => {
    expect(resolveManagementIntake(base)).toMatchObject({ ok: true, clearSecret: true });
  });

  it("maps confirmation, secret, wallet, and forbidden-scope failures", () => {
    expect(resolveManagementIntake({ ...base, scopeConfirmed: false })).toMatchObject({ ok: false, reason: "scope-unconfirmed", clearSecret: false });
    expect(resolveManagementIntake({ ...base, apiKey: "0x" + "a".repeat(64) })).toMatchObject({ ok: false, reason: "secret-input" });
    expect(resolveManagementIntake({ ...base, walletAddress: "not-a-wallet" })).toMatchObject({ ok: false, reason: "wallet-format" });
    expect(resolveManagementIntake({ ...base, requestedScopes: ["trade"] })).toMatchObject({ ok: false, reason: "scope-forbidden" });
  });
});
