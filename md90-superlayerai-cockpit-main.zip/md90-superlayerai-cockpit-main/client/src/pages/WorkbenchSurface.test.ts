import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const root = resolve(import.meta.dirname, "../../..");
const app = readFileSync(resolve(root, "client/src/App.tsx"), "utf8");
const workbench = readFileSync(resolve(root, "client/src/pages/WorkbenchSurface.tsx"), "utf8");
const css = readFileSync(resolve(root, "client/src/index.css"), "utf8");

describe("operator workbench route contract", () => {
  it("registers all lower-surface operator routes", () => {
    expect(app).toContain('path="/market-map"');
    expect(app).toContain('path="/risk-lab"');
    expect(app).toContain('path="/replay"');
    expect(app).toContain('path="/audit-log"');
    expect(app).toContain("component={WorkbenchSurface}");
  });

  it("keeps every lower surface on one canonical snapshot and context", () => {
    expect(workbench).toContain("trpc.cockpit.snapshot.useQuery");
    expect(workbench).toContain("useTimeframe");
    expect(workbench).toContain("MarketContextControls");
    expect(workbench).toContain("paper.decide.useMutation");
    expect(workbench).toContain("paper.sync.useMutation");
    expect(workbench).toContain("paper.close.useMutation");
    expect(workbench).toContain("paper.retry.useMutation");
    expect(workbench).toContain("paper.replay.useQuery");
    expect(workbench).toContain("paper.journal.useQuery");
    expect(workbench).toContain("paper.learning.useQuery");
    expect(workbench).toContain("paper.timeStop.useQuery");
    expect(workbench).toContain("paper.commands.useQuery");
    expect(workbench).toContain("datasets.ingest.useMutation");
    expect(workbench).toContain("PROVENANCE DRILL-DOWN");
    expect(workbench).toContain("OPERATOR OBSERVABILITY");
    expect(workbench).toContain("PAPER / SHADOW ONLY");
    expect(workbench).toContain("CLOSE PAPER POSITION");
    expect(workbench).toContain("SYNC EVIDENCE & JOURNAL");
    expect(workbench).toContain("INGEST MANIFEST");
    expect(workbench).toContain("INGEST FX/XAU EVIDENCE");
    expect(workbench).toContain("latestImport?.limitation");
    expect(workbench).toContain("coverage?.classification");
    expect(workbench).toContain("Upload manual FX/XAU historical dataset");
    expect(workbench).toContain("manualSymbol &&");
    expect(workbench).toContain("RETRY PAPER");
    expect(workbench).toContain("COMMAND RUN LEDGER");
    expect(workbench).toContain("RISK_REDUCTION");
    expect(workbench).toContain("LEARNING EVIDENCE");
    expect(workbench).toContain("Auto-tuning, model promotion, and external release remain disabled");
    expect(workbench).toContain("Durable time-stop");
    expect(workbench).toContain("timeStop?.executionAuthority");
    expect(workbench).toContain("artifactProtection");
    expect(workbench).toContain("Protective outcome");
    expect(workbench).toContain("protection?.authority");
    expect(workbench).toContain("artifactTradeProposal");
    expect(workbench).toContain("PAPER trade proposal");
    expect(workbench).toContain("proposal?.executionAuthority");
    expect(workbench).toContain("artifactBoundaryLocks");
    expect(workbench).toContain("Artifact outbound actions");
    expect(workbench).toContain("artifactLocks.length");
    expect(workbench).toContain("Canonical indicator audit");
    expect(workbench).toContain("parity?.indicators");
    expect(workbench).toContain("READ ONLY");
  });

  it("does not introduce network order or custody authority", () => {
    expect(workbench).toContain("LIVE DISABLED");
    expect(workbench).toContain("Network order route: DISABLED");
    expect(workbench).toMatch(/signing, deposit, or withdrawal/i);
    expect(workbench).not.toMatch(/placeOrder\s*\(|createOrder\s*\(|signTransaction\s*\(/);
  });

  it("has a responsive visual contract for the operator workbench", () => {
    expect(css).toContain(".workbench-shell");
    expect(css).toContain(".workbench-tabs");
    expect(css).toContain(".risk-lab-grid");
    expect(css).toContain(".replay-control-card");
    expect(css).toContain(".provenance-drawer");
    expect(css).toContain(".observability-grid");
    expect(css).toContain(".paper-close-control");
    expect(css).toContain(".command-row");
    expect(css).toContain(".manual-ingest-control");
    expect(css).toContain(".command-action");
    expect(css).toContain("@media(max-width:560px)");
  });
});
