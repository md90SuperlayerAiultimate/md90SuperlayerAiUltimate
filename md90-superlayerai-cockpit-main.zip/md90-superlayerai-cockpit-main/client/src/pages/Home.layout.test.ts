import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("Overview workstation first-viewport contract", () => {
  const home = readFileSync(resolve(process.cwd(), "client/src/pages/Home.tsx"), "utf8");
  const css = readFileSync(resolve(process.cwd(), "client/src/index.css"), "utf8");

  it("keeps the operational evidence selectors in the Overview structure", () => {
    expect(home).toContain('className="metrics-strip"');
    expect(home).toContain('className="metric-label">DATA FRESHNESS');
    expect(home).toContain("signal-panel");
    expect(home).toContain("risk-panel");
    expect(home).toContain('className="compact-tape"');
    expect(home).toContain('className="main-chart candle-chart"');
    expect(home).toContain('className="terminal-command-deck"');
    expect(home).toContain('className="terminal-control-grid"');
    expect(home).toContain('className="terminal-open"');
    expect(home).not.toContain('className="hero-panel"');
    expect(home).toContain('const focusPanel =');
    expect(home).not.toContain('notifySoon');
    expect(home).toContain('navigate("/signal-room")');
    expect(home).toContain('PaperWorkflowPanel');
  });

  it("provides synchronized artifact search and status filtering without mutating the registry", () => {
    expect(home).toContain('aria-label="Search synchronized artifacts"');
    expect(home).toContain('aria-label="Filter artifact status"');
    expect(home).toContain('className="artifact-filters"');
    expect(home).toContain('className="artifact-empty"');
    expect(home).toContain('setArtifactQuery("")');
    expect(home).toContain('setArtifactStatus("ALL")');
    expect(home).toContain('moduleRows.filter');
    expect(css).toContain(".artifact-filters {");
    expect(css).toContain(".artifact-empty {");
  });

  it("defines a bounded desktop/mobile budget for the identity and chart surfaces", () => {
    expect(css).toContain(".terminal-command-deck {");
    expect(css).toContain(".terminal-control-grid {");
    expect(css).toContain(".hero-panel { height: 180px");
    expect(css).toContain(".workspace-grid .chart-wrap { height: 165px");
    expect(css).toContain("@media (max-width: 520px) { .workspace-grid .chart-wrap { height: 222px; }");
    expect(css).not.toMatch(/\.main-chart[^}]*display:\s*none/);
    expect(css).not.toMatch(/\.risk-panel[^}]*display:\s*none/);
  });
});
