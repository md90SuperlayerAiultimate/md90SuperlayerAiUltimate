import { describe, expect, it } from "vitest";
import { DEFAULT_INSTRUMENT, INSTRUMENTS, getInstrument } from "@shared/instruments";
import { BASE_TIMEFRAMES, HTF_TIMEFRAMES, timeframeToTradingViewInterval } from "@shared/timeframe";
import { readFileSync } from "node:fs";

const source = readFileSync(new URL("./MarketContextControls.tsx", import.meta.url), "utf8");
const workflow = readFileSync(new URL("./PaperWorkflowPanel.tsx", import.meta.url), "utf8");

describe("global MTFA and paper workflow contracts", () => {
  it("keeps instrument registry and TradingView mapping deterministic", () => {
    expect(DEFAULT_INSTRUMENT.id).toBe("BTCUSDT");
    expect(INSTRUMENTS.map((item) => item.id)).toEqual(["BTCUSDT", "ETHUSDT", "SOLUSDT", "EURUSD", "XAUUSD"]);
    expect(getInstrument("xauusd").tradingView).toBe("OANDA:XAUUSD");
    expect(timeframeToTradingViewInterval("4h")).toBe("240");
    expect(BASE_TIMEFRAMES).toContain("15m");
    expect(HTF_TIMEFRAMES).toContain("4h");
  });

  it("exposes one control plane and paper-only workflow actions", () => {
    expect(source).toContain("setInstrument");
    expect(source).toContain("setBase");
    expect(source).toContain("setHtf");
    expect(workflow).toContain("MARKET MAP");
    expect(workflow).toContain("RISK LAB");
    expect(workflow).toContain("RUN PAPER DECISION");
    expect(workflow).toContain("LIVE DISABLED");
    expect(workflow).toContain("deposit");
    expect(workflow).toContain("withdrawal");
    expect(workflow).not.toContain("signTransaction");
    expect(workflow).not.toContain("placeOrder");
  });
});
