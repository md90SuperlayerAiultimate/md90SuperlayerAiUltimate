import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const read = (file: string) => readFileSync(resolve(process.cwd(), file), "utf8");

describe("direct authenticated scope visibility", () => {
  it("reads the authenticated session and exposes a fail-visible scope state", () => {
    const source = read("client/src/components/AuthenticatedScopeBadge.tsx");
    expect(source).toContain("trpc.auth.me.useQuery");
    expect(source).toContain("trpc.paper.overview.useQuery");
    expect(source).toContain("trpc.shadow.observations.useQuery");
    expect(source).toContain("trpc.intel.news.useQuery");
    expect(source).toContain("READ / WRITE");
    expect(source).toContain("REFRESHED");
    expect(source).toContain("AUTHENTICATED");
    expect(source).toContain("DEMO SESSION");
    expect(source).toContain("ERROR");
  });

  it("is wired to every institutional surface with language controls", () => {
    for (const page of ["Home.tsx", "Management.tsx", "ResearchDesk.tsx", "SignalRoom.tsx"]) {
      const source = read(`client/src/pages/${page}`);
      expect(source).toContain("AuthenticatedScopeBadge");
      expect(source).toContain("setLanguage");
    }
  });
});
