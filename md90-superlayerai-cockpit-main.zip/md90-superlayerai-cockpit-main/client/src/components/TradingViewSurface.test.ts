import { describe, expect, it } from "vitest";
import { buildMtfaRows, buildTradingViewUrl, transitionTradingViewStatus } from "./TradingViewSurface";

describe("TradingView research surface", () => {
  it("transitions explicitly between connecting, connected, and unavailable", () => {
    expect(transitionTradingViewStatus("selection-changed")).toBe("CONNECTING");
    expect(transitionTradingViewStatus("load")).toBe("CONNECTED");
    expect(transitionTradingViewStatus("error")).toBe("UNAVAILABLE");
  });

  it("maps base, HTF, and context rows for synchronized MTFA", () => {
    const rows = buildMtfaRows("15m", "4h");
    expect(rows).toHaveLength(9);
    expect(rows.find((row) => row.interval === "15m")).toMatchObject({ role: "BASE", selected: true, tvInterval: "15" });
    expect(rows.find((row) => row.interval === "4h")).toMatchObject({ role: "HTF", selected: true, tvInterval: "240" });
    expect(rows.find((row) => row.interval === "1h")).toMatchObject({ role: "CONTEXT", selected: false, tvInterval: "60" });
    expect(rows.find((row) => row.interval === "1m")).toMatchObject({ role: "CONTEXT", selected: false, tvInterval: "1" });
    expect(rows.find((row) => row.interval === "1M")).toMatchObject({ role: "CONTEXT", selected: false, tvInterval: "M" });
    expect(buildMtfaRows("1h", "same").every((row) => row.selected === (row.interval === "1h"))).toBe(true);
  });

  it("builds a read-only widget URL with selected symbol and timeframe", () => {
    const url = buildTradingViewUrl("BINANCE:BTCUSDT", "1h");
    expect(url).toContain("symbol=BINANCE%3ABTCUSDT");
    expect(url).toContain("interval=60");
    expect(url).toContain("symboledit=0");
    expect(url).not.toContain("apiKey");
    expect(url).not.toContain("order");
  });
});
