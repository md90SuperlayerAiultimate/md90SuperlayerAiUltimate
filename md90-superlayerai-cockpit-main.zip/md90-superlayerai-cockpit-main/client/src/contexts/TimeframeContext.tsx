import { createContext, useContext, useMemo, useState } from "react";
import { canonicalTimeframe, formatTimeframe, getTimeframeSyncStatus, timeframeToTradingViewInterval, type BaseTimeframe, type CanonicalTimeframe, type HtfTimeframe } from "@shared/timeframe";
import { DEFAULT_INSTRUMENT, getInstrument, type InstrumentId } from "@shared/instruments";

const TimeframeContext = createContext<{
  timeframe: CanonicalTimeframe;
  instrument: ReturnType<typeof getInstrument>;
  setBase: (base: BaseTimeframe) => void;
  setHtf: (htf: HtfTimeframe) => void;
  setInstrument: (id: InstrumentId) => void;
} | null>(null);

export function TimeframeProvider({ children }: { children: React.ReactNode }) {
  const [base, setBase] = useState<BaseTimeframe>(canonicalTimeframe.base);
  const [htf, setHtf] = useState<HtfTimeframe>(canonicalTimeframe.htf);
  const [instrumentId, setInstrumentId] = useState<InstrumentId>(DEFAULT_INSTRUMENT.id);
  const instrument = useMemo(() => getInstrument(instrumentId), [instrumentId]);
  const timeframe = useMemo(() => ({ ...canonicalTimeframe, base, htf, symbol: instrument.tradingView, updatedAt: Date.now() }), [base, htf, instrument]);
  const value = useMemo(() => ({ timeframe, instrument, setBase, setHtf, setInstrument: setInstrumentId }), [timeframe, instrument]);
  return <TimeframeContext.Provider value={value}>{children}</TimeframeContext.Provider>;
}

export function useTimeframe() {
  const context = useContext(TimeframeContext);
  if (!context) throw new Error("useTimeframe must be used within TimeframeProvider");
  return context;
}

export function TimeframeLineage() {
  const { timeframe, instrument } = useTimeframe();
  const sync = getTimeframeSyncStatus(timeframe.base, timeframe.base, timeframe.htf);
  return <div className="timeframe-lineage" aria-label="Canonical instrument and timeframe lineage"><span>/ MARKET CONTEXT</span><strong>{instrument.label}</strong><span>/ BASE</span><strong>{formatTimeframe(timeframe.base)}</strong><span>→ HTF {formatTimeframe(timeframe.htf)}</span><span>{timeframeToTradingViewInterval(timeframe.base)} TV</span><b className={sync === "SYNCED" ? "timeframe-synced" : "timeframe-mismatch"}>{sync}</b>{sync === "MISMATCH" && <span role="alert">chart mismatch · paper signal paused</span>}</div>;
}
