import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const source = readFileSync(resolve(process.cwd(), "client/src/main.tsx"), "utf8");

describe("public render authentication boundary", () => {
  it("does not replace the public cockpit with a global OAuth redirect", () => {
    expect(source).not.toContain("redirectToLoginIfUnauthorized");
    expect(source).not.toContain('import { startLogin } from "./const"');
    expect(source).toContain("createRoot(document.getElementById(\"root\")!).render(");
    expect(source).toContain("<App />");
  });
});
