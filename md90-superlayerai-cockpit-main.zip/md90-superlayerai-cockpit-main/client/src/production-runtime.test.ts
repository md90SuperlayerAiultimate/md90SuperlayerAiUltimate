import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const viteSource = readFileSync(resolve(process.cwd(), "vite.config.ts"), "utf8");
const authSource = readFileSync(
  resolve(process.cwd(), "client/src/_core/hooks/useAuth.ts"),
  "utf8"
);
const indexSource = readFileSync(resolve(process.cwd(), "client/index.html"), "utf8");

describe("production runtime hardening", () => {
  it("does not force a manual vendor split that can create a React chunk cycle", () => {
    expect(viteSource).not.toContain("manualChunks");
    expect(viteSource).not.toContain('"vendor-react"');
    expect(viteSource).not.toContain('"vendor-core"');
  });

  it("guards runtime user persistence when browser storage is unavailable", () => {
    expect(authSource).toContain('if (typeof window === "undefined") return;');
    expect(authSource).toContain("window.localStorage.setItem");
    expect(authSource).toContain("Storage can be denied");
    expect(authSource).not.toContain('    localStorage.setItem(');
  });

  it("leaves a visible, paper-only fallback when module boot rejects", () => {
    expect(indexSource).toContain('data-boot-fallback');
    expect(indexSource).toContain("unhandledrejection");
    expect(indexSource).toContain("PAPER / SHADOW ONLY · LIVE DISABLED");
  });
});
