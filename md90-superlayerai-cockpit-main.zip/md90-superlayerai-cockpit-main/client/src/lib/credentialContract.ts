import { isForbiddenSecretInput, isPublicWalletAddress } from "./credentialSafety";

export type CredentialIntake = {
  apiKey: string;
  walletAddress: string;
  scopeConfirmed: boolean;
  requestedScopes: string[];
};

export function validateCredentialIntake(input: CredentialIntake) {
  const forbiddenScopes = input.requestedScopes.filter((scope) => !["market-data", "read-only"].includes(scope));
  if (isForbiddenSecretInput(input.apiKey)) return { ok: false as const, reason: "secret-input" as const };
  if (input.walletAddress && !isPublicWalletAddress(input.walletAddress)) return { ok: false as const, reason: "wallet-format" as const };
  if (forbiddenScopes.length) return { ok: false as const, reason: "scope-forbidden" as const };
  if (input.apiKey && !input.scopeConfirmed) return { ok: false as const, reason: "scope-unconfirmed" as const };
  return { ok: true as const, providerVerification: "REQUIRED" as const, permittedScopes: ["market-data", "read-only"] as const };
}
