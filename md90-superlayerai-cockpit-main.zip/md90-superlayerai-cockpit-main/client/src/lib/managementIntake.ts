import { validateCredentialIntake, type CredentialIntake } from "./credentialContract";

export type IntakeResult =
  | { ok: true; clearSecret: true; message: string }
  | { ok: false; clearSecret: false; message: string; reason: string };

const messages: Record<string, string> = {
  "secret-input": "Input ditolak: seed phrase/private key tidak boleh dimasukkan.",
  "wallet-format": "Alamat wallet tidak cocok dengan format publik yang didukung.",
  "scope-forbidden": "Scope ditolak: hanya market-data/read-only yang diizinkan.",
  "scope-unconfirmed": "Konfirmasi read-only diperlukan sebelum menyimpan metadata.",
};

export function resolveManagementIntake(input: CredentialIntake): IntakeResult {
  const validation = validateCredentialIntake(input);
  if (!validation.ok) return { ok: false, clearSecret: false, reason: validation.reason, message: messages[validation.reason] };
  return { ok: true, clearSecret: true, message: "Metadata hanya tersimpan lokal untuk review. Secret cleared; order route tetap disabled." };
}
