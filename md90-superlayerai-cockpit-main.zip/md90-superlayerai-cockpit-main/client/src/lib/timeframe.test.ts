import { describe, expect, it } from "vitest";
import { formatTimeframe, getTimeframeSyncStatus, normalizeTimeframe, timeframeToTradingViewInterval } from "@shared/timeframe";

describe("canonical timeframe contract", () => {
  it("normalizes chart and TradingView values into canonical labels", () => {
    expect(normalizeTimeframe("15")).toBe("15m");
    expect(normalizeTimeframe("240")).toBe("4h");
    expect(normalizeTimeframe("daily")).toBe("1d");
    expect(timeframeToTradingViewInterval("15m")).toBe("15");
    expect(timeframeToTradingViewInterval("4h")).toBe("240");
    expect(formatTimeframe("same")).toBe("Same TF");
  });

  it("fails closed on mismatched chart state", () => {
    expect(getTimeframeSyncStatus("15m", "15m", "4h")).toBe("SYNCED");
    expect(getTimeframeSyncStatus("15m", "1h", "4h")).toBe("MISMATCH");
  });
});
