import { describe, expect, it } from "vitest";
import { isPublicWalletAddress, redactCredential } from "./credentialSafety";

describe("credential safety helpers", () => {
  it("redacts short and long secrets", () => {
    expect(redactCredential("")).toBe("—");
    expect(redactCredential("short")).toBe("••••••••");
    expect(redactCredential("abcd1234567890wxyz")).toBe("abcd••••••••wxyz");
  });

  it("accepts public wallet formats but not seed/private-key style strings", () => {
    expect(isPublicWalletAddress("0x0000000000000000000000000000000000000000")).toBe(true);
    expect(isPublicWalletAddress("not-a-wallet")).toBe(false);
    expect(isPublicWalletAddress("word ".repeat(12))).toBe(false);
  });
});
