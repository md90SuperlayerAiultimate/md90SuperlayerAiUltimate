import { describe, expect, it } from "vitest";
import { validateCredentialIntake } from "./credentialContract";

describe("credential intake contract", () => {
  it("allows only attested market-data/read-only metadata", () => {
    expect(validateCredentialIntake({ apiKey: "read-only-key-123456", walletAddress: "", scopeConfirmed: true, requestedScopes: ["market-data", "read-only"] })).toMatchObject({ ok: true, providerVerification: "REQUIRED" });
    expect(validateCredentialIntake({ apiKey: "read-only-key-123456", walletAddress: "", scopeConfirmed: false, requestedScopes: ["market-data", "read-only"] }).reason).toBe("scope-unconfirmed");
  });

  it("rejects secret material and execution scopes", () => {
    expect(validateCredentialIntake({ apiKey: "0x" + "a".repeat(64), walletAddress: "", scopeConfirmed: true, requestedScopes: ["market-data"] }).reason).toBe("secret-input");
    expect(validateCredentialIntake({ apiKey: "key", walletAddress: "", scopeConfirmed: true, requestedScopes: ["trade"] }).reason).toBe("scope-forbidden");
  });
});
