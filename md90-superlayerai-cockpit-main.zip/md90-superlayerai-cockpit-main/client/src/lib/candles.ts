export type Candle = { timestamp: string; open: number; high: number; low: number; close: number };
export type ProjectedCandle = Candle & { x: number; yHigh: number; yLow: number; yOpen: number; yClose: number; rising: boolean };

export function projectCandles(candles: Candle[], width: number, height: number, padding = 8): ProjectedCandle[] {
  if (!candles.length) return [];
  const min = Math.min(...candles.map((c) => c.low));
  const max = Math.max(...candles.map((c) => c.high));
  const span = Math.max(1, max - min);
  const y = (price: number) => padding + ((max - price) / span) * (height - padding * 2);
  const step = width / candles.length;
  return candles.map((candle, index) => ({ ...candle, x: step * index + step / 2, yHigh: y(candle.high), yLow: y(candle.low), yOpen: y(candle.open), yClose: y(candle.close), rising: candle.close >= candle.open }));
}

export const fallbackReplayPrices = [70220, 70310, 70180, 70490, 70620, 70510, 70840, 70980, 71120, 71040, 71320, 71480, 71390, 71640, 71810, 71740, 71980, 72140, 72080, 72290, 72410, 72350, 72540, 72620];

export function candlesFromPrices(prices: number[], nowMs = Date.now()): Candle[] {
  return prices.slice(-12).map((close, index, recent) => {
    const open = recent[index - 1] ?? close - 45;
    return { timestamp: new Date(nowMs - (recent.length - 1 - index) * 15 * 60 * 1000).toISOString(), open, high: Math.max(open, close) + 38, low: Math.min(open, close) - 32, close };
  });
}
