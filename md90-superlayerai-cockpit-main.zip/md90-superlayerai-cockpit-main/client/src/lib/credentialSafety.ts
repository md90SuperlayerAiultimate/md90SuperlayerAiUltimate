export function redactCredential(value: string) {
  if (!value) return "—";
  if (value.length < 10) return "••••••••";
  return `${value.slice(0, 4)}••••••••${value.slice(-4)}`;
}

export function isPublicWalletAddress(value: string) {
  const normalized = value.trim();
  return /^(0x[a-fA-F0-9]{40}|[1-9A-HJ-NP-Za-km-z]{26,62})$/.test(normalized);
}

export function isForbiddenSecretInput(value: string) {
  const normalized = value.trim();
  const words = normalized.split(/\s+/).filter(Boolean);
  return /private|seed phrase|mnemonic|secret key/i.test(normalized) || /^(0x)?[a-fA-F0-9]{64}$/.test(normalized) || words.length >= 12;
}
