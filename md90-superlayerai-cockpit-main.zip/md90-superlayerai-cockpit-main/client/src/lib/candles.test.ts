import { describe, expect, it } from "vitest";
import { candlesFromPrices, projectCandles } from "./candles";

describe("candlestick projection", () => {
  it("builds ordered OHLC candles from replay prices", () => {
    const candles = candlesFromPrices([100, 102, 101], 1_000_000);
    expect(candles).toHaveLength(3);
    expect(candles[1]?.open).toBe(100);
    expect(candles[1]?.close).toBe(102);
    expect(candles[2]?.close).toBe(101);
  });

  it("projects wick and body coordinates within the chart viewport", () => {
    const projected = projectCandles(candlesFromPrices([100, 102, 101]), 520, 190);
    expect(projected.every((candle) => candle.x >= 0 && candle.x <= 520 && candle.yHigh >= 8 && candle.yLow <= 182)).toBe(true);
    expect(projected[1]?.rising).toBe(true);
    expect(projected[2]?.rising).toBe(false);
  });
});
