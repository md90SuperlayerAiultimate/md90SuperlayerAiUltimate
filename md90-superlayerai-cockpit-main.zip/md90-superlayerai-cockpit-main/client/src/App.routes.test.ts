import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const source = readFileSync(resolve(process.cwd(), "client/src/App.tsx"), "utf8");

describe("lazy route shell", () => {
  it("splits operator surfaces while preserving canonical providers and routes", () => {
    expect(source).toContain('const WorkbenchSurface = lazy(() => import("./pages/WorkbenchSurface"))');
    expect(source).toContain('const Home = lazy(() => import("./pages/Home"))');
    expect(source).toContain("<TimeframeProvider>");
    expect(source).toContain("<Suspense fallback={<RouteLoading />}>");
    for (const route of ["/market-map", "/risk-lab", "/replay", "/audit-log", "/signal-room", "/research-desk", "/management"]) expect(source).toContain(route);
  });
});
