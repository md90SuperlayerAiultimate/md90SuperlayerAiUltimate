import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("mobile workstation layout contract", () => {
  const css = readFileSync(resolve(process.cwd(), "client/src/index.css"), "utf8");

  it("wraps hero copy/actions and keeps the compact tape within mobile columns", () => {
    expect(css).toContain("@media (max-width: 520px)");
    expect(css).toContain(".hero-description { white-space: normal");
    expect(css).toContain(".hero-actions { flex-wrap: wrap");
    expect(css).toContain(".compact-tape-head, .compact-tape-row { grid-template-columns: 52px 1fr 82px");
  });

  it("does not hide the primary chart or risk panel at the mobile breakpoint", () => {
    const mobileBlock = css.slice(css.indexOf("@media (max-width: 520px)"));
    expect(mobileBlock).not.toMatch(/(main-chart|risk-panel)[^}]*display:\s*none/);
    expect(css).toContain(".hero-panel { height: 236px");
    expect(css).toContain(".chart-wrap { height: 222px");
  });
});
