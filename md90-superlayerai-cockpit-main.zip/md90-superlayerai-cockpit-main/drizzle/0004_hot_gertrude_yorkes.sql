CREATE TABLE `demo_accounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(64) NOT NULL,
	`displayName` varchar(120) NOT NULL,
	`startingEquity` double NOT NULL,
	`equity` double NOT NULL,
	`peakEquity` double NOT NULL,
	`realizedPnl` double NOT NULL DEFAULT 0,
	`tradeCount` int NOT NULL DEFAULT 0,
	`wins` int NOT NULL DEFAULT 0,
	`losses` int NOT NULL DEFAULT 0,
	`winRatePct` double NOT NULL DEFAULT 0,
	`maxDrawdownPct` double NOT NULL DEFAULT 0,
	`lastBatchId` varchar(96),
	`lastRunAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `demo_accounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `demo_accounts_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `demo_runs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`accountId` int NOT NULL,
	`batchId` varchar(96) NOT NULL,
	`tradeCount` int NOT NULL,
	`executedAt` timestamp NOT NULL,
	`status` enum('completed','skipped','failed') NOT NULL,
	CONSTRAINT `demo_runs_id` PRIMARY KEY(`id`),
	CONSTRAINT `demo_runs_batchId_unique` UNIQUE(`batchId`)
);
--> statement-breakpoint
CREATE TABLE `demo_trades` (
	`id` int AUTO_INCREMENT NOT NULL,
	`accountId` int NOT NULL,
	`batchId` varchar(96) NOT NULL,
	`instrument` varchar(80) NOT NULL,
	`side` varchar(12) NOT NULL,
	`entryPrice` double NOT NULL,
	`exitPrice` double NOT NULL,
	`quantity` double NOT NULL,
	`pnl` double NOT NULL,
	`fee` double NOT NULL DEFAULT 0,
	`outcome` enum('WIN','LOSS','FLAT') NOT NULL,
	`executedAt` timestamp NOT NULL,
	`provenance` varchar(200) NOT NULL,
	CONSTRAINT `demo_trades_id` PRIMARY KEY(`id`),
	CONSTRAINT `demo_trades_batchId_unique` UNIQUE(`batchId`)
);
