CREATE TABLE `paper_signals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`signalId` varchar(96) NOT NULL,
	`instrument` varchar(80) NOT NULL,
	`bias` varchar(16) NOT NULL,
	`score` int NOT NULL,
	`confidence` int NOT NULL,
	`source` varchar(160) NOT NULL,
	`observedAt` timestamp NOT NULL,
	`provenance` varchar(200) NOT NULL,
	CONSTRAINT `paper_signals_id` PRIMARY KEY(`id`)
);
