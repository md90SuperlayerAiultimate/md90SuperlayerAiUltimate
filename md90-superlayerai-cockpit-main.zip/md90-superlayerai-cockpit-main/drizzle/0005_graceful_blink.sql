CREATE TABLE `demo_equity_points` (
	`id` int AUTO_INCREMENT NOT NULL,
	`accountId` int NOT NULL,
	`batchId` varchar(96) NOT NULL,
	`timestamp` timestamp NOT NULL,
	`equity` double NOT NULL,
	`realizedPnl` double NOT NULL,
	`drawdownPct` double NOT NULL,
	CONSTRAINT `demo_equity_points_id` PRIMARY KEY(`id`),
	CONSTRAINT `demo_equity_points_batchId_unique` UNIQUE(`batchId`)
);
