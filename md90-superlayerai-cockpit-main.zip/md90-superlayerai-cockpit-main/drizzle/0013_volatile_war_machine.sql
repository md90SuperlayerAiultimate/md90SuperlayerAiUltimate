CREATE TABLE `audit_parity_vectors` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`ingestionId` int NOT NULL,
	`symbol` varchar(80) NOT NULL,
	`interval` varchar(16) NOT NULL,
	`source` varchar(240) NOT NULL,
	`datasetChecksum` varchar(80) NOT NULL,
	`expectedJson` text NOT NULL,
	`actualJson` text NOT NULL,
	`tolerance` varchar(32) NOT NULL,
	`parityStatus` enum('MATCH','MISMATCH','NOT_EVALUATED') NOT NULL,
	`provenance` varchar(300) NOT NULL,
	`sourceTimestamp` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_parity_vectors_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `audit_parity_user_ingestion_idx` ON `audit_parity_vectors` (`userId`,`ingestionId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `audit_parity_checksum_idx` ON `audit_parity_vectors` (`datasetChecksum`,`createdAt`);