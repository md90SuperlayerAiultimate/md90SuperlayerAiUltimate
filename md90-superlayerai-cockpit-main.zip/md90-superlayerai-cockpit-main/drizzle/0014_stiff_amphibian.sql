CREATE TABLE `paper_replay_runs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`ingestionId` int NOT NULL,
	`correlationId` varchar(160) NOT NULL,
	`trainBars` int NOT NULL,
	`testBars` int NOT NULL,
	`strategyVersion` varchar(80) NOT NULL,
	`sourceChecksum` varchar(80) NOT NULL,
	`status` enum('READY','BLOCKED','FAILED') NOT NULL,
	`metricsJson` text NOT NULL,
	`orderRoute` varchar(40) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `paper_replay_runs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `audit_parity_vectors` MODIFY COLUMN `parityStatus` enum('MATCH','MISMATCH','NOT_EVALUATED','EVIDENCE_REQUIRED') NOT NULL;--> statement-breakpoint
CREATE INDEX `paper_replay_user_created_idx` ON `paper_replay_runs` (`userId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `paper_replay_ingestion_created_idx` ON `paper_replay_runs` (`ingestionId`,`createdAt`);