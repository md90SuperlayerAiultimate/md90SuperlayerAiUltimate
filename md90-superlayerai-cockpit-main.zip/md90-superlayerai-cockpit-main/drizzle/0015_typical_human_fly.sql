CREATE TABLE `paper_attribution_reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`reportKey` varchar(180) NOT NULL,
	`correlationId` varchar(160) NOT NULL,
	`ingestionIdsJson` text NOT NULL,
	`sourceChecksumsJson` text NOT NULL,
	`metricsJson` text NOT NULL,
	`authority` varchar(40) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `paper_attribution_reports_id` PRIMARY KEY(`id`),
	CONSTRAINT `paper_attribution_reports_reportKey_unique` UNIQUE(`reportKey`)
);
--> statement-breakpoint
ALTER TABLE `audit_parity_vectors` ADD `sourceArtifactChecksum` varchar(80);--> statement-breakpoint
ALTER TABLE `audit_parity_vectors` ADD `sourceLineRange` varchar(80);--> statement-breakpoint
ALTER TABLE `audit_parity_vectors` ADD `formulaVersion` varchar(120);--> statement-breakpoint
CREATE INDEX `paper_attribution_user_created_idx` ON `paper_attribution_reports` (`userId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `paper_attribution_correlation_idx` ON `paper_attribution_reports` (`correlationId`,`createdAt`);