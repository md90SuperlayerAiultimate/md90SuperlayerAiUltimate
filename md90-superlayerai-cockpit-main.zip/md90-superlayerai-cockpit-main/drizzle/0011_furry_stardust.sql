ALTER TABLE `paper_positions` ADD `openedAt` timestamp DEFAULT (now()) NOT NULL;--> statement-breakpoint
ALTER TABLE `paper_positions` ADD `barClockAt` timestamp;--> statement-breakpoint
ALTER TABLE `paper_positions` ADD `barsHeld` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `paper_positions` ADD `baseTimeframe` varchar(16) DEFAULT '15m' NOT NULL;