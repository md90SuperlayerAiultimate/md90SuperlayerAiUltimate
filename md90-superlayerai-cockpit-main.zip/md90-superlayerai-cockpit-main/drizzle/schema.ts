import { double, index, int, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const paperSessions = mysqlTable("paper_sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 120 }).notNull(),
  mode: mysqlEnum("mode", ["paper", "shadow", "replay"]).default("paper").notNull(),
  startingEquity: double("startingEquity").notNull(),
  equity: double("equity").notNull(),
  peakEquity: double("peakEquity").notNull(),
  dailyPnl: double("dailyPnl").default(0).notNull(),
  grossExposure: double("grossExposure").default(0).notNull(),
  realizedPnl: double("realizedPnl").default(0).notNull(),
  unrealizedPnl: double("unrealizedPnl").default(0).notNull(),
  maxDrawdownPct: double("maxDrawdownPct").default(0).notNull(),
  tradeCount: int("tradeCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const paperSnapshots = mysqlTable("paper_snapshots", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  venue: varchar("venue", { length: 40 }).notNull(),
  instrument: varchar("instrument", { length: 80 }).notNull(),
  timestamp: timestamp("timestamp").notNull(),
  bid: double("bid").notNull(),
  ask: double("ask").notNull(),
  last: double("last").notNull(),
  volume24h: double("volume24h"),
  spreadBps: double("spreadBps"),
  source: varchar("source", { length: 160 }).notNull(),
  quality: mysqlEnum("quality", ["valid", "stale", "invalid"]).default("valid").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const paperSignals = mysqlTable("paper_signals", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  signalId: varchar("signalId", { length: 96 }).notNull(),
  instrument: varchar("instrument", { length: 80 }).notNull(),
  bias: varchar("bias", { length: 16 }).notNull(),
  score: int("score").notNull(),
  confidence: int("confidence").notNull(),
  source: varchar("source", { length: 160 }).notNull(),
  observedAt: timestamp("observedAt").notNull(),
  provenance: varchar("provenance", { length: 200 }).notNull(),
});

export const paperOrders = mysqlTable("paper_orders", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  clientOrderId: varchar("clientOrderId", { length: 96 }).notNull().unique(),
  signalId: varchar("signalId", { length: 96 }).notNull(),
  venue: varchar("venue", { length: 40 }).notNull(),
  instrument: varchar("instrument", { length: 80 }).notNull(),
  direction: varchar("direction", { length: 20 }).notNull(),
  intent: varchar("intent", { length: 20 }).notNull(),
  quantity: double("quantity").notNull(),
  limitPrice: double("limitPrice").notNull(),
  stopPrice: double("stopPrice"),
  status: mysqlEnum("status", ["accepted", "filled", "rejected", "cancelled"]).notNull(),
  rejectionReason: varchar("rejectionReason", { length: 160 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const paperFills = mysqlTable("paper_fills", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("orderId").notNull(),
  fillQuantity: double("fillQuantity").notNull(),
  averagePrice: double("averagePrice").notNull(),
  fee: double("fee").default(0).notNull(),
  slippageBps: double("slippageBps").default(0).notNull(),
  filledAt: timestamp("filledAt").defaultNow().notNull(),
});

export const paperPositions = mysqlTable("paper_positions", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  venue: varchar("venue", { length: 40 }).notNull(),
  instrument: varchar("instrument", { length: 80 }).notNull(),
  direction: varchar("direction", { length: 20 }).notNull(),
  quantity: double("quantity").notNull(),
  averageEntry: double("averageEntry").notNull(),
  markPrice: double("markPrice").notNull(),
  unrealizedPnl: double("unrealizedPnl").default(0).notNull(),
  stopPrice: double("stopPrice"),
  takeProfit: double("takeProfit"),
  openedAt: timestamp("openedAt").defaultNow().notNull(),
  barClockAt: timestamp("barClockAt"),
  barsHeld: int("barsHeld").default(0).notNull(),
  baseTimeframe: varchar("baseTimeframe", { length: 16 }).default("15m").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const shadowObservations = mysqlTable("shadow_observations", {
  id: int("id").autoincrement().primaryKey(),
  source: varchar("source", { length: 48 }).notNull(),
  instrument: varchar("instrument", { length: 80 }).notNull(),
  bid: double("bid").notNull(),
  ask: double("ask").notNull(),
  mid: double("mid").notNull(),
  spreadBps: double("spreadBps").notNull(),
  observedAt: timestamp("observedAt").notNull(),
  freshnessSeconds: int("freshnessSeconds").notNull(),
  quality: varchar("quality", { length: 40 }).notNull(),
  provenance: varchar("provenance", { length: 200 }).notNull(),
});

export const newsItems = mysqlTable("news_items", {
  id: int("id").autoincrement().primaryKey(),
  externalId: varchar("externalId", { length: 96 }).notNull().unique(),
  headline: text("headline").notNull(),
  source: varchar("source", { length: 120 }).notNull(),
  instrument: varchar("instrument", { length: 120 }).notNull(),
  publishedAt: timestamp("publishedAt").notNull(),
  relevance: int("relevance").notNull(),
  sentiment: mysqlEnum("sentiment", ["POSITIVE", "NEUTRAL", "NEGATIVE"]).notNull(),
  status: mysqlEnum("status", ["SHADOW", "PENDING_REVIEW"]).notNull(),
});

export const paperRiskStates = mysqlTable("paper_risk_states", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  dailyLossPct: double("dailyLossPct").notNull(),
  grossExposurePct: double("grossExposurePct").notNull(),
  drawdownPct: double("drawdownPct").notNull(),
  dataFreshnessSeconds: int("dataFreshnessSeconds").notNull(),
  liveApproval: mysqlEnum("liveApproval", ["locked", "approved"]).default("locked").notNull(),
  evaluatedAt: timestamp("evaluatedAt").defaultNow().notNull(),
});

export const paperJournal = mysqlTable("paper_journal", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  event: varchar("event", { length: 64 }).notNull(),
  detail: text("detail").notNull(),
  provenance: varchar("provenance", { length: 160 }).notNull(),
  timestamp: timestamp("timestamp").notNull(),
});

export const demoAccounts = mysqlTable("demo_accounts", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 64 }).notNull().unique(),
  displayName: varchar("displayName", { length: 120 }).notNull(),
  startingEquity: double("startingEquity").notNull(),
  equity: double("equity").notNull(),
  peakEquity: double("peakEquity").notNull(),
  realizedPnl: double("realizedPnl").default(0).notNull(),
  tradeCount: int("tradeCount").default(0).notNull(),
  wins: int("wins").default(0).notNull(),
  losses: int("losses").default(0).notNull(),
  winRatePct: double("winRatePct").default(0).notNull(),
  maxDrawdownPct: double("maxDrawdownPct").default(0).notNull(),
  lastBatchId: varchar("lastBatchId", { length: 96 }),
  scheduleCronTaskUid: varchar("scheduleCronTaskUid", { length: 65 }),
  lastRunAt: timestamp("lastRunAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const demoTrades = mysqlTable("demo_trades", {
  id: int("id").autoincrement().primaryKey(),
  accountId: int("accountId").notNull(),
  batchId: varchar("batchId", { length: 96 }).notNull().unique(),
  instrument: varchar("instrument", { length: 80 }).notNull(),
  side: varchar("side", { length: 12 }).notNull(),
  entryPrice: double("entryPrice").notNull(),
  exitPrice: double("exitPrice").notNull(),
  quantity: double("quantity").notNull(),
  pnl: double("pnl").notNull(),
  fee: double("fee").default(0).notNull(),
  outcome: mysqlEnum("outcome", ["WIN", "LOSS", "FLAT"]).notNull(),
  executedAt: timestamp("executedAt").notNull(),
  provenance: varchar("provenance", { length: 200 }).notNull(),
});

export const demoEquityPoints = mysqlTable("demo_equity_points", {
  id: int("id").autoincrement().primaryKey(),
  accountId: int("accountId").notNull(),
  batchId: varchar("batchId", { length: 96 }).notNull().unique(),
  timestamp: timestamp("timestamp").notNull(),
  equity: double("equity").notNull(),
  realizedPnl: double("realizedPnl").notNull(),
  drawdownPct: double("drawdownPct").notNull(),
});

export const demoRuns = mysqlTable("demo_runs", {
  id: int("id").autoincrement().primaryKey(),
  accountId: int("accountId").notNull(),
  batchId: varchar("batchId", { length: 96 }).notNull().unique(),
  tradeCount: int("tradeCount").notNull(),
  executedAt: timestamp("executedAt").notNull(),
  status: mysqlEnum("status", ["completed", "skipped", "failed"]).notNull(),
});

export const paperEquityPoints = mysqlTable("paper_equity_points", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  timestamp: timestamp("timestamp").notNull(),
  equity: double("equity").notNull(),
  realizedPnl: double("realizedPnl").notNull(),
  unrealizedPnl: double("unrealizedPnl").notNull(),
  drawdownPct: double("drawdownPct").notNull(),
}, (table) => ({
  sessionTimestampIdx: index("paper_equity_session_timestamp_idx").on(table.sessionId, table.timestamp),
}));

export const paperWorkflowEvents = mysqlTable("paper_workflow_events", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  eventId: varchar("eventId", { length: 120 }).notNull().unique(),
  idempotencyKey: varchar("idempotencyKey", { length: 160 }).notNull().unique(),
  correlationId: varchar("correlationId", { length: 160 }).notNull(),
  causationId: varchar("causationId", { length: 160 }),
  stage: varchar("stage", { length: 48 }).notNull(),
  eventType: varchar("eventType", { length: 80 }).notNull(),
  instrument: varchar("instrument", { length: 80 }).notNull(),
  payloadJson: text("payloadJson").notNull(),
  provenance: varchar("provenance", { length: 200 }).notNull(),
  occurredAt: timestamp("occurredAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  sessionOccurredIdx: index("paper_workflow_session_occurred_idx").on(table.sessionId, table.occurredAt),
  correlationIdx: index("paper_workflow_correlation_idx").on(table.correlationId, table.occurredAt),
}));

export const paperCommandRuns = mysqlTable("paper_command_runs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  commandKey: varchar("commandKey", { length: 180 }).notNull(),
  commandType: mysqlEnum("commandType", ["SYNC", "DECIDE", "CLOSE", "RECONCILIATION", "DATASET_INGEST"]).notNull(),
  correlationId: varchar("correlationId", { length: 160 }).notNull(),
  state: mysqlEnum("state", ["STARTED", "SUCCEEDED", "FAILED", "BLOCKED"]).default("STARTED").notNull(),
  attempts: int("attempts").default(1).notNull(),
  payloadJson: text("payloadJson").notNull(),
  resultJson: text("resultJson"),
  failureReason: text("failureReason"),
  startedAt: timestamp("startedAt").notNull(),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userCommandKeyIdx: uniqueIndex("paper_command_user_key_idx").on(table.userId, table.commandKey),
  userStartedIdx: index("paper_command_user_started_idx").on(table.userId, table.startedAt),
  correlationIdx: index("paper_command_correlation_idx").on(table.correlationId, table.startedAt),
}));

export const paperIdempotencyReceipts = mysqlTable("paper_idempotency_receipts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  idempotencyKey: varchar("idempotencyKey", { length: 180 }).notNull().unique(),
  resource: varchar("resource", { length: 80 }).notNull(),
  generatedAt: timestamp("generatedAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userResourceIdx: index("paper_idempotency_user_resource_idx").on(table.userId, table.resource, table.createdAt),
}));

export const datasetIngestions = mysqlTable("dataset_ingestions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  datasetKey: varchar("datasetKey", { length: 180 }).notNull(),
  source: varchar("source", { length: 80 }).notNull(),
  mode: mysqlEnum("mode", ["SHADOW_EXTERNAL", "PAPER_REPLAY"]).notNull(),
  symbol: varchar("symbol", { length: 80 }).notNull(),
  interval: varchar("interval", { length: 16 }).notNull(),
  coverageStart: timestamp("coverageStart").notNull(),
  coverageEnd: timestamp("coverageEnd").notNull(),
  barCount: int("barCount").notNull(),
  coverageClass: mysqlEnum("coverageClass", ["SHORT", "MEDIUM", "LONG"]).default("SHORT").notNull(),
  evidenceState: mysqlEnum("evidenceState", ["READY", "EVIDENCE_REQUIRED", "BLOCKED"]).default("EVIDENCE_REQUIRED").notNull(),
  checksum: varchar("checksum", { length: 80 }).notNull(),
  storageKey: varchar("storageKey", { length: 240 }).notNull(),
  storageUrl: varchar("storageUrl", { length: 300 }).notNull(),
  sourceTimestamp: timestamp("sourceTimestamp").notNull(),
  fetchedAt: timestamp("fetchedAt").notNull(),
  status: mysqlEnum("status", ["READY", "FAILED", "BLOCKED"]).default("READY").notNull(),
  limitation: text("limitation").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userDatasetKeyIdx: uniqueIndex("dataset_ingestion_user_key_idx").on(table.userId, table.datasetKey),
  userFetchedIdx: index("dataset_ingestion_user_fetched_idx").on(table.userId, table.fetchedAt),
}));

export const auditParityVectors = mysqlTable("audit_parity_vectors", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  ingestionId: int("ingestionId").notNull(),
  symbol: varchar("symbol", { length: 80 }).notNull(),
  interval: varchar("interval", { length: 16 }).notNull(),
  source: varchar("source", { length: 240 }).notNull(),
  datasetChecksum: varchar("datasetChecksum", { length: 80 }).notNull(),
  expectedJson: text("expectedJson").notNull(),
  actualJson: text("actualJson").notNull(),
  tolerance: varchar("tolerance", { length: 32 }).notNull(),
  parityStatus: mysqlEnum("parityStatus", ["MATCH", "MISMATCH", "NOT_EVALUATED", "EVIDENCE_REQUIRED"]).notNull(),
  provenance: varchar("provenance", { length: 300 }).notNull(),
  sourceArtifactChecksum: varchar("sourceArtifactChecksum", { length: 80 }),
  sourceLineRange: varchar("sourceLineRange", { length: 80 }),
  formulaVersion: varchar("formulaVersion", { length: 120 }),
  sourceTimestamp: timestamp("sourceTimestamp"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userIngestionIdx: index("audit_parity_user_ingestion_idx").on(table.userId, table.ingestionId, table.createdAt),
  checksumIdx: index("audit_parity_checksum_idx").on(table.datasetChecksum, table.createdAt),
}));

export const paperReplayRuns = mysqlTable("paper_replay_runs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  ingestionId: int("ingestionId").notNull(),
  correlationId: varchar("correlationId", { length: 160 }).notNull(),
  trainBars: int("trainBars").notNull(),
  testBars: int("testBars").notNull(),
  strategyVersion: varchar("strategyVersion", { length: 80 }).notNull(),
  sourceChecksum: varchar("sourceChecksum", { length: 80 }).notNull(),
  status: mysqlEnum("status", ["READY", "BLOCKED", "FAILED"]).notNull(),
  metricsJson: text("metricsJson").notNull(),
  orderRoute: varchar("orderRoute", { length: 40 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userCreatedIdx: index("paper_replay_user_created_idx").on(table.userId, table.createdAt),
  ingestionCreatedIdx: index("paper_replay_ingestion_created_idx").on(table.ingestionId, table.createdAt),
}));

export const paperAttributionReports = mysqlTable("paper_attribution_reports", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  reportKey: varchar("reportKey", { length: 180 }).notNull().unique(),
  correlationId: varchar("correlationId", { length: 160 }).notNull(),
  ingestionIdsJson: text("ingestionIdsJson").notNull(),
  sourceChecksumsJson: text("sourceChecksumsJson").notNull(),
  metricsJson: text("metricsJson").notNull(),
  authority: varchar("authority", { length: 40 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userCreatedIdx: index("paper_attribution_user_created_idx").on(table.userId, table.createdAt),
  correlationIdx: index("paper_attribution_correlation_idx").on(table.correlationId, table.createdAt),
}));

export const paperReconciliationExceptions = mysqlTable("paper_reconciliation_exceptions", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  exceptionKey: varchar("exceptionKey", { length: 180 }).notNull().unique(),
  correlationId: varchar("correlationId", { length: 160 }).notNull(),
  instrument: varchar("instrument", { length: 80 }).notNull(),
  category: varchar("category", { length: 64 }).notNull(),
  severity: mysqlEnum("severity", ["LOW", "MEDIUM", "HIGH", "CRITICAL"]).default("MEDIUM").notNull(),
  state: mysqlEnum("state", ["OPEN", "ACKNOWLEDGED", "RESOLVED"]).default("OPEN").notNull(),
  expectedState: varchar("expectedState", { length: 64 }).notNull(),
  observedState: varchar("observedState", { length: 64 }).notNull(),
  detail: text("detail").notNull(),
  firstSeenAt: timestamp("firstSeenAt").notNull(),
  lastSeenAt: timestamp("lastSeenAt").notNull(),
  resolvedAt: timestamp("resolvedAt"),
  resolutionNote: text("resolutionNote"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  sessionStateIdx: index("paper_recon_session_state_idx").on(table.sessionId, table.state, table.lastSeenAt),
  correlationIdx: index("paper_recon_correlation_idx").on(table.correlationId, table.lastSeenAt),
}));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type PaperSession = typeof paperSessions.$inferSelect;
export type PaperSnapshot = typeof paperSnapshots.$inferSelect;
export type PaperSignal = typeof paperSignals.$inferSelect;
export type PaperOrder = typeof paperOrders.$inferSelect;
export type PaperFill = typeof paperFills.$inferSelect;
export type PaperPosition = typeof paperPositions.$inferSelect;
export type PaperEquityPoint = typeof paperEquityPoints.$inferSelect;
export type PaperRiskState = typeof paperRiskStates.$inferSelect;
export type ShadowObservation = typeof shadowObservations.$inferSelect;
export type NewsItem = typeof newsItems.$inferSelect;
export type PaperJournal = typeof paperJournal.$inferSelect;
export type PaperWorkflowEvent = typeof paperWorkflowEvents.$inferSelect;
export type PaperIdempotencyReceipt = typeof paperIdempotencyReceipts.$inferSelect;
export type PaperReconciliationException = typeof paperReconciliationExceptions.$inferSelect;
export type AuditParityVector = typeof auditParityVectors.$inferSelect;
export type PaperReplayRun = typeof paperReplayRuns.$inferSelect;
export type PaperAttributionReport = typeof paperAttributionReports.$inferSelect;
export type DemoAccount = typeof demoAccounts.$inferSelect;
export type DemoEquityPoint = typeof demoEquityPoints.$inferSelect;
export type DemoTrade = typeof demoTrades.$inferSelect;
export type DemoRun = typeof demoRuns.$inferSelect;
