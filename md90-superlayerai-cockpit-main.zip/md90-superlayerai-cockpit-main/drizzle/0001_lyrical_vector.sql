CREATE TABLE `paper_journal` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`event` varchar(64) NOT NULL,
	`detail` text NOT NULL,
	`provenance` varchar(160) NOT NULL,
	`timestamp` timestamp NOT NULL,
	CONSTRAINT `paper_journal_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `paper_risk_states` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`dailyLossPct` double NOT NULL,
	`grossExposurePct` double NOT NULL,
	`drawdownPct` double NOT NULL,
	`dataFreshnessSeconds` int NOT NULL,
	`liveApproval` enum('locked','approved') NOT NULL DEFAULT 'locked',
	`evaluatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `paper_risk_states_id` PRIMARY KEY(`id`)
);
