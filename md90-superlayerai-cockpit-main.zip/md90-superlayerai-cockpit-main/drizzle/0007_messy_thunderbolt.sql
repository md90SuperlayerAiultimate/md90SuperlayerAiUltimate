CREATE TABLE `paper_reconciliation_exceptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`exceptionKey` varchar(180) NOT NULL,
	`correlationId` varchar(160) NOT NULL,
	`instrument` varchar(80) NOT NULL,
	`category` varchar(64) NOT NULL,
	`severity` enum('LOW','MEDIUM','HIGH','CRITICAL') NOT NULL DEFAULT 'MEDIUM',
	`state` enum('OPEN','ACKNOWLEDGED','RESOLVED') NOT NULL DEFAULT 'OPEN',
	`expectedState` varchar(64) NOT NULL,
	`observedState` varchar(64) NOT NULL,
	`detail` text NOT NULL,
	`firstSeenAt` timestamp NOT NULL,
	`lastSeenAt` timestamp NOT NULL,
	`resolvedAt` timestamp,
	`resolutionNote` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `paper_reconciliation_exceptions_id` PRIMARY KEY(`id`),
	CONSTRAINT `paper_reconciliation_exceptions_exceptionKey_unique` UNIQUE(`exceptionKey`)
);
--> statement-breakpoint
CREATE TABLE `paper_workflow_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`eventId` varchar(120) NOT NULL,
	`idempotencyKey` varchar(160) NOT NULL,
	`correlationId` varchar(160) NOT NULL,
	`causationId` varchar(160),
	`stage` varchar(48) NOT NULL,
	`eventType` varchar(80) NOT NULL,
	`instrument` varchar(80) NOT NULL,
	`payloadJson` text NOT NULL,
	`provenance` varchar(200) NOT NULL,
	`occurredAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `paper_workflow_events_id` PRIMARY KEY(`id`),
	CONSTRAINT `paper_workflow_events_eventId_unique` UNIQUE(`eventId`),
	CONSTRAINT `paper_workflow_events_idempotencyKey_unique` UNIQUE(`idempotencyKey`)
);
--> statement-breakpoint
CREATE INDEX `paper_recon_session_state_idx` ON `paper_reconciliation_exceptions` (`sessionId`,`state`,`lastSeenAt`);--> statement-breakpoint
CREATE INDEX `paper_recon_correlation_idx` ON `paper_reconciliation_exceptions` (`correlationId`,`lastSeenAt`);--> statement-breakpoint
CREATE INDEX `paper_workflow_session_occurred_idx` ON `paper_workflow_events` (`sessionId`,`occurredAt`);--> statement-breakpoint
CREATE INDEX `paper_workflow_correlation_idx` ON `paper_workflow_events` (`correlationId`,`occurredAt`);--> statement-breakpoint
CREATE INDEX `paper_equity_session_timestamp_idx` ON `paper_equity_points` (`sessionId`,`timestamp`);