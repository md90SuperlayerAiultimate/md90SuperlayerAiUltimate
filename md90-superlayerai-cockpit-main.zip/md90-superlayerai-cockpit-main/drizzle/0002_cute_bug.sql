CREATE TABLE `news_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`externalId` varchar(96) NOT NULL,
	`headline` text NOT NULL,
	`source` varchar(120) NOT NULL,
	`instrument` varchar(120) NOT NULL,
	`publishedAt` timestamp NOT NULL,
	`relevance` int NOT NULL,
	`sentiment` enum('POSITIVE','NEUTRAL','NEGATIVE') NOT NULL,
	`status` enum('SHADOW','PENDING_REVIEW') NOT NULL,
	CONSTRAINT `news_items_id` PRIMARY KEY(`id`),
	CONSTRAINT `news_items_externalId_unique` UNIQUE(`externalId`)
);
--> statement-breakpoint
CREATE TABLE `shadow_observations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`source` varchar(48) NOT NULL,
	`instrument` varchar(80) NOT NULL,
	`bid` double NOT NULL,
	`ask` double NOT NULL,
	`mid` double NOT NULL,
	`spreadBps` double NOT NULL,
	`observedAt` timestamp NOT NULL,
	`freshnessSeconds` int NOT NULL,
	`quality` varchar(40) NOT NULL,
	`provenance` varchar(200) NOT NULL,
	CONSTRAINT `shadow_observations_id` PRIMARY KEY(`id`)
);
