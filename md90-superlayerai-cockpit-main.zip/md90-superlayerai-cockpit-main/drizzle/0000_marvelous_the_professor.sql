CREATE TABLE `paper_equity_points` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`timestamp` timestamp NOT NULL,
	`equity` double NOT NULL,
	`realizedPnl` double NOT NULL,
	`unrealizedPnl` double NOT NULL,
	`drawdownPct` double NOT NULL,
	CONSTRAINT `paper_equity_points_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `paper_fills` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderId` int NOT NULL,
	`fillQuantity` double NOT NULL,
	`averagePrice` double NOT NULL,
	`fee` double NOT NULL DEFAULT 0,
	`slippageBps` double NOT NULL DEFAULT 0,
	`filledAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `paper_fills_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `paper_orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`clientOrderId` varchar(96) NOT NULL,
	`signalId` varchar(96) NOT NULL,
	`venue` varchar(40) NOT NULL,
	`instrument` varchar(80) NOT NULL,
	`direction` varchar(20) NOT NULL,
	`intent` varchar(20) NOT NULL,
	`quantity` double NOT NULL,
	`limitPrice` double NOT NULL,
	`stopPrice` double,
	`status` enum('accepted','filled','rejected','cancelled') NOT NULL,
	`rejectionReason` varchar(160),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `paper_orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `paper_orders_clientOrderId_unique` UNIQUE(`clientOrderId`)
);
--> statement-breakpoint
CREATE TABLE `paper_positions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`venue` varchar(40) NOT NULL,
	`instrument` varchar(80) NOT NULL,
	`direction` varchar(20) NOT NULL,
	`quantity` double NOT NULL,
	`averageEntry` double NOT NULL,
	`markPrice` double NOT NULL,
	`unrealizedPnl` double NOT NULL DEFAULT 0,
	`stopPrice` double,
	`takeProfit` double,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `paper_positions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `paper_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(120) NOT NULL,
	`mode` enum('paper','shadow','replay') NOT NULL DEFAULT 'paper',
	`startingEquity` double NOT NULL,
	`equity` double NOT NULL,
	`peakEquity` double NOT NULL,
	`dailyPnl` double NOT NULL DEFAULT 0,
	`grossExposure` double NOT NULL DEFAULT 0,
	`realizedPnl` double NOT NULL DEFAULT 0,
	`unrealizedPnl` double NOT NULL DEFAULT 0,
	`maxDrawdownPct` double NOT NULL DEFAULT 0,
	`tradeCount` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `paper_sessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `paper_snapshots` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`venue` varchar(40) NOT NULL,
	`instrument` varchar(80) NOT NULL,
	`timestamp` timestamp NOT NULL,
	`bid` double NOT NULL,
	`ask` double NOT NULL,
	`last` double NOT NULL,
	`volume24h` double,
	`spreadBps` double,
	`source` varchar(160) NOT NULL,
	`quality` enum('valid','stale','invalid') NOT NULL DEFAULT 'valid',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `paper_snapshots_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
