CREATE TABLE `paper_idempotency_receipts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`idempotencyKey` varchar(180) NOT NULL,
	`resource` varchar(80) NOT NULL,
	`generatedAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `paper_idempotency_receipts_id` PRIMARY KEY(`id`),
	CONSTRAINT `paper_idempotency_receipts_idempotencyKey_unique` UNIQUE(`idempotencyKey`)
);
--> statement-breakpoint
CREATE INDEX `paper_idempotency_user_resource_idx` ON `paper_idempotency_receipts` (`userId`,`resource`,`createdAt`);