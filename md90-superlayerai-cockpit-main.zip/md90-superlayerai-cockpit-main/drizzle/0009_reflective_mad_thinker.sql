CREATE TABLE `dataset_ingestions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`datasetKey` varchar(180) NOT NULL,
	`source` varchar(80) NOT NULL,
	`mode` enum('SHADOW_EXTERNAL','PAPER_REPLAY') NOT NULL,
	`symbol` varchar(80) NOT NULL,
	`interval` varchar(16) NOT NULL,
	`coverageStart` timestamp NOT NULL,
	`coverageEnd` timestamp NOT NULL,
	`barCount` int NOT NULL,
	`checksum` varchar(80) NOT NULL,
	`storageKey` varchar(240) NOT NULL,
	`storageUrl` varchar(300) NOT NULL,
	`sourceTimestamp` timestamp NOT NULL,
	`fetchedAt` timestamp NOT NULL,
	`status` enum('READY','FAILED','BLOCKED') NOT NULL DEFAULT 'READY',
	`limitation` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `dataset_ingestions_id` PRIMARY KEY(`id`),
	CONSTRAINT `dataset_ingestion_user_key_idx` UNIQUE(`userId`,`datasetKey`)
);
--> statement-breakpoint
CREATE INDEX `dataset_ingestion_user_fetched_idx` ON `dataset_ingestions` (`userId`,`fetchedAt`);