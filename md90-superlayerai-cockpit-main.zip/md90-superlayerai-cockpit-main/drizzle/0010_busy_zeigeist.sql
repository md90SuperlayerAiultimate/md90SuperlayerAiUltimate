CREATE TABLE `paper_command_runs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`commandKey` varchar(180) NOT NULL,
	`commandType` enum('SYNC','DECIDE','CLOSE','RECONCILIATION','DATASET_INGEST') NOT NULL,
	`correlationId` varchar(160) NOT NULL,
	`state` enum('STARTED','SUCCEEDED','FAILED','BLOCKED') NOT NULL DEFAULT 'STARTED',
	`attempts` int NOT NULL DEFAULT 1,
	`payloadJson` text NOT NULL,
	`resultJson` text,
	`failureReason` text,
	`startedAt` timestamp NOT NULL,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `paper_command_runs_id` PRIMARY KEY(`id`),
	CONSTRAINT `paper_command_user_key_idx` UNIQUE(`userId`,`commandKey`)
);
--> statement-breakpoint
CREATE INDEX `paper_command_user_started_idx` ON `paper_command_runs` (`userId`,`startedAt`);--> statement-breakpoint
CREATE INDEX `paper_command_correlation_idx` ON `paper_command_runs` (`correlationId`,`startedAt`);