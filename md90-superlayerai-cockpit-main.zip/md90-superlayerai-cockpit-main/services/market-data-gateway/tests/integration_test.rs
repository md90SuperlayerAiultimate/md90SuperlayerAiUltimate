#[cfg(test)]
mod tests {
    use market_data_gateway::orderbook::OrderBook;

    #[test]
    fn test_orderbook_bid_insert() {
        let book = OrderBook::new(100);
        assert!(book.update_bid(100.0, 1.0));
        assert!(book.update_bid(99.0, 2.0));

        let snapshot = book.snapshot(|b| (b.bid_count(), b.get_spread_bps()));
        assert_eq!(snapshot.0, 2);
    }

    #[test]
    fn test_orderbook_ask_insert() {
        let book = OrderBook::new(100);
        assert!(book.update_ask(101.0, 1.0));
        assert!(book.update_ask(102.0, 2.0));

        book.snapshot(|b| {
            assert_eq!(b.ask_count(), 2);
        });
    }

    #[test]
    fn test_orderbook_bid_update() {
        let book = OrderBook::new(100);
        book.update_bid(100.0, 1.0);
        book.update_bid(100.0, 2.5);

        book.snapshot(|b| {
            assert_eq!(b.get_bids()[0].quantity, 2.5);
        });
    }

    #[test]
    fn test_orderbook_bid_remove() {
        let book = OrderBook::new(100);
        book.update_bid(100.0, 1.0);
        book.update_bid(100.0, 0.0); // Remove

        book.snapshot(|b| {
            assert_eq!(b.bid_count(), 0);
        });
    }

    #[test]
    fn test_orderbook_spread() {
        let book = OrderBook::new(100);
        book.update_bid(100.0, 1.0);
        book.update_ask(101.0, 1.0);

        let spread_bps = book.snapshot(|b| b.get_spread_bps());
        assert!(spread_bps.is_some());
        let spread = spread_bps.unwrap();
        assert!(spread > 0.0);
        assert!(spread < 200.0); // Should be ~100 bps
    }

    #[test]
    fn test_orderbook_update_counter() {
        let book = OrderBook::new(100);
        assert_eq!(book.get_update_count(), 0);
        
        book.update_bid(100.0, 1.0);
        assert_eq!(book.get_update_count(), 1);
        
        book.update_ask(101.0, 1.0);
        assert_eq!(book.get_update_count(), 2);
    }
}
