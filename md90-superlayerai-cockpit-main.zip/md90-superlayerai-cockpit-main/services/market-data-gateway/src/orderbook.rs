use parking_lot::RwLock;
use std::sync::atomic::{AtomicUsize, Ordering};
use log::warn;

/// Fixed-size price level for contiguous memory allocation
/// No heap fragmentation, L1 cache friendly
#[derive(Clone, Copy, Debug)]
pub struct PriceLevel {
    pub price: f64,
    pub quantity: f64,
}

impl PriceLevel {
    pub fn new(price: f64, quantity: f64) -> Self {
        Self { price, quantity }
    }
}

/// Zero-copy L2 Order Book using contiguous arrays
/// Binary search on fixed memory = guaranteed low latency
pub struct OrderBookL2 {
    /// Bid side: highest price first
    bids: Vec<PriceLevel>,
    /// Ask side: lowest price first
    asks: Vec<PriceLevel>,
    /// Current number of bid levels
    bid_count: usize,
    /// Current number of ask levels
    ask_count: usize,
    /// Max levels per side
    max_levels: usize,
    /// Update sequence number for reconciliation
    sequence: u64,
}

impl OrderBookL2 {
    pub fn new(max_levels: usize) -> Self {
        Self {
            bids: vec![PriceLevel::new(0.0, 0.0); max_levels],
            asks: vec![PriceLevel::new(0.0, 0.0); max_levels],
            bid_count: 0,
            ask_count: 0,
            max_levels,
            sequence: 0,
        }
    }

    /// Update bid side with binary search
    /// Returns: true if updated, false if price level not found
    pub fn update_bid(&mut self, price: f64, quantity: f64) -> bool {
        if quantity < 0.0 {
            return false; // Invalid
        }

        // Binary search for price level (bids are descending)
        match self.bids[..self.bid_count].binary_search_by(|level| {
            level.price.partial_cmp(&price).unwrap_or(std::cmp::Ordering::Equal)
        }) {
            Ok(idx) => {
                // Price level exists
                if quantity == 0.0 {
                    // Remove level
                    self.bids.copy_within((idx + 1)..self.bid_count, idx);
                    self.bid_count -= 1;
                } else {
                    // Update quantity
                    self.bids[idx].quantity = quantity;
                }
                true
            }
            Err(idx) => {
                // New price level
                if quantity == 0.0 {
                    return false; // Don't add with 0 quantity
                }
                if self.bid_count >= self.max_levels {
                    warn!("Bid book full at {} levels", self.max_levels);
                    return false;
                }
                // Insert at correct position (maintain descending order)
                self.bids.copy_within(idx..self.bid_count, idx + 1);
                self.bids[idx] = PriceLevel::new(price, quantity);
                self.bid_count += 1;
                true
            }
        }
    }

    /// Update ask side with binary search
    pub fn update_ask(&mut self, price: f64, quantity: f64) -> bool {
        if quantity < 0.0 {
            return false;
        }

        // Binary search for price level (asks are ascending)
        match self.asks[..self.ask_count].binary_search_by(|level| {
            price.partial_cmp(&level.price).unwrap_or(std::cmp::Ordering::Equal)
        }) {
            Ok(idx) => {
                if quantity == 0.0 {
                    self.asks.copy_within((idx + 1)..self.ask_count, idx);
                    self.ask_count -= 1;
                } else {
                    self.asks[idx].quantity = quantity;
                }
                true
            }
            Err(idx) => {
                if quantity == 0.0 {
                    return false;
                }
                if self.ask_count >= self.max_levels {
                    warn!("Ask book full at {} levels", self.max_levels);
                    return false;
                }
                self.asks.copy_within(idx..self.ask_count, idx + 1);
                self.asks[idx] = PriceLevel::new(price, quantity);
                self.ask_count += 1;
                true
            }
        }
    }

    pub fn get_bids(&self) -> &[PriceLevel] {
        &self.bids[..self.bid_count]
    }

    pub fn get_asks(&self) -> &[PriceLevel] {
        &self.asks[..self.ask_count]
    }

    pub fn get_sequence(&self) -> u64 {
        self.sequence
    }

    pub fn increment_sequence(&mut self) {
        self.sequence += 1;
    }

    pub fn bid_count(&self) -> usize {
        self.bid_count
    }

    pub fn ask_count(&self) -> usize {
        self.ask_count
    }

    /// Get spread in basis points
    pub fn get_spread_bps(&self) -> Option<f64> {
        if self.bid_count == 0 || self.ask_count == 0 {
            return None;
        }
        let best_bid = self.bids[0].price;
        let best_ask = self.asks[0].price;
        if best_bid <= 0.0 || best_ask <= 0.0 {
            return None;
        }
        let spread = (best_ask - best_bid) / best_bid * 10000.0;
        Some(spread)
    }
}

/// Thread-safe Order Book wrapper
pub struct OrderBook {
    data: RwLock<OrderBookL2>,
    update_counter: AtomicUsize,
}

impl OrderBook {
    pub fn new(max_levels: usize) -> Self {
        Self {
            data: RwLock::new(OrderBookL2::new(max_levels)),
            update_counter: AtomicUsize::new(0),
        }
    }

    pub fn update_bid(&self, price: f64, quantity: f64) -> bool {
        let mut book = self.data.write();
        let result = book.update_bid(price, quantity);
        if result {
            book.increment_sequence();
            self.update_counter.fetch_add(1, Ordering::Relaxed);
        }
        result
    }

    pub fn update_ask(&self, price: f64, quantity: f64) -> bool {
        let mut book = self.data.write();
        let result = book.update_ask(price, quantity);
        if result {
            book.increment_sequence();
            self.update_counter.fetch_add(1, Ordering::Relaxed);
        }
        result
    }

    pub fn snapshot<F, R>(&self, f: F) -> R
    where
        F: FnOnce(&OrderBookL2) -> R,
    {
        let book = self.data.read();
        f(&*book)
    }

    pub fn get_update_count(&self) -> usize {
        self.update_counter.load(Ordering::Relaxed)
    }
}
