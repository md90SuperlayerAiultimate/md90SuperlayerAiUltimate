pub struct Config {
    pub binance_ws_url: String,
    pub max_price_levels: usize,
    pub ping_interval_secs: u64,
    pub message_timeout_secs: u64,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            binance_ws_url: "wss://stream.binance.com:9443/ws/btcusdt@depth20@100ms".to_string(),
            max_price_levels: 1000,
            ping_interval_secs: 25,
            message_timeout_secs: 5,
        }
    }
}
