use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::time::Duration;
use log::info;

pub struct GatewayMetrics {
    /// Total messages processed
    message_count: AtomicU64,
    /// Total errors
    error_count: AtomicUsize,
    /// Reconnection count
    reconnect_count: AtomicUsize,
    /// Processing time sum (nanoseconds)
    processing_time_sum: AtomicU64,
    /// Min processing time (nanoseconds)
    processing_time_min: AtomicU64,
    /// Max processing time (nanoseconds)
    processing_time_max: AtomicU64,
}

impl GatewayMetrics {
    pub fn new() -> Self {
        Self {
            message_count: AtomicU64::new(0),
            error_count: AtomicUsize::new(0),
            reconnect_count: AtomicUsize::new(0),
            processing_time_sum: AtomicU64::new(0),
            processing_time_min: AtomicU64::new(u64::MAX),
            processing_time_max: AtomicU64::new(0),
        }
    }

    pub fn increment_message_count(&self) {
        self.message_count.fetch_add(1, Ordering::Relaxed);
    }

    pub fn increment_error_count(&self) {
        self.error_count.fetch_add(1, Ordering::Relaxed);
    }

    pub fn increment_reconnect_count(&self) {
        self.reconnect_count.fetch_add(1, Ordering::Relaxed);
    }

    pub fn get_reconnect_count(&self) -> usize {
        self.reconnect_count.load(Ordering::Relaxed)
    }

    pub fn reset_reconnect_count(&self) {
        self.reconnect_count.store(0, Ordering::Relaxed);
    }

    pub fn record_processing_time(&self, duration: Duration) {
        let nanos = duration.as_nanos() as u64;
        self.processing_time_sum.fetch_add(nanos, Ordering::Relaxed);

        let mut min = self.processing_time_min.load(Ordering::Relaxed);
        while nanos < min {
            match self.processing_time_min.compare_exchange_weak(
                min,
                nanos,
                Ordering::Relaxed,
                Ordering::Relaxed,
            ) {
                Ok(_) => break,
                Err(actual) => min = actual,
            }
        }

        let mut max = self.processing_time_max.load(Ordering::Relaxed);
        while nanos > max {
            match self.processing_time_max.compare_exchange_weak(
                max,
                nanos,
                Ordering::Relaxed,
                Ordering::Relaxed,
            ) {
                Ok(_) => break,
                Err(actual) => max = actual,
            }
        }
    }

    pub fn get_message_count(&self) -> u64 {
        self.message_count.load(Ordering::Relaxed)
    }

    pub fn get_error_count(&self) -> usize {
        self.error_count.load(Ordering::Relaxed)
    }

    pub fn get_avg_processing_time_us(&self) -> f64 {
        let sum = self.processing_time_sum.load(Ordering::Relaxed);
        let count = self.message_count.load(Ordering::Relaxed);
        if count == 0 {
            return 0.0;
        }
        (sum as f64 / count as f64) / 1000.0 // Convert to microseconds
    }

    pub fn get_min_processing_time_us(&self) -> f64 {
        let min = self.processing_time_min.load(Ordering::Relaxed);
        if min == u64::MAX {
            return 0.0;
        }
        (min as f64) / 1000.0
    }

    pub fn get_max_processing_time_us(&self) -> f64 {
        let max = self.processing_time_max.load(Ordering::Relaxed);
        (max as f64) / 1000.0
    }

    pub fn print_summary(&self) {
        info!(
            "📊 Metrics: msgs={} errors={} reconnects={} avg_time={:.3}µs min={:.3}µs max={:.3}µs",
            self.get_message_count(),
            self.get_error_count(),
            self.get_reconnect_count(),
            self.get_avg_processing_time_us(),
            self.get_min_processing_time_us(),
            self.get_max_processing_time_us(),
        );
    }
}
