use bytes::{BytesMut, BufMut};

/// Simple Binary Encoding (SBE) for market data
/// Zero-copy serialization for IPC communication
pub struct SBEEncoder;

impl SBEEncoder {
    /// Encode order book update to binary format
    /// Format: [schema_id(1)] [price(8)] [quantity(8)] [side(1)] [timestamp(8)]
    pub fn encode_price_level(
        price: f64,
        quantity: f64,
        side: u8, // 0 = BID, 1 = ASK
        timestamp: u64,
    ) -> Vec<u8> {
        let mut buf = BytesMut::with_capacity(26);
        buf.put_u8(1); // Schema version
        buf.put_f64_le(price);
        buf.put_f64_le(quantity);
        buf.put_u8(side);
        buf.put_u64_le(timestamp);
        buf.to_vec()
    }

    /// Encode multiple price levels
    pub fn encode_levels(levels: &[(f64, f64)], side: u8, timestamp: u64) -> Vec<u8> {
        let mut buf = BytesMut::with_capacity(2 + levels.len() * 17);
        buf.put_u16_le(levels.len() as u16);

        for (price, qty) in levels {
            buf.put_f64_le(*price);
            buf.put_f64_le(*qty);
            buf.put_u8(side);
            buf.put_u64_le(timestamp);
        }

        buf.to_vec()
    }

    /// Decode binary level back to tuple
    pub fn decode_level(data: &[u8]) -> Option<(f64, f64, u8, u64)> {
        if data.len() < 18 {
            return None;
        }

        let price = f64::from_le_bytes([data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7]]);
        let quantity = f64::from_le_bytes([
            data[8], data[9], data[10], data[11], data[12], data[13], data[14], data[15],
        ]);
        let side = data[16];
        let timestamp = u64::from_le_bytes([
            data[17], data[18], data[19], data[20], data[21], data[22], data[23], data[24],
        ]);

        Some((price, quantity, side, timestamp))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_encode_decode_level() {
        let encoded = SBEEncoder::encode_price_level(100.5, 1.25, 0, 1234567890);
        let decoded = SBEEncoder::decode_level(&encoded).unwrap();

        assert_eq!(decoded.0, 100.5);
        assert_eq!(decoded.1, 1.25);
        assert_eq!(decoded.2, 0);
        assert_eq!(decoded.3, 1234567890);
    }
}
