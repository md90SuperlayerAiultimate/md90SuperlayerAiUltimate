use crate::orderbook::OrderBook;
use crate::checksum::ChecksumValidator;
use crate::metrics::GatewayMetrics;
use log::{info, error, warn};
use serde_json::{json, Value};
use std::sync::Arc;
use tokio_tungstenite::{connect_async, tungstenite::Message};
use tokio::time::{sleep, Duration, Instant};
use futures::{SinkExt, StreamExt};

pub struct WebSocketGateway {
    url: String,
    orderbook: Arc<OrderBook>,
    metrics: Arc<GatewayMetrics>,
}

impl WebSocketGateway {
    pub fn new(
        url: String,
        orderbook: Arc<OrderBook>,
        metrics: Arc<GatewayMetrics>,
    ) -> Self {
        Self {
            url,
            orderbook,
            metrics,
        }
    }

    pub async fn run(&self) -> Result<(), Box<dyn std::error::Error>> {
        loop {
            match self.connect_and_stream().await {
                Ok(_) => {
                    info!("✅ Stream ended gracefully");
                    break;
                }
                Err(e) => {
                    error!("❌ Connection error: {}", e);
                    self.metrics.increment_reconnect_count();
                    
                    // Exponential backoff (Phase 1)
                    let backoff = std::cmp::min(1000 * 2_u64.pow(self.metrics.get_reconnect_count() as u32), 32000);
                    info!("⏳ Reconnecting in {}ms...", backoff);
                    sleep(Duration::from_millis(backoff)).await;
                }
            }
        }
        Ok(())
    }

    async fn connect_and_stream(&self) -> Result<(), Box<dyn std::error::Error>> {
        let (ws_stream, _) = connect_async(&self.url).await?;
        info!("🔗 Connected to {}", self.url);
        self.metrics.reset_reconnect_count();

        let (mut write, mut read) = ws_stream.split();
        let mut last_seq_num = 0u64;
        let mut message_count = 0u64;
        let start_time = Instant::now();

        while let Some(msg) = read.next().await {
            match msg {
                Ok(Message::Text(data)) => {
                    let process_start = Instant::now();
                    
                    match serde_json::from_str::<Value>(&data) {
                        Ok(json) => {
                            // Parse Binance depth stream
                            if let Some(e) = json.get("e").and_then(|v| v.as_str()) {
                                match e {
                                    "depthUpdate" => {
                                        if let Err(err) = self.process_depth_update(&json) {
                                            warn!("Failed to process depth update: {}", err);
                                            self.metrics.increment_error_count();
                                        } else {
                                            message_count += 1;
                                        }
                                    }
                                    _ => {}
                                }
                            }
                        }
                        Err(e) => {
                            warn!("JSON parse error: {}", e);
                            self.metrics.increment_error_count();
                        }
                    }
                    
                    let elapsed = process_start.elapsed();
                    self.metrics.record_processing_time(elapsed);
                }
                Ok(Message::Close(_)) => {
                    info!("📊 Stream closed by server");
                    break;
                }
                Ok(_) => {}
                Err(e) => {
                    error!("WebSocket error: {}", e);
                    break;
                }
            }
        }

        let elapsed = start_time.elapsed();
        info!(
            "📊 Stream stats: {} messages in {:.2}s ({:.0} msg/s)",
            message_count,
            elapsed.as_secs_f64(),
            message_count as f64 / elapsed.as_secs_f64()
        );

        Ok(())
    }

    fn process_depth_update(&self, json: &Value) -> Result<(), Box<dyn std::error::Error>> {
        // Extract sequence numbers for reconciliation
        let u = json
            .get("u")
            .and_then(|v| v.as_u64())
            .ok_or("Missing sequence number 'u'")?;

        let pu = json
            .get("pu")
            .and_then(|v| v.as_u64())
            .ok_or("Missing previous sequence 'pu'")?;

        // Process bids
        if let Some(bids) = json.get("b").and_then(|v| v.as_array()) {
            for bid in bids {
                if let Some(pair) = bid.as_array() {
                    if pair.len() >= 2 {
                        let price: f64 = pair[0]
                            .as_str()
                            .and_then(|s| s.parse().ok())
                            .ok_or("Invalid bid price")?;
                        let quantity: f64 = pair[1]
                            .as_str()
                            .and_then(|s| s.parse().ok())
                            .ok_or("Invalid bid quantity")?;

                        self.orderbook.update_bid(price, quantity);
                    }
                }
            }
        }

        // Process asks
        if let Some(asks) = json.get("a").and_then(|v| v.as_array()) {
            for ask in asks {
                if let Some(pair) = ask.as_array() {
                    if pair.len() >= 2 {
                        let price: f64 = pair[0]
                            .as_str()
                            .and_then(|s| s.parse().ok())
                            .ok_or("Invalid ask price")?;
                        let quantity: f64 = pair[1]
                            .as_str()
                            .and_then(|s| s.parse().ok())
                            .ok_or("Invalid ask quantity")?;

                        self.orderbook.update_ask(price, quantity);
                    }
                }
            }
        }

        Ok(())
    }
}
