mod orderbook;
mod websocket;
mod checksum;
mod sbe;
mod metrics;
mod config;

use log::{info, error};
use std::sync::Arc;
use parking_lot::Mutex;
use metrics::GatewayMetrics;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    env_logger::init();
    
    info!("🚀 Market Data Gateway starting...");
    
    // Initialize metrics
    let metrics = Arc::new(GatewayMetrics::new());
    info!("✅ Metrics initialized");
    
    // Create order book (contiguous memory allocation)
    let orderbook = Arc::new(Mutex::new(
        orderbook::OrderBook::new(1000) // Max 1000 price levels per side
    ));
    info!("✅ Order Book allocated (1000 levels x 2 sides)");
    
    // Create WebSocket gateway
    let gateway = websocket::WebSocketGateway::new(
        "wss://stream.binance.com:9443/ws/btcusdt@depth20@100ms".to_string(),
        Arc::clone(&orderbook),
        Arc::clone(&metrics),
    );
    
    info!("✅ WebSocket Gateway configured");
    
    // Start gateway
    match gateway.run().await {
        Ok(_) => info!("🏁 Gateway shutdown gracefully"),
        Err(e) => error!("❌ Gateway error: {}", e),
    }
    
    Ok(())
}
