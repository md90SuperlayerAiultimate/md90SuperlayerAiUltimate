use crc::{Crc, CRC_32_CKSUM};

pub struct ChecksumValidator;

impl ChecksumValidator {
    /// Calculate CRC32 checksum of order book state
    /// Used to detect divergence between local and exchange state
    pub fn calculate_book_checksum(bids: &[(f64, f64)], asks: &[(f64, f64)]) -> u32 {
        const CRC: Crc<u32> = Crc::<u32>::new(&CRC_32_CKSUM);
        let mut digest = CRC.digest();

        // Hash bids
        for (price, qty) in bids {
            digest.update(&price.to_bits().to_le_bytes());
            digest.update(&qty.to_bits().to_le_bytes());
        }

        // Hash asks
        for (price, qty) in asks {
            digest.update(&price.to_bits().to_le_bytes());
            digest.update(&qty.to_bits().to_le_bytes());
        }

        digest.finalize()
    }

    /// Validate that local book matches exchange checksum
    pub fn validate(
        local_checksum: u32,
        exchange_checksum: u32,
    ) -> Result<(), String> {
        if local_checksum == exchange_checksum {
            Ok(())
        } else {
            Err(format!(
                "Checksum mismatch: local={:x} exchange={:x}",
                local_checksum, exchange_checksum
            ))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_checksum_consistency() {
        let bids = vec![(100.0, 1.0), (99.0, 2.0)];
        let asks = vec![(101.0, 1.0), (102.0, 2.0)];

        let checksum1 = ChecksumValidator::calculate_book_checksum(&bids, &asks);
        let checksum2 = ChecksumValidator::calculate_book_checksum(&bids, &asks);

        assert_eq!(checksum1, checksum2, "Same data should produce same checksum");
    }

    #[test]
    fn test_checksum_different_data() {
        let bids1 = vec![(100.0, 1.0)];
        let bids2 = vec![(100.0, 2.0)];
        let asks = vec![(101.0, 1.0)];

        let checksum1 = ChecksumValidator::calculate_book_checksum(&bids1, &asks);
        let checksum2 = ChecksumValidator::calculate_book_checksum(&bids2, &asks);

        assert_ne!(
            checksum1, checksum2,
            "Different data should produce different checksums"
        );
    }
}
