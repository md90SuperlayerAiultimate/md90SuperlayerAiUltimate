import { z } from 'zod';
import { publicProcedure, router } from '../_core/trpc';
import { IdempotencyManager, OrderIntent } from '../../shared/idempotency';
import { Logger } from '../_core/logger';
import { evaluateAndPlaceLiveOrder, loadBinanceLiveConfig, type LiveOrderSide } from '../binanceLiveAdapter';

const logger = new Logger('OrdersRouter');
const idempotencyManager = new IdempotencyManager(logger);

// Run cleanup every hour
setInterval(() => idempotencyManager.cleanup(), 60 * 60 * 1000);

const submitOrderSchema = z.object({
  symbol: z.string(),
  side: z.enum(['BUY', 'SELL']),
  quantity: z.number().positive(),
  price: z.number().positive(),
  type: z.enum(['MARKET', 'LIMIT']),
  clientOrderId: z.string().uuid().optional(),
});

export const ordersRouter = router({
  /**
   * Submit order with idempotency guarantee
   * If network fails, retry with same clientOrderId = no duplicate
   */
  submitOrder: publicProcedure
    .input(submitOrderSchema)
    .mutation(async ({ input }) => {
      const intent: OrderIntent = {
        symbol: input.symbol,
        side: input.side,
        quantity: input.quantity,
        price: input.price,
        type: input.type,
      };

      // Generate or use provided clientOrderId
      let clientOrderId = input.clientOrderId;
      if (!clientOrderId) {
        const key = idempotencyManager.generateKey(intent);
        clientOrderId = key.clientOrderId;
        idempotencyManager.registerOrder(key, intent);
      } else {
        // Check if this is a retry
        if (!idempotencyManager.canRetry(clientOrderId)) {
          const existingOrder = idempotencyManager.getOrder(clientOrderId);
          if (existingOrder) {
            logger.info(
              `Returning cached result for order ${clientOrderId}: ${existingOrder.status}`
            );
            return {
              clientOrderId: existingOrder.clientOrderId,
              exchangeOrderId: existingOrder.exchangeOrderId,
              status: existingOrder.status,
              cached: true,
            };
          }
        }

        if (idempotencyManager.isDuplicate(clientOrderId, intent)) {
          logger.warn(`Duplicate order detected: ${clientOrderId}`);
          return {
            clientOrderId,
            error: 'DUPLICATE_ORDER',
            message: 'This order has already been submitted',
          };
        }

        idempotencyManager.recordRetry(clientOrderId);
      }

      try {
        // Submit to exchange
        const exchangeResponse = await submitToExchange(intent, clientOrderId);

        if (exchangeResponse.success) {
          idempotencyManager.updateOrderState(
            clientOrderId,
            exchangeResponse.orderId ?? clientOrderId,
            'PENDING'
          );

          logger.info(
            `Order submitted successfully: ${clientOrderId} -> ${exchangeResponse.orderId}`
          );

          return {
            clientOrderId,
            exchangeOrderId: exchangeResponse.orderId,
            status: 'PENDING',
            success: true,
          };
        } else {
          throw new Error(exchangeResponse.error);
        }
      } catch (error) {
        logger.error(
          `Order submission failed for ${clientOrderId}: ${error}. Will retry with same ID.`
        );

        return {
          clientOrderId,
          error: 'SUBMISSION_FAILED',
          message: String(error),
          retryable: true,
        };
      }
    }),

  /**
   * Query order status
   * Used to check if order was filled before retry
   */
  queryOrderStatus: publicProcedure
    .input(z.object({ clientOrderId: z.string().uuid() }))
    .query(async ({ input }) => {
      const orderState = idempotencyManager.getOrder(input.clientOrderId);

      if (!orderState) {
        return {
          found: false,
          message: 'Order not found in local state',
        };
      }

      return {
        found: true,
        clientOrderId: orderState.clientOrderId,
        exchangeOrderId: orderState.exchangeOrderId,
        status: orderState.status,
        attempts: orderState.attempts,
        timestamp: orderState.timestamp,
      };
    }),

  /**
   * Reconcile orders after restart
   * Query exchange for all open orders and sync state
   */
  reconcileOrders: publicProcedure.mutation(async () => {
    logger.info('Starting order reconciliation...');

    try {
      const exchangeOrders = await queryExchangeOpenOrders();

      for (const exchangeOrder of exchangeOrders) {
        const localOrder = idempotencyManager.getOrder(
          exchangeOrder.clientOrderId
        );

        if (!localOrder) {
          logger.warn(
            `Exchange has order ${exchangeOrder.clientOrderId} not in local state`
          );
          continue;
        }

        if (localOrder.status !== exchangeOrder.status) {
          logger.info(
            `Syncing order ${exchangeOrder.clientOrderId}: ${localOrder.status} -> ${exchangeOrder.status}`
          );
          idempotencyManager.updateOrderState(
            exchangeOrder.clientOrderId,
            exchangeOrder.exchangeOrderId,
            exchangeOrder.status as any
          );
        }
      }

      logger.info('Order reconciliation complete');
      return { success: true, ordersReconciled: exchangeOrders.length };
    } catch (error) {
      logger.error(`Reconciliation failed: ${error}`);
      return { success: false, error: String(error) };
    }
  }),
});

/**
 * Real Binance submission via binanceLiveAdapter.ts. This previously simulated network
 * latency and returned a fake 95%-success result (`Math.random() > 0.05`) — that mock is
 * removed entirely, not left as a fallback, because a mock that silently reports fake
 * fills is worse than an explicit BLOCKED result: it hides the absence of a real order
 * from anyone reading the response. The adapter's own fail-closed gate (LIVE_TRADING_ENABLED,
 * kill switch, credentials, notional cap) still applies — this function does not bypass it.
 * LIMIT orders are intentionally rejected: the adapter only implements MARKET orders today,
 * and silently downgrading a LIMIT intent to MARKET would change the trader's risk profile
 * without their consent.
 */
async function submitToExchange(
  intent: OrderIntent,
  clientOrderId: string
): Promise<{ success: boolean; orderId?: string; error?: string }> {
  if (intent.type !== 'MARKET') {
    return { success: false, error: 'UNSUPPORTED_ORDER_TYPE: only MARKET is implemented in binanceLiveAdapter' };
  }

  const result = await evaluateAndPlaceLiveOrder(
    { symbol: intent.symbol, side: intent.side as LiveOrderSide, quantity: intent.quantity },
    intent.price,
    loadBinanceLiveConfig(),
  );

  if (result.status === 'BLOCKED') {
    return { success: false, error: `BLOCKED: ${result.reasons.join(', ')}` };
  }
  if (result.status === 'ERROR') {
    return { success: false, error: result.errorMessage ?? 'UNKNOWN_EXCHANGE_ERROR' };
  }
  return { success: true, orderId: result.binanceOrderId ? String(result.binanceOrderId) : result.clientOrderId };
}

/**
 * Queries Binance for currently open orders on a symbol, signed the same way as order
 * submission. Requires the same LIVE_TRADING_ENABLED + credentials as placing an order —
 * reconciliation after a restart should not run against a different trust boundary than
 * the trading path itself.
 */
async function queryExchangeOpenOrders(): Promise<
  Array<{
    clientOrderId: string;
    exchangeOrderId: string;
    status: string;
  }>
> {
  const config = loadBinanceLiveConfig();
  if (!config.liveTradingEnabled || !config.apiKey || !config.apiSecret) {
    return [];
  }
  const { createHmac } = await import('node:crypto');
  const timestamp = Date.now();
  const params = new URLSearchParams({ recvWindow: '5000', timestamp: timestamp.toString() });
  const signature = createHmac('sha256', config.apiSecret).update(params.toString()).digest('hex');
  params.set('signature', signature);

  const response = await fetch(`${config.baseUrl}/api/v3/openOrders?${params.toString()}`, {
    headers: { 'X-MBX-APIKEY': config.apiKey },
  });
  if (!response.ok) return [];
  const orders = (await response.json()) as Array<{ clientOrderId: string; orderId: number; status: string }>;
  return orders.map((o) => ({ clientOrderId: o.clientOrderId, exchangeOrderId: String(o.orderId), status: o.status }));
}
