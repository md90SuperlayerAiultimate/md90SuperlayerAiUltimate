import { createHmac } from "node:crypto";

/**
 * Live-restricted Binance spot order adapter.
 *
 * Safety boundary (non-negotiable, matches the rest of this codebase's PAPER/SHADOW
 * conventions): this module NEVER sends a real order unless ALL of the following are true:
 *   1. env LIVE_TRADING_ENABLED === "true" (explicit, no default-on)
 *   2. env BINANCE_API_KEY and BINANCE_API_SECRET are present
 *   3. the requested notional is under MAX_ORDER_NOTIONAL_USD
 *   4. the kill switch (env KILL_SWITCH_ENGAGED) is not "true"
 * If any check fails, the function returns a BLOCKED result with a reason instead of
 * throwing — callers must branch on `status`, matching the BLOCKED/COMPLETED pattern
 * already used in forwardPaperSession.ts.
 */

export type LiveOrderSide = "BUY" | "SELL";

export type LiveOrderRequest = {
  symbol: string;
  side: LiveOrderSide;
  quantity: number;
  priceHint?: number;
};

export type LiveOrderBlockedResult = {
  status: "BLOCKED";
  reasons: string[];
  orderRoute: "DISABLED" | "LIVE";
};

export type LiveOrderFilledResult = {
  status: "FILLED" | "ERROR";
  orderRoute: "LIVE";
  venue: "BINANCE_LIVE";
  binanceOrderId: number | null;
  clientOrderId: string;
  symbol: string;
  side: LiveOrderSide;
  requestedQuantity: number;
  executedQuantity: number;
  executedNotionalUsd: number;
  rawResponse: unknown;
  errorMessage: string | null;
};

export type LiveOrderResult = LiveOrderBlockedResult | LiveOrderFilledResult;

export type BinanceLiveConfig = {
  liveTradingEnabled: boolean;
  killSwitchEngaged: boolean;
  apiKey: string | null;
  apiSecret: string | null;
  maxOrderNotionalUsd: number;
  baseUrl: string;
};

const DEFAULT_MAX_ORDER_NOTIONAL_USD = 25;
const MAINNET_BASE = "https://api.binance.com";
const TESTNET_BASE = "https://testnet.binance.vision";

export function loadBinanceLiveConfig(env: NodeJS.ProcessEnv = process.env): BinanceLiveConfig {
  const liveTradingEnabled = env.LIVE_TRADING_ENABLED === "true";
  const killSwitchEngaged = env.KILL_SWITCH_ENGAGED === "true";
  const apiKey = env.BINANCE_API_KEY?.trim() || null;
  const apiSecret = env.BINANCE_API_SECRET?.trim() || null;
  const parsedCap = env.MAX_ORDER_NOTIONAL_USD ? Number(env.MAX_ORDER_NOTIONAL_USD) : NaN;
  const maxOrderNotionalUsd = Number.isFinite(parsedCap) && parsedCap > 0 ? parsedCap : DEFAULT_MAX_ORDER_NOTIONAL_USD;
  // Fail-closed on environment target: anything other than an explicit "mainnet" stays on testnet,
  // so a missing/misspelled env var can never silently point at real funds.
  const baseUrl = env.BINANCE_ENV === "mainnet" ? MAINNET_BASE : TESTNET_BASE;
  return { liveTradingEnabled, killSwitchEngaged, apiKey, apiSecret, maxOrderNotionalUsd, baseUrl };
}

function normalizeSymbol(symbol: string): string {
  const normalized = symbol.trim().toUpperCase();
  if (!/^[A-Z0-9]{5,20}$/.test(normalized)) throw new Error("Invalid live order symbol");
  return normalized;
}

function signQuery(secret: string, query: string): string {
  return createHmac("sha256", secret).update(query).digest("hex");
}

/**
 * Pre-trade gate. Pure function, no network call — this is what callers should check
 * (and what tests should exercise) before ever attempting evaluateAndPlaceLiveOrder.
 * Mirrors the RISK_GATE fail-closed pattern already fixed in operatingOrchestrator.ts:
 * any missing or invalid condition blocks, never assumes safe.
 */
export function evaluateLiveOrderGate(request: LiveOrderRequest, config: BinanceLiveConfig, estimatedPriceUsd: number): LiveOrderBlockedResult | { status: "READY" } {
  const reasons: string[] = [];

  if (!config.liveTradingEnabled) reasons.push("LIVE_TRADING_NOT_ENABLED");
  if (config.killSwitchEngaged) reasons.push("KILL_SWITCH_ENGAGED");
  if (!config.apiKey || !config.apiSecret) reasons.push("MISSING_API_CREDENTIALS");
  if (!(request.quantity > 0)) reasons.push("INVALID_QUANTITY");
  if (!(estimatedPriceUsd > 0)) reasons.push("INVALID_PRICE_ESTIMATE");

  const estimatedNotionalUsd = request.quantity * estimatedPriceUsd;
  if (Number.isFinite(estimatedNotionalUsd) && estimatedNotionalUsd > config.maxOrderNotionalUsd) {
    reasons.push(`NOTIONAL_EXCEEDS_CAP:${estimatedNotionalUsd.toFixed(2)}>${config.maxOrderNotionalUsd}`);
  }

  try {
    normalizeSymbol(request.symbol);
  } catch {
    reasons.push("INVALID_SYMBOL");
  }

  if (reasons.length > 0) {
    return { status: "BLOCKED", reasons, orderRoute: config.liveTradingEnabled ? "LIVE" : "DISABLED" };
  }
  return { status: "READY" };
}

/**
 * Places a real Binance order. Only call this after evaluateLiveOrderGate returns READY —
 * this function re-checks the gate internally too (defense in depth), so it is safe even
 * if a caller forgets the pre-check.
 */
export async function evaluateAndPlaceLiveOrder(request: LiveOrderRequest, estimatedPriceUsd: number, config: BinanceLiveConfig = loadBinanceLiveConfig(), fetchImpl: typeof fetch = fetch): Promise<LiveOrderResult> {
  const gate = evaluateLiveOrderGate(request, config, estimatedPriceUsd);
  if (gate.status === "BLOCKED") return gate;

  const symbol = normalizeSymbol(request.symbol);
  const clientOrderId = `md90-live-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const timestamp = Date.now();
  const params = new URLSearchParams({
    symbol,
    side: request.side,
    type: "MARKET",
    quantity: request.quantity.toString(),
    newClientOrderId: clientOrderId,
    recvWindow: "5000",
    timestamp: timestamp.toString(),
  });
  const signature = signQuery(config.apiSecret as string, params.toString());
  params.set("signature", signature);

  try {
    const response = await fetchImpl(`${config.baseUrl}/api/v3/order`, {
      method: "POST",
      headers: { "X-MBX-APIKEY": config.apiKey as string, "Content-Type": "application/x-www-form-urlencoded" },
      body: params.toString(),
    });
    const body: unknown = await response.json();
    if (!response.ok) {
      const message = (body as { msg?: string })?.msg ?? `HTTP_${response.status}`;
      return { status: "ERROR", orderRoute: "LIVE", venue: "BINANCE_LIVE", binanceOrderId: null, clientOrderId, symbol, side: request.side, requestedQuantity: request.quantity, executedQuantity: 0, executedNotionalUsd: 0, rawResponse: body, errorMessage: message };
    }
    const parsed = body as { orderId?: number; executedQty?: string; cummulativeQuoteQty?: string };
    return {
      status: "FILLED",
      orderRoute: "LIVE",
      venue: "BINANCE_LIVE",
      binanceOrderId: parsed.orderId ?? null,
      clientOrderId,
      symbol,
      side: request.side,
      requestedQuantity: request.quantity,
      executedQuantity: Number(parsed.executedQty ?? 0),
      executedNotionalUsd: Number(parsed.cummulativeQuoteQty ?? 0),
      rawResponse: body,
      errorMessage: null,
    };
  } catch (error) {
    return { status: "ERROR", orderRoute: "LIVE", venue: "BINANCE_LIVE", binanceOrderId: null, clientOrderId, symbol, side: request.side, requestedQuantity: request.quantity, executedQuantity: 0, executedNotionalUsd: 0, rawResponse: null, errorMessage: error instanceof Error ? error.message : "UNKNOWN_ERROR" };
  }
}
