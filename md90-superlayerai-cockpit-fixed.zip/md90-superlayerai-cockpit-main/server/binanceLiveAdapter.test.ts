import { describe, expect, it, vi } from "vitest";
import { evaluateAndPlaceLiveOrder, evaluateLiveOrderGate, loadBinanceLiveConfig, type BinanceLiveConfig } from "./binanceLiveAdapter";

const readyConfig: BinanceLiveConfig = {
  liveTradingEnabled: true,
  killSwitchEngaged: false,
  apiKey: "test-key",
  apiSecret: "test-secret",
  maxOrderNotionalUsd: 25,
  baseUrl: "https://testnet.binance.vision",
};

describe("live order fail-closed gate", () => {
  it("blocks when LIVE_TRADING_ENABLED is not explicitly true", () => {
    const config = loadBinanceLiveConfig({} as NodeJS.ProcessEnv);
    expect(config.liveTradingEnabled).toBe(false);
    const result = evaluateLiveOrderGate({ symbol: "BTCUSDT", side: "BUY", quantity: 0.001 }, config, 20);
    expect(result.status).toBe("BLOCKED");
    if (result.status === "BLOCKED") expect(result.reasons).toContain("LIVE_TRADING_NOT_ENABLED");
  });

  it("blocks when the kill switch is engaged even with valid credentials", () => {
    const result = evaluateLiveOrderGate({ symbol: "BTCUSDT", side: "BUY", quantity: 0.001 }, { ...readyConfig, killSwitchEngaged: true }, 20);
    expect(result.status).toBe("BLOCKED");
    if (result.status === "BLOCKED") expect(result.reasons).toContain("KILL_SWITCH_ENGAGED");
  });

  it("blocks when estimated notional exceeds the hard cap", () => {
    const result = evaluateLiveOrderGate({ symbol: "BTCUSDT", side: "BUY", quantity: 10 }, readyConfig, 50_000);
    expect(result.status).toBe("BLOCKED");
    if (result.status === "BLOCKED") expect(result.reasons.some((r) => r.startsWith("NOTIONAL_EXCEEDS_CAP"))).toBe(true);
  });

  it("blocks on missing credentials", () => {
    const result = evaluateLiveOrderGate({ symbol: "BTCUSDT", side: "BUY", quantity: 0.001 }, { ...readyConfig, apiKey: null }, 20);
    expect(result.status).toBe("BLOCKED");
    if (result.status === "BLOCKED") expect(result.reasons).toContain("MISSING_API_CREDENTIALS");
  });

  it("is READY only when every condition passes", () => {
    const result = evaluateLiveOrderGate({ symbol: "BTCUSDT", side: "BUY", quantity: 0.001 }, readyConfig, 20);
    expect(result.status).toBe("READY");
  });

  it("defaults BINANCE_ENV to testnet unless mainnet is explicit", () => {
    const config = loadBinanceLiveConfig({ BINANCE_ENV: "typo-mainnet" } as NodeJS.ProcessEnv);
    expect(config.baseUrl).toBe("https://testnet.binance.vision");
  });
});

describe("live order execution (network mocked, never hits a real exchange)", () => {
  it("never calls fetch when the gate blocks", async () => {
    const fetchImpl = vi.fn();
    const result = await evaluateAndPlaceLiveOrder({ symbol: "BTCUSDT", side: "BUY", quantity: 0.001 }, 20, { ...readyConfig, killSwitchEngaged: true }, fetchImpl);
    expect(result.status).toBe("BLOCKED");
    expect(fetchImpl).not.toHaveBeenCalled();
  });

  it("signs the request and reports FILLED on a successful mocked response", async () => {
    const fetchImpl = vi.fn().mockResolvedValue({ ok: true, json: async () => ({ orderId: 123456, executedQty: "0.001", cummulativeQuoteQty: "20.15" }) });
    const result = await evaluateAndPlaceLiveOrder({ symbol: "btcusdt", side: "BUY", quantity: 0.001 }, 20, readyConfig, fetchImpl);
    expect(result.status).toBe("FILLED");
    if (result.status === "FILLED") {
      expect(result.binanceOrderId).toBe(123456);
      expect(result.symbol).toBe("BTCUSDT");
      expect(result.orderRoute).toBe("LIVE");
    }
    const [url, init] = fetchImpl.mock.calls[0];
    expect(url).toBe("https://testnet.binance.vision/api/v3/order");
    expect(init.headers["X-MBX-APIKEY"]).toBe("test-key");
    expect(String(init.body)).toContain("signature=");
  });

  it("reports ERROR (not FILLED) on a non-ok exchange response", async () => {
    const fetchImpl = vi.fn().mockResolvedValue({ ok: false, status: 400, json: async () => ({ msg: "Insufficient balance" }) });
    const result = await evaluateAndPlaceLiveOrder({ symbol: "BTCUSDT", side: "SELL", quantity: 0.001 }, 20, readyConfig, fetchImpl);
    expect(result.status).toBe("ERROR");
    if (result.status === "ERROR") expect(result.errorMessage).toBe("Insufficient balance");
  });
});
