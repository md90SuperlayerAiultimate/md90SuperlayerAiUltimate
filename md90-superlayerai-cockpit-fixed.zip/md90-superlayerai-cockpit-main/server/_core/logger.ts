/**
 * Minimal structured logger used across server/_core consumers (idempotency manager,
 * reconnection manager, websocket client, order router). Wraps console output with a
 * named prefix and ISO timestamp so log lines are attributable when several subsystems
 * run in the same process — this was a missing module referenced by several files;
 * this implementation matches the .info/.warn/.error call sites already written against it.
 */
export class Logger {
  constructor(private readonly name: string) {}

  private format(level: string, message: string): string {
    return `[${new Date().toISOString()}] [${level}] [${this.name}] ${message}`;
  }

  debug(message: string): void {
    console.debug(this.format("DEBUG", message));
  }

  info(message: string): void {
    console.log(this.format("INFO", message));
  }

  warn(message: string): void {
    console.warn(this.format("WARN", message));
  }

  error(message: string): void {
    console.error(this.format("ERROR", message));
  }
}
