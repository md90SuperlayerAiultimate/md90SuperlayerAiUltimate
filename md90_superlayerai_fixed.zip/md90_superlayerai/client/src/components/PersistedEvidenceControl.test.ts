import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("persisted evidence command center contract", () => {
  const source = readFileSync(resolve(process.cwd(), "client/src/components/PersistedEvidenceControl.tsx"), "utf8");

  it("keeps the complete evidence chain visible and sourced from persisted manifests", () => {
    expect(source).toContain("Select persisted dataset manifest");
    expect(source).toContain("EVALUATE + PERSIST PARITY");
    expect(source).toContain("RUN OOS COHORT REPLAY");
    expect(source).toContain("provenance");
    expect(source).toContain("checksum");
    expect(source).toContain("RISK GATE REQUIRED");
    expect(source).toContain("JOURNAL");
    expect(source).toContain("RUN FULL OPERATING WORKFLOW");
    expect(source).toContain("Operating workflow held by evidence gate");
    expect(source).toContain("ADAPTER COMPARISON MANIFESTS");
    expect(source).toContain("RUN EA ADAPTER COMPARISON");
    expect(source).toContain("EXPORT SIGNED JSON");
    expect(source).toContain("EXPORT SIGNED CSV");
  });

  it("does not provide default expected vectors or an execution authority", () => {
    expect(source).toContain("EVIDENCE_REQUIRED");
    expect(source).toContain("ORDER ROUTE DISABLED");
    expect(source).toContain("No persisted manifest");
    expect(source).not.toContain("expected: { macdHistogram: 0");
    expect(source).not.toContain("placeOrder");
    expect(source).not.toContain("signTransaction");
    expect(source).toContain("selectedComparisonIds");
    expect(source).toContain("SHA-256");
  });
});
