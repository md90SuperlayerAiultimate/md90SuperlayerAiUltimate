import { describe, expect, it } from "vitest";
import { buildTradingViewUrl, transitionTradingViewStatus } from "./TradingViewSurface";

describe("TradingView research surface", () => {
  it("transitions explicitly between connecting, connected, and unavailable", () => {
    expect(transitionTradingViewStatus("selection-changed")).toBe("CONNECTING");
    expect(transitionTradingViewStatus("load")).toBe("CONNECTED");
    expect(transitionTradingViewStatus("error")).toBe("UNAVAILABLE");
  });

  it("builds a read-only widget URL with selected symbol and timeframe", () => {
    const url = buildTradingViewUrl("BINANCE:BTCUSDT", "1h");
    expect(url).toContain("symbol=BINANCE%3ABTCUSDT");
    expect(url).toContain("interval=60");
    expect(url).toContain("symboledit=0");
    expect(url).not.toContain("apiKey");
    expect(url).not.toContain("order");
  });
});
