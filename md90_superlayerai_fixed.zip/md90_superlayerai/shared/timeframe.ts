export const BASE_TIMEFRAMES = ["15m", "1h", "4h", "1d"] as const;
export const HTF_TIMEFRAMES = ["same", "1h", "4h", "1d"] as const;

export type BaseTimeframe = (typeof BASE_TIMEFRAMES)[number];
export type HtfTimeframe = (typeof HTF_TIMEFRAMES)[number];
export type TimeframeSyncStatus = "SYNCED" | "MISMATCH" | "PENDING";

export type CanonicalTimeframe = {
  base: BaseTimeframe;
  htf: HtfTimeframe;
  symbol: string;
  source: "PAPER_REPLAY" | "TRADINGVIEW_WIDGET";
  timezone: "Etc/UTC";
  updatedAt: number;
};

export const canonicalTimeframe: CanonicalTimeframe = {
  base: "15m",
  htf: "4h",
  symbol: "BINANCE:BTCUSDT",
  source: "PAPER_REPLAY",
  timezone: "Etc/UTC",
  updatedAt: 0,
};

export function normalizeTimeframe(value: string): BaseTimeframe | HtfTimeframe {
  const normalized = value.trim().toLowerCase();
  if (normalized === "15" || normalized === "15m") return "15m";
  if (normalized === "60" || normalized === "1h" || normalized === "1hour") return "1h";
  if (normalized === "240" || normalized === "4h" || normalized === "4hour") return "4h";
  if (normalized === "d" || normalized === "1d" || normalized === "daily") return "1d";
  if (normalized === "same" || normalized === "chart") return "same";
  return "15m";
}

export function timeframeToTradingViewInterval(value: BaseTimeframe | HtfTimeframe): string {
  if (value === "same") return "15";
  if (value === "1d") return "D";
  return value === "15m" ? "15" : value === "1h" ? "60" : "240";
}

export function getTimeframeSyncStatus(base: BaseTimeframe, chart: BaseTimeframe | HtfTimeframe, htf: HtfTimeframe): TimeframeSyncStatus {
  if (chart === base && (htf === "same" || htf !== base)) return "SYNCED";
  return "MISMATCH";
}

export function formatTimeframe(value: BaseTimeframe | HtfTimeframe): string {
  return value === "same" ? "Same TF" : value.toUpperCase();
}
