import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({
  persistParity: vi.fn().mockResolvedValue({ status: "persisted", recordId: 17, result: { overall: "EVIDENCE_REQUIRED", checksum: "a".repeat(24) } }),
  listParity: vi.fn().mockResolvedValue([{ id: 17, ingestionId: 31, parityStatus: "EVIDENCE_REQUIRED", datasetChecksum: "a".repeat(24), provenance: "source artifact line 44" }]),
  replay: vi.fn().mockResolvedValue({ status: "persisted", runId: 22, correlationId: "replay:31", replay: { trades: 6, outOfSampleWinRatePct: 50, orderRoute: "DISABLED" } }),
  listReplay: vi.fn().mockResolvedValue([{ id: 22, ingestionId: 31, sourceChecksum: "a".repeat(24), replay: { trades: 6 } }]),
  imports: vi.fn().mockResolvedValue([{ id: 31, userId: 8801, symbol: "EURUSD", interval: "15m", source: "DUKASCOPY", barCount: 3072, checksum: "a".repeat(24), status: "READY", limitation: "SHADOW_EXTERNAL only; LONG coverage / REVIEW_READY" }]),
  operating: vi.fn().mockResolvedValue({ persisted: true, state: { stage: "AUDIT", outcome: "COMPLETED", events: [{ eventId: "e1" }], blockReasons: [], correlationId: "operating:31" } }),
  operatingBatch: vi.fn().mockResolvedValue({ status: "completed", count: 2, results: [], authority: "PAPER_SHADOW_ONLY", orderRoute: "DISABLED" }),
  adapterComparison: vi.fn().mockResolvedValue({ status: "completed", authority: "PAPER_ONLY", orderRoute: "DISABLED", results: [{ ingestionId: 31, symbol: "EURUSD", attribution: [{ strategyId: "fusion-v9-imp", sampleSize: 4, blockedWindows: 1, hitRatePct: 50, realizedPnl: 12, expectancy: 3, maxDrawdownPct: 0.2, blockedReasons: [] }] }] }),
}));
vi.mock("./parityPersistence", () => ({ evaluateAndPersistParity: mocks.persistParity, getPersistedParityVectors: mocks.listParity }));
vi.mock("./replayPersistence", () => ({ runAndPersistDatasetReplay: mocks.replay, getDatasetReplayRuns: mocks.listReplay }));
vi.mock("./operatingOrchestrator", () => ({ runOperatingWorkflow: mocks.operating, runOperatingBatch: mocks.operatingBatch }));
vi.mock("./strategyAdapterReplay", () => ({ runPersistedStrategyAdapterComparison: mocks.adapterComparison }));
vi.mock("./datasetPersistence", async () => {
  const actual = await vi.importActual<typeof import("./datasetPersistence")>("./datasetPersistence");
  return { ...actual, getExternalDatasetIngestions: mocks.imports };
});

const user = { id: 8801, openId: "uplift-user", name: "Operator", email: "operator@example.test", loginMethod: "oauth", role: "user" as const, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() };
const context = (value: TrpcContext["user"]): TrpcContext => ({ user: value, req: { protocol: "https", headers: {} } as TrpcContext["req"], res: {} as TrpcContext["res"] });

describe("significant uplift operator contracts", () => {
  it("routes one full operating command through the protected user-scoped orchestrator", async () => {
    const result = await appRouter.createCaller(context(user)).operating.run({ ingestionId: 31, baseTimeframe: "15m", higherTimeframe: "4h", idempotencyKey: "operator-31-001" });
    expect(result.state).toMatchObject({ stage: "AUDIT", outcome: "COMPLETED" });
    expect(mocks.operating).toHaveBeenCalledWith(expect.objectContaining({ userId: 8801, ingestionId: 31, idempotencyKey: "operator-31-001" }));
  });

  it("runs a bounded multi-manifest cycle with execution disabled", async () => {
    const result = await appRouter.createCaller(context(user)).operating.runBatch({ ingestionIds: [31, 32], baseTimeframe: "15m", higherTimeframe: "4h", idempotencyKey: "batch-31-001" });
    expect(result).toMatchObject({ status: "completed", count: 2, authority: "PAPER_SHADOW_ONLY", orderRoute: "DISABLED" });
    expect(mocks.operatingBatch).toHaveBeenCalledWith(expect.objectContaining({ userId: 8801, ingestionIds: [31, 32] }));
  });

  it("persists parity input and keeps it linked to the selected ingestion", async () => {
    const result = await appRouter.createCaller(context(user)).audit.persistParityVector({ ingestionId: 31, source: "Pine source line 44", provenance: "Dukascopy checksum + source formula", artifactName: "MD90_ALLIN_FIXED.pine.txt", sourceArtifactChecksum: "a".repeat(64), sourceLineRange: "L44-L58", formulaVersion: "pine-v1", expected: { vwap: 1.1 }, tolerance: 0.000001 });
    expect(result).toMatchObject({ status: "persisted", recordId: 17 });
    expect(mocks.persistParity).toHaveBeenCalledWith(expect.objectContaining({ userId: 8801, ingestionId: 31, expected: { vwap: 1.1 } }));
    await expect(appRouter.createCaller(context(user)).audit.parityVectors({ ingestionId: 31 })).resolves.toMatchObject([{ ingestionId: 31, parityStatus: "EVIDENCE_REQUIRED" }]);
  });

  it("runs a bounded persisted adapter comparison in the same user scope", async () => {
    const result = await appRouter.createCaller(context(user)).operating.adapterComparison({ ingestionIds: [31, 32], trainBars: 240, testBars: 96 });
    expect(result).toMatchObject({ status: "completed", authority: "PAPER_ONLY", orderRoute: "DISABLED" });
    expect(mocks.adapterComparison).toHaveBeenCalledWith(8801, expect.objectContaining({ ingestionIds: [31, 32] }));
  });

  it("runs the persisted dataset cohort and exposes replay history in the same user scope", async () => {
    const result = await appRouter.createCaller(context(user)).datasets.replay({ ingestionId: 31, trainBars: 240, testBars: 96 });
    expect(result).toMatchObject({ status: "persisted", runId: 22, replay: { orderRoute: "DISABLED" } });
    expect(mocks.replay).toHaveBeenCalledWith(8801, 31, expect.objectContaining({ trainBars: 240, testBars: 96 }));
    await expect(appRouter.createCaller(context(user)).datasets.replays({ ingestionId: 31 })).resolves.toMatchObject([{ ingestionId: 31, sourceChecksum: "a".repeat(24) }]);
  });

  it("reflects the persisted LONG manifest in the authenticated cockpit and rejects anonymous writes", async () => {
    const snapshot = await appRouter.createCaller(context(user)).cockpit.snapshot({ symbol: "EURUSD", timeframe: "15m", htf: "4h" });
    expect(snapshot.datasetEvidence).toMatchObject({ status: "PERSISTED_EXTERNAL", coverageBars: 3072, checksum: "a".repeat(24) });
    await expect(appRouter.createCaller(context(null)).datasets.replay({ ingestionId: 31, trainBars: 240, testBars: 96 })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
});
