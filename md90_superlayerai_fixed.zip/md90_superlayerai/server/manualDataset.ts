import { createHash } from "node:crypto";

export type ExternalHistoricalCandle = {
  openedAt: number;
  closedAt: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
};

export type ExternalHistoricalSeries = {
  venue: "DUKASCOPY_FILE" | "OPERATOR_UPLOAD";
  mode: "SHADOW_EXTERNAL";
  symbol: string;
  interval: string;
  candles: ExternalHistoricalCandle[];
  sourceTimestamp: number;
  receivedAt: number;
  checksum: string;
  freshnessSeconds: number;
  provenance: string;
  orderRoute: "DISABLED";
};

function normalizeSymbol(symbol: string) {
  const normalized = symbol.trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
  if (!/^[A-Z0-9]{5,20}$/.test(normalized)) throw new Error("Invalid external dataset symbol");
  return normalized;
}

function asNumber(value: unknown, label: string) {
  const raw = String(value ?? "").trim();
  if (!raw) throw new Error(`Invalid ${label}`);
  const number = Number(raw);
  if (!Number.isFinite(number) || number < 0) throw new Error(`Invalid ${label}`);
  return number;
}

function asTimestamp(value: unknown) {
  const raw = String(value ?? "").trim();
  const numeric = Number(raw);
  if (Number.isFinite(numeric) && numeric > 0) return numeric < 10_000_000_000 ? numeric * 1000 : numeric;
  const parsed = Date.parse(raw);
  if (!Number.isFinite(parsed)) throw new Error("Invalid candle timestamp");
  return parsed;
}

function rowValue(row: Record<string, unknown>, candidates: string[]) {
  const matched = Object.keys(row).find((key) => candidates.includes(key.trim().toLowerCase()));
  return matched ? row[matched] : undefined;
}

function parseCsv(contents: string) {
  const lines = contents.replace(/^\uFEFF/, "").split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  if (lines.length < 2) throw new Error("CSV historical dataset must include a header and at least one row");
  const headers = lines[0].split(",").map((header) => header.trim());
  return lines.slice(1).map((line) => {
    const values = line.split(",");
    if (values.length !== headers.length) throw new Error("CSV row does not match header width");
    return Object.fromEntries(headers.map((header, index) => [header, values[index]?.trim()]));
  });
}

function parseRows(contents: string, format: "CSV" | "JSON") {
  if (format === "CSV") return parseCsv(contents);
  const parsed = JSON.parse(contents) as unknown;
  if (!Array.isArray(parsed) || parsed.length === 0) throw new Error("JSON historical dataset must be a non-empty array");
  return parsed.map((item) => {
    if (!item || typeof item !== "object" || Array.isArray(item)) throw new Error("JSON candle must be an object");
    return item as Record<string, unknown>;
  });
}

function intervalMilliseconds(interval: string) {
  const values: Record<string, number> = { "1m": 60_000, "5m": 300_000, "15m": 900_000, "1h": 3_600_000, "4h": 14_400_000, "1d": 86_400_000 };
  const value = values[interval];
  if (!value) throw new Error("Unsupported manual dataset interval");
  return value;
}

export function normalizeManualHistoricalDataset(input: { contents: string; format: "CSV" | "JSON"; symbol: string; interval: string; source: "DUKASCOPY_FILE" | "OPERATOR_UPLOAD"; now?: number }) {
  const symbol = normalizeSymbol(input.symbol);
  const receivedAt = input.now ?? Date.now();
  const intervalMs = intervalMilliseconds(input.interval);
  if (input.contents.length > 6_000_000) throw new Error("Historical upload exceeds the 6 MB safety limit");
  const candles = parseRows(input.contents, input.format).map((row) => {
    const openedAt = asTimestamp(rowValue(row, ["time", "timestamp", "date", "opentime", "openedat", "etc/utc", "utc", "datetime"]));
    const closeCandidate = rowValue(row, ["closetime", "closedat", "endtime"]);
    const closedAt = closeCandidate === undefined ? openedAt + intervalMs : asTimestamp(closeCandidate);
    const open = asNumber(rowValue(row, ["open", "o"]), "open");
    const high = asNumber(rowValue(row, ["high", "h"]), "high");
    const low = asNumber(rowValue(row, ["low", "l"]), "low");
    const close = asNumber(rowValue(row, ["close", "c"]), "close");
    const volume = asNumber(rowValue(row, ["volume", "vol", "tickvolume", "tick_volume"]), "volume");
    if (closedAt <= openedAt || low > high || open < low || open > high || close < low || close > high) throw new Error("Invalid uploaded OHLC relationship");
    return { openedAt, closedAt, open, high, low, close, volume };
  }).sort((a, b) => a.openedAt - b.openedAt);
  for (let index = 1; index < candles.length; index += 1) if (candles[index - 1]!.openedAt >= candles[index]!.openedAt) throw new Error("Uploaded candles contain duplicate timestamps");
  const checksum = createHash("sha256").update(JSON.stringify(candles)).digest("hex").slice(0, 24);
  const sourceTimestamp = candles.at(-1)!.closedAt;
  const series: ExternalHistoricalSeries = {
    venue: input.source,
    mode: "SHADOW_EXTERNAL",
    symbol,
    interval: input.interval,
    candles,
    sourceTimestamp,
    receivedAt,
    checksum,
    freshnessSeconds: Math.max(0, Math.floor((receivedAt - sourceTimestamp) / 1000)),
    provenance: `${input.source} ${input.format} operator upload; source file retained in object storage; evidence-only`,
    orderRoute: "DISABLED",
  };
  return series;
}
