import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { executionBoundary } from "./botContracts";
import { evaluatePaperRisk, getPaperOverview } from "./paperEngine";
import { classifyNewsFreshness, getNewsItems, getShadowObservations } from "./shadowAdapters";
import { closeLatestPaperPosition, getPaperJournal, getPaperTimeStopReview, getPaperWorkflowEvents, getReconciliationExceptions, persistPaperOverview, persistShadowAndNews, persistPaperWorkflowEvents, transitionReconciliationException, upsertReconciliationException } from "./paperPersistence";
import { getDemoOverview, runDemoBatch } from "./demoPersistence";
import { scheduleDemoHeartbeat } from "./demoSchedule";
import { fetchBinancePublicTicker } from "./brokerMarketData";
import { fetchBinancePublicHistory } from "./publicHistory";
import { getExternalDatasetIngestions, loadPersistedDatasetForParity, persistExternalDataset } from "./datasetPersistence";
import { finishPaperCommand, getPaperCommandRun, getPaperCommandRuns, startPaperCommand } from "./commandPersistence";
import { normalizeManualHistoricalDataset } from "./manualDataset";
import { z } from "zod";
import { getInstrument } from "@shared/instruments";
import { getDatasetEvidence, listDatasetEvidence } from "@shared/datasetEvidence";
import { normalizeTimeframe } from "@shared/timeframe";
import { auditClassifications, auditStatuses, filterAuditFindings } from "@shared/auditMatrix";
import { evaluateNumericParity } from "@shared/numericParity";
import { evaluateAndPersistParity, getPersistedParityVectors } from "./parityPersistence";
import { getDatasetReplayRuns, runAndPersistDatasetReplay } from "./replayPersistence";
import { buildWorkflow } from "@shared/workflow";
import { buildPaperExecution, reconcilePaperFill } from "@shared/paperExecution";
import { runCanonicalWalkForwardReplay } from "./walkForwardReplay";
import { getEvidenceGates } from "@shared/evidenceGates";
import { runOperatingBatch, runOperatingWorkflow } from "./operatingOrchestrator";
import { getOperatingTimeline } from "./operatingPersistence";
import { runAndPersistCrossInstrumentAttribution, getCrossInstrumentAttributionReports } from "./attributionPersistence";
import { auditBundleCsv, auditBundleJson, buildAuditBundle } from "./auditBundle";
import { evaluateLearningEvidence } from "@shared/learningEvidence";
import { runPersistedStrategyAdapterComparison } from "./strategyAdapterReplay";
import { buildPersistedInstitutionalRiskReport } from "./institutionalRiskPersistence";
import { runForwardPaperSession } from "@shared/forwardPaperSession";
import { auditDatasetCoverage } from "@shared/dataCoverageAudit";
import { persistForwardPaperSession } from "./forwardPaperPersistence";
import { runDatasetReplay } from "./datasetReplay";
import { compareForwardToBacktest } from "@shared/forwardComparison";

function parseCommandPayload(payloadJson: string) {
  try {
    const value = JSON.parse(payloadJson);
    return value && typeof value === "object" && !Array.isArray(value) ? value : null;
  } catch {
    return null;
  }
}

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  cockpit: router({
    snapshot: publicProcedure.input(z.object({ timeframe: z.string().optional(), htf: z.string().optional(), symbol: z.string().optional() }).optional()).query(async ({ ctx, input }) => {
      const timeframe = input?.timeframe ?? "15m";
      const htf = input?.htf ? normalizeTimeframe(input.htf) : "4h";
      const instrument = getInstrument(input?.symbol ?? "BTCUSDT");
      const paper = getPaperOverview(timeframe);
      const observations = getShadowObservations();
      const newsItems = getNewsItems().map((item) => ({ ...item, freshness: classifyNewsFreshness(item.publishedAt) }));
      const demo = await getDemoOverview();
      const userDatasetImports = ctx.user ? await getExternalDatasetIngestions(ctx.user.id) : [];
      const persistedManifest = userDatasetImports.find((item) => item.symbol === instrument.id);
      const staticDatasetEvidence = getDatasetEvidence(instrument.id);
      const datasetEvidence = persistedManifest ? {
        ...staticDatasetEvidence,
        status: "PERSISTED_EXTERNAL" as const,
        source: persistedManifest.source,
        coverageBars: persistedManifest.barCount,
        checksum: persistedManifest.checksum,
        benchmark: "Persisted cohort replay + parity evidence",
        limitation: persistedManifest.limitation,
      } : staticDatasetEvidence;
      const unavailableBroker = { venue: instrument.venue, symbol: instrument.id, bid: 0, ask: 0, spreadBps: 0, sourceTimestamp: Date.now(), receivedAt: Date.now(), health: "UNAVAILABLE" as const, orderRoute: "DISABLED" as const };
      const broker = instrument.venue === "BINANCE_PUBLIC"
        ? await fetchBinancePublicTicker(instrument.id, fetch, Date.now(), 1_200).catch(() => unavailableBroker)
        : unavailableBroker;
      const workflowRiskChecks = instrument.paperReplay ? paper.riskChecks : [...paper.riskChecks, { label: "Paper dataset", status: "LOCKED" as const, detail: "No canonical replay dataset for selected instrument" }];
      const workflow = buildWorkflow({ instrument: instrument.label, baseTimeframe: timeframe, higherTimeframe: htf, generatedAt: paper.generatedAt, provenance: paper.provenance, dataFreshnessSeconds: paper.metrics.dataFreshnessSeconds, riskChecks: workflowRiskChecks, hasTrade: instrument.paperReplay && paper.trades.length > 0 });
      const paperPersistence = null;
      const workflowPersistence = null;
      const shadowPersistence = null;
      const freshShadowCount = observations.filter((item) => item.freshnessSeconds <= 90).length;
      const freshNewsCount = newsItems.filter((item) => classifyNewsFreshness(item.publishedAt) === "FRESH").length;
      const persistenceState = ctx.user ? "COMMAND_ONLY" as const : "AUTH_REQUIRED" as const;
      return {
        identity: ctx.user ? { authenticated: true, userId: ctx.user.id, email: ctx.user.email } : { authenticated: false },
        instrument: { id: instrument.id, label: instrument.label, tradingView: instrument.tradingView, assetClass: instrument.assetClass, paperReplay: instrument.paperReplay },
        timeframe: { base: timeframe, htf, symbol: instrument.tradingView, source: "CANONICAL_CONTEXT" },
        paper: instrument.paperReplay ? paper : null,
        paperAvailability: instrument.paperReplay ? { status: "AVAILABLE" as const, source: "PAPER_REPLAY" as const } : { status: "PENDING_DATASET" as const, source: "SHADOW_ONLY" as const, reason: "No canonical replay dataset for selected instrument" },
        shadow: { mode: "SHADOW" as const, observations, orderRoute: executionBoundary("SHADOW").orderRoute },
        news: { mode: "SHADOW" as const, items: newsItems },
        workflow,
        execution: buildPaperExecution({ correlationId: workflow.correlationId, timestamp: paper.generatedAt, allowed: workflow.decision === "PAPER_ALLOWED", hasTrade: instrument.paperReplay && paper.trades.length > 0 }),
        demo,
        walkForward: instrument.paperReplay ? runCanonicalWalkForwardReplay() : null,
        observability: {
          checkedAt: Date.now(),
          paperPersistence: ctx.user ? "COMMAND_ONLY" as const : "AUTH_REQUIRED" as const,
          shadowPersistence: ctx.user ? "COMMAND_ONLY" as const : "AUTH_REQUIRED" as const,
          workflowEvents: ctx.user ? "COMMAND_ONLY" as const : "AUTH_REQUIRED",
          shadowFreshness: `${freshShadowCount}/${observations.length}`,
          newsFreshness: `${freshNewsCount}/${newsItems.length}`,
          scheduler: demo.status === "ready" ? demo.account.scheduleCronTaskUid ? "REGISTERED" as const : "PENDING" as const : "UNAVAILABLE" as const,
          exceptions: [
            ...(freshShadowCount < observations.length ? ["STALE_SHADOW_OBSERVATION"] : []),
            ...(freshNewsCount < newsItems.length ? ["NEWS_REVIEW_OR_STALE"] : []),
            ...(instrument.paperReplay && !ctx.user ? ["AUTH_REQUIRED_FOR_PERSISTENCE"] : []),
          ],
        },
        broker,
        safety: { operationMode: "PAPER_SHADOW" as const, liveRoute: executionBoundary("LIVE").orderRoute, custody: "DISABLED" as const },
        evidenceGates: getEvidenceGates(),
        datasetEvidence,
      };
    }),
  }),
  operating: router({
    timeline: protectedProcedure.input(z.object({ symbol: z.string().max(80).optional() }).optional()).query(({ ctx, input }) => getOperatingTimeline(ctx.user.id, input?.symbol)),
    run: protectedProcedure.input(z.object({ ingestionId: z.number().int().positive(), baseTimeframe: z.string().min(1).max(16).default("15m"), higherTimeframe: z.string().min(1).max(16).default("4h"), expected: z.object({ macdHistogram: z.number().finite().nullable().optional(), obv: z.number().finite().nullable().optional(), mfi: z.number().finite().nullable().optional(), vwap: z.number().finite().nullable().optional(), bollingerWidthPct: z.number().finite().nullable().optional(), volumeRatio: z.number().finite().nullable().optional(), buyPressurePct: z.number().finite().nullable().optional() }).optional(), source: z.string().min(3).max(240).optional(), artifactName: z.string().min(3).max(160).optional(), sourceArtifactChecksum: z.string().regex(/^[a-f0-9]{64}$/i).optional(), sourceLineRange: z.string().min(1).max(80).optional(), formulaVersion: z.string().min(3).max(120).optional(), tolerance: z.number().finite().positive().max(10).optional(), idempotencyKey: z.string().min(8).max(120) })).mutation(({ ctx, input }) => runOperatingWorkflow({ userId: ctx.user.id, ...input })),
    runBatch: protectedProcedure.input(z.object({ ingestionIds: z.array(z.number().int().positive()).min(1).max(5), baseTimeframe: z.string().min(1).max(16).default("15m"), higherTimeframe: z.string().min(1).max(16).default("4h"), source: z.string().min(3).max(240).optional(), artifactName: z.string().min(3).max(160).optional(), sourceArtifactChecksum: z.string().regex(/^[a-f0-9]{64}$/i).optional(), sourceLineRange: z.string().min(1).max(80).optional(), formulaVersion: z.string().min(3).max(120).optional(), tolerance: z.number().finite().positive().max(10).optional(), idempotencyKey: z.string().min(8).max(120) })).mutation(({ ctx, input }) => runOperatingBatch({ userId: ctx.user.id, ...input })),
    attribution: protectedProcedure.input(z.object({ ingestionIds: z.array(z.number().int().positive()).min(1).max(5), trainBars: z.number().int().min(32).max(5000).default(240), testBars: z.number().int().min(8).max(1000).default(96), startingEquity: z.number().finite().positive().max(10_000_000).default(100_000), feeBps: z.number().finite().min(0).max(1000).default(10), slippageBps: z.number().finite().min(0).max(1000).default(5) })).mutation(({ ctx, input }) => runAndPersistCrossInstrumentAttribution({ userId: ctx.user.id, ...input })),
    attributionReports: protectedProcedure.query(({ ctx }) => getCrossInstrumentAttributionReports(ctx.user.id)),
    adapterComparison: protectedProcedure.input(z.object({ ingestionIds: z.array(z.number().int().positive()).min(1).max(5), trainBars: z.number().int().min(32).max(5000).default(240), testBars: z.number().int().min(8).max(1000).default(96), startingEquity: z.number().finite().positive().max(10_000_000).default(100_000), feeBps: z.number().finite().min(0).max(1000).default(10), slippageBps: z.number().finite().min(0).max(1000).default(5) })).mutation(({ ctx, input }) => runPersistedStrategyAdapterComparison(ctx.user.id, input)),
  }),
  audit: router({
    bundle: protectedProcedure.input(z.object({ format: z.enum(["json", "csv"]).default("json"), correlationId: z.string().max(160).optional(), from: z.string().datetime().optional(), to: z.string().datetime().optional() })).query(async ({ ctx, input }) => {
      const result = await buildAuditBundle(ctx.user.id, { filter: { correlationId: input.correlationId, from: input.from, to: input.to } });
      if (result.status !== "READY") return result;
      const content = input.format === "csv" ? auditBundleCsv(result.bundle) : auditBundleJson(result.bundle);
      return { status: "READY" as const, format: input.format, filename: `md90-audit-bundle-${ctx.user.id}-${result.bundle.signature.slice(0, 12)}.${input.format}`, content, signature: result.bundle.signature, filter: result.bundle.filter, authority: result.bundle.authority, orderRoute: result.bundle.orderRoute };
    }),
    matrix: protectedProcedure.input(z.object({ status: z.enum(auditStatuses).optional(), classification: z.enum(auditClassifications).optional(), artifact: z.string().max(160).optional(), checksum: z.string().max(128).optional(), search: z.string().max(160).optional() }).optional()).query(({ input }) => ({ findings: filterAuditFindings(input ?? {}), filter: input ?? {}, generatedAt: Date.now(), source: "OMNI_SOURCE_ATOMIC_REGISTER", provenance: "static-audit-register", orderRoute: "DISABLED" as const })),
    parityVector: protectedProcedure.input(z.object({ symbol: z.string().min(2).max(32), interval: z.string().min(1).max(16), source: z.string().min(3).max(240), checksum: z.string().regex(/^[a-f0-9]{64}$/i), candles: z.array(z.object({ open: z.number().finite(), high: z.number().finite(), low: z.number().finite(), close: z.number().finite(), volume: z.number().finite().optional() })).min(2).max(10_000), expected: z.object({ macdHistogram: z.number().finite().nullable().optional(), obv: z.number().finite().nullable().optional(), mfi: z.number().finite().nullable().optional(), vwap: z.number().finite().nullable().optional(), bollingerWidthPct: z.number().finite().nullable().optional(), volumeRatio: z.number().finite().nullable().optional(), buyPressurePct: z.number().finite().nullable().optional() }), tolerance: z.number().finite().positive().max(10).optional() })).query(({ input }) => evaluateNumericParity(input)),
    parityVectorFromManifest: protectedProcedure.input(z.object({ ingestionId: z.number().int().positive(), expected: z.object({ macdHistogram: z.number().finite().nullable().optional(), obv: z.number().finite().nullable().optional(), mfi: z.number().finite().nullable().optional(), vwap: z.number().finite().nullable().optional(), bollingerWidthPct: z.number().finite().nullable().optional(), volumeRatio: z.number().finite().nullable().optional(), buyPressurePct: z.number().finite().nullable().optional() }), tolerance: z.number().finite().positive().max(10).optional() })).query(async ({ ctx, input }) => {
      const loaded = await loadPersistedDatasetForParity(ctx.user.id, input.ingestionId);
      if (loaded.status !== "READY") return { status: loaded.status, reason: loaded.reason, authority: "READ_ONLY" as const, oosGate: "PENDING" as const, executionAuthority: "DISABLED" as const };
      return evaluateNumericParity({ symbol: loaded.series.symbol!, interval: loaded.series.interval!, source: loaded.series.venue!, checksum: loaded.series.checksum!, candles: loaded.series.candles!, expected: input.expected, tolerance: input.tolerance });
    }),
    persistParityVector: protectedProcedure.input(z.object({ ingestionId: z.number().int().positive(), source: z.string().min(3).max(240), provenance: z.string().min(3).max(300), artifactName: z.string().min(3).max(160), sourceArtifactChecksum: z.string().regex(/^[a-f0-9]{64}$/i), sourceLineRange: z.string().min(1).max(80), formulaVersion: z.string().min(3).max(120), expected: z.object({ macdHistogram: z.number().finite().nullable().optional(), obv: z.number().finite().nullable().optional(), mfi: z.number().finite().nullable().optional(), vwap: z.number().finite().nullable().optional(), bollingerWidthPct: z.number().finite().nullable().optional(), volumeRatio: z.number().finite().nullable().optional(), buyPressurePct: z.number().finite().nullable().optional() }), tolerance: z.number().finite().positive().max(10).optional() })).mutation(({ ctx, input }) => evaluateAndPersistParity({ userId: ctx.user.id, ...input })),
    parityVectors: protectedProcedure.input(z.object({ ingestionId: z.number().int().positive().optional() }).optional()).query(({ ctx, input }) => getPersistedParityVectors(ctx.user.id, input?.ingestionId)),
  }),
  datasets: router({
    evidence: publicProcedure.query(() => listDatasetEvidence()),
    imports: protectedProcedure.query(({ ctx }) => getExternalDatasetIngestions(ctx.user.id)),
    replays: protectedProcedure.input(z.object({ ingestionId: z.number().int().positive().optional() }).optional()).query(({ ctx, input }) => getDatasetReplayRuns(ctx.user.id, input?.ingestionId)),
    replay: protectedProcedure.input(z.object({ ingestionId: z.number().int().positive(), trainBars: z.number().int().min(32).max(5000).default(240), testBars: z.number().int().min(8).max(1000).default(96), startingEquity: z.number().finite().positive().max(10_000_000).default(100_000), feeBps: z.number().finite().min(0).max(1000).default(10), slippageBps: z.number().finite().min(0).max(1000).default(5) })).mutation(({ ctx, input }) => runAndPersistDatasetReplay(ctx.user.id, input.ingestionId, input)),
    ingest: protectedProcedure.input(z.object({ symbol: z.string().default("BTCUSDT"), interval: z.enum(["1m", "5m", "15m", "1h", "4h", "1d"]).default("15m"), limit: z.number().int().min(10).max(300).default(120) })).mutation(async ({ ctx, input }) => {
      const instrument = getInstrument(input.symbol);
      if (instrument.assetClass !== "CRYPTO") return { status: "blocked" as const, reason: "External ingestion is not certified for this instrument; no crypto fallback is applied.", symbol: instrument.id };
      const correlationId = `dataset:${instrument.id}:${input.interval}:${Math.floor(Date.now() / 60_000)}`;
      await startPaperCommand(ctx.user.id, "DATASET_INGEST", correlationId, input);
      try {
        const series = await fetchBinancePublicHistory(instrument.id, input.interval, input.limit);
        const persisted = await persistExternalDataset(ctx.user.id, series);
        const result = { status: "ingested" as const, correlationId, series: { symbol: series.symbol, interval: series.interval, checksum: series.checksum, barCount: series.candles.length, freshnessSeconds: series.freshnessSeconds, orderRoute: series.orderRoute }, persisted };
        await finishPaperCommand(ctx.user.id, "DATASET_INGEST", correlationId, "SUCCEEDED", result);
        return result;
      } catch (error) {
        const message = error instanceof Error ? error.message : "Dataset ingest failed";
        await finishPaperCommand(ctx.user.id, "DATASET_INGEST", correlationId, "FAILED", { input }, message);
        throw error;
      }
    }),
    ingestManual: protectedProcedure.input(z.object({ symbol: z.enum(["EURUSD", "XAUUSD"]), interval: z.enum(["1m", "5m", "15m", "1h", "4h", "1d"]).default("15m"), format: z.enum(["CSV", "JSON"]), source: z.enum(["DUKASCOPY_FILE", "OPERATOR_UPLOAD"]), contents: z.string().min(20).max(6_000_000) })).mutation(async ({ ctx, input }) => {
      const correlationId = `dataset-manual:${input.symbol}:${input.interval}:${Math.floor(Date.now() / 60_000)}`;
      await startPaperCommand(ctx.user.id, "DATASET_INGEST", correlationId, { symbol: input.symbol, interval: input.interval, format: input.format, source: input.source });
      try {
        const series = normalizeManualHistoricalDataset(input);
        const persisted = await persistExternalDataset(ctx.user.id, series);
        const result = { status: "ingested" as const, correlationId, series: { symbol: series.symbol, interval: series.interval, checksum: series.checksum, barCount: series.candles.length, freshnessSeconds: series.freshnessSeconds, orderRoute: series.orderRoute, source: series.venue }, persisted };
        await finishPaperCommand(ctx.user.id, "DATASET_INGEST", correlationId, "SUCCEEDED", result);
        return result;
      } catch (error) {
        const message = error instanceof Error ? error.message : "Manual dataset ingest failed";
        await finishPaperCommand(ctx.user.id, "DATASET_INGEST", correlationId, "FAILED", { symbol: input.symbol, interval: input.interval, format: input.format, source: input.source }, message);
        throw error;
      }
    }),
  }),
  risk: router({
    institutional: protectedProcedure.input(z.object({ ingestionIds: z.array(z.number().int().positive()).min(1).max(5) })).query(({ ctx, input }) => buildPersistedInstitutionalRiskReport(ctx.user.id, input.ingestionIds)),
  }),
  paper: router({
    sync: protectedProcedure.input(z.object({ timeframe: z.string().optional(), htf: z.string().optional(), symbol: z.string().optional() }).optional()).mutation(async ({ ctx, input }) => {
      const timeframe = input?.timeframe ?? "15m";
      const htf = input?.htf ? normalizeTimeframe(input.htf) : "4h";
      const instrument = getInstrument(input?.symbol ?? "BTCUSDT");
      if (!instrument.paperReplay) return { status: "blocked" as const, reason: "No canonical replay dataset for selected instrument; sync paused." };
      const overview = getPaperOverview(timeframe);
      const observations = getShadowObservations();
      const news = getNewsItems().map((item) => ({ ...item, freshness: classifyNewsFreshness(item.publishedAt) }));
      const workflow = buildWorkflow({ instrument: instrument.label, baseTimeframe: timeframe, higherTimeframe: htf, generatedAt: overview.generatedAt, provenance: overview.provenance, dataFreshnessSeconds: overview.metrics.dataFreshnessSeconds, riskChecks: overview.riskChecks, hasTrade: overview.trades.length > 0 });
      await startPaperCommand(ctx.user.id, "SYNC", workflow.correlationId, { timeframe, htf, instrument: instrument.id });
      try {
        const persisted = await persistPaperOverview(ctx.user.id, overview);
        const events = persisted.persisted ? await persistPaperWorkflowEvents(ctx.user.id, overview, workflow.correlationId) : null;
        const shadow = await persistShadowAndNews(observations, news);
        const stale = observations.some((item) => item.freshnessSeconds > 90) ? await upsertReconciliationException(ctx.user.id, overview, { exceptionKey: `shadow-stale:${instrument.id}`, correlationId: workflow.correlationId, instrument: instrument.id, category: "STALE_SHADOW", severity: "MEDIUM", expectedState: "FRESH", observedState: "STALE", detail: "One or more shadow observations exceeded the 90 second freshness policy.", lastSeenAt: new Date() }) : null;
        const result = { status: "synced" as const, correlationId: workflow.correlationId, persisted, events, shadow, stale };
        await finishPaperCommand(ctx.user.id, "SYNC", workflow.correlationId, "SUCCEEDED", result);
        return result;
      } catch (error) {
        const message = error instanceof Error ? error.message : "Paper sync failed";
        await finishPaperCommand(ctx.user.id, "SYNC", workflow.correlationId, "FAILED", { timeframe, htf, instrument: instrument.id }, message);
        throw error;
      }
    }),
    overview: publicProcedure.input(z.object({ timeframe: z.string().optional() }).optional()).query(({ input }) => getPaperOverview(input?.timeframe ?? "15m")),
    ingest: protectedProcedure.mutation(async ({ ctx }) => {
      const overview = getPaperOverview();
      return persistPaperOverview(ctx.user.id, overview);
    }),
    journal: protectedProcedure.query(({ ctx }) => getPaperJournal(ctx.user.id)),
    timeStop: protectedProcedure.input(z.object({ symbol: z.string().default("BTCUSDT") })).query(async ({ ctx, input }) => {
      const instrument = getInstrument(input.symbol);
      if (!instrument.paperReplay) return { status: "blocked" as const, reason: "No canonical replay position for selected instrument; time-stop review paused." as const };
      return await getPaperTimeStopReview(ctx.user.id, instrument.label);
    }),
    learning: protectedProcedure.query(async ({ ctx }) => evaluateLearningEvidence(await getPaperJournal(ctx.user.id))),
    commands: protectedProcedure.query(({ ctx }) => getPaperCommandRuns(ctx.user.id)),
    retry: protectedProcedure.input(z.object({ commandRunId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const record = await getPaperCommandRun(ctx.user.id, input.commandRunId);
      if (!record) return { status: "blocked" as const, reason: "Command run not found in this user scope." };
      if (record.state !== "FAILED" && record.state !== "BLOCKED") return { status: "blocked" as const, reason: "Only FAILED or BLOCKED command runs can be retried." };
      if (!(["SYNC", "DECIDE", "RECONCILIATION"] as readonly string[]).includes(record.commandType)) return { status: "blocked" as const, reason: `${record.commandType} retry is disabled. Create a new protected command instead.` };
      const payload = parseCommandPayload(record.payloadJson);
      if (!payload) return { status: "blocked" as const, reason: "Stored payload is malformed and cannot be safely replayed." };
      const retryType = record.commandType as "SYNC" | "DECIDE" | "RECONCILIATION";
      await startPaperCommand(ctx.user.id, retryType, record.correlationId, payload);
      try {
        const caller = appRouter.createCaller(ctx);
        let result: unknown;
        if (record.commandType === "SYNC") {
          const safe = z.object({ timeframe: z.string().optional(), htf: z.string().optional(), symbol: z.string().optional(), instrument: z.string().optional() }).safeParse(payload);
          if (!safe.success) throw new Error("Stored SYNC payload does not match the retry schema");
          result = await caller.paper.sync({ timeframe: safe.data.timeframe, htf: safe.data.htf, symbol: safe.data.symbol ?? safe.data.instrument });
        } else if (record.commandType === "DECIDE") {
          const safe = z.object({ timeframe: z.string().optional(), htf: z.string().optional(), symbol: z.string().optional(), riskPct: z.number().min(0.5).max(1) }).safeParse(payload);
          if (!safe.success) throw new Error("Stored DECIDE payload does not match the retry schema");
          result = await caller.paper.decide(safe.data);
        } else {
          const safe = z.object({ exceptionId: z.number().int().positive(), state: z.enum(["ACKNOWLEDGED", "RESOLVED"]), resolutionNote: z.string().max(500).optional() }).safeParse(payload);
          if (!safe.success) throw new Error("Stored RECONCILIATION payload does not match the retry schema");
          result = await caller.paper.reconciliation.transition(safe.data);
        }
        const blocked = typeof result === "object" && result !== null && "status" in result && (result as { status?: string }).status === "blocked";
        await finishPaperCommand(ctx.user.id, retryType, record.correlationId, blocked ? "BLOCKED" : "SUCCEEDED", { retry: true, result }, blocked ? "Retry completed without a PAPER state transition" : undefined);
        return { status: "retried" as const, commandRunId: record.id, commandType: retryType, result };
      } catch (error) {
        const message = error instanceof Error ? error.message : "Paper command retry failed";
        await finishPaperCommand(ctx.user.id, retryType, record.correlationId, "FAILED", { retry: true }, message);
        throw error;
      }
    }),
    workflowEvents: protectedProcedure.input(z.object({ correlationId: z.string().max(160).optional() }).optional()).query(({ ctx, input }) => getPaperWorkflowEvents(ctx.user.id, input?.correlationId)),
    reconciliation: router({
      exceptions: protectedProcedure.input(z.object({ state: z.enum(["OPEN", "ACKNOWLEDGED", "RESOLVED"]).optional() }).optional()).query(({ ctx, input }) => getReconciliationExceptions(ctx.user.id, input?.state)),
      transition: protectedProcedure.input(z.object({ exceptionId: z.number().int().positive(), state: z.enum(["ACKNOWLEDGED", "RESOLVED"]), resolutionNote: z.string().max(500).optional() })).mutation(async ({ ctx, input }) => {
        const correlationId = `reconciliation:${input.exceptionId}:${input.state}:${Math.floor(Date.now() / 60_000)}`;
        await startPaperCommand(ctx.user.id, "RECONCILIATION", correlationId, input);
        try {
          const result = await transitionReconciliationException(ctx.user.id, input.exceptionId, input.state, input.resolutionNote);
          await finishPaperCommand(ctx.user.id, "RECONCILIATION", correlationId, result.updated ? "SUCCEEDED" : "BLOCKED", result, result.updated ? undefined : "Reconciliation transition was not applied");
          return result;
        } catch (error) {
          const message = error instanceof Error ? error.message : "Reconciliation transition failed";
          await finishPaperCommand(ctx.user.id, "RECONCILIATION", correlationId, "FAILED", input, message);
          throw error;
        }
      }),
    }),
    forwardRun: protectedProcedure.input(z.object({ ingestionId: z.number().int().positive(), lookbackBars: z.number().int().min(2).max(500).default(20), maxHoldingBars: z.number().int().min(1).max(500).default(10), startingEquity: z.number().finite().positive().max(10_000_000).default(100_000), riskFraction: z.number().finite().min(0.005).max(0.01).default(0.005), feeBps: z.number().finite().min(0).max(1000).default(10), slippageBps: z.number().finite().min(0).max(1000).default(5), spreadBps: z.number().finite().min(0).max(1000).default(2) })).mutation(async ({ ctx, input }) => {
      const loaded = await loadPersistedDatasetForParity(ctx.user.id, input.ingestionId);
      if (loaded.status !== "READY") return { status: "blocked" as const, reason: loaded.reason, executionAuthority: "PAPER_ONLY" as const, orderRoute: "DISABLED" as const };
      const series = loaded.series;
      const coverage = auditDatasetCoverage(series.candles ?? []);
      if (coverage.status === "BLOCKED") return { status: "blocked" as const, reason: coverage.reasons.join(", "), coverage, executionAuthority: "PAPER_ONLY" as const, orderRoute: "DISABLED" as const };
      const result = runForwardPaperSession(series.candles ?? [], { symbol: series.symbol ?? loaded.manifest.symbol, venue: series.venue ?? loaded.manifest.source, lookbackBars: input.lookbackBars, maxHoldingBars: input.maxHoldingBars, startingEquity: input.startingEquity, riskFraction: input.riskFraction, feeBps: input.feeBps, slippageBps: input.slippageBps, spreadBps: input.spreadBps });
      const correlationId = `forward:${series.symbol ?? loaded.manifest.symbol}:${loaded.manifest.checksum}:${Math.floor(Date.now() / 60_000)}`;
      const backtest = runDatasetReplay(series.candles ?? [], { trainBars: Math.min(240, Math.max(32, Math.floor((series.candles?.length ?? 32) / 3))), testBars: Math.min(96, Math.max(8, Math.floor((series.candles?.length ?? 8) / 12))), startingEquity: input.startingEquity, feeBps: input.feeBps, slippageBps: input.slippageBps });
      const comparison = compareForwardToBacktest({ symbol: series.symbol ?? loaded.manifest.symbol, interval: series.interval ?? loaded.manifest.interval, manifestChecksum: loaded.manifest.checksum, backtest: { trades: backtest.trades, winRatePct: backtest.outOfSampleWinRatePct, realizedPnl: backtest.realizedPnl, expectancy: backtest.expectancy, maxDrawdownPct: backtest.maxDrawdownPct }, forward: { trades: result.fills, winRatePct: result.fills ? Number((result.events.filter((event) => event.type === "JOURNAL" && Number(event.payload.realizedPnl ?? 0) > 0).length / result.fills * 100).toFixed(2)) : 0, realizedPnl: result.realizedPnl, expectancy: result.fills ? Number((result.realizedPnl / result.fills).toFixed(4)) : 0, maxDrawdownPct: result.maxDrawdownPct } });
      const persisted = await persistForwardPaperSession(ctx.user.id, result, `manifest:${loaded.manifest.id}:${loaded.manifest.checksum}`, correlationId, comparison);
      return { status: result.status === "BLOCKED" ? "blocked" as const : "completed" as const, correlationId, manifest: { id: loaded.manifest.id, symbol: loaded.manifest.symbol, interval: loaded.manifest.interval, checksum: loaded.manifest.checksum, barCount: loaded.manifest.barCount }, coverage, result, backtest, comparison, persisted };
    }),
    replay: publicProcedure.input(z.object({ symbol: z.string().default("BTCUSDT"), trainBars: z.number().int().min(4).max(12).default(8), testBars: z.number().int().min(2).max(8).default(4) })).query(({ input }) => {
      if (input.symbol !== "BTCUSDT") return { status: "blocked" as const, reason: "Canonical OOS replay is not certified for this instrument; no BTC fallback is applied." };
      return { status: "ready" as const, replay: runCanonicalWalkForwardReplay(input.trainBars, input.testBars) };
    }),
    decide: protectedProcedure.input(z.object({ timeframe: z.string().optional(), htf: z.string().optional(), symbol: z.string().optional(), riskPct: z.number().min(0.5).max(1) })).mutation(async ({ ctx, input }) => {
      const instrument = getInstrument(input.symbol ?? "BTCUSDT");
      if (!instrument.paperReplay) return { status: "blocked" as const, reason: "No canonical replay dataset for selected instrument; paper decision paused." };
      const overview = getPaperOverview(input.timeframe ?? "15m");
      const correlation = `paper:${instrument.id}:${input.timeframe ?? "15m"}:${input.htf ?? "4h"}:${Math.floor(Date.now() / 60_000)}`;
      const riskDecision = evaluatePaperRisk({ dailyLossPct: 0, grossExposurePct: overview.metrics.grossExposurePct, drawdownPct: Math.abs(overview.metrics.peakDrawdownPct), dataFreshnessSeconds: overview.metrics.dataFreshnessSeconds, riskPct: input.riskPct });
      if (!riskDecision.approved) {
        const blockedExecution = buildPaperExecution({ correlationId: correlation, timestamp: overview.generatedAt, allowed: false, hasTrade: false });
        return { status: "blocked" as const, reason: "Paper risk gate did not approve this decision.", correlation, riskPct: input.riskPct, riskDecision, execution: blockedExecution };
      }
      await startPaperCommand(ctx.user.id, "DECIDE", correlation, input);
      try {
        const persisted = await persistPaperOverview(ctx.user.id, overview);
        const workflowEvents = await persistPaperWorkflowEvents(ctx.user.id, overview, correlation);
        const execution = buildPaperExecution({ correlationId: correlation, timestamp: overview.generatedAt, allowed: riskDecision.approved, hasTrade: overview.trades.length > 0 });
        const fillReconciliation = overview.trades[0] ? reconcilePaperFill(overview.trades[0].quantity, overview.trades[0].quantity) : null;
        const exception = fillReconciliation && fillReconciliation.status === "EXCEPTION" ? await upsertReconciliationException(ctx.user.id, overview, { exceptionKey: `${fillReconciliation.category.toLowerCase()}:${correlation}`, correlationId: correlation, instrument: instrument.id, category: fillReconciliation.category, severity: fillReconciliation.category === "INVALID_QUANTITY" ? "HIGH" : "LOW", expectedState: "RECONCILED", observedState: fillReconciliation.category, detail: fillReconciliation.detail, lastSeenAt: new Date() }) : null;
        const result = { status: "recorded" as const, correlation, riskPct: input.riskPct, persisted, workflowEvents, execution, fillReconciliation, exception };
        await finishPaperCommand(ctx.user.id, "DECIDE", correlation, "SUCCEEDED", result);
        return result;
      } catch (error) {
        const message = error instanceof Error ? error.message : "Paper decision failed";
        await finishPaperCommand(ctx.user.id, "DECIDE", correlation, "FAILED", { input, riskDecision }, message);
        throw error;
      }
    }),
    close: protectedProcedure.input(z.object({ timeframe: z.string().optional(), symbol: z.string().optional(), reason: z.enum(["RISK_REDUCTION", "TIME_STOP", "OPERATOR_REVIEW"]).default("OPERATOR_REVIEW") })).mutation(async ({ ctx, input }) => {
      const instrument = getInstrument(input.symbol ?? "BTCUSDT");
      if (!instrument.paperReplay) return { status: "blocked" as const, reason: "No canonical replay dataset for selected instrument; close command paused." };
      const overview = getPaperOverview(input.timeframe ?? "15m");
      const correlationId = `paper-close:${instrument.id}:${input.reason}:${Math.floor(Date.now() / 60_000)}`;
      await startPaperCommand(ctx.user.id, "CLOSE", correlationId, input);
      try {
        const result = await closeLatestPaperPosition(ctx.user.id, overview, { correlationId, instrument: overview.primary.market, reason: input.reason });
        await finishPaperCommand(ctx.user.id, "CLOSE", correlationId, result.status === "closed" || result.status === "already-closed" ? "SUCCEEDED" : "BLOCKED", result, result.status === "blocked" ? result.reason : undefined);
        return result;
      } catch (error) {
        const message = error instanceof Error ? error.message : "Paper close failed";
        await finishPaperCommand(ctx.user.id, "CLOSE", correlationId, "FAILED", input, message);
        throw error;
      }
    }),
  }),
  shadow: router({
    observations: publicProcedure.query(async ({ ctx }) => {
      const observations = getShadowObservations();
      if (ctx.user) await persistShadowAndNews(observations, []);
      return { mode: "SHADOW" as const, observations, orderRoute: executionBoundary("SHADOW").orderRoute };
    }),
  }),
  demo: router({
    overview: publicProcedure.query(() => getDemoOverview()),
    runBatch: publicProcedure.mutation(() => runDemoBatch()),
    schedule: protectedProcedure.mutation(({ ctx }) => scheduleDemoHeartbeat(ctx.req.headers.cookie)),
  }),
  broker: router({
    publicTicker: publicProcedure.query(() => fetchBinancePublicTicker("BTCUSDT")),
  }),
  market: router({
    history: publicProcedure.input(z.object({ symbol: z.string().default("BTCUSDT"), interval: z.enum(["1m", "5m", "15m", "1h", "4h", "1d"]).default("15m"), limit: z.number().int().min(10).max(300).default(120) })).query(async ({ input }) => {
      const instrument = getInstrument(input.symbol);
      if (instrument.assetClass !== "CRYPTO") return { status: "blocked" as const, reason: "Independent public history is not certified for this instrument; no crypto fallback is applied.", symbol: instrument.id };
      const series = await fetchBinancePublicHistory(instrument.id, input.interval, input.limit);
      return { status: "ready" as const, series };
    }),
  }),
  intel: router({
    news: publicProcedure.query(async ({ ctx }) => {
      const items = getNewsItems().map((item) => ({ ...item, freshness: classifyNewsFreshness(item.publishedAt) }));
      if (ctx.user) await persistShadowAndNews([], items);
      return { mode: "SHADOW" as const, items };
    }),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
